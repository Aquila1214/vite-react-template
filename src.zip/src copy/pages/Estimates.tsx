import React, { useEffect, useState } from 'react';
import { useCrmStore } from '../stores/crmStore';
import { Plus, Search, FileText, DollarSign, CheckCircle, XCircle, Eye, Edit, Trash2, Filter, Calendar, User } from 'lucide-react';
import { Estimate } from '../types';
import { formatDate, formatCurrency, getStatusColor } from '../lib/utils';
import { EstimateModal } from '../components/Estimates/EstimateModal';
import { EstimateDetailModal } from '../components/Estimates/EstimateDetailModal';

export function Estimates() {
  const { 
    estimates, 
    customers,
    isLoading, 
    error, 
    fetchEstimates,
    fetchCustomers,
    createEstimate,
    updateEstimate,
    deleteEstimate
  } = useCrmStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [dateFilter, setDateFilter] = useState('');
  const [amountFilter, setAmountFilter] = useState('');
  const [selectedEstimate, setSelectedEstimate] = useState<Estimate | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isEstimateModalOpen, setIsEstimateModalOpen] = useState(false);

  useEffect(() => {
    fetchEstimates();
    fetchCustomers();
  }, [fetchEstimates, fetchCustomers]);

  const filteredEstimates = estimates.filter(estimate => {
    const matchesSearch = 
      estimate.total.toString().includes(searchTerm) ||
      estimate.lineItems.some(item => 
        item.description.toLowerCase().includes(searchTerm.toLowerCase())
      ) ||
      (customers.find(c => c.id === estimate.customerId)?.name || '').toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = !statusFilter || 
      (statusFilter === 'accepted' && estimate.accepted) ||
      (statusFilter === 'pending' && !estimate.accepted);
    
    // Date filter
    let matchesDate = true;
    if (dateFilter === 'last30days') {
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      matchesDate = new Date(estimate.createdAt) >= thirtyDaysAgo;
    } else if (dateFilter === 'last90days') {
      const ninetyDaysAgo = new Date();
      ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
      matchesDate = new Date(estimate.createdAt) >= ninetyDaysAgo;
    } else if (dateFilter === 'thisYear') {
      const thisYear = new Date().getFullYear();
      matchesDate = new Date(estimate.createdAt).getFullYear() === thisYear;
    }

    // Amount filter
    let matchesAmount = true;
    if (amountFilter === 'under1000') {
      matchesAmount = estimate.total < 1000;
    } else if (amountFilter === '1000to5000') {
      matchesAmount = estimate.total >= 1000 && estimate.total <= 5000;
    } else if (amountFilter === 'over5000') {
      matchesAmount = estimate.total > 5000;
    }
    
    return matchesSearch && matchesStatus && matchesDate && matchesAmount;
  });

  // Calculate key metrics
  const totalEstimatesValue = estimates.reduce((sum, est) => sum + est.total, 0);
  const pendingEstimatesValue = estimates
    .filter(est => !est.accepted)
    .reduce((sum, est) => sum + est.total, 0);
  const acceptedEstimatesValue = estimates
    .filter(est => est.accepted)
    .reduce((sum, est) => sum + est.total, 0);
  const conversionRate = estimates.length > 0
    ? (estimates.filter(est => est.accepted).length / estimates.length) * 100
    : 0;

  const getCustomerName = (customerId: string) => {
    const customer = customers.find(c => c.id === customerId);
    return customer ? customer.name : 'Unknown Customer';
  };

  const handleViewEstimate = (estimate: Estimate) => {
    setSelectedEstimate(estimate);
    setIsDetailModalOpen(true);
  };

  const handleEditEstimate = (estimate: Estimate) => {
    setSelectedEstimate(estimate);
    setIsEstimateModalOpen(true);
  };

  const handleCreateEstimate = () => {
    setSelectedEstimate(null);
    setIsEstimateModalOpen(true);
  };

  const handleDeleteEstimate = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this estimate? This action cannot be undone.')) {
      try {
        await deleteEstimate(id);
      } catch (error) {
        console.error('Failed to delete estimate:', error);
      }
    }
  };

  const handleSaveEstimate = async (estimateData: Partial<Estimate>) => {
    try {
      if (selectedEstimate) {
        await updateEstimate(selectedEstimate.id, estimateData);
      } else {
        await createEstimate(estimateData);
      }
    } catch (error) {
      console.error('Failed to save estimate:', error);
    }
  };

  if (error) {
    return (
      <div className="rounded-md bg-red-50 p-4">
        <div className="text-sm text-red-700">{error}</div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="h-10 bg-gray-200 rounded animate-pulse"></div>
        {[...Array(5)].map((_, i) => (
          <div key={i} className="h-20 bg-gray-200 rounded animate-pulse"></div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Estimates</h1>
          <p className="text-gray-600">Create and manage project estimates</p>
        </div>
        
        <button 
          onClick={handleCreateEstimate}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="h-4 w-4 mr-2" />
          New Estimate
        </button>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Estimates Value</p>
              <p className="text-2xl font-bold text-gray-900">{formatCurrency(totalEstimatesValue)}</p>
            </div>
            <div className="p-3 bg-blue-50 rounded-full">
              <FileText className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Pending Estimates</p>
              <p className="text-2xl font-bold text-amber-600">{formatCurrency(pendingEstimatesValue)}</p>
            </div>
            <div className="p-3 bg-amber-50 rounded-full">
              <XCircle className="h-6 w-6 text-amber-600" />
            </div>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Accepted Estimates</p>
              <p className="text-2xl font-bold text-green-600">{formatCurrency(acceptedEstimatesValue)}</p>
            </div>
            <div className="p-3 bg-green-50 rounded-full">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Conversion Rate</p>
              <p className="text-2xl font-bold text-purple-600">{conversionRate.toFixed(1)}%</p>
            </div>
            <div className="p-3 bg-purple-50 rounded-full">
              <DollarSign className="h-6 w-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search estimates by customer, amount, or description..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="flex flex-wrap gap-4">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">All Status</option>
              <option value="pending">Pending</option>
              <option value="accepted">Accepted</option>
            </select>
            
            <select
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">All Dates</option>
              <option value="last30days">Last 30 Days</option>
              <option value="last90days">Last 90 Days</option>
              <option value="thisYear">This Year</option>
            </select>
            
            <select
              value={amountFilter}
              onChange={(e) => setAmountFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">All Amounts</option>
              <option value="under1000">Under $1,000</option>
              <option value="1000to5000">$1,000 - $5,000</option>
              <option value="over5000">Over $5,000</option>
            </select>
          </div>
        </div>
      </div>

      {/* Estimates Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredEstimates.map((estimate) => (
          <div key={estimate.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <FileText className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    Estimate #{estimate.id.slice(-6)}
                  </h3>
                  <p className="text-sm text-gray-500">
                    {getCustomerName(estimate.customerId)}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                {estimate.accepted ? (
                  <CheckCircle className="h-5 w-5 text-green-600" />
                ) : (
                  <XCircle className="h-5 w-5 text-gray-400" />
                )}
                <span className={`text-sm font-medium ${estimate.accepted ? 'text-green-600' : 'text-gray-500'}`}>
                  {estimate.accepted ? 'Accepted' : 'Pending'}
                </span>
              </div>
            </div>
            
            <div className="space-y-3 mb-4">
              <div className="flex items-center justify-between">
                <span className="text-2xl font-bold text-gray-900">
                  {formatCurrency(estimate.total)}
                </span>
                <span className="text-sm text-gray-500">
                  {estimate.lineItems.length} line items
                </span>
              </div>
              
              <div className="space-y-2">
                {estimate.lineItems.slice(0, 2).map((item) => (
                  <div key={item.id} className="flex justify-between text-sm">
                    <span className="text-gray-600">{item.description}</span>
                    <span className="font-medium">{formatCurrency(item.total)}</span>
                  </div>
                ))}
                {estimate.lineItems.length > 2 && (
                  <div className="text-sm text-gray-500">
                    +{estimate.lineItems.length - 2} more items
                  </div>
                )}
              </div>
            </div>
            
            <div className="flex items-center justify-between pt-4 border-t border-gray-100">
              <div className="text-sm text-gray-500">
                Created {formatDate(estimate.createdAt)}
                {estimate.expirationDate && (
                  <div>Expires {formatDate(estimate.expirationDate)}</div>
                )}
              </div>
              
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => handleViewEstimate(estimate)}
                  className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                  title="View"
                >
                  <Eye className="h-4 w-4" />
                </button>
                <button
                  onClick={() => handleEditEstimate(estimate)}
                  className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                  title="Edit"
                >
                  <Edit className="h-4 w-4" />
                </button>
                <button
                  onClick={() => handleDeleteEstimate(estimate.id)}
                  className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                  title="Delete"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {filteredEstimates.length === 0 && (
        <div className="text-center py-12">
          <FileText className="h-8 w-8 mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500">
            {estimates.length === 0 ? 'No estimates found. Create your first estimate!' : 'No estimates match your search criteria.'}
          </p>
          {estimates.length === 0 && (
            <button 
              onClick={handleCreateEstimate}
              className="mt-4 inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Estimate
            </button>
          )}
        </div>
      )}

      {/* Estimate Detail Modal */}
      <EstimateDetailModal
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        estimate={selectedEstimate}
        onEdit={handleEditEstimate}
      />

      {/* Estimate Create/Edit Modal */}
      <EstimateModal
        isOpen={isEstimateModalOpen}
        onClose={() => setIsEstimateModalOpen(false)}
        onSave={handleSaveEstimate}
        estimate={selectedEstimate}
        isLoading={isLoading}
      />
    </div>
  );
}