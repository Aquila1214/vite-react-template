import React, { useEffect } from 'react';
import { useCrmStore } from '../stores/crmStore';
import { ModularDashboard } from '../components/Dashboard/ModularDashboard';

export function Dashboard() {
  const { 
    dashboardStats, 
    pipeline, 
    recentActivity, 
    isLoading, 
    error, 
    fetchDashboardStats 
  } = useCrmStore();

  useEffect(() => {
    fetchDashboardStats();
  }, [fetchDashboardStats]);

  if (error) {
    return (
      <div className="rounded-md bg-red-50 p-4">
        <div className="text-sm text-red-700">{error}</div>
      </div>
    );
  }

  return (
    <ModularDashboard />
  );
}