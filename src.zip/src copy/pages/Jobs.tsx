import React, { useState, useEffect } from 'react';
import { useCrmStore } from '../stores/crmStore';
import { useAuthStore } from '../stores/authStore';
import { 
  Plus, Filter, Search, Calendar, User, MapPin, Eye, Edit, Trash2, 
  List, Columns, ChevronDown, Tag, Clock, CheckCircle, XCircle, 
  AlertTriangle, Briefcase, ArrowRight
} from 'lucide-react';
import { formatDate, getStatusColor } from '../lib/utils';
import { UserFilter } from '../components/Common/UserFilter';
import { JobTile } from '../components/Jobs/JobTile';
import { JobModal } from '../components/Jobs/JobModal';
import { Job } from '../types';

// Project pipeline stages
type PipelineStage = 
  | 'project_submitted'
  | 'scheduled' 
  | 'in_progress' 
  | 'completed' 
  | 'punch_list'
  | 'closed';

interface PipelineStageConfig {
  id: PipelineStage;
  label: string;
  description: string;
  color: string;
}

// Define pipeline stages configuration
const pipelineStages: PipelineStageConfig[] = [
  { 
    id: 'project_submitted', 
    label: 'Project Submitted', 
    description: 'Initial project details received',
    color: '#3B82F6' // blue
  },
  { 
    id: 'scheduled', 
    label: 'Scheduled', 
    description: 'Project scheduled for execution',
    color: '#6366F1' // indigo
  },
  { 
    id: 'in_progress', 
    label: 'In Progress', 
    description: 'Work currently being performed',
    color: '#EC4899' // pink
  },
  { 
    id: 'completed', 
    label: 'Completed', 
    description: 'Project work finished',
    color: '#059669' // emerald
  },
  { 
    id: 'punch_list', 
    label: 'Punch List', 
    description: 'Final items being addressed',
    color: '#8B5CF6' // purple
  },
  { 
    id: 'closed', 
    label: 'Closed', 
    description: 'Project fully completed and closed',
    color: '#059669' // emerald
  }
];

export function Jobs() {
  const { user: currentUser } = useAuthStore();
  const { 
    jobs, 
    users,
    customers,
    leads,
    isLoading, 
    error, 
    fetchJobs,
    fetchUsers,
    fetchCustomers,
    fetchLeads,
    updateJob,
    deleteJob,
    createJob
  } = useCrmStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<PipelineStage | ''>('');
  const [projectTypeFilter, setProjectTypeFilter] = useState<string>('');
  const [permitFilter, setPermitFilter] = useState<'all' | 'required' | 'not_required'>('all');
  const [selectedUserId, setSelectedUserId] = useState<string | null>(
    // Default to current user for technicians
    currentUser?.role === 'TECHNICIAN' ? currentUser?.id || null : null
  );
  const [selectedTeamId, setSelectedTeamId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'pipeline' | 'list'>('pipeline');
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Job | null>(null);
  const [draggedProjectId, setDraggedProjectId] = useState<string | null>(null);
  const [dragOverStageId, setDragOverStageId] = useState<string | null>(null);
  const [filterOpen, setFilterOpen] = useState(false);

  useEffect(() => {
    fetchJobs();
    fetchUsers();
    fetchCustomers();
    fetchLeads();
  }, [fetchJobs, fetchUsers, fetchCustomers, fetchLeads]);

  // Map job status to pipeline stage
  const mapJobToPipelineStage = (job: Job): PipelineStage => {
    switch(job.status) {
      case 'SCHEDULED':
        return 'scheduled';
      case 'IN_PROGRESS':
        return 'in_progress';
      case 'COMPLETED':
        // Randomly assign to completed or punch_list for visual variety
        return Math.random() > 0.5 ? 'completed' : 'punch_list';
      case 'CANCELLED':
        return 'closed';
      default:
        return 'project_submitted';
    }
  };

  // Calculate days in stage if not provided
  const calculateDaysInStage = (job: Job): number => {
    if (job.daysInStage !== undefined) return job.daysInStage;
    
    const now = new Date();
    const updatedDate = new Date(job.updatedAt);
    return Math.floor((now.getTime() - updatedDate.getTime()) / (1000 * 60 * 60 * 24));
  };

  // Enhance jobs with pipeline stage and days in stage
  const enhancedJobs: Job[] = jobs.map(job => ({
    ...job,
    pipelineStage: mapJobToPipelineStage(job),
    daysInStage: calculateDaysInStage(job),
    // Ensure these properties exist with default values if needed
    progress: job.progress !== undefined ? job.progress : Math.floor(Math.random() * 100),
    tags: job.tags || [],
    projectType: job.projectType || 'foundation_repair',
    permitRequired: job.permitRequired !== undefined ? job.permitRequired : Math.random() > 0.5,
    estimatedValue: job.estimatedValue || Math.floor(Math.random() * 15000) + 5000,
    // Add customer reference if not already present
    customer: job.customer || customers.find(c => c.id === job.customerId)
  }));

  const filteredJobs = enhancedJobs.filter(job => {
    const matchesSearch = 
      job.jobAddress.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.notes?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (job.customer?.name || '').toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = !statusFilter || job.pipelineStage === statusFilter;
    const matchesProjectType = !projectTypeFilter || job.projectType === projectTypeFilter;
    
    // Permit filter
    const matchesPermit = 
      permitFilter === 'all' || 
      (permitFilter === 'required' && job.permitRequired) || 
      (permitFilter === 'not_required' && !job.permitRequired);
    
    // User filter
    const matchesUser = !selectedUserId || job.assignedTo === selectedUserId;
    
    // Team filter
    const matchesTeam = !selectedTeamId || 
      users.find(u => u.id === job.assignedTo)?.teamId === selectedTeamId;
    
    // Role-based filtering
    let hasAccess = true;
    if (currentUser?.role === 'TECHNICIAN') {
      // Technicians can only see their assigned jobs
      hasAccess = job.assignedTo === currentUser.id;
    } else if (currentUser?.role === 'SALES') {
      // Sales can see jobs from their leads/customers
      hasAccess = true; // Sales can see all jobs for visibility
    }
    
    return matchesSearch && matchesStatus && matchesProjectType && matchesPermit && matchesUser && matchesTeam && hasAccess;
  });

  // Group jobs by pipeline stage
  const jobsByStage = pipelineStages.reduce((acc, stage) => {
    acc[stage.id] = filteredJobs.filter(job => job.pipelineStage === stage.id);
    return acc;
  }, {} as Record<PipelineStage, Job[]>);

  const getUserName = (userId?: string) => {
    if (!userId) return 'Unassigned';
    const user = users.find(u => u.id === userId);
    return user ? user.name : `User ${userId.slice(-4)}`;
  };

  const getProjectTypeLabel = (type?: string) => {
    if (!type) return 'Unknown';
    return type.replace(/_/g, ' ');
  };

  const getStageConfig = (stageId: PipelineStage) => {
    return pipelineStages.find(stage => stage.id === stageId) || pipelineStages[0];
  };

  const handleCreateProject = () => {
    setEditingProject(null);
    setIsProjectModalOpen(true);
  };

  const handleEditProject = (job: Job) => {
    setEditingProject(job);
    setIsProjectModalOpen(true);
  };

  const handleDeleteProject = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this project?')) {
      try {
        await deleteJob(id);
      } catch (error) {
        console.error('Failed to delete project:', error);
      }
    }
  };

  const handleSaveProject = async (jobData: Partial<Job>) => {
    try {
      if (editingProject) {
        await updateJob(editingProject.id, jobData);
      } else {
        await createJob(jobData);
      }
      setIsProjectModalOpen(false);
    } catch (error) {
      console.error('Failed to save project:', error);
    }
  };

  const handleStatusChange = async (jobId: string, newStatus: string) => {
    try {
      await updateJob(jobId, { status: newStatus as Job['status'] });
    } catch (error) {
      console.error('Failed to update job status:', error);
    }
  };

  const handleDragStart = (e: React.DragEvent, job: Job) => {
    // Set a small delay to improve drag start visual feedback
    setTimeout(() => {
      setDraggedProjectId(job.id);
    }, 10);
    
    e.dataTransfer.effectAllowed = 'move';
    
    // Set minimal data to improve performance
    e.dataTransfer.setData('text/plain', job.id);
    
    // Create a lightweight ghost image
    const ghost = document.createElement('div');
    ghost.classList.add('bg-white', 'p-2', 'rounded', 'shadow', 'border', 'border-blue-300');
    ghost.textContent = job.jobAddress;
    ghost.style.position = 'absolute';
    ghost.style.top = '-1000px';
    ghost.style.opacity = '0.8';
    ghost.style.pointerEvents = 'none';
    ghost.style.width = '200px';
    document.body.appendChild(ghost);
    
    e.dataTransfer.setDragImage(ghost, 10, 10);
    
    // Clean up ghost element
    setTimeout(() => {
      document.body.removeChild(ghost);
    }, 0);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    
    // Add visual feedback for the drop target
    const target = e.currentTarget as HTMLElement;
    const stageId = target.getAttribute('data-stage-id');
    
    if (stageId && stageId !== dragOverStageId) {
      setDragOverStageId(stageId);
      
      // Remove highlight from all other stages
      document.querySelectorAll('.pipeline-stage').forEach(el => {
        if (el !== target) {
          el.classList.remove('bg-blue-50', 'border-blue-300');
        }
      });
      
      // Add highlight to current stage
      target.classList.add('bg-blue-50', 'border-blue-300');
    }
  };

  const handleDragLeave = (e: React.DragEvent) => {
    const target = e.currentTarget as HTMLElement;
    
    // Only remove highlight if we're leaving the element (not entering a child)
    if (!target.contains(e.relatedTarget as Node)) {
      target.classList.remove('bg-blue-50', 'border-blue-300');
    }
  };

  const handleDrop = (e: React.DragEvent, newStage: PipelineStage) => {
    e.preventDefault();
    e.stopPropagation();
    
    // Reset drag state
    setDragOverStageId(null);
    
    // Remove any lingering highlights
    document.querySelectorAll('.pipeline-stage').forEach(el => {
      el.classList.remove('bg-blue-50', 'border-blue-300');
    });
    
    if (!draggedProjectId) return;
    
    const job = jobs.find(p => p.id === draggedProjectId);
    if (!job) {
      setDraggedProjectId(null);
      return;
    }
    
    // Map pipeline stage to job status
    let newStatus: Job['status'];
    switch (newStage) {
      case 'scheduled':
        newStatus = 'SCHEDULED';
        break;
      case 'in_progress':
        newStatus = 'IN_PROGRESS';
        break;
      case 'completed':
      case 'punch_list':
        newStatus = 'COMPLETED';
        break;
      case 'closed':
        newStatus = 'COMPLETED';
        break;
      default:
        newStatus = 'SCHEDULED';
    }
    
    // Add a small delay to improve visual feedback
    setTimeout(() => {
      handleStatusChange(draggedProjectId, newStatus);
      setDraggedProjectId(null);
    }, 100);
  };

  if (error) {
    return (
      <div className="rounded-md bg-red-50 p-4">
        <div className="text-sm text-red-700">{error}</div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="h-10 bg-gray-200 rounded animate-pulse"></div>
        {[...Array(5)].map((_, i) => (
          <div key={i} className="h-20 bg-gray-200 rounded animate-pulse"></div>
        ))}
      </div>
    );
  }

  const renderPipelineView = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sm:p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Project Pipeline</h3>
          <div className="text-sm text-gray-600">
            {filteredJobs.length} projects • {new Intl.NumberFormat('en-US', {
              style: 'currency',
              currency: 'USD',
            }).format(filteredJobs.reduce((sum, project) => sum + (project.estimatedValue || 0), 0))} total value
          </div>
        </div>

        <div className="overflow-x-auto pb-2">
          <div className="inline-flex space-x-4 min-w-max pb-4">
            {pipelineStages.map(stage => {
              const stageJobs = jobsByStage[stage.id] || [];
              
              return (
                <div 
                  key={stage.id} 
                  data-stage-id={stage.id}
                  className="pipeline-stage w-72 flex-shrink-0 bg-gray-50 rounded-lg border border-gray-200 overflow-hidden transition-colors duration-150"
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={(e) => handleDrop(e, stage.id)}
                >
                  <div 
                    className="p-3 border-b-2 flex items-center justify-between"
                    style={{ borderColor: stage.color }}
                  >
                    <div>
                      <h4 className="font-medium text-gray-900">{stage.label}</h4>
                      <p className="text-xs text-gray-500">{stage.description}</p>
                    </div>
                    <div className="flex items-center justify-center w-6 h-6 bg-gray-200 rounded-full text-xs font-medium text-gray-700">
                      {stageJobs.length}
                    </div>
                  </div>
                  
                  <div className="p-2 max-h-[600px] overflow-y-auto">
                    {stageJobs.length > 0 ? (
                      <div className="space-y-2">
                        {stageJobs.map(job => (
                          <JobTile 
                            key={job.id} 
                            project={job}
                            onEdit={handleEditProject}
                            onDelete={handleDeleteProject}
                            onStatusChange={handleStatusChange}
                            onDragStart={handleDragStart}
                            onDragOver={handleDragOver}
                            onDrop={handleDrop}
                          />
                        ))}
                      </div>
                    ) : (
                      <div className="flex items-center justify-center h-24 text-gray-400 text-sm">
                        No projects in this stage
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );

  const renderListView = () => (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Project
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Customer
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Type
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Stage
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Schedule
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Assigned To
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Value
              </th>
              <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredJobs.map((job) => {
              const stageConfig = getStageConfig(job.pipelineStage || 'project_submitted');
              
              return (
                <tr key={job.id} className="hover:bg-gray-50">
                  <td className="px-4 py-4">
                    <div className="flex items-start">
                      <MapPin className="h-4 w-4 text-gray-400 mt-1 mr-2 flex-shrink-0" />
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          {job.jobAddress}
                        </div>
                        {job.notes && (
                          <div className="text-sm text-gray-500 mt-1 line-clamp-1">
                            {job.notes}
                          </div>
                        )}
                        {job.subStatus && (
                          <div className="flex items-center text-xs text-gray-500 mt-1">
                            <Tag className="h-3 w-3 mr-1" />
                            <span>{job.subStatus}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  
                  <td className="px-4 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {job.customer?.name || 'Unknown Customer'}
                    </div>
                  </td>
                  
                  <td className="px-4 py-4 whitespace-nowrap">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      {getProjectTypeLabel(job.projectType)}
                    </span>
                    {job.permitRequired && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800 ml-2">
                        Permit
                      </span>
                    )}
                  </td>
                  
                  <td className="px-4 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div 
                        className="w-2 h-2 rounded-full mr-2"
                        style={{ backgroundColor: stageConfig.color }}
                      ></div>
                      <span className="text-sm text-gray-900">
                        {stageConfig.label}
                      </span>
                    </div>
                    {job.daysInStage !== undefined && job.daysInStage > 7 && (
                      <div className="flex items-center text-xs text-amber-600 mt-1">
                        <Clock className="h-3 w-3 mr-1" />
                        <span>{job.daysInStage} days in stage</span>
                      </div>
                    )}
                  </td>
                  
                  <td className="px-4 py-4 whitespace-nowrap">
                    <div className="flex items-center text-sm text-gray-900">
                      <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                      <div>
                        {job.startDate && (
                          <div>{formatDate(job.startDate)}</div>
                        )}
                        {job.endDate && (
                          <div className="text-xs text-gray-500">
                            to {formatDate(job.endDate)}
                          </div>
                        )}
                        {!job.startDate && (
                          <span className="text-gray-500">Not scheduled</span>
                        )}
                      </div>
                    </div>
                  </td>
                  
                  <td className="px-4 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <User className="h-4 w-4 text-gray-400 mr-2" />
                      <span className="text-sm text-gray-900">
                        {getUserName(job.assignedTo)}
                        {job.assignedTo === currentUser?.id && ' (Me)'}
                      </span>
                    </div>
                  </td>
                  
                  <td className="px-4 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {job.estimatedValue ? new Intl.NumberFormat('en-US', {
                        style: 'currency',
                        currency: 'USD',
                      }).format(job.estimatedValue) : 'N/A'}
                    </div>
                  </td>
                  
                  <td className="px-4 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex items-center justify-end space-x-2">
                      <button
                        type="button"
                        className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                        title="View"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                      {(currentUser?.role === 'ADMIN' || 
                        currentUser?.role === 'OPERATIONS' || 
                        job.assignedTo === currentUser?.id) && (
                        <button
                          type="button"
                          onClick={() => handleEditProject(job)}
                          className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                          title="Edit"
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                      )}
                      {(currentUser?.role === 'ADMIN' || currentUser?.role === 'OPERATIONS') && (
                        <button
                          type="button"
                          onClick={() => handleDeleteProject(job.id)}
                          className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      
      {filteredJobs.length === 0 && (
        <div className="text-center py-12">
          <Calendar className="h-8 w-8 mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500">
            {jobs.length === 0 ? 'No projects found. Create your first project!' : 'No projects match your search criteria.'}
          </p>
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900">Projects</h1>
          <p className="text-gray-600">Manage and track foundation repair and construction projects</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          {/* View Toggle */}
          <div className="flex items-center">
            <button
              type="button"
              onClick={() => setViewMode('pipeline')}
              className={`flex items-center px-3 py-2 border border-gray-300 rounded-l-lg text-sm font-medium transition-colors ${
                viewMode === 'pipeline'
                  ? 'bg-white text-gray-900'
                  : 'bg-gray-100 text-gray-600 hover:text-gray-900'
              }`}
            >
              <Columns className="h-4 w-4 mr-2" />
              Pipeline
            </button>
            <button
              type="button"
              onClick={() => setViewMode('list')}
              className={`flex items-center px-3 py-2 border border-gray-300 border-l-0 rounded-r-lg text-sm font-medium transition-colors ${
                viewMode === 'list'
                  ? 'bg-white text-gray-900'
                  : 'bg-gray-100 text-gray-600 hover:text-gray-900'
              }`}
            >
              <List className="h-4 w-4 mr-2" />
              List
            </button>
          </div>
          
          {(currentUser?.role === 'ADMIN' || currentUser?.role === 'OPERATIONS') && (
            <button 
              type="button"
              onClick={handleCreateProject}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="h-4 w-4 mr-2" />
              New Project
            </button>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search projects by location, customer, or notes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="flex items-center">
            <button
              onClick={() => setFilterOpen(!filterOpen)}
              className="flex items-center px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <Filter className="h-4 w-4 mr-2" />
              Filters
              <ChevronDown className="h-4 w-4 ml-2" />
            </button>
          </div>
        </div>
        
        {filterOpen && (
          <div className="mt-4 pt-4 border-t border-gray-200">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Pipeline Stage Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Pipeline Stage
                </label>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as PipelineStage | '')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">All Stages</option>
                  {pipelineStages.map(stage => (
                    <option key={stage.id} value={stage.id}>
                      {stage.label}
                    </option>
                  ))}
                </select>
              </div>
              
              {/* Project Type Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Project Type
                </label>
                <select
                  value={projectTypeFilter}
                  onChange={(e) => setProjectTypeFilter(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">All Project Types</option>
                  <option value="foundation_repair">Foundation Repair</option>
                  <option value="waterproofing">Waterproofing</option>
                  <option value="crawlspace_repair">Crawlspace Repair</option>
                  <option value="concrete_repair">Concrete Repair</option>
                  <option value="general_construction">General Construction</option>
                </select>
              </div>
              
              {/* Permit Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Permit Status
                </label>
                <select
                  value={permitFilter}
                  onChange={(e) => setPermitFilter(e.target.value as 'all' | 'required' | 'not_required')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="all">All Permits</option>
                  <option value="required">Permit Required</option>
                  <option value="not_required">No Permit Required</option>
                </select>
              </div>
              
              {/* User Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Assigned To
                </label>
                <UserFilter
                  selectedUserId={selectedUserId}
                  selectedTeamId={selectedTeamId}
                  onUserChange={setSelectedUserId}
                  onTeamChange={setSelectedTeamId}
                  showTeamFilter={currentUser?.role === 'ADMIN' || currentUser?.role === 'OPERATIONS'}
                  className="w-full"
                />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Pipeline Legend */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 overflow-x-auto">
        <div className="flex items-center min-w-max">
          <div className="text-sm font-medium text-gray-700 mr-4">Pipeline Stages:</div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-blue-500 mr-1"></div>
              <span className="text-xs text-gray-600">Project Submitted</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-indigo-500 mr-1"></div>
              <span className="text-xs text-gray-600">Scheduled</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-pink-500 mr-1"></div>
              <span className="text-xs text-gray-600">In Progress</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-emerald-500 mr-1"></div>
              <span className="text-xs text-gray-600">Completed</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-purple-500 mr-1"></div>
              <span className="text-xs text-gray-600">Punch List</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-emerald-500 mr-1"></div>
              <span className="text-xs text-gray-600">Closed</span>
            </div>
          </div>
        </div>
      </div>

      {/* Content based on view mode */}
      {viewMode === 'pipeline' ? renderPipelineView() : renderListView()}

      {/* Project Stats */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
            <div className="p-2 bg-blue-100 rounded-full">
              <Briefcase className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <div className="text-sm font-medium text-gray-900">Total Projects</div>
              <div className="text-lg font-semibold text-blue-600">{filteredJobs.length}</div>
            </div>
          </div>
          
          <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
            <div className="p-2 bg-green-100 rounded-full">
              <CheckCircle className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <div className="text-sm font-medium text-gray-900">Completed</div>
              <div className="text-lg font-semibold text-green-600">
                {filteredJobs.filter(job => job.pipelineStage === 'completed' || job.pipelineStage === 'closed').length}
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-3 p-3 bg-amber-50 rounded-lg">
            <div className="p-2 bg-amber-100 rounded-full">
              <Clock className="h-5 w-5 text-amber-600" />
            </div>
            <div>
              <div className="text-sm font-medium text-gray-900">In Progress</div>
              <div className="text-lg font-semibold text-amber-600">
                {filteredJobs.filter(job => job.pipelineStage === 'in_progress').length}
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
            <div className="p-2 bg-purple-100 rounded-full">
              <AlertTriangle className="h-5 w-5 text-purple-600" />
            </div>
            <div>
              <div className="text-sm font-medium text-gray-900">Permit Required</div>
              <div className="text-lg font-semibold text-purple-600">
                {filteredJobs.filter(job => job.permitRequired).length}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Project Modal */}
      {isProjectModalOpen && (
        <JobModal
          isOpen={isProjectModalOpen}
          onClose={() => setIsProjectModalOpen(false)}
          onSave={handleSaveProject}
          project={editingProject}
        />
      )}
    </div>
  );
}