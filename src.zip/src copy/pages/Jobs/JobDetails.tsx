import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useCrmStore } from '../../stores/crmStore';
import { 
  ArrowLeft, 
  Briefcase, 
  User, 
  Calendar, 
  MapPin, 
  Tag, 
  FileText, 
  CheckSquare, 
  Edit, 
  Trash2, 
  Clock, 
  DollarSign,
  FileImage,
  MessageSquare
} from 'lucide-react';
import { formatDate } from '../../lib/utils';
import { JobModal } from '../../components/Jobs/JobModal';
import { FileGallery } from '../../components/Files/FileGallery';

export function JobDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { 
    jobs, 
    customers, 
    leads, 
    tasks, 
    estimates, 
    users,
    fetchJobs, 
    fetchCustomers, 
    fetchLeads, 
    fetchTasks, 
    fetchEstimates, 
    fetchUsers,
    updateJob,
    deleteJob
  } = useCrmStore();
  
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'details' | 'files' | 'tasks' | 'estimates' | 'notes'>('details');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      await Promise.all([
        fetchJobs(),
        fetchCustomers(),
        fetchLeads(),
        fetchTasks(),
        fetchEstimates(),
        fetchUsers()
      ]);
      setIsLoading(false);
    };
    
    loadData();
  }, [fetchJobs, fetchCustomers, fetchLeads, fetchTasks, fetchEstimates, fetchUsers]);
  
  const job = jobs.find(j => j.id === id);
  const customer = job ? customers.find(c => c.id === job.customerId) : null;
  const lead = job?.leadId ? leads.find(l => l.id === job.leadId) : null;
  const jobTasks = tasks.filter(t => t.jobId === id);
  const jobEstimates = estimates.filter(e => e.jobId === id);
  
  const handleBack = () => {
    navigate('/jobs');
  };
  
  const handleEdit = () => {
    setIsEditModalOpen(true);
  };
  
  const handleDelete = async () => {
    if (window.confirm('Are you sure you want to delete this job? This action cannot be undone.')) {
      await deleteJob(id!);
      navigate('/jobs');
    }
  };
  
  const handleSaveJob = async (data: any) => {
    await updateJob(id!, data);
    setIsEditModalOpen(false);
  };
  
  const getAssigneeName = (userId?: string) => {
    if (!userId) return 'Unassigned';
    const user = users.find(u => u.id === userId);
    return user ? user.name : 'Unknown User';
  };
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  
  if (!job) {
    return (
      <div className="bg-red-50 p-4 rounded-lg">
        <p className="text-red-700">Job not found</p>
        <button
          onClick={handleBack}
          className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Back to Jobs
        </button>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={handleBack}
            className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-full transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Job Details</h1>
            <p className="text-gray-600">{job.jobAddress}</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          <button
            onClick={handleEdit}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Edit className="h-4 w-4 mr-2" />
            Edit Job
          </button>
          <button
            onClick={handleDelete}
            className="flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Delete
          </button>
        </div>
      </div>
      
      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="flex space-x-8">
          {[
            { id: 'details', label: 'Details', icon: Briefcase },
            { id: 'files', label: 'Files', icon: FileImage },
            { id: 'tasks', label: 'Tasks', icon: CheckSquare, count: jobTasks.length },
            { id: 'estimates', label: 'Estimates', icon: FileText, count: jobEstimates.length },
            { id: 'notes', label: 'Notes', icon: MessageSquare },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span>{tab.label}</span>
                {tab.count !== undefined && tab.count > 0 && (
                  <span className="bg-gray-100 text-gray-600 py-0.5 px-2 rounded-full text-xs">
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>
      
      {/* Content */}
      <div>
        {activeTab === 'details' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Job Information */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
                <Briefcase className="h-5 w-5 text-gray-500 mr-2" />
                Job Information
              </h3>
              
              <div className="space-y-4">
                <div>
                  <div className="text-sm text-gray-500">Location</div>
                  <div className="text-sm font-medium text-gray-900">{job.jobAddress}</div>
                </div>
                
                <div>
                  <div className="text-sm text-gray-500">Status</div>
                  <div className="text-sm font-medium text-gray-900">{job.status}</div>
                </div>
                
                <div>
                  <div className="text-sm text-gray-500">Project Type</div>
                  <div className="text-sm font-medium text-gray-900">
                    {job.projectType ? job.projectType.replace(/_/g, ' ') : 'Not specified'}
                  </div>
                </div>
                
                <div>
                  <div className="text-sm text-gray-500">Permit Required</div>
                  <div className="text-sm font-medium text-gray-900">
                    {job.permitRequired ? 'Yes' : 'No'}
                  </div>
                </div>
                
                <div>
                  <div className="text-sm text-gray-500">Assigned To</div>
                  <div className="text-sm font-medium text-gray-900">
                    {getAssigneeName(job.assignedTo)}
                  </div>
                </div>
                
                <div>
                  <div className="text-sm text-gray-500">Estimated Value</div>
                  <div className="text-sm font-medium text-gray-900">
                    ${job.estimatedValue?.toLocaleString() || 'Not specified'}
                  </div>
                </div>
                
                {job.tags && job.tags.length > 0 && (
                  <div>
                    <div className="text-sm text-gray-500">Tags</div>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {job.tags.map(tag => (
                        <span 
                          key={tag} 
                          className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            {/* Schedule Information */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
                <Calendar className="h-5 w-5 text-gray-500 mr-2" />
                Schedule Information
              </h3>
              
              <div className="space-y-4">
                <div>
                  <div className="text-sm text-gray-500">Start Date</div>
                  <div className="text-sm font-medium text-gray-900">
                    {job.startDate ? formatDate(job.startDate) : 'Not scheduled'}
                  </div>
                </div>
                
                <div>
                  <div className="text-sm text-gray-500">End Date</div>
                  <div className="text-sm font-medium text-gray-900">
                    {job.endDate ? formatDate(job.endDate) : 'Not specified'}
                  </div>
                </div>
                
                <div>
                  <div className="text-sm text-gray-500">Progress</div>
                  <div className="mt-1">
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div 
                        className="bg-blue-600 h-2.5 rounded-full" 
                        style={{ width: `${job.progress || 0}%` }}
                      ></div>
                    </div>
                    <div className="text-right text-xs text-gray-500 mt-1">
                      {job.progress || 0}% complete
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Customer Information */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
                <User className="h-5 w-5 text-gray-500 mr-2" />
                Customer Information
              </h3>
              
              {customer ? (
                <div className="space-y-4">
                  <div>
                    <div className="text-sm text-gray-500">Name</div>
                    <div className="text-sm font-medium text-gray-900">{customer.name}</div>
                  </div>
                  
                  {customer.phone && (
                    <div>
                      <div className="text-sm text-gray-500">Phone</div>
                      <div className="text-sm font-medium text-gray-900">{customer.phone}</div>
                    </div>
                  )}
                  
                  {customer.email && (
                    <div>
                      <div className="text-sm text-gray-500">Email</div>
                      <div className="text-sm font-medium text-gray-900">{customer.email}</div>
                    </div>
                  )}
                  
                  {customer.address && (
                    <div>
                      <div className="text-sm text-gray-500">Address</div>
                      <div className="text-sm font-medium text-gray-900">{customer.address}</div>
                    </div>
                  )}
                  
                  {lead && (
                    <div>
                      <div className="text-sm text-gray-500">Lead Source</div>
                      <div className="text-sm font-medium text-gray-900">{lead.source}</div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-sm text-gray-500">Customer information not available</div>
              )}
            </div>
          </div>
        )}
        
        {activeTab === 'files' && (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <FileGallery jobId={id!} />
          </div>
        )}
        
        {activeTab === 'tasks' && (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-medium text-gray-900">Tasks</h3>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                Add Task
              </button>
            </div>
            
            {jobTasks.length > 0 ? (
              <div className="space-y-4">
                {jobTasks.map(task => (
                  <div key={task.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-3">
                        <div className="mt-0.5">
                          {task.status === 'COMPLETED' ? (
                            <CheckSquare className="h-5 w-5 text-green-600" />
                          ) : (
                            <CheckSquare className="h-5 w-5 text-gray-400" />
                          )}
                        </div>
                        <div>
                          <div className="text-sm font-medium text-gray-900">{task.description}</div>
                          {task.notes && (
                            <div className="text-sm text-gray-600 mt-1">{task.notes}</div>
                          )}
                          <div className="flex items-center space-x-4 mt-2">
                            <div className="flex items-center text-xs text-gray-500">
                              <Calendar className="h-3 w-3 mr-1" />
                              Due: {formatDate(task.dueDate)}
                            </div>
                            <div className="flex items-center text-xs text-gray-500">
                              <User className="h-3 w-3 mr-1" />
                              {getAssigneeName(task.assignedTo)}
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <button className="p-1 text-gray-400 hover:text-blue-600 transition-colors">
                          <Edit className="h-4 w-4" />
                        </button>
                        <button className="p-1 text-gray-400 hover:text-red-600 transition-colors">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-gray-50 rounded-lg">
                <CheckSquare className="h-8 w-8 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500">No tasks found for this job</p>
              </div>
            )}
          </div>
        )}
        
        {activeTab === 'estimates' && (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-medium text-gray-900">Estimates</h3>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                Create Estimate
              </button>
            </div>
            
            {jobEstimates.length > 0 ? (
              <div className="space-y-4">
                {jobEstimates.map(estimate => (
                  <div key={estimate.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          Estimate #{estimate.id.slice(-6)}
                        </div>
                        <div className="flex items-center space-x-4 mt-2">
                          <div className="flex items-center text-xs text-gray-500">
                            <Calendar className="h-3 w-3 mr-1" />
                            Created: {formatDate(estimate.createdAt)}
                          </div>
                          <div className="flex items-center text-xs text-gray-500">
                            <DollarSign className="h-3 w-3 mr-1" />
                            Total: ${estimate.total.toLocaleString()}
                          </div>
                          <div className="flex items-center text-xs">
                            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                              estimate.accepted ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                            }`}>
                              {estimate.accepted ? 'Accepted' : 'Pending'}
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <button className="p-1 text-gray-400 hover:text-blue-600 transition-colors">
                          <Edit className="h-4 w-4" />
                        </button>
                        <button className="p-1 text-gray-400 hover:text-red-600 transition-colors">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-gray-50 rounded-lg">
                <FileText className="h-8 w-8 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500">No estimates found for this job</p>
              </div>
            )}
          </div>
        )}
        
        {activeTab === 'notes' && (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Notes</h3>
            
            {job.notes ? (
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-gray-700 whitespace-pre-wrap">{job.notes}</p>
              </div>
            ) : (
              <div className="text-center py-12 bg-gray-50 rounded-lg">
                <MessageSquare className="h-8 w-8 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500">No notes for this job</p>
              </div>
            )}
            
            <div className="mt-6">
              <h4 className="text-sm font-medium text-gray-900 mb-2">Add Note</h4>
              <textarea
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows={4}
                placeholder="Add notes about this job..."
              ></textarea>
              <div className="flex justify-end mt-2">
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                  Save Note
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Edit Modal */}
      <JobModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onSave={handleSaveJob}
        project={job}
      />
    </div>
  );
}