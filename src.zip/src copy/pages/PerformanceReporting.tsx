import React, { useState, useEffect } from 'react';
import { useAuthStore } from '../stores/authStore';
import { usePerformanceStore } from '../stores/performanceStore';
import { useSalesStore } from '../stores/salesStore';
import { useCrmStore } from '../stores/crmStore';
import { 
  BarChart3, TrendingUp, Users, DollarSign, Target, Calendar,
  Download, RefreshCw, Filter, ChevronDown, AlertTriangle,
  Building, Megaphone, Calculator, Wrench
} from 'lucide-react';
import { formatCurrency, formatDate } from '../lib/utils';
import { OverviewMetrics } from '../components/Performance/OverviewMetrics';
import { SalesMetrics } from '../components/Performance/SalesMetrics';
import { OperationsMetrics } from '../components/Performance/OperationsMetrics';
import { MarketingMetrics } from '../components/Performance/MarketingMetrics';
import { FinanceMetrics } from '../components/Performance/FinanceMetrics';
import { SalesKPICards } from '../components/SalesPerformance/SalesKPICards';
import { SalesCharts } from '../components/SalesPerformance/SalesCharts';
import { TeamRankings } from '../components/SalesPerformance/TeamRankings';
import { PerformanceTargets } from '../components/SalesPerformance/PerformanceTargets';
import { HistoricalAnalysis } from '../components/SalesPerformance/HistoricalAnalysis';
import type { TimePeriod, DashboardView } from '../types/performance';
import type { ViewMode } from '../types/sales';

export function PerformanceReporting() {
  const { user: currentUser } = useAuthStore();
  const { 
    overviewData,
    salesData,
    operationsData,
    marketingData,
    financeData,
    isLoading: perfIsLoading,
    error: perfError,
    lastUpdated,
    fetchOverviewData,
    fetchSalesData,
    fetchOperationsData,
    fetchMarketingData,
    fetchFinanceData,
    exportData,
    refreshAllData
  } = usePerformanceStore();

  const { 
    salesMetrics,
    teamMetrics,
    historicalData,
    targets,
    isLoading: salesIsLoading,
    error: salesError,
    fetchSalesMetrics,
    fetchTeamMetrics,
    fetchHistoricalData,
    fetchTargets,
    refreshData
  } = useSalesStore();

  const { users, teams, fetchUsers, fetchTeams } = useCrmStore();

  const [activeView, setActiveView] = useState<DashboardView>('overview');
  const [timePeriod, setTimePeriod] = useState<TimePeriod>('last30days');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  
  // Sales performance specific states
  const [salesViewMode, setSalesViewMode] = useState<ViewMode>('individual');
  const [selectedUserId, setSelectedUserId] = useState<string | null>(
    currentUser?.role === 'SALES' ? currentUser.id : null
  );
  const [selectedTeamId, setSelectedTeamId] = useState<string | null>(null);

  useEffect(() => {
    // Load data based on user permissions and active view
    if (activeView === 'overview' && hasAccess('overview')) {
      fetchOverviewData(timePeriod);
    } else if (activeView === 'sales' && hasAccess('sales')) {
      fetchSalesData(timePeriod);
      // Also fetch sales performance data
      fetchSalesMetrics(timePeriod, selectedUserId);
      fetchTeamMetrics(timePeriod, selectedTeamId);
      fetchHistoricalData(timePeriod);
      fetchTargets();
      fetchUsers();
      fetchTeams();
    } else if (activeView === 'operations' && hasAccess('operations')) {
      fetchOperationsData(timePeriod);
    } else if (activeView === 'marketing' && hasAccess('marketing')) {
      fetchMarketingData(timePeriod);
    } else if (activeView === 'finance' && hasAccess('finance')) {
      fetchFinanceData(timePeriod);
    }
  }, [activeView, timePeriod, selectedUserId, selectedTeamId]);

  // Role-based access control
  const hasAccess = (view: DashboardView): boolean => {
    if (!currentUser) return false;

    switch (currentUser.role) {
      case 'ADMIN':
        return true; // Full access to all dashboards
      case 'SALES':
        return view === 'sales' || view === 'overview';
      case 'OPERATIONS':
        return view === 'operations' || view === 'overview';
      default:
        return view === 'overview'; // Basic access for other roles
    }
  };

  const getAvailableViews = () => {
    const views = [
      { id: 'overview', label: 'Overview', icon: BarChart3, description: 'Company-wide metrics' }
    ];

    if (hasAccess('sales')) {
      views.push({ 
        id: 'sales', 
        label: 'Sales', 
        icon: DollarSign, 
        description: 'Revenue and sales performance' 
      });
    }

    if (hasAccess('operations')) {
      views.push({ 
        id: 'operations', 
        label: 'Operations', 
        icon: Wrench, 
        description: 'Productivity and efficiency' 
      });
    }

    if (hasAccess('marketing')) {
      views.push({ 
        id: 'marketing', 
        label: 'Marketing', 
        icon: Megaphone, 
        description: 'Campaigns and lead generation' 
      });
    }

    if (hasAccess('finance')) {
      views.push({ 
        id: 'finance', 
        label: 'Finance', 
        icon: Calculator, 
        description: 'Financial performance and forecasts' 
      });
    }

    return views;
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      if (activeView === 'sales') {
        await refreshData();
      } else {
        await refreshAllData();
      }
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleExport = async () => {
    try {
      await exportData(activeView, timePeriod);
    } catch (error) {
      console.error('Failed to export data:', error);
    }
  };

  const getTimePeriodLabel = (period: TimePeriod) => {
    switch (period) {
      case 'last7days': return 'Last 7 Days';
      case 'last30days': return 'Last 30 Days';
      case 'last90days': return 'Last 90 Days';
      case 'thisMonth': return 'This Month';
      case 'lastMonth': return 'Last Month';
      case 'thisQuarter': return 'This Quarter';
      case 'lastQuarter': return 'Last Quarter';
      case 'thisYear': return 'This Year';
      case 'lastYear': return 'Last Year';
      default: return 'Last 30 Days';
    }
  };

  const renderSalesContent = () => {
    const isLoading = perfIsLoading || salesIsLoading;
    
    if (isLoading) {
      return (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
        </div>
      );
    }

    // Sales Performance View Modes
    if (salesViewMode === 'individual') {
      return (
        <div className="space-y-6">
          <SalesKPICards 
            metrics={salesMetrics}
            timePeriod={timePeriod}
            selectedUser={selectedUserId ? getUserName(selectedUserId) : 'All Sales Reps'}
          />
          <SalesCharts 
            metrics={salesMetrics}
            historicalData={historicalData}
            timePeriod={timePeriod}
          />
          <PerformanceTargets 
            metrics={salesMetrics}
            targets={targets}
            userId={selectedUserId}
          />
        </div>
      );
    } else if (salesViewMode === 'team') {
      return (
        <div className="space-y-6">
          <SalesKPICards 
            metrics={teamMetrics}
            timePeriod={timePeriod}
            selectedUser={selectedTeamId ? getTeamName(selectedTeamId) : 'All Teams'}
            isTeamView={true}
          />
          <TeamRankings 
            teamMetrics={teamMetrics}
            users={users}
            teams={teams}
          />
          <SalesCharts 
            metrics={teamMetrics}
            historicalData={historicalData}
            timePeriod={timePeriod}
            isTeamView={true}
          />
        </div>
      );
    } else if (salesViewMode === 'historical') {
      return (
        <HistoricalAnalysis 
          historicalData={historicalData}
          timePeriod={timePeriod}
          selectedUserId={selectedUserId}
          selectedTeamId={selectedTeamId}
        />
      );
    }

    // Default to standard sales metrics
    return <SalesMetrics data={salesData} timePeriod={timePeriod} />;
  };

  const renderContent = () => {
    switch (activeView) {
      case 'overview':
        return <OverviewMetrics data={overviewData} timePeriod={timePeriod} />;
      case 'sales':
        return renderSalesContent();
      case 'operations':
        return <OperationsMetrics data={operationsData} timePeriod={timePeriod} />;
      case 'marketing':
        return <MarketingMetrics data={marketingData} timePeriod={timePeriod} />;
      case 'finance':
        return <FinanceMetrics data={financeData} timePeriod={timePeriod} />;
      default:
        return <OverviewMetrics data={overviewData} timePeriod={timePeriod} />;
    }
  };

  const getUserName = (userId: string) => {
    const user = users?.find(u => u.id === userId);
    return user ? user.name : 'Unknown User';
  };

  const getTeamName = (teamId: string) => {
    const team = teams?.find(t => t.id === teamId);
    return team ? team.name : 'Unknown Team';
  };

  const error = perfError || salesError;

  if (!currentUser) {
    return (
      <div className="rounded-md bg-red-50 p-4">
        <div className="flex">
          <AlertTriangle className="h-5 w-5 text-red-400" />
          <div className="ml-3">
            <h3 className="text-sm font-medium text-red-800">Access Denied</h3>
            <div className="mt-2 text-sm text-red-700">
              Please log in to access performance reporting.
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="rounded-md bg-red-50 p-4">
        <div className="text-sm text-red-700">{error}</div>
      </div>
    );
  }

  const availableViews = getAvailableViews();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Performance Reporting</h1>
          <p className="text-gray-600">
            Comprehensive performance metrics and analytics dashboard
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          {/* Real-time indicator */}
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span>Live data</span>
            {lastUpdated && (
              <>
                <span className="text-gray-400">•</span>
                <span>Updated {formatDate(lastUpdated)}</span>
              </>
            )}
          </div>
          
          <button
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="flex items-center px-3 py-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
            title="Refresh Data"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
            Refresh
          </button>
          
          <button
            onClick={handleExport}
            className="flex items-center px-3 py-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <Download className="h-4 w-4 mr-2" />
            Export
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {availableViews.map((view) => {
              const Icon = view.icon;
              return (
                <button
                  key={view.id}
                  onClick={() => setActiveView(view.id as DashboardView)}
                  className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                    activeView === view.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{view.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Controls */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
              <h2 className="text-lg font-semibold text-gray-900">
                {availableViews.find(v => v.id === activeView)?.label} Dashboard
              </h2>
              <p className="text-sm text-gray-600">
                {availableViews.find(v => v.id === activeView)?.description}
              </p>
            </div>

            <div className="flex items-center space-x-4">
              {/* Time Period Selector */}
              <div className="relative">
                <select
                  value={timePeriod}
                  onChange={(e) => setTimePeriod(e.target.value as TimePeriod)}
                  className="appearance-none bg-white border border-gray-300 rounded-lg px-4 py-2 pr-8 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="last7days">Last 7 Days</option>
                  <option value="last30days">Last 30 Days</option>
                  <option value="last90days">Last 90 Days</option>
                  <option value="thisMonth">This Month</option>
                  <option value="lastMonth">Last Month</option>
                  <option value="thisQuarter">This Quarter</option>
                  <option value="lastQuarter">Last Quarter</option>
                  <option value="thisYear">This Year</option>
                  <option value="lastYear">Last Year</option>
                </select>
                <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
              </div>

              {/* Filters Toggle */}
              <button
                onClick={() => setShowFilters(!showFilters)}
                className={`flex items-center px-3 py-2 rounded-lg transition-colors ${
                  showFilters
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </button>
            </div>
          </div>

          {/* Sales View Mode Selector (only show when sales view is active) */}
          {activeView === 'sales' && (
            <div className="mt-4 pt-4 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center bg-gray-100 rounded-lg p-1">
                  {[
                    { mode: 'individual', label: 'Individual', icon: Users },
                    { mode: 'team', label: 'Team Overview', icon: BarChart3 },
                    { mode: 'historical', label: 'Historical', icon: TrendingUp },
                  ].map(({ mode, label, icon: Icon }) => (
                    <button
                      key={mode}
                      onClick={() => setSalesViewMode(mode as ViewMode)}
                      className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                        salesViewMode === mode
                          ? 'bg-white text-gray-900 shadow-sm'
                          : 'text-gray-600 hover:text-gray-900'
                      }`}
                    >
                      <Icon className="h-4 w-4 mr-2" />
                      {label}
                    </button>
                  ))}
                </div>

                {/* User/Team Selector for Sales */}
                <div className="flex items-center space-x-4">
                  {salesViewMode === 'individual' && (
                    <div className="relative">
                      <select
                        value={selectedUserId || ''}
                        onChange={(e) => setSelectedUserId(e.target.value || null)}
                        className="appearance-none bg-white border border-gray-300 rounded-lg px-4 py-2 pr-8 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      >
                        <option value="">All Sales Reps</option>
                        {users?.filter(u => u.role === 'SALES' || u.role === 'ADMIN').map(user => (
                          <option key={user.id} value={user.id}>
                            {user.name} {user.id === currentUser?.id ? '(Me)' : ''}
                          </option>
                        ))}
                      </select>
                      <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
                    </div>
                  )}

                  {salesViewMode === 'team' && (
                    <div className="relative">
                      <select
                        value={selectedTeamId || ''}
                        onChange={(e) => setSelectedTeamId(e.target.value || null)}
                        className="appearance-none bg-white border border-gray-300 rounded-lg px-4 py-2 pr-8 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      >
                        <option value="">All Teams</option>
                        {teams?.filter(t => t.name.toLowerCase().includes('sales')).map(team => (
                          <option key={team.id} value={team.id}>
                            {team.name}
                          </option>
                        ))}
                      </select>
                      <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Advanced Filters */}
          {showFilters && (
            <div className="mt-4 pt-4 border-t border-gray-200">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Department
                  </label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option value="">All Departments</option>
                    <option value="sales">Sales</option>
                    <option value="operations">Operations</option>
                    <option value="marketing">Marketing</option>
                    <option value="finance">Finance</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Metric Type
                  </label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option value="">All Metrics</option>
                    <option value="revenue">Revenue</option>
                    <option value="efficiency">Efficiency</option>
                    <option value="quality">Quality</option>
                    <option value="growth">Growth</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Comparison
                  </label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option value="previous">vs Previous Period</option>
                    <option value="target">vs Target</option>
                    <option value="yoy">Year over Year</option>
                  </select>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Dashboard Content */}
      <div className="min-h-[600px]">
        {(perfIsLoading || salesIsLoading) && activeView !== 'sales' ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
          </div>
        ) : (
          renderContent()
        )}
      </div>

      {/* Footer Info */}
      <div className="bg-gray-50 rounded-lg p-4">
        <div className="flex items-center justify-between text-sm text-gray-600">
          <div className="flex items-center space-x-4">
            <span>Viewing: {getTimePeriodLabel(timePeriod)}</span>
            <span>•</span>
            <span>Role: {currentUser.role}</span>
            <span>•</span>
            <span>Access Level: {hasAccess('overview') && hasAccess('sales') && hasAccess('operations') ? 'Full' : 'Limited'}</span>
          </div>
          
          <div className="flex items-center space-x-4">
            <span>Data refreshes every 15 minutes</span>
            <span>•</span>
            <span>Export available in PDF, Excel, CSV</span>
          </div>
        </div>
      </div>
    </div>
  );
}