import React, { useEffect, useState } from 'react';
import { useCrmStore } from '../stores/crmStore';
import { useAuthStore } from '../stores/authStore';
import { LeadsList } from '../components/Leads/LeadsList';
import { LeadsPipeline } from '../components/Leads/LeadsPipeline';
import { LeadModal } from '../components/Leads/LeadModal';
import { LeadDetailModal } from '../components/Leads/LeadDetailModal';
import { UserFilter } from '../components/Common/UserFilter';
import { Lead } from '../types';
import { LayoutGrid, List } from 'lucide-react';

export function Leads() {
  const { user: currentUser } = useAuthStore();
  const { 
    leads, 
    pipeline,
    users,
    isLoading, 
    error, 
    fetchLeads, 
    fetchPipeline,
    fetchUsers,
    createLead,
    updateLead,
    deleteLead,
    setSelectedLead,
    selectedLead
  } = useCrmStore();

  const [viewMode, setViewMode] = useState<'list' | 'pipeline'>('pipeline');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [editingLead, setEditingLead] = useState<Lead | null>(null);
  const [viewingLead, setViewingLead] = useState<Lead | null>(null);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(
    // Default to current user for sales reps
    currentUser?.role === 'SALES' ? currentUser?.id || null : null
  );
  const [selectedTeamId, setSelectedTeamId] = useState<string | null>(null);

  useEffect(() => {
    fetchLeads();
    fetchPipeline();
    fetchUsers();
  }, [fetchLeads, fetchPipeline, fetchUsers]);

  // Filter leads based on user and team selection
  const filteredLeads = leads.filter(lead => {
    // User filter
    const matchesUser = !selectedUserId || lead.assignedTo === selectedUserId;
    
    // Team filter
    const matchesTeam = !selectedTeamId || 
      users.find(u => u.id === lead.assignedTo)?.teamId === selectedTeamId;
    
    // Role-based filtering
    let hasAccess = true;
    if (currentUser?.role === 'SALES') {
      // Sales can see leads assigned to their team
      const assignedUser = users.find(u => u.id === lead.assignedTo);
      hasAccess = assignedUser?.teamId === currentUser.teamId || 
                  lead.assignedTo === currentUser.id ||
                  !lead.assignedTo; // Unassigned leads
    } else if (currentUser?.role === 'TECHNICIAN') {
      // Technicians can only see leads that have converted to jobs assigned to them
      hasAccess = lead.status === 'CONVERTED' && lead.jobs?.some(job => job.assignedTo === currentUser.id);
    }
    
    return matchesUser && matchesTeam && hasAccess;
  });

  const handleCreateLead = () => {
    setEditingLead(null);
    setIsModalOpen(true);
  };

  const handleEditLead = (lead: Lead) => {
    setEditingLead(lead);
    setIsModalOpen(true);
  };

  const handleDeleteLead = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this lead?')) {
      try {
        await deleteLead(id);
      } catch (error) {
        console.error('Failed to delete lead:', error);
      }
    }
  };

  const handleViewLead = (lead: Lead) => {
    setViewingLead(lead);
    setIsDetailModalOpen(true);
  };

  const handleSaveLead = async (leadData: Partial<Lead>) => {
    // Auto-assign to current user if not specified and user is sales
    if (!leadData.assignedTo && currentUser?.role === 'SALES') {
      leadData.assignedTo = currentUser.id;
    }
    
    if (editingLead) {
      await updateLead(editingLead.id, leadData);
    } else {
      await createLead(leadData);
    }
    setIsModalOpen(false);
  };

  const handleStatusChange = async (leadId: string, newStatus: Lead['status']) => {
    await updateLead(leadId, { status: newStatus });
  };

  const getUserName = (userId?: string) => {
    if (!userId) return 'Unassigned';
    const user = users.find(u => u.id === userId);
    return user ? user.name : `User ${userId.slice(-4)}`;
  };

  if (error) {
    return (
      <div className="rounded-md bg-red-50 p-4">
        <div className="text-sm text-red-700">{error}</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Leads</h1>
          <p className="text-gray-600">Manage and track your sales leads</p>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* View Toggle */}
          <div className="flex items-center bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setViewMode('pipeline')}
              className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                viewMode === 'pipeline'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <LayoutGrid className="h-4 w-4 mr-2" />
              Pipeline
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                viewMode === 'list'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <List className="h-4 w-4 mr-2" />
              List
            </button>
          </div>
          
          {(currentUser?.role === 'ADMIN' || currentUser?.role === 'SALES') && (
            <button
              onClick={handleCreateLead}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              New Lead
            </button>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <UserFilter
            selectedUserId={selectedUserId}
            selectedTeamId={selectedTeamId}
            onUserChange={setSelectedUserId}
            onTeamChange={setSelectedTeamId}
            showTeamFilter={currentUser?.role === 'ADMIN' || currentUser?.role === 'OPERATIONS'}
          />
          
          <div className="text-sm text-gray-600">
            Showing {filteredLeads.length} of {leads.length} leads
          </div>
        </div>
      </div>

      {/* Content */}
      {viewMode === 'pipeline' ? (
        <LeadsPipeline
          leads={filteredLeads}
          pipeline={pipeline}
          onLeadClick={handleViewLead}
          onStatusChange={handleStatusChange}
        />
      ) : (
        <LeadsList
          leads={filteredLeads}
          isLoading={isLoading}
          onCreateLead={handleCreateLead}
          onEditLead={handleEditLead}
          onDeleteLead={handleDeleteLead}
          onViewLead={handleViewLead}
        />
      )}

      {/* Lead Modal */}
      <LeadModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveLead}
        lead={editingLead}
        isLoading={isLoading}
      />

      {/* Lead Detail Modal */}
      <LeadDetailModal
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        lead={viewingLead}
        onEdit={handleEditLead}
        onDelete={handleDeleteLead}
      />
    </div>
  );
}