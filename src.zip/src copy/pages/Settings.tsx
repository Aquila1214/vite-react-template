import React, { useState, useEffect } from 'react';
import { 
  Settings as SettingsIcon, 
  Users, 
  Shield, 
  Bell, 
  Database, 
  Palette, 
  Globe, 
  Lock,
  Save,
  Eye,
  Edit,
  Trash2,
  Plus,
  Check,
  X,
  AlertTriangle,
  Building,
  Phone,
  Mail,
  Layout
} from 'lucide-react';
import { useAuthStore } from '../stores/authStore';
import { useCrmStore } from '../stores/crmStore';
import { useLocationStore } from '../stores/locationStore';
import { TeamModal } from '../components/Teams/TeamModal';
import { Location, Team } from '../types';

interface Permission {
  id: string;
  name: string;
  description: string;
  category: 'customers' | 'leads' | 'jobs' | 'tasks' | 'estimates' | 'invoices' | 'messages' | 'files' | 'users' | 'settings';
  actions: {
    view: boolean;
    create: boolean;
    edit: boolean;
    delete: boolean;
    assign?: boolean;
    approve?: boolean;
  };
}

interface Role {
  id: string;
  name: string;
  description: string;
  permissions: Permission[];
  isSystem: boolean;
}

const defaultPermissions: Permission[] = [
  {
    id: 'customers',
    name: 'Customer Management',
    description: 'Access to customer information and profiles',
    category: 'customers',
    actions: { view: true, create: true, edit: true, delete: false }
  },
  {
    id: 'leads',
    name: 'Lead Management',
    description: 'Access to lead tracking and conversion',
    category: 'leads',
    actions: { view: true, create: true, edit: true, delete: false, assign: true }
  },
  {
    id: 'jobs',
    name: 'Job Management',
    description: 'Access to job scheduling and tracking',
    category: 'jobs',
    actions: { view: true, create: true, edit: true, delete: false, assign: true }
  },
  {
    id: 'tasks',
    name: 'Task Management',
    description: 'Access to task creation and assignment',
    category: 'tasks',
    actions: { view: true, create: true, edit: true, delete: false, assign: true }
  },
  {
    id: 'estimates',
    name: 'Estimate Management',
    description: 'Access to estimate creation and approval',
    category: 'estimates',
    actions: { view: true, create: true, edit: true, delete: false, approve: true }
  },
  {
    id: 'invoices',
    name: 'Invoice Management',
    description: 'Access to invoice creation and payment tracking',
    category: 'invoices',
    actions: { view: true, create: true, edit: true, delete: false }
  },
  {
    id: 'messages',
    name: 'Communication',
    description: 'Access to customer communications',
    category: 'messages',
    actions: { view: true, create: true, edit: false, delete: false }
  },
  {
    id: 'files',
    name: 'File Management',
    description: 'Access to file uploads and attachments',
    category: 'files',
    actions: { view: true, create: true, edit: false, delete: false }
  },
  {
    id: 'users',
    name: 'User Management',
    description: 'Access to user accounts and permissions',
    category: 'users',
    actions: { view: false, create: false, edit: false, delete: false }
  },
  {
    id: 'settings',
    name: 'System Settings',
    description: 'Access to system configuration',
    category: 'settings',
    actions: { view: false, create: false, edit: false, delete: false }
  }
];

const systemRoles: Role[] = [
  {
    id: 'admin',
    name: 'Administrator',
    description: 'Full system access with all permissions',
    isSystem: true,
    permissions: defaultPermissions.map(p => ({
      ...p,
      actions: { view: true, create: true, edit: true, delete: true, assign: true, approve: true }
    }))
  },
  {
    id: 'sales',
    name: 'Sales Representative',
    description: 'Access to leads, customers, estimates, and communications',
    isSystem: true,
    permissions: defaultPermissions.map(p => {
      if (['customers', 'leads', 'estimates', 'messages', 'files'].includes(p.category)) {
        return { ...p, actions: { view: true, create: true, edit: true, delete: false, assign: true, approve: false } };
      }
      if (['jobs', 'tasks'].includes(p.category)) {
        return { ...p, actions: { view: true, create: true, edit: false, delete: false, assign: false } };
      }
      if (p.category === 'invoices') {
        return { ...p, actions: { view: true, create: false, edit: false, delete: false } };
      }
      return { ...p, actions: { view: false, create: false, edit: false, delete: false } };
    })
  },
  {
    id: 'operations',
    name: 'Operations Manager',
    description: 'Access to jobs, tasks, scheduling, and resource management',
    isSystem: true,
    permissions: defaultPermissions.map(p => {
      if (['customers', 'jobs', 'tasks', 'files'].includes(p.category)) {
        return { ...p, actions: { view: true, create: true, edit: true, delete: false, assign: true } };
      }
      if (['leads', 'estimates', 'invoices', 'messages'].includes(p.category)) {
        return { ...p, actions: { view: true, create: false, edit: false, delete: false } };
      }
      return { ...p, actions: { view: false, create: false, edit: false, delete: false } };
    })
  },
  {
    id: 'technician',
    name: 'Field Technician',
    description: 'Limited access to assigned customers, jobs, and basic communication',
    isSystem: true,
    permissions: defaultPermissions.map(p => {
      if (p.category === 'customers') {
        return { ...p, actions: { view: true, create: false, edit: false, delete: false } };
      }
      if (['jobs', 'tasks'].includes(p.category)) {
        return { ...p, actions: { view: true, create: false, edit: true, delete: false, assign: false } };
      }
      if (['messages', 'files'].includes(p.category)) {
        return { ...p, actions: { view: true, create: true, edit: false, delete: false } };
      }
      return { ...p, actions: { view: false, create: false, edit: false, delete: false } };
    })
  }
];

export function Settings() {
  const { user } = useAuthStore();
  const { teams, fetchTeams, createTeam, updateTeam, deleteTeam } = useCrmStore();
  const { locations, fetchLocations, createLocation, updateLocation, deleteLocation } = useLocationStore();
  
  // Consolidated tabs
  const [activeTab, setActiveTab] = useState<'access-control' | 'organization' | 'notifications' | 'integrations' | 'appearance' | 'security'>('access-control');
  
  // Access Control state
  const [roles, setRoles] = useState<Role[]>(systemRoles);
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [isEditingRole, setIsEditingRole] = useState(false);
  const [newRoleName, setNewRoleName] = useState('');
  const [newRoleDescription, setNewRoleDescription] = useState('');
  const [permissionsView, setPermissionsView] = useState<'roles' | 'matrix'>('roles');
  
  // Organization state
  const [organizationView, setOrganizationView] = useState<'locations' | 'teams'>('locations');
  const [isTeamModalOpen, setIsTeamModalOpen] = useState(false);
  const [editingTeam, setEditingTeam] = useState<Team | null>(null);
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);
  const [editingLocation, setEditingLocation] = useState<Location | null>(null);
  const [newLocationName, setNewLocationName] = useState('');
  const [newLocationAddress, setNewLocationAddress] = useState('');
  const [newLocationPhone, setNewLocationPhone] = useState('');
  const [newLocationEmail, setNewLocationEmail] = useState('');

  useEffect(() => {
    fetchTeams();
    fetchLocations();
  }, [fetchTeams, fetchLocations]);

  // Only admins can access settings
  if (user?.role !== 'ADMIN') {
    return (
      <div className="rounded-md bg-yellow-50 p-4">
        <div className="flex">
          <AlertTriangle className="h-5 w-5 text-yellow-400" />
          <div className="ml-3">
            <h3 className="text-sm font-medium text-yellow-800">Access Denied</h3>
            <div className="mt-2 text-sm text-yellow-700">
              Administrator privileges required to access system settings.
            </div>
          </div>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'access-control', label: 'Access Control', icon: Shield, description: 'User roles and permissions' },
    { id: 'organization', label: 'Organization', icon: Building, description: 'Locations and teams' },
    { id: 'notifications', label: 'Notifications', icon: Bell, description: 'System notifications and alerts' },
    { id: 'integrations', label: 'Integrations', icon: Database, description: 'External service connections' },
    { id: 'appearance', label: 'Appearance', icon: Palette, description: 'UI customization' },
    { id: 'security', label: 'Security', icon: Lock, description: 'Security settings' },
  ];

  const handleCreateRole = () => {
    if (!newRoleName.trim()) return;

    const newRole: Role = {
      id: newRoleName.toLowerCase().replace(/\s+/g, '_'),
      name: newRoleName,
      description: newRoleDescription,
      isSystem: false,
      permissions: defaultPermissions.map(p => ({
        ...p,
        actions: { view: false, create: false, edit: false, delete: false }
      }))
    };

    setRoles([...roles, newRole]);
    setNewRoleName('');
    setNewRoleDescription('');
    setSelectedRole(newRole);
    setIsEditingRole(true);
  };

  const handleUpdateRolePermissions = (roleId: string, permissionId: string, action: keyof Permission['actions'], value: boolean) => {
    setRoles(roles.map(role => {
      if (role.id === roleId) {
        return {
          ...role,
          permissions: role.permissions.map(permission => {
            if (permission.id === permissionId) {
              return {
                ...permission,
                actions: { ...permission.actions, [action]: value }
              };
            }
            return permission;
          })
        };
      }
      return role;
    }));
  };

  const handleDeleteRole = (roleId: string) => {
    if (window.confirm('Are you sure you want to delete this role?')) {
      setRoles(roles.filter(role => role.id !== roleId));
      if (selectedRole?.id === roleId) {
        setSelectedRole(null);
        setIsEditingRole(false);
      }
    }
  };

  // Team management handlers
  const handleCreateTeam = () => {
    setEditingTeam(null);
    setIsTeamModalOpen(true);
  };

  const handleEditTeam = (team: Team) => {
    setEditingTeam(team);
    setIsTeamModalOpen(true);
  };

  const handleSaveTeam = async (teamData: Partial<Team>) => {
    if (editingTeam) {
      await updateTeam(editingTeam.id, teamData);
    } else {
      await createTeam(teamData);
    }
    setIsTeamModalOpen(false);
  };

  const handleDeleteTeam = async (teamId: string) => {
    if (window.confirm('Are you sure you want to delete this team? Users in this team will become unassigned.')) {
      await deleteTeam(teamId);
    }
  };
  
  // Location management handlers
  const handleCreateLocation = () => {
    setEditingLocation(null);
    setNewLocationName('');
    setNewLocationAddress('');
    setNewLocationPhone('');
    setNewLocationEmail('');
    setIsLocationModalOpen(true);
  };
  
  const handleEditLocation = (location: Location) => {
    setEditingLocation(location);
    setNewLocationName(location.name);
    setNewLocationAddress(location.address || '');
    setNewLocationPhone(location.phone || '');
    setNewLocationEmail(location.email || '');
    setIsLocationModalOpen(true);
  };
  
  const handleSaveLocation = async () => {
    if (!newLocationName.trim()) {
      alert('Location name is required');
      return;
    }
    
    const locationData = {
      name: newLocationName,
      address: newLocationAddress || undefined,
      phone: newLocationPhone || undefined,
      email: newLocationEmail || undefined,
    };
    
    if (editingLocation) {
      await updateLocation(editingLocation.id, locationData);
    } else {
      await createLocation(locationData);
    }
    
    setIsLocationModalOpen(false);
  };
  
  const handleDeleteLocation = async (locationId: string) => {
    if (window.confirm('Are you sure you want to delete this location? This may affect users, customers, and other data associated with this location.')) {
      try {
        await deleteLocation(locationId);
      } catch (error) {
        console.error('Failed to delete location:', error);
        alert('Failed to delete location. It may be in use by users, customers, or other data.');
      }
    }
  };

  const renderAccessControlTab = () => (
    <div className="space-y-6">
      {/* Sub-navigation */}
      <div className="flex items-center space-x-4 border-b border-gray-200 pb-4">
        <button
          onClick={() => setPermissionsView('roles')}
          className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
            permissionsView === 'roles' 
              ? 'bg-blue-100 text-blue-700' 
              : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          User Roles
        </button>
        <button
          onClick={() => setPermissionsView('matrix')}
          className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
            permissionsView === 'matrix' 
              ? 'bg-blue-100 text-blue-700' 
              : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          Permission Matrix
        </button>
      </div>

      {permissionsView === 'roles' ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Roles List */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-medium text-gray-900">Available Roles</h4>
              <button
                onClick={() => setIsEditingRole(true)}
                className="flex items-center px-3 py-1 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Role
              </button>
            </div>
            <div className="space-y-3">
              {roles.map(role => (
                <div
                  key={role.id}
                  className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                    selectedRole?.id === role.id
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedRole(role)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <h5 className="font-medium text-gray-900">{role.name}</h5>
                        {role.isSystem && (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800">
                            System
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mt-1">{role.description}</p>
                      <div className="text-xs text-gray-500 mt-2">
                        {role.permissions.filter(p => Object.values(p.actions).some(Boolean)).length} permissions enabled
                      </div>
                    </div>
                    {!role.isSystem && (
                      <div className="flex items-center space-x-2 ml-4">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedRole(role);
                            setIsEditingRole(true);
                          }}
                          className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                          title="Edit"
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteRole(role.id);
                          }}
                          className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Role Details */}
          <div className="space-y-4">
            {selectedRole ? (
              <div className="border border-gray-200 rounded-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-medium text-gray-900">Role Permissions: {selectedRole.name}</h4>
                  {!selectedRole.isSystem && (
                    <button
                      onClick={() => setIsEditingRole(!isEditingRole)}
                      className="text-blue-600 hover:text-blue-800 text-sm"
                    >
                      {isEditingRole ? 'View Mode' : 'Edit Mode'}
                    </button>
                  )}
                </div>

                <div className="space-y-4">
                  {selectedRole.permissions.map(permission => (
                    <div key={permission.id} className="border border-gray-100 rounded-lg p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h5 className="font-medium text-gray-900">{permission.name}</h5>
                          <p className="text-sm text-gray-600">{permission.description}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        {Object.entries(permission.actions).map(([action, enabled]) => (
                          <label key={action} className="flex items-center space-x-2">
                            <input
                              type="checkbox"
                              checked={enabled}
                              disabled={!isEditingRole || selectedRole.isSystem}
                              onChange={(e) => handleUpdateRolePermissions(
                                selectedRole.id,
                                permission.id,
                                action as keyof Permission['actions'],
                                e.target.checked
                              )}
                              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 disabled:opacity-50"
                            />
                            <span className="text-sm text-gray-700 capitalize">{action}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                {isEditingRole && !selectedRole.isSystem && (
                  <div className="mt-6 flex items-center justify-end space-x-3">
                    <button
                      onClick={() => setIsEditingRole(false)}
                      className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => setIsEditingRole(false)}
                      className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700"
                    >
                      <Save className="h-4 w-4 mr-2" />
                      Save Changes
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="border border-gray-200 rounded-lg p-6 text-center">
                <Users className="h-8 w-8 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500">Select a role to view and edit permissions</p>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Permission Matrix</h3>
            <p className="text-gray-600">Overview of all permissions across different roles</p>
          </div>

          <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Permission
                    </th>
                    {roles.map(role => (
                      <th key={role.id} className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {role.name}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {defaultPermissions.map(permission => (
                    <tr key={permission.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>
                          <div className="text-sm font-medium text-gray-900">{permission.name}</div>
                          <div className="text-sm text-gray-500">{permission.description}</div>
                        </div>
                      </td>
                      {roles.map(role => {
                        const rolePermission = role.permissions.find(p => p.id === permission.id);
                        const hasAnyPermission = rolePermission && Object.values(rolePermission.actions).some(Boolean);
                        
                        return (
                          <td key={role.id} className="px-6 py-4 whitespace-nowrap text-center">
                            {hasAnyPermission ? (
                              <Check className="h-5 w-5 text-green-600 mx-auto" />
                            ) : (
                              <X className="h-5 w-5 text-red-400 mx-auto" />
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Create Role Modal */}
      {isEditingRole && !selectedRole && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Create New Role</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Role Name
                  </label>
                  <input
                    type="text"
                    value={newRoleName}
                    onChange={(e) => setNewRoleName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter role name"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    value={newRoleDescription}
                    onChange={(e) => setNewRoleDescription(e.target.value)}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Describe this role's purpose and responsibilities"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end space-x-3 mt-6">
                <button
                  onClick={() => {
                    setIsEditingRole(false);
                    setNewRoleName('');
                    setNewRoleDescription('');
                  }}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleCreateRole}
                  disabled={!newRoleName.trim()}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Create Role
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  const renderOrganizationTab = () => (
    <div className="space-y-6">
      {/* Sub-navigation */}
      <div className="flex items-center space-x-4 border-b border-gray-200 pb-4">
        <button
          onClick={() => setOrganizationView('locations')}
          className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
            organizationView === 'locations' 
              ? 'bg-blue-100 text-blue-700' 
              : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          Locations
        </button>
        <button
          onClick={() => setOrganizationView('teams')}
          className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
            organizationView === 'teams' 
              ? 'bg-blue-100 text-blue-700' 
              : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          Teams
        </button>
      </div>

      {organizationView === 'locations' ? (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Locations</h3>
              <p className="text-gray-600">Manage multiple business locations and assign users and data to specific locations</p>
            </div>
            <button
              onClick={handleCreateLocation}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Location
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {locations.map(location => (
              <div key={location.id} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h4 className="font-medium text-gray-900">{location.name}</h4>
                    {location.address && (
                      <p className="text-sm text-gray-600 mt-1">{location.address}</p>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleEditLocation(location)}
                      className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                      title="Edit"
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteLocation(location.id)}
                      className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  {location.phone && (
                    <div className="flex items-center text-sm text-gray-600">
                      <Phone className="h-4 w-4 mr-2 text-gray-400" />
                      {location.phone}
                    </div>
                  )}
                  
                  {location.email && (
                    <div className="flex items-center text-sm text-gray-600">
                      <Mail className="h-4 w-4 mr-2 text-gray-400" />
                      {location.email}
                    </div>
                  )}
                  
                  {/* Show teams associated with this location */}
                  <div className="mt-4 pt-4 border-t border-gray-100">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Teams:</span>
                      <span className="font-medium">{teams.filter(t => t.locationId === location.id).length}</span>
                    </div>
                    {teams.filter(t => t.locationId === location.id).length > 0 && (
                      <div className="mt-2 space-y-1">
                        {teams.filter(t => t.locationId === location.id).map(team => (
                          <div key={team.id} className="flex items-center text-sm">
                            <div 
                              className="w-3 h-3 rounded-full mr-2"
                              style={{ backgroundColor: team.color }}
                            />
                            <span>{team.name}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {locations.length === 0 && (
            <div className="text-center py-12">
              <Building className="h-8 w-8 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500">No locations created yet. Add your first location to organize your data.</p>
            </div>
          )}
          
          {/* Location Modal */}
          {isLocationModalOpen && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
              <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
                <div className="p-6 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900">
                    {editingLocation ? 'Edit Location' : 'Add New Location'}
                  </h3>
                </div>
                
                <div className="p-6 space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Location Name *
                    </label>
                    <input
                      type="text"
                      value={newLocationName}
                      onChange={(e) => setNewLocationName(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Enter location name"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Address
                    </label>
                    <input
                      type="text"
                      value={newLocationAddress}
                      onChange={(e) => setNewLocationAddress(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Enter location address"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Phone
                    </label>
                    <input
                      type="tel"
                      value={newLocationPhone}
                      onChange={(e) => setNewLocationPhone(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="(555) 123-4567"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      value={newLocationEmail}
                      onChange={(e) => setNewLocationEmail(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="location@example.com"
                    />
                  </div>
                </div>
                
                <div className="p-6 border-t border-gray-200 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setIsLocationModalOpen(false)}
                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveLocation}
                    className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700"
                  >
                    {editingLocation ? 'Update Location' : 'Add Location'}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Teams & Groups</h3>
              <p className="text-gray-600">Organize users into teams for better collaboration and filtering</p>
            </div>
            <button
              onClick={handleCreateTeam}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Team
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {teams.map(team => (
              <div key={team.id} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: team.color }}
                    />
                    <div>
                      <h4 className="font-medium text-gray-900">{team.name}</h4>
                      {team.description && (
                        <p className="text-sm text-gray-600 mt-1">{team.description}</p>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleEditTeam(team)}
                      className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                      title="Edit"
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteTeam(team.id)}
                      className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Team Leader:</span>
                    <span className="font-medium">Leader {team.leaderId.slice(-1)}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Members:</span>
                    <span className="font-medium">{team.members?.length || 0}</span>
                  </div>
                  {team.location && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Location:</span>
                      <span className="font-medium">{team.location.name}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {teams.length === 0 && (
            <div className="text-center py-12">
              <Users className="h-8 w-8 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500">No teams created yet. Create your first team to organize users.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );

  const renderNotificationsTab = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900">Notification Settings</h3>
        <p className="text-gray-600">Configure system notifications and alerts</p>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h4 className="font-medium text-gray-900 mb-4">Email Notifications</h4>
        <div className="space-y-4">
          {[
            { id: 'new_leads', label: 'New Lead Created', description: 'Notify when a new lead is added to the system' },
            { id: 'job_assigned', label: 'Job Assigned', description: 'Notify when a job is assigned to a technician' },
            { id: 'estimate_approved', label: 'Estimate Approved', description: 'Notify when an estimate is approved by a customer' },
            { id: 'payment_received', label: 'Payment Received', description: 'Notify when a payment is processed' },
            { id: 'task_overdue', label: 'Task Overdue', description: 'Notify when tasks become overdue' },
          ].map(notification => (
            <label key={notification.id} className="flex items-start space-x-3">
              <input
                type="checkbox"
                defaultChecked
                className="mt-1 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <div>
                <div className="text-sm font-medium text-gray-900">{notification.label}</div>
                <div className="text-sm text-gray-600">{notification.description}</div>
              </div>
            </label>
          ))}
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h4 className="font-medium text-gray-900 mb-4">SMS Notifications</h4>
        <div className="space-y-4">
          {[
            { id: 'urgent_tasks', label: 'Urgent Tasks', description: 'Send SMS for high-priority task assignments' },
            { id: 'job_reminders', label: 'Job Reminders', description: 'Send SMS reminders 1 hour before scheduled jobs' },
            { id: 'customer_messages', label: 'Customer Messages', description: 'Forward customer messages via SMS' },
          ].map(notification => (
            <label key={notification.id} className="flex items-start space-x-3">
              <input
                type="checkbox"
                defaultChecked={notification.id === 'urgent_tasks'}
                className="mt-1 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <div>
                <div className="text-sm font-medium text-gray-900">{notification.label}</div>
                <div className="text-sm text-gray-600">{notification.description}</div>
              </div>
            </label>
          ))}
        </div>
      </div>
    </div>
  );

  const renderIntegrationsTab = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900">Third-Party Integrations</h3>
        <p className="text-gray-600">Configure external service integrations</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {[
          {
            name: 'CallRail',
            description: 'Automatic lead creation from phone calls',
            status: 'connected',
            icon: '📞'
          },
          {
            name: 'Twilio',
            description: 'SMS messaging and notifications',
            status: 'connected',
            icon: '💬'
          },
          {
            name: 'Stripe',
            description: 'Payment processing and invoicing',
            status: 'disconnected',
            icon: '💳'
          },
          {
            name: 'QuickBooks',
            description: 'Accounting and financial management',
            status: 'disconnected',
            icon: '📊'
          },
          {
            name: 'Google Calendar',
            description: 'Job scheduling and calendar sync',
            status: 'disconnected',
            icon: '📅'
          },
          {
            name: 'Zapier',
            description: 'Workflow automation and integrations',
            status: 'disconnected',
            icon: '⚡'
          }
        ].map(integration => (
          <div key={integration.name} className="bg-white border border-gray-200 rounded-lg p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="text-2xl">{integration.icon}</div>
                <div>
                  <h4 className="font-medium text-gray-900">{integration.name}</h4>
                  <p className="text-sm text-gray-600">{integration.description}</p>
                </div>
              </div>
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                integration.status === 'connected'
                  ? 'bg-green-100 text-green-800'
                  : 'bg-gray-100 text-gray-800'
              }`}>
                {integration.status}
              </span>
            </div>
            
            <button className={`w-full px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              integration.status === 'connected'
                ? 'text-red-600 bg-red-50 hover:bg-red-100'
                : 'text-blue-600 bg-blue-50 hover:bg-blue-100'
            }`}>
              {integration.status === 'connected' ? 'Disconnect' : 'Connect'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );

  const renderAppearanceTab = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900">Appearance Settings</h3>
        <p className="text-gray-600">Customize the look and feel of the application</p>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h4 className="font-medium text-gray-900 mb-4">Theme</h4>
        <div className="grid grid-cols-3 gap-4">
          {[
            { id: 'light', name: 'Light', preview: 'bg-white border-2 border-gray-200' },
            { id: 'dark', name: 'Dark', preview: 'bg-gray-900 border-2 border-gray-700' },
            { id: 'auto', name: 'Auto', preview: 'bg-gradient-to-r from-white to-gray-900 border-2 border-gray-400' }
          ].map(theme => (
            <label key={theme.id} className="cursor-pointer">
              <input type="radio" name="theme" value={theme.id} defaultChecked={theme.id === 'light'} className="sr-only" />
              <div className="p-4 rounded-lg border-2 border-transparent hover:border-blue-500 transition-colors">
                <div className={`w-full h-20 rounded-lg mb-2 ${theme.preview}`}></div>
                <div className="text-sm font-medium text-gray-900 text-center">{theme.name}</div>
              </div>
            </label>
          ))}
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h4 className="font-medium text-gray-900 mb-4">Brand Colors</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Primary Color</label>
            <div className="flex items-center space-x-3">
              <input type="color" value="#3B82F6" className="w-12 h-10 rounded border border-gray-300" />
              <input type="text" value="#3B82F6" className="flex-1 px-3 py-2 border border-gray-300 rounded-lg" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Secondary Color</label>
            <div className="flex items-center space-x-3">
              <input type="color" value="#F59E0B" className="w-12 h-10 rounded border border-gray-300" />
              <input type="text" value="#F59E0B" className="flex-1 px-3 py-2 border border-gray-300 rounded-lg" />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h4 className="font-medium text-gray-900 mb-4">Layout Options</h4>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Default Dashboard Layout</label>
            <div className="grid grid-cols-2 gap-4">
              <label className="cursor-pointer">
                <input type="radio" name="layout" value="cards" defaultChecked className="sr-only" />
                <div className="p-4 rounded-lg border-2 border-transparent hover:border-blue-500 transition-colors">
                  <div className="w-full h-20 bg-gray-100 rounded-lg mb-2 flex items-center justify-center">
                    <Layout className="h-8 w-8 text-gray-400" />
                  </div>
                  <div className="text-sm font-medium text-gray-900 text-center">Cards</div>
                </div>
              </label>
              <label className="cursor-pointer">
                <input type="radio" name="layout" value="list" className="sr-only" />
                <div className="p-4 rounded-lg border-2 border-transparent hover:border-blue-500 transition-colors">
                  <div className="w-full h-20 bg-gray-100 rounded-lg mb-2 flex items-center justify-center">
                    <Layout className="h-8 w-8 text-gray-400" />
                  </div>
                  <div className="text-sm font-medium text-gray-900 text-center">List</div>
                </div>
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderSecurityTab = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900">Security Settings</h3>
        <p className="text-gray-600">Configure security policies and access controls</p>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h4 className="font-medium text-gray-900 mb-4">Password Policy</h4>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Minimum Length</label>
              <input type="number" defaultValue={8} min={6} max={20} className="w-full px-3 py-2 border border-gray-300 rounded-lg" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Password Expiry (days)</label>
              <input type="number" defaultValue={90} min={30} max={365} className="w-full px-3 py-2 border border-gray-300 rounded-lg" />
            </div>
          </div>
          
          <div className="space-y-3">
            {[
              'Require uppercase letters',
              'Require lowercase letters',
              'Require numbers',
              'Require special characters',
              'Prevent password reuse (last 5 passwords)'
            ].map(requirement => (
              <label key={requirement} className="flex items-center space-x-3">
                <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
                <span className="text-sm text-gray-700">{requirement}</span>
              </label>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h4 className="font-medium text-gray-900 mb-4">Session Management</h4>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Session Timeout (minutes)</label>
              <input type="number" defaultValue={60} min={15} max={480} className="w-full px-3 py-2 border border-gray-300 rounded-lg" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Max Concurrent Sessions</label>
              <input type="number" defaultValue={3} min={1} max={10} className="w-full px-3 py-2 border border-gray-300 rounded-lg" />
            </div>
          </div>
          
          <div className="space-y-3">
            {[
              'Force logout on password change',
              'Require re-authentication for sensitive actions',
              'Log all user activities',
              'Enable two-factor authentication'
            ].map(setting => (
              <label key={setting} className="flex items-center space-x-3">
                <input type="checkbox" defaultChecked={setting.includes('Log')} className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
                <span className="text-sm text-gray-700">{setting}</span>
              </label>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h4 className="font-medium text-gray-900 mb-4">Data Protection</h4>
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Data Retention Period (days)</label>
              <input type="number" defaultValue={365} min={30} max={3650} className="w-full px-3 py-2 border border-gray-300 rounded-lg" />
              <p className="mt-1 text-xs text-gray-500">Deleted data will be permanently removed after this period</p>
            </div>
          </div>
          
          <div className="space-y-3">
            {[
              'Enable data encryption at rest',
              'Enable data encryption in transit',
              'Anonymize customer data on deletion',
              'Regular security audits'
            ].map(setting => (
              <label key={setting} className="flex items-center space-x-3">
                <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
                <span className="text-sm text-gray-700">{setting}</span>
              </label>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'access-control': return renderAccessControlTab();
      case 'organization': return renderOrganizationTab();
      case 'notifications': return renderNotificationsTab();
      case 'integrations': return renderIntegrationsTab();
      case 'appearance': return renderAppearanceTab();
      case 'security': return renderSecurityTab();
      default: return renderAccessControlTab();
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-600">Configure system settings, user permissions, and team organization</p>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="flex space-x-8">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Content */}
      <div className="pb-6">
        {renderTabContent()}
      </div>

      {/* Team Modal */}
      <TeamModal
        isOpen={isTeamModalOpen}
        onClose={() => setIsTeamModalOpen(false)}
        onSave={handleSaveTeam}
        team={editingTeam}
      />

      {/* Save Button */}
      <div className="fixed bottom-6 right-6">
        <button className="flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg shadow-lg hover:bg-blue-700 transition-colors">
          <Save className="h-5 w-5 mr-2" />
          Save All Changes
        </button>
      </div>
    </div>
  );
}