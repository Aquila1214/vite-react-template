import React, { useEffect, useState } from 'react';
import { useCrmStore } from '../stores/crmStore';
import { Plus, Search, Filter, ChevronDown, User, Phone, Mail, Building, Tag, Edit, Trash2, Eye, X } from 'lucide-react';
import { GeneralContact, ContactLabel } from '../types';
import { formatPhone } from '../lib/utils';
import { GeneralContactModal } from '../components/GeneralContacts/GeneralContactModal';
import { ContactLabelManager } from '../components/GeneralContacts/ContactLabelManager';
import { GeneralContactDetailModal } from '../components/GeneralContacts/GeneralContactDetailModal';

export function GeneralContacts() {
  const { 
    generalContacts, 
    contactLabels,
    isLoading, 
    error, 
    fetchGeneralContacts,
    fetchContactLabels,
    createGeneralContact,
    updateGeneralContact,
    deleteGeneralContact,
    addLabelToContact,
    removeLabelFromContact
  } = useCrmStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLabelIds, setSelectedLabelIds] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [sortBy, setSortBy] = useState<'name' | 'date'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [isLabelManagerOpen, setIsLabelManagerOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [selectedContact, setSelectedContact] = useState<GeneralContact | null>(null);
  const [editingContact, setEditingContact] = useState<GeneralContact | null>(null);

  useEffect(() => {
    fetchGeneralContacts();
    fetchContactLabels();
  }, [fetchGeneralContacts, fetchContactLabels]);

  const filteredContacts = generalContacts.filter(contact => {
    const matchesSearch = 
      contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (contact.businessName && contact.businessName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (contact.phone && contact.phone.includes(searchTerm)) ||
      (contact.email && contact.email.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (contact.notes && contact.notes.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesLabels = selectedLabelIds.length === 0 || 
      (contact.labels && contact.labels.some(label => selectedLabelIds.includes(label.id)));
    
    return matchesSearch && matchesLabels;
  }).sort((a, b) => {
    if (sortBy === 'name') {
      return sortOrder === 'asc' 
        ? a.name.localeCompare(b.name)
        : b.name.localeCompare(a.name);
    } else {
      return sortOrder === 'asc'
        ? new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
        : new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
  });

  const handleCreateContact = () => {
    setEditingContact(null);
    setIsContactModalOpen(true);
  };

  const handleEditContact = (contact: GeneralContact) => {
    setEditingContact(contact);
    setIsContactModalOpen(true);
  };

  const handleViewContact = (contact: GeneralContact) => {
    setSelectedContact(contact);
    setIsDetailModalOpen(true);
  };

  const handleDeleteContact = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this contact? This action cannot be undone.')) {
      await deleteGeneralContact(id);
    }
  };

  const handleSaveContact = async (contactData: Partial<GeneralContact>) => {
    if (editingContact) {
      await updateGeneralContact(editingContact.id, contactData);
    } else {
      await createGeneralContact(contactData);
    }
    setIsContactModalOpen(false);
  };

  const handleToggleLabel = (labelId: string) => {
    setSelectedLabelIds(prev => 
      prev.includes(labelId)
        ? prev.filter(id => id !== labelId)
        : [...prev, labelId]
    );
  };

  const toggleSort = (field: 'name' | 'date') => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('asc');
    }
  };

  const handleAddLabelToContact = async (contactId: string, labelId: string) => {
    await addLabelToContact(contactId, labelId);
  };

  const handleRemoveLabelFromContact = async (contactId: string, labelId: string) => {
    await removeLabelFromContact(contactId, labelId);
  };

  if (error) {
    return (
      <div className="rounded-md bg-red-50 p-4">
        <div className="text-sm text-red-700">{error}</div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="h-10 bg-gray-200 rounded animate-pulse"></div>
        {[...Array(5)].map((_, i) => (
          <div key={i} className="h-32 bg-gray-200 rounded animate-pulse"></div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900">General Contacts</h1>
          <p className="text-gray-600">Manage non-customer contacts, vendors, and other business relationships</p>
        </div>
        
        <div className="flex flex-wrap gap-2">
          <button 
            onClick={handleCreateContact}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="h-4 w-4 mr-2" />
            New Contact
          </button>
          
          <button 
            onClick={() => setIsLabelManagerOpen(true)}
            className="flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            <Tag className="h-4 w-4 mr-2" />
            Manage Labels
          </button>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search contacts by name, business, phone, or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2 sm:gap-4">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <Filter className="h-4 w-4 mr-2" />
              Filters
              <ChevronDown className="h-4 w-4 ml-2" />
            </button>
            
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-600">Sort by:</span>
              <button
                onClick={() => toggleSort('name')}
                className={`px-3 py-2 text-sm rounded-lg transition-colors ${
                  sortBy === 'name' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'
                }`}
              >
                Name {sortBy === 'name' && (sortOrder === 'asc' ? '↑' : '↓')}
              </button>
              <button
                onClick={() => toggleSort('date')}
                className={`px-3 py-2 text-sm rounded-lg transition-colors ${
                  sortBy === 'date' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'
                }`}
              >
                Date {sortBy === 'date' && (sortOrder === 'asc' ? '↑' : '↓')}
              </button>
            </div>
          </div>
        </div>
        
        {showFilters && (
          <div className="mt-4 pt-4 border-t border-gray-200">
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-2">Filter by Labels</h3>
              <div className="flex flex-wrap gap-2">
                {contactLabels.map(label => (
                  <label 
                    key={label.id} 
                    className={`inline-flex items-center px-3 py-2 rounded-lg cursor-pointer transition-colors ${
                      selectedLabelIds.includes(label.id)
                        ? 'bg-gray-800 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                    style={{
                      backgroundColor: selectedLabelIds.includes(label.id) ? label.color : undefined,
                      color: selectedLabelIds.includes(label.id) ? '#fff' : undefined
                    }}
                  >
                    <input
                      type="checkbox"
                      checked={selectedLabelIds.includes(label.id)}
                      onChange={() => handleToggleLabel(label.id)}
                      className="sr-only"
                    />
                    <span>{label.name}</span>
                    {selectedLabelIds.includes(label.id) && (
                      <X className="h-4 w-4 ml-2" />
                    )}
                  </label>
                ))}
                
                {contactLabels.length === 0 && (
                  <p className="text-sm text-gray-500">No labels created yet. Use the "Manage Labels" button to create labels.</p>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Contacts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-6">
        {filteredContacts.map((contact) => (
          <div key={contact.id} className="bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
            <div className="p-4 sm:p-6 border-b border-gray-100">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">
                    {contact.name}
                  </h3>
                  
                  {contact.businessName && (
                    <div className="flex items-center text-sm text-gray-600 mb-2">
                      <Building className="h-4 w-4 mr-2 text-gray-400" />
                      {contact.businessName}
                    </div>
                  )}
                  
                  <div className="space-y-2">
                    {contact.phone && (
                      <div className="flex items-center text-sm text-gray-600">
                        <Phone className="h-4 w-4 mr-2 text-gray-400" />
                        {formatPhone(contact.phone)}
                      </div>
                    )}
                    
                    {contact.email && (
                      <div className="flex items-center text-sm text-gray-600">
                        <Mail className="h-4 w-4 mr-2 text-gray-400" />
                        {contact.email}
                      </div>
                    )}
                  </div>

                  {/* Labels */}
                  {contact.labels && contact.labels.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-3">
                      {contact.labels.map(label => (
                        <span 
                          key={label.id} 
                          className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium text-white"
                          style={{ backgroundColor: label.color }}
                        >
                          {label.name}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                
                <div className="flex items-center space-x-2 ml-4">
                  <button
                    onClick={() => handleViewContact(contact)}
                    className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    title="View Details"
                  >
                    <Eye className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handleEditContact(contact)}
                    className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    title="Edit"
                  >
                    <Edit className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handleDeleteContact(contact.id)}
                    className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    title="Delete"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
              
              {contact.notes && (
                <div className="mb-4">
                  <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg line-clamp-2">
                    {contact.notes}
                  </p>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
      
      {filteredContacts.length === 0 && (
        <div className="text-center py-12">
          <User className="h-8 w-8 mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500">
            {generalContacts.length === 0 ? 'No contacts found. Add your first contact!' : 'No contacts match your search criteria.'}
          </p>
          {generalContacts.length === 0 && (
            <button 
              onClick={handleCreateContact}
              className="mt-4 inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Contact
            </button>
          )}
        </div>
      )}

      {/* Contact Modal */}
      <GeneralContactModal
        isOpen={isContactModalOpen}
        onClose={() => setIsContactModalOpen(false)}
        onSave={handleSaveContact}
        contact={editingContact}
        labels={contactLabels}
      />

      {/* Label Manager Modal */}
      <ContactLabelManager
        isOpen={isLabelManagerOpen}
        onClose={() => setIsLabelManagerOpen(false)}
      />

      {/* Contact Detail Modal */}
      <GeneralContactDetailModal
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        contact={selectedContact}
        onEdit={handleEditContact}
        onAddLabel={handleAddLabelToContact}
        onRemoveLabel={handleRemoveLabelFromContact}
        availableLabels={contactLabels}
      />
    </div>
  );
}