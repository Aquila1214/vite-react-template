import React, { useEffect, useState } from 'react';
import { Plus, Search, MessageSquare, Phone, Mail, Send, Filter, User, ArrowLeft, ChevronDown, X, ExternalLink, Clock, CheckCircle, AlertTriangle, UserPlus, Link, UserCheck } from 'lucide-react';
import { formatDateTime, formatPhone } from '../lib/utils';
import { useCrmStore } from '../stores/crmStore';
import { useAuthStore } from '../stores/authStore';
import { Message, Customer, UnknownContact } from '../types';
import { CustomerSelectForMessageModal } from '../components/Messages/CustomerSelectForMessageModal';
import { MessageComposer } from '../components/Messages/MessageComposer';
import { NewContactModal } from '../components/Messages/NewContactModal';
import { ConvertContactModal } from '../components/Messages/ConvertContactModal';

export function Messages() {
  const { user: currentUser } = useAuthStore();
  const { 
    messages, 
    customers, 
    users, 
    unknownContacts,
    fetchMessages, 
    fetchCustomers, 
    fetchUsers, 
    fetchUnknownContacts,
    createMessage,
    addUnknownContact,
    convertUnknownToCustomer,
    linkUnknownToCustomer
  } = useCrmStore();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilters, setTypeFilters] = useState<string[]>([]);
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);
  const [isCustomer, setIsCustomer] = useState(true);
  const [newMessage, setNewMessage] = useState('');
  const [selectedSendTypes, setSelectedSendTypes] = useState<('SMS' | 'EMAIL')[]>(['SMS']);
  const [showFilters, setShowFilters] = useState(false);
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');
  const [isCustomerSelectModalOpen, setIsCustomerSelectModalOpen] = useState(false);
  const [isNewContactModalOpen, setIsNewContactModalOpen] = useState(false);
  const [isConvertContactModalOpen, setIsConvertContactModalOpen] = useState(false);
  const [selectedUnknownContact, setSelectedUnknownContact] = useState<UnknownContact | null>(null);

  useEffect(() => {
    fetchMessages();
    fetchCustomers();
    fetchUsers();
    fetchUnknownContacts();
  }, [fetchMessages, fetchCustomers, fetchUsers, fetchUnknownContacts]);

  // Create a unique identifier for each conversation
  const getConversationId = (message: Message): string => {
    if (message.customerId) return `customer-${message.customerId}`;
    if (message.unknownContactId) return `unknown-${message.unknownContactId}`;
    if (message.fromPhone) return `phone-${message.fromPhone}`;
    if (message.fromEmail) return `email-${message.fromEmail}`;
    return `unknown-${message.id}`;
  };

  // Get conversation partner details
  const getConversationPartner = (conversationId: string) => {
    if (conversationId.startsWith('customer-')) {
      const customerId = conversationId.replace('customer-', '');
      return {
        isCustomer: true,
        data: customers.find(c => c.id === customerId) || null
      };
    } else if (conversationId.startsWith('unknown-')) {
      const unknownId = conversationId.replace('unknown-', '');
      return {
        isCustomer: false,
        data: unknownContacts.find(c => c.id === unknownId) || null
      };
    } else if (conversationId.startsWith('phone-')) {
      const phone = conversationId.replace('phone-', '');
      return {
        isCustomer: false,
        data: { phone, name: 'Unknown Caller' }
      };
    } else if (conversationId.startsWith('email-')) {
      const email = conversationId.replace('email-', '');
      return {
        isCustomer: false,
        data: { email, name: 'Unknown Contact' }
      };
    }
    return { isCustomer: false, data: null };
  };

  const filteredMessages = messages.filter(message => {
    const matchesSearch = 
      message.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (message.customerId && customers.find(c => c.id === message.customerId)?.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (message.userId && users.find(u => u.id === message.userId)?.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (message.fromName && message.fromName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (message.fromPhone && message.fromPhone.includes(searchTerm)) ||
      (message.fromEmail && message.fromEmail.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesType = typeFilters.length === 0 || typeFilters.includes(message.type);
    
    return matchesSearch && matchesType;
  });

  // Group messages by conversation
  const conversations = filteredMessages.reduce((acc, message) => {
    const conversationId = getConversationId(message);
    if (!acc[conversationId]) {
      acc[conversationId] = [];
    }
    acc[conversationId].push(message);
    return acc;
  }, {} as Record<string, Message[]>);

  // Sort conversations by most recent message
  const sortedConversations = Object.entries(conversations)
    .map(([conversationId, messages]) => {
      // Sort messages within conversation by timestamp
      const sortedMessages = [...messages].sort((a, b) => 
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );
      
      const partner = getConversationPartner(conversationId);
      
      return {
        id: conversationId,
        messages: sortedMessages,
        latestMessage: sortedMessages[0],
        isCustomer: partner.isCustomer,
        partner: partner.data
      };
    })
    .sort((a, b) => 
      new Date(b.latestMessage.timestamp).getTime() - new Date(a.latestMessage.timestamp).getTime()
    );

  const getMessageIcon = (type: string) => {
    switch (type) {
      case 'SMS':
        return <MessageSquare className="h-4 w-4 text-blue-600" />;
      case 'EMAIL':
        return <Mail className="h-4 w-4 text-green-600" />;
      default:
        return <MessageSquare className="h-4 w-4 text-gray-400" />;
    }
  };

  const getMessageTypeColor = (type: string) => {
    switch (type) {
      case 'SMS':
        return 'bg-blue-100 text-blue-800';
      case 'EMAIL':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getDirectionColor = (direction: string) => {
    return direction === 'INBOUND' 
      ? 'bg-yellow-100 text-yellow-800' 
      : 'bg-green-100 text-green-800';
  };

  const handleSendMessage = () => {
    if (!newMessage.trim() || !selectedConversationId || selectedSendTypes.length === 0) return;

    const partner = getConversationPartner(selectedConversationId);
    
    // Create a message for each selected type
    selectedSendTypes.forEach(type => {
      let messageData: Partial<Message> = {
        type: type,
        content: newMessage,
        direction: 'OUTBOUND',
        timestamp: new Date().toISOString(),
        userId: currentUser?.id
      };

      if (partner.isCustomer && partner.data) {
        // Message to a known customer
        messageData.customerId = (partner.data as Customer).id;
      } else if (!partner.isCustomer && partner.data) {
        // Message to an unknown contact
        if ('id' in partner.data) {
          // Known unknown contact
          messageData.unknownContactId = (partner.data as UnknownContact).id;
        } else {
          // New unknown contact
          if ('phone' in partner.data) {
            messageData.fromPhone = partner.data.phone as string;
          }
          if ('email' in partner.data) {
            messageData.fromEmail = partner.data.email as string;
          }
          messageData.fromName = partner.data.name as string;
        }
      }

      createMessage(messageData);
    });
    
    setNewMessage('');
  };

  const handleSelectConversation = (conversationId: string, isCustomer: boolean) => {
    setSelectedConversationId(conversationId);
    setIsCustomer(isCustomer);
  };

  const handleBackToList = () => {
    setSelectedConversationId(null);
  };

  const handleNewMessage = () => {
    setIsCustomerSelectModalOpen(true);
  };

  const handleNewContact = () => {
    setIsNewContactModalOpen(true);
  };

  const handleCustomerSelected = (customer: Customer) => {
    setSelectedConversationId(`customer-${customer.id}`);
    setIsCustomer(true);
    setIsCustomerSelectModalOpen(false);
  };

  const handleCreateUnknownContact = async (contactData: Partial<UnknownContact>) => {
    const newContact = await addUnknownContact(contactData);
    setSelectedConversationId(`unknown-${newContact.id}`);
    setIsCustomer(false);
    setIsNewContactModalOpen(false);
  };

  const handleConvertToCustomer = (unknownContact: UnknownContact) => {
    setSelectedUnknownContact(unknownContact);
    setIsConvertContactModalOpen(true);
  };

  const handleLinkToCustomer = (unknownContact: UnknownContact, customer: Customer) => {
    linkUnknownToCustomer(unknownContact.id, customer.id);
    setSelectedConversationId(`customer-${customer.id}`);
    setIsCustomer(true);
  };

  const handleConvertContactSubmit = async (customerData: Partial<Customer>) => {
    if (!selectedUnknownContact) return;
    
    await convertUnknownToCustomer(selectedUnknownContact.id, customerData);
    setIsConvertContactModalOpen(false);
    
    // Find the newly created customer
    const newCustomer = customers.find(c => 
      c.phone === selectedUnknownContact.phone || 
      c.email === selectedUnknownContact.email
    );
    
    if (newCustomer) {
      setSelectedConversationId(`customer-${newCustomer.id}`);
      setIsCustomer(true);
    } else {
      // Fallback to conversation list if we can't find the new customer
      setSelectedConversationId(null);
    }
    
    setSelectedUnknownContact(null);
  };

  const getUserName = (userId?: string) => {
    if (!userId) return 'System';
    const user = users.find(u => u.id === userId);
    return user ? user.name : 'Unknown User';
  };

  const getContactName = (message: Message): string => {
    if (message.customerId) {
      const customer = customers.find(c => c.id === message.customerId);
      return customer ? customer.name : 'Unknown Customer';
    }
    
    if (message.unknownContactId) {
      const contact = unknownContacts.find(c => c.id === message.unknownContactId);
      return contact?.name || 'Unknown Contact';
    }
    
    return message.fromName || 'Unknown Contact';
  };

  const getContactInfo = (message: Message): { phone?: string; email?: string } => {
    if (message.customerId) {
      const customer = customers.find(c => c.id === message.customerId);
      return { 
        phone: customer?.phone,
        email: customer?.email
      };
    }
    
    if (message.unknownContactId) {
      const contact = unknownContacts.find(c => c.id === message.unknownContactId);
      return {
        phone: contact?.phone,
        email: contact?.email
      };
    }
    
    return {
      phone: message.fromPhone,
      email: message.fromEmail
    };
  };

  const handleToggleMessageType = (type: 'SMS' | 'EMAIL') => {
    setSelectedSendTypes(prev => {
      if (prev.includes(type)) {
        // Don't allow removing the last type
        if (prev.length === 1) return prev;
        return prev.filter(t => t !== type);
      } else {
        return [...prev, type];
      }
    });
  };

  const handleToggleTypeFilter = (type: string) => {
    setTypeFilters(prev => {
      if (prev.includes(type)) {
        return prev.filter(t => t !== type);
      } else {
        return [...prev, type];
      }
    });
  };

  const renderMessageList = () => (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900">Messages</h1>
          <p className="text-gray-600">Manage SMS and email communications</p>
        </div>
        
        <div className="flex flex-wrap gap-2">
          <button 
            onClick={handleNewMessage}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="h-4 w-4 mr-2" />
            New Message
          </button>
          
          <button 
            onClick={handleNewContact}
            className="flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            <UserPlus className="h-4 w-4 mr-2" />
            New Contact
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search messages..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2 sm:gap-4">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <Filter className="h-4 w-4 mr-2" />
              Filters
              <ChevronDown className="h-4 w-4 ml-2" />
            </button>
            
            <select
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value as 'newest' | 'oldest')}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="newest">Newest First</option>
              <option value="oldest">Oldest First</option>
            </select>
          </div>
        </div>
        
        {showFilters && (
          <div className="mt-4 pt-4 border-t border-gray-200">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Message Type
                </label>
                <div className="flex flex-wrap gap-2">
                  <label className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={typeFilters.includes('SMS')}
                      onChange={() => handleToggleTypeFilter('SMS')}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 mr-2"
                    />
                    <MessageSquare className="h-4 w-4 text-blue-600 mr-2" />
                    SMS
                  </label>
                  <label className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={typeFilters.includes('EMAIL')}
                      onChange={() => handleToggleTypeFilter('EMAIL')}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 mr-2"
                    />
                    <Mail className="h-4 w-4 text-green-600 mr-2" />
                    Email
                  </label>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Contact Type
                </label>
                <div className="flex flex-wrap gap-2">
                  <label className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={true} // Always show customers
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 mr-2"
                    />
                    <User className="h-4 w-4 text-blue-600 mr-2" />
                    Customers
                  </label>
                  <label className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={true} // Always show unknown contacts
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 mr-2"
                    />
                    <UserPlus className="h-4 w-4 text-purple-600 mr-2" />
                    Unknown Contacts
                  </label>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Conversation List */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="divide-y divide-gray-200">
          {sortedConversations.length > 0 ? (
            sortedConversations.map(conversation => {
              const { id, latestMessage, isCustomer, partner } = conversation;
              
              return (
                <div 
                  key={id} 
                  className="p-4 hover:bg-gray-50 transition-colors cursor-pointer"
                  onClick={() => handleSelectConversation(id, isCustomer)}
                >
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        isCustomer ? 'bg-blue-100 text-blue-600' : 'bg-purple-100 text-purple-600'
                      }`}>
                        <User className="h-5 w-5" />
                      </div>
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="text-base font-medium text-gray-900 flex items-center">
                          {partner ? (
                            <>
                              {partner.name || 'Unknown Contact'}
                              {!isCustomer && (
                                <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                                  Unknown
                                </span>
                              )}
                            </>
                          ) : (
                            'Unknown Contact'
                          )}
                        </h3>
                        <span className="text-xs text-gray-500">
                          {new Date(latestMessage.timestamp).toLocaleDateString()}
                        </span>
                      </div>
                      
                      <div className="flex items-center space-x-2 mb-2">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${getMessageTypeColor(latestMessage.type)}`}>
                          {latestMessage.type}
                        </span>
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${getDirectionColor(latestMessage.direction)}`}>
                          {latestMessage.direction === 'INBOUND' ? 'Received' : 'Sent'}
                        </span>
                      </div>
                      
                      <p className="text-sm text-gray-600 line-clamp-2">
                        {latestMessage.content}
                      </p>
                      
                      <div className="mt-1 text-xs text-gray-500">
                        {conversation.messages.length > 1 && (
                          <span>{conversation.messages.length} messages in this thread</span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-12">
              <MessageSquare className="h-8 w-8 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500">
                {messages.length === 0 ? 'No messages found.' : 'No messages match your search criteria.'}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderMessageThread = () => {
    if (!selectedConversationId) return null;
    
    const partner = getConversationPartner(selectedConversationId);
    const threadMessages = messages
      .filter(message => getConversationId(message) === selectedConversationId)
      .sort((a, b) => 
        sortOrder === 'newest' 
          ? new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
          : new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
      );
    
    return (
      <div className="space-y-6">
        {/* Thread Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={handleBackToList}
              className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-full transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            
            <div className="flex-shrink-0">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                isCustomer ? 'bg-blue-100 text-blue-600' : 'bg-purple-100 text-purple-600'
              }`}>
                <User className="h-5 w-5" />
              </div>
            </div>
            
            <div>
              <h2 className="text-xl font-semibold text-gray-900 flex items-center">
                {partner.data ? (
                  <>
                    {(partner.data as any).name || 'Unknown Contact'}
                    {!isCustomer && (
                      <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                        Unknown
                      </span>
                    )}
                  </>
                ) : (
                  'Unknown Contact'
                )}
              </h2>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                {(partner.data as any)?.phone && (
                  <span className="flex items-center">
                    <Phone className="h-3 w-3 mr-1" />
                    {formatPhone((partner.data as any).phone)}
                  </span>
                )}
                {(partner.data as any)?.email && (
                  <span className="flex items-center">
                    <Mail className="h-3 w-3 mr-1" />
                    {(partner.data as any).email}
                  </span>
                )}
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            {!isCustomer && partner.data && (
              <>
                <button
                  onClick={() => handleConvertToCustomer(partner.data as UnknownContact)}
                  className="flex items-center px-3 py-2 text-sm text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
                >
                  <UserPlus className="h-4 w-4 mr-2" />
                  Add as Customer
                </button>
                <button
                  onClick={() => setIsCustomerSelectModalOpen(true)}
                  className="flex items-center px-3 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                >
                  <Link className="h-4 w-4 mr-2" />
                  Link to Customer
                </button>
              </>
            )}
            
            {isCustomer && partner.data && (
              <button
                onClick={() => {/* Navigate to customer profile */}}
                className="flex items-center px-3 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
              >
                <User className="h-4 w-4 mr-2" />
                View Profile
              </button>
            )}
          </div>
        </div>

        {/* Message Thread */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="p-4 border-b border-gray-200 flex items-center justify-between">
            <h3 className="font-medium text-gray-900">Conversation History</h3>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setSortOrder(sortOrder === 'newest' ? 'oldest' : 'newest')}
                className="flex items-center text-sm text-gray-600 hover:text-gray-900"
              >
                <Clock className="h-4 w-4 mr-1" />
                {sortOrder === 'newest' ? 'Newest first' : 'Oldest first'}
              </button>
            </div>
          </div>
          
          <div className="divide-y divide-gray-200 max-h-[500px] overflow-y-auto">
            {threadMessages.map((message) => (
              <div 
                key={message.id} 
                className="p-4 hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      message.direction === 'OUTBOUND' 
                        ? 'bg-blue-100' 
                        : 'bg-gray-100'
                    }`}>
                      {getMessageIcon(message.type)}
                    </div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center space-x-2">
                        <span className="font-medium text-gray-900">
                          {message.direction === 'INBOUND' 
                            ? getContactName(message)
                            : message.userId ? getUserName(message.userId) : 'System'
                          }
                        </span>
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${getMessageTypeColor(message.type)}`}>
                          {message.type}
                        </span>
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${getDirectionColor(message.direction)}`}>
                          {message.direction === 'INBOUND' ? 'Received' : 'Sent'}
                        </span>
                      </div>
                      <span className="text-xs text-gray-500">
                        {formatDateTime(message.timestamp)}
                      </span>
                    </div>
                    
                    <p className="text-gray-700 whitespace-pre-wrap">
                      {message.content}
                    </p>
                    
                    {message.direction === 'OUTBOUND' && (
                      <div className="mt-1 flex items-center text-xs text-gray-500">
                        <CheckCircle className="h-3 w-3 mr-1 text-green-500" />
                        <span>Delivered</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
            
            {threadMessages.length === 0 && (
              <div className="p-6 text-center">
                <p className="text-gray-500">No messages in this thread yet.</p>
              </div>
            )}
          </div>
        </div>

        {/* Message Composer */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex flex-col space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-medium text-gray-900">
                Send Message
              </h3>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <span>Sending as:</span>
                <span className="font-medium">{currentUser?.name || 'Company Name'}</span>
              </div>
            </div>
            
            <div className="flex flex-wrap gap-2">
              <label className={`inline-flex items-center px-3 py-2 border rounded-lg cursor-pointer ${
                selectedSendTypes.includes('SMS') 
                  ? 'bg-blue-100 border-blue-300 text-blue-800' 
                  : 'border-gray-300 hover:bg-gray-50'
              }`}>
                <input
                  type="checkbox"
                  checked={selectedSendTypes.includes('SMS')}
                  onChange={() => handleToggleMessageType('SMS')}
                  className="sr-only"
                />
                <MessageSquare className="h-4 w-4 mr-2" />
                SMS {(partner.data as any)?.phone ? `(${formatPhone((partner.data as any).phone)})` : ''}
              </label>
              
              <label className={`inline-flex items-center px-3 py-2 border rounded-lg cursor-pointer ${
                selectedSendTypes.includes('EMAIL') 
                  ? 'bg-green-100 border-green-300 text-green-800' 
                  : 'border-gray-300 hover:bg-gray-50'
              }`}>
                <input
                  type="checkbox"
                  checked={selectedSendTypes.includes('EMAIL')}
                  onChange={() => handleToggleMessageType('EMAIL')}
                  className="sr-only"
                />
                <Mail className="h-4 w-4 mr-2" />
                Email {(partner.data as any)?.email ? `(${(partner.data as any).email})` : ''}
              </label>
            </div>
            
            <div className="flex gap-3">
              <textarea
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder={`Type your message...`}
                className={`flex-1 px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  selectedSendTypes.length === 1 && selectedSendTypes[0] === 'SMS'
                    ? 'border-blue-200 bg-blue-50'
                    : selectedSendTypes.length === 1 && selectedSendTypes[0] === 'EMAIL'
                    ? 'border-green-200 bg-green-50'
                    : 'border-purple-200 bg-purple-50'
                }`}
                rows={3}
              />
              <div className="flex flex-col justify-end">
                <button
                  onClick={handleSendMessage}
                  disabled={!newMessage.trim() || selectedSendTypes.length === 0}
                  className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Send className="h-4 w-4 mr-2" />
                  Send
                </button>
              </div>
            </div>
            
            <div className="text-xs text-gray-500">
              {selectedSendTypes.includes('SMS') && selectedSendTypes.length === 1 && (
                <div className="flex items-center">
                  <AlertTriangle className="h-3 w-3 mr-1 text-amber-500" />
                  <span>SMS messages are limited to 160 characters. Longer messages will be split.</span>
                </div>
              )}
              {selectedSendTypes.includes('EMAIL') && selectedSendTypes.length === 1 && (
                <div className="flex items-center">
                  <Mail className="h-3 w-3 mr-1 text-gray-400" />
                  <span>Email will be sent from your company email address.</span>
                </div>
              )}
              {selectedSendTypes.length > 1 && (
                <div className="flex items-center">
                  <AlertTriangle className="h-3 w-3 mr-1 text-purple-500" />
                  <span>Message will be sent via {selectedSendTypes.join(' and ')}.</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {selectedConversationId ? renderMessageThread() : renderMessageList()}
      
      {/* Customer Select Modal */}
      <CustomerSelectForMessageModal
        isOpen={isCustomerSelectModalOpen}
        onClose={() => setIsCustomerSelectModalOpen(false)}
        onSelectCustomer={handleCustomerSelected}
      />
      
      {/* New Contact Modal */}
      <NewContactModal
        isOpen={isNewContactModalOpen}
        onClose={() => setIsNewContactModalOpen(false)}
        onSave={handleCreateUnknownContact}
      />
      
      {/* Convert Contact Modal */}
      <ConvertContactModal
        isOpen={isConvertContactModalOpen}
        onClose={() => setIsConvertContactModalOpen(false)}
        unknownContact={selectedUnknownContact}
        onSave={handleConvertContactSubmit}
      />
    </div>
  );
}