import React from 'react';
import { useAuthStore } from '../stores/authStore';

export function Users() {
  const { user } = useAuthStore();

  // Only admins can access this page
  if (user?.role !== 'ADMIN') {
    return (
      <div className="rounded-md bg-yellow-50 p-4">
        <div className="text-sm text-yellow-700">Access denied. Admin privileges required.</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Users</h1>
        <p className="text-gray-600">Manage system users and permissions</p>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <p className="text-gray-500">User management coming soon...</p>
      </div>
    </div>
  );
}