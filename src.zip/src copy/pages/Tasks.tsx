import React, { useEffect, useState } from 'react';
import { useCrmStore } from '../stores/crmStore';
import { useAuthStore } from '../stores/authStore';
import { Plus, Filter, Search, Calendar, User, CheckSquare, Clock, Eye, Edit, Trash2, Bell, Users, Tag, Briefcase } from 'lucide-react';
import { Task, Customer } from '../types';
import { formatDate, formatDateTime, getStatusColor } from '../lib/utils';
import { UserFilter } from '../components/Common/UserFilter';
import { TaskModal } from '../components/Tasks/TaskModal';

export function Tasks() {
  const { user: currentUser } = useAuthStore();
  const { 
    tasks, 
    users,
    customers,
    isLoading, 
    error, 
    fetchTasks,
    fetchUsers,
    fetchCustomers,
    createTask,
    updateTask,
    deleteTask
  } = useCrmStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [priorityFilter, setpriorityFilter] = useState('');
  const [selectedUserId, setSelectedUserId] = useState<string | null>(
    // Default to current user for non-admins
    currentUser?.role === 'ADMIN' ? null : currentUser?.id || null
  );
  const [selectedTeamId, setSelectedTeamId] = useState<string | null>(null);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [selectedTasks, setSelectedTasks] = useState<string[]>([]);
  const [selectAll, setSelectAll] = useState(false);

  useEffect(() => {
    fetchTasks();
    fetchUsers();
    fetchCustomers();
  }, [fetchTasks, fetchUsers, fetchCustomers]);

  const filteredTasks = tasks.filter(task => {
    const matchesSearch = 
      task.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.notes?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (task.customerId && customers.find(c => c.id === task.customerId)?.name.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesStatus = !statusFilter || task.status === statusFilter;
    const matchesType = !typeFilter || task.type === typeFilter;
    const matchesPriority = !priorityFilter || task.priority === priorityFilter;
    
    // User filter
    const matchesUser = !selectedUserId || task.assignedTo === selectedUserId;
    
    // Team filter
    const matchesTeam = !selectedTeamId || 
      users.find(u => u.id === task.assignedTo)?.teamId === selectedTeamId;
    
    // Role-based filtering
    let hasAccess = true;
    if (currentUser?.role === 'TECHNICIAN') {
      // Technicians can only see their own tasks
      hasAccess = task.assignedTo === currentUser.id;
    } else if (currentUser?.role === 'SALES') {
      // Sales can see tasks assigned to their team
      const assignedUser = users.find(u => u.id === task.assignedTo);
      hasAccess = assignedUser?.teamId === currentUser.teamId || task.assignedTo === currentUser.id;
    } else if (currentUser?.role === 'OPERATIONS') {
      // Operations can see all tasks in their team and technician tasks
      const assignedUser = users.find(u => u.id === task.assignedTo);
      hasAccess = assignedUser?.teamId === currentUser.teamId || 
                  assignedUser?.role === 'TECHNICIAN' ||
                  task.assignedTo === currentUser.id;
    }
    
    return matchesSearch && matchesStatus && matchesType && matchesPriority && matchesUser && matchesTeam && hasAccess;
  });

  useEffect(() => {
    // Reset selected tasks when filters change
    setSelectedTasks([]);
    setSelectAll(false);
  }, [searchTerm, statusFilter, typeFilter, priorityFilter, selectedUserId, selectedTeamId]);

  const getTaskIcon = (task: Task) => {
    if (task.type === 'REMINDER') {
      return <Bell className="h-4 w-4 text-amber-600" />;
    }
    
    switch (task.status) {
      case 'COMPLETED':
        return <CheckSquare className="h-4 w-4 text-green-600" />;
      case 'IN_PROGRESS':
        return <Clock className="h-4 w-4 text-yellow-600" />;
      default:
        return <CheckSquare className="h-4 w-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return 'bg-green-100 text-green-800';
      case 'IN_PROGRESS':
        return 'bg-yellow-100 text-yellow-800';
      case 'CANCELLED':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'LOW':
        return 'bg-gray-100 text-gray-800';
      case 'MEDIUM':
        return 'bg-blue-100 text-blue-800';
      case 'HIGH':
        return 'bg-orange-100 text-orange-800';
      case 'URGENT':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const isOverdue = (dueDate: string, status: string) => {
    return new Date(dueDate) < new Date() && !['COMPLETED', 'CANCELLED'].includes(status);
  };

  const getUserName = (userId: string) => {
    const user = users.find(u => u.id === userId);
    return user ? user.name : `User ${userId.slice(-4)}`;
  };

  const getCustomerName = (customerId?: string) => {
    if (!customerId) return null;
    const customer = customers.find(c => c.id === customerId);
    return customer ? customer.name : null;
  };

  const handleCreateTask = () => {
    setEditingTask(null);
    setIsTaskModalOpen(true);
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setIsTaskModalOpen(true);
  };

  const handleDeleteTask = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      try {
        await deleteTask(id);
      } catch (error) {
        console.error('Failed to delete task:', error);
      }
    }
  };

  const handleSaveTask = async (taskData: Partial<Task>) => {
    try {
      if (editingTask) {
        await updateTask(editingTask.id, taskData);
      } else {
        await createTask(taskData);
      }
      setIsTaskModalOpen(false);
    } catch (error) {
      console.error('Failed to save task:', error);
    }
  };

  const handleToggleSelect = (taskId: string) => {
    setSelectedTasks(prev => 
      prev.includes(taskId)
        ? prev.filter(id => id !== taskId)
        : [...prev, taskId]
    );
  };

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedTasks([]);
    } else {
      setSelectedTasks(filteredTasks.map(task => task.id));
    }
    setSelectAll(!selectAll);
  };

  const handleBulkStatusChange = async (status: string) => {
    if (selectedTasks.length === 0) return;
    
    try {
      for (const taskId of selectedTasks) {
        await updateTask(taskId, { status: status as Task['status'] });
      }
      setSelectedTasks([]);
      setSelectAll(false);
    } catch (error) {
      console.error('Failed to update tasks:', error);
    }
  };

  const handleBulkDelete = async () => {
    if (selectedTasks.length === 0) return;
    
    if (window.confirm(`Are you sure you want to delete ${selectedTasks.length} selected items?`)) {
      try {
        for (const taskId of selectedTasks) {
          await deleteTask(taskId);
        }
        setSelectedTasks([]);
        setSelectAll(false);
      } catch (error) {
        console.error('Failed to delete tasks:', error);
      }
    }
  };

  if (error) {
    return (
      <div className="rounded-md bg-red-50 p-4">
        <div className="text-sm text-red-700">{error}</div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="h-10 bg-gray-200 rounded animate-pulse"></div>
        {[...Array(5)].map((_, i) => (
          <div key={i} className="h-20 bg-gray-200 rounded animate-pulse"></div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Tasks & Reminders</h1>
          <p className="text-gray-600">Manage your tasks, reminders, and follow-ups</p>
        </div>
        
        <button 
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          onClick={handleCreateTask}
        >
          <Plus className="h-4 w-4 mr-2" />
          New Task/Reminder
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search tasks and reminders..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="flex flex-wrap gap-4 items-center">
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">All Types</option>
              <option value="TASK">Tasks</option>
              <option value="REMINDER">Reminders</option>
            </select>
            
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">All Status</option>
              <option value="PENDING">Pending</option>
              <option value="IN_PROGRESS">In Progress</option>
              <option value="COMPLETED">Completed</option>
              <option value="CANCELLED">Cancelled</option>
            </select>
            
            <select
              value={priorityFilter}
              onChange={(e) => setpriorityFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">All Priorities</option>
              <option value="LOW">Low</option>
              <option value="MEDIUM">Medium</option>
              <option value="HIGH">High</option>
              <option value="URGENT">Urgent</option>
            </select>
            
            <UserFilter
              selectedUserId={selectedUserId}
              selectedTeamId={selectedTeamId}
              onUserChange={setSelectedUserId}
              onTeamChange={setSelectedTeamId}
              showTeamFilter={currentUser?.role === 'ADMIN' || currentUser?.role === 'OPERATIONS'}
            />
          </div>
        </div>
      </div>

      {/* Bulk Actions */}
      {selectedTasks.length > 0 && (
        <div className="bg-blue-50 rounded-lg shadow-sm border border-blue-200 p-4">
          <div className="flex items-center justify-between">
            <div className="text-sm text-blue-700">
              <span className="font-medium">{selectedTasks.length}</span> items selected
            </div>
            <div className="flex items-center space-x-3">
              <button
                onClick={() => handleBulkStatusChange('COMPLETED')}
                className="flex items-center px-3 py-1 text-sm bg-green-600 text-white rounded hover:bg-green-700"
              >
                <CheckSquare className="h-4 w-4 mr-1" />
                Mark Complete
              </button>
              <button
                onClick={() => handleBulkStatusChange('IN_PROGRESS')}
                className="flex items-center px-3 py-1 text-sm bg-yellow-600 text-white rounded hover:bg-yellow-700"
              >
                <Clock className="h-4 w-4 mr-1" />
                Mark In Progress
              </button>
              <button
                onClick={handleBulkDelete}
                className="flex items-center px-3 py-1 text-sm bg-red-600 text-white rounded hover:bg-red-700"
              >
                <Trash2 className="h-4 w-4 mr-1" />
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tasks List */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left">
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      checked={selectAll}
                      onChange={handleSelectAll}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                  </div>
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Description
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Due Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Priority
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Assigned To
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Customer
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredTasks.map((task) => {
                const customerName = getCustomerName(task.customerId);
                
                return (
                  <tr key={task.id} className="hover:bg-gray-50">
                    <td className="px-4 py-4 whitespace-nowrap">
                      <input
                        type="checkbox"
                        checked={selectedTasks.includes(task.id)}
                        onChange={() => handleToggleSelect(task.id)}
                        className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center">
                        <div className="mr-3">
                          {getTaskIcon(task)}
                        </div>
                        <div>
                          <div className="text-sm font-medium text-gray-900">
                            {task.description}
                          </div>
                          {task.notes && (
                            <div className="text-sm text-gray-500 mt-1 line-clamp-1">
                              {task.notes}
                            </div>
                          )}
                        </div>
                      </div>
                    </td>
                    
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        task.type === 'REMINDER' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                      }`}>
                        {task.type || 'TASK'}
                      </span>
                    </td>
                    
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                        <span className={`text-sm ${isOverdue(task.dueDate, task.status) ? 'text-red-600 font-medium' : 'text-gray-900'}`}>
                          {formatDateTime(task.dueDate)}
                        </span>
                      </div>
                    </td>
                    
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(task.status)}`}>
                        {task.status.replace('_', ' ')}
                      </span>
                    </td>
                    
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getPriorityColor(task.priority || 'MEDIUM')}`}>
                        {task.priority || 'MEDIUM'}
                      </span>
                    </td>
                    
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <User className="h-4 w-4 text-gray-400 mr-2" />
                        <span className="text-sm text-gray-900">
                          {getUserName(task.assignedTo)}
                          {task.assignedTo === currentUser?.id && ' (Me)'}
                        </span>
                      </div>
                    </td>
                    
                    <td className="px-6 py-4 whitespace-nowrap">
                      {customerName ? (
                        <div className="flex items-center">
                          <Briefcase className="h-4 w-4 text-gray-400 mr-2" />
                          <span className="text-sm text-gray-900">{customerName}</span>
                        </div>
                      ) : (
                        <span className="text-sm text-gray-400">—</span>
                      )}
                    </td>
                    
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex items-center justify-end space-x-2">
                        <button
                          className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                          title="View"
                          onClick={() => handleEditTask(task)}
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                        <button
                          className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                          title="Edit"
                          onClick={() => handleEditTask(task)}
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        {(currentUser?.role === 'ADMIN' || task.assignedTo === currentUser?.id) && (
                          <button
                            className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                            title="Delete"
                            onClick={() => handleDeleteTask(task.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        
        {filteredTasks.length === 0 && (
          <div className="text-center py-12">
            <CheckSquare className="h-8 w-8 mx-auto text-gray-300 mb-4" />
            <p className="text-gray-500">
              {tasks.length === 0 ? 'No tasks or reminders found. Create your first one!' : 'No items match your search criteria.'}
            </p>
          </div>
        )}
      </div>

      {/* Task Modal */}
      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => setIsTaskModalOpen(false)}
        onSave={handleSaveTask}
        task={editingTask}
        users={users}
        customers={customers}
        isLoading={isLoading}
      />
    </div>
  );
}