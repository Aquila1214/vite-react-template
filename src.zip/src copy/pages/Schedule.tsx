import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Users, Filter, Search, Plus, ChevronLeft, ChevronRight, Grid, List, BarChart3, Settings, RefreshCw, Download, Upload, CalendarDays, CalendarOff, Briefcase } from 'lucide-react';
import { useAuthStore } from '../stores/authStore';
import { useCrmStore } from '../stores/crmStore';
import { useScheduleStore } from '../stores/scheduleStore';
import { CalendarView } from '../components/Schedule/CalendarView';
import { TimelineView } from '../components/Schedule/TimelineView';
import { GanttView } from '../components/Schedule/GanttView';
import { EventModal } from '../components/Schedule/EventModal';
import { FilterPanel } from '../components/Schedule/FilterPanel';
import { QuickActions } from '../components/Schedule/QuickActions';
import { TeamAvailabilityModal } from '../components/Schedule/TeamAvailabilityModal';
import { HolidaySyncModal } from '../components/Schedule/HolidaySyncModal';
import { ScheduleLeadJobModal } from '../components/Schedule/ScheduleLeadJobModal';
import { formatDate, formatDateTime } from '../lib/utils';
import type { ScheduleEvent, ViewType, EventStatus, RecurrencePattern } from '../types/schedule';

export function Schedule() {
  const { user: currentUser } = useAuthStore();
  const { users, teams, fetchUsers, fetchTeams } = useCrmStore();
  const { 
    events, 
    isLoading, 
    error, 
    currentDate,
    viewType,
    filters,
    isGoogleConnected,
    lastSyncTime,
    fetchEvents,
    setCurrentDate,
    setViewType,
    updateFilters,
    syncWithGoogle,
    createEvent,
    updateEvent,
    deleteEvent,
    bulkCreateEvents,
    exportEvents,
    importEvents
  } = useScheduleStore();

  const [isEventModalOpen, setIsEventModalOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<ScheduleEvent | null>(null);
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<{ start: Date; end: Date } | null>(null);
  const [isTeamAvailabilityModalOpen, setIsTeamAvailabilityModalOpen] = useState(false);
  const [isHolidaySyncModalOpen, setIsHolidaySyncModalOpen] = useState(false);
  const [selectedTeamId, setSelectedTeamId] = useState<string | null>(null);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [isScheduleLeadJobModalOpen, setIsScheduleLeadJobModalOpen] = useState(false);
  const [scheduleInitialType, setScheduleInitialType] = useState<'lead' | 'job'>('lead');

  useEffect(() => {
    fetchEvents();
    fetchUsers();
    fetchTeams();
  }, [fetchEvents, fetchUsers, fetchTeams]);

  // Filter events based on search and filters
  const filteredEvents = events.filter(event => {
    // Search filter
    const matchesSearch = !searchTerm || 
      event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.location?.toLowerCase().includes(searchTerm.toLowerCase());

    // Team filter
    const matchesTeam = !filters.teamIds.length || 
      event.attendees?.some(attendee => 
        users.find(u => u.id === attendee.userId)?.teamId && 
        filters.teamIds.includes(users.find(u => u.id === attendee.userId)!.teamId!)
      );

    // User filter
    const matchesUser = !filters.userIds.length ||
      event.attendees?.some(attendee => filters.userIds.includes(attendee.userId));

    // Event type filter
    const matchesType = !filters.eventTypes.length || 
      filters.eventTypes.includes(event.type);

    // Status filter
    const matchesStatus = !filters.statuses.length || 
      filters.statuses.includes(event.status);

    // Date range filter
    const eventDate = new Date(event.startTime);
    const matchesDateRange = !filters.dateRange.start || !filters.dateRange.end ||
      (eventDate >= filters.dateRange.start && eventDate <= filters.dateRange.end);

    // Role-based access control
    let hasAccess = true;
    if (currentUser?.role === 'TECHNICIAN') {
      // Technicians can only see events they're assigned to
      hasAccess = event.attendees?.some(attendee => attendee.userId === currentUser.id) || false;
    } else if (currentUser?.role === 'SALES') {
      // Sales can see team events and their own
      const userTeamId = currentUser.teamId;
      hasAccess = event.attendees?.some(attendee => {
        const user = users.find(u => u.id === attendee.userId);
        return user?.teamId === userTeamId || attendee.userId === currentUser.id;
      }) || false;
    }

    return matchesSearch && matchesTeam && matchesUser && matchesType && 
           matchesStatus && matchesDateRange && hasAccess;
  });

  const handleCreateEvent = (timeSlot?: { start: Date; end: Date }) => {
    setSelectedTimeSlot(timeSlot || null);
    setEditingEvent(null);
    setIsEventModalOpen(true);
  };

  const handleEditEvent = (event: ScheduleEvent) => {
    setEditingEvent(event);
    setSelectedTimeSlot(null);
    setIsEventModalOpen(true);
  };

  const handleSaveEvent = async (eventData: Partial<ScheduleEvent>) => {
    try {
      if (eventData.id) {
        await updateEvent(eventData.id, eventData);
      } else {
        await createEvent(eventData);
      }
      setIsEventModalOpen(false);
      setEditingEvent(null);
      setSelectedTimeSlot(null);
    } catch (error) {
      console.error('Failed to save event:', error);
    }
  };

  const handleDeleteEvent = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this event?')) {
      try {
        await deleteEvent(id);
        setIsEventModalOpen(false);
        setEditingEvent(null);
      } catch (error) {
        console.error('Failed to delete event:', error);
      }
    }
  };

  const handleBulkCreate = async (events: Partial<ScheduleEvent>[]) => {
    try {
      await bulkCreateEvents(events);
    } catch (error) {
      console.error('Failed to create bulk events:', error);
    }
  };

  const handleExport = async () => {
    try {
      await exportEvents(filteredEvents);
    } catch (error) {
      console.error('Failed to export events:', error);
    }
  };

  const handleImport = async (file: File) => {
    try {
      await importEvents(file);
    } catch (error) {
      console.error('Failed to import events:', error);
    }
  };

  const handleGoogleSync = async () => {
    try {
      await syncWithGoogle();
    } catch (error) {
      console.error('Failed to sync with Google Calendar:', error);
    }
  };

  const handleOpenTeamAvailability = (teamId?: string | null, userId?: string | null) => {
    setSelectedTeamId(teamId || null);
    setSelectedUserId(userId || null);
    setIsTeamAvailabilityModalOpen(true);
  };

  const handleScheduleLeadJob = (type: 'lead' | 'job') => {
    setScheduleInitialType(type);
    setIsScheduleLeadJobModalOpen(true);
  };

  const navigateDate = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    
    switch (viewType) {
      case 'day':
        newDate.setDate(newDate.getDate() + (direction === 'next' ? 1 : -1));
        break;
      case 'week':
        newDate.setDate(newDate.getDate() + (direction === 'next' ? 7 : -7));
        break;
      case 'month':
        newDate.setMonth(newDate.getMonth() + (direction === 'next' ? 1 : -1));
        break;
      case 'timeline':
        newDate.setDate(newDate.getDate() + (direction === 'next' ? 7 : -7));
        break;
    }
    
    setCurrentDate(newDate);
  };

  const getDateRangeLabel = () => {
    const date = new Date(currentDate);
    
    switch (viewType) {
      case 'day':
        return formatDate(date);
      case 'week':
        const weekStart = new Date(date);
        weekStart.setDate(date.getDate() - date.getDay());
        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekStart.getDate() + 6);
        return `${formatDate(weekStart)} - ${formatDate(weekEnd)}`;
      case 'month':
        return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
      case 'timeline':
        const timelineStart = new Date(date);
        timelineStart.setDate(date.getDate() - 3);
        const timelineEnd = new Date(date);
        timelineEnd.setDate(date.getDate() + 3);
        return `${formatDate(timelineStart)} - ${formatDate(timelineEnd)}`;
      default:
        return formatDate(date);
    }
  };

  const renderCurrentView = () => {
    const commonProps = {
      events: filteredEvents,
      currentDate,
      onEventClick: handleEditEvent,
      onTimeSlotClick: handleCreateEvent,
      onEventUpdate: handleSaveEvent,
      users,
      teams,
    };

    switch (viewType) {
      case 'day':
      case 'week':
      case 'month':
        return <CalendarView {...commonProps} viewType={viewType} />;
      case 'timeline':
        return <TimelineView {...commonProps} />;
      case 'gantt':
        return <GanttView {...commonProps} />;
      default:
        return <CalendarView {...commonProps} viewType="month" />;
    }
  };

  if (error) {
    return (
      <div className="rounded-md bg-red-50 p-4">
        <div className="text-sm text-red-700">{error}</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Schedule</h1>
          <p className="text-gray-600">Manage appointments, jobs, and team availability</p>
        </div>
        
        <div className="flex items-center space-x-3">
          {/* Google Calendar Sync */}
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${isGoogleConnected ? 'bg-green-500' : 'bg-red-500'}`} />
            <span className="text-sm text-gray-600">
              {isGoogleConnected ? 'Google Calendar Connected' : 'Not Connected'}
            </span>
            <button
              onClick={handleGoogleSync}
              className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
              title="Sync with Google Calendar"
            >
              <RefreshCw className="h-4 w-4" />
            </button>
          </div>
          
          {/* Quick Actions */}
          <QuickActions
            onExport={handleExport}
            onImport={handleImport}
            onBulkCreate={handleBulkCreate}
          />
          
          {/* Schedule Lead/Job Button */}
          <div className="relative group">
            <button
              onClick={() => handleScheduleLeadJob('lead')}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="h-4 w-4 mr-2" />
              New Event
            </button>
            
            {/* Dropdown Menu */}
            <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
              <div className="py-1">
                <button
                  onClick={() => handleCreateEvent()}
                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  <Calendar className="h-4 w-4 mr-3" />
                  General Event
                </button>
                <button
                  onClick={() => handleScheduleLeadJob('lead')}
                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  <Users className="h-4 w-4 mr-3" />
                  Lead Appointment
                </button>
                <button
                  onClick={() => handleScheduleLeadJob('job')}
                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  <Briefcase className="h-4 w-4 mr-3" />
                  Schedule Job
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          {/* View Controls */}
          <div className="flex items-center space-x-4">
            {/* View Type Selector */}
            <div className="flex items-center bg-gray-100 rounded-lg p-1">
              {[
                { type: 'day', label: 'Day', icon: Calendar },
                { type: 'week', label: 'Week', icon: Grid },
                { type: 'month', label: 'Month', icon: Calendar },
                { type: 'timeline', label: 'Timeline', icon: BarChart3 },
                { type: 'gantt', label: 'Gantt', icon: List },
              ].map(({ type, label, icon: Icon }) => (
                <button
                  key={type}
                  onClick={() => setViewType(type as ViewType)}
                  className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    viewType === type
                      ? 'bg-white text-gray-900 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <Icon className="h-4 w-4 mr-2" />
                  {label}
                </button>
              ))}
            </div>

            {/* Date Navigation */}
            <div className="flex items-center space-x-2">
              <button
                onClick={() => navigateDate('prev')}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
              
              <div className="min-w-[200px] text-center">
                <h2 className="text-lg font-semibold text-gray-900">
                  {getDateRangeLabel()}
                </h2>
              </div>
              
              <button
                onClick={() => navigateDate('next')}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
              
              <button
                onClick={() => setCurrentDate(new Date())}
                className="px-3 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
              >
                Today
              </button>
            </div>
          </div>

          {/* Search and Filters */}
          <div className="flex items-center space-x-3">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search events..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            {/* Team Availability */}
            <button
              onClick={() => handleOpenTeamAvailability()}
              className="flex items-center px-3 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              title="Set Team Availability"
            >
              <CalendarDays className="h-4 w-4 mr-2" />
              Team Availability
            </button>

            {/* Holiday Sync */}
            <button
              onClick={() => setIsHolidaySyncModalOpen(true)}
              className="flex items-center px-3 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              title="Sync Holidays"
            >
              <Calendar className="h-4 w-4 mr-2" />
              Holidays
            </button>

            {/* Filter Toggle */}
            <button
              onClick={() => setIsFilterPanelOpen(!isFilterPanelOpen)}
              className={`flex items-center px-3 py-2 rounded-lg transition-colors ${
                isFilterPanelOpen || Object.values(filters).some(f => Array.isArray(f) ? f.length > 0 : f)
                  ? 'bg-blue-100 text-blue-700'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <Filter className="h-4 w-4 mr-2" />
              Filters
            </button>

            {/* Settings */}
            <button
              className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              title="Schedule Settings"
            >
              <Settings className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Filter Panel */}
        {isFilterPanelOpen && (
          <div className="mt-4 pt-4 border-t border-gray-200">
            <FilterPanel
              filters={filters}
              onFiltersChange={updateFilters}
              users={users}
              teams={teams}
            />
          </div>
        )}

        {/* Stats Bar */}
        <div className="mt-4 pt-4 border-t border-gray-200">
          <div className="flex items-center justify-between text-sm text-gray-600">
            <div className="flex items-center space-x-6">
              <span>Showing {filteredEvents.length} of {events.length} events</span>
              {lastSyncTime && (
                <span>Last sync: {formatDateTime(lastSyncTime)}</span>
              )}
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-blue-500 rounded-full" />
                <span>Available</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-red-500 rounded-full" />
                <span>Busy</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-yellow-500 rounded-full" />
                <span>Tentative</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-gray-500 rounded-full" />
                <span>Time Off</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Calendar View */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center h-96">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
          </div>
        ) : (
          renderCurrentView()
        )}
      </div>

      {/* Event Modal */}
      <EventModal
        isOpen={isEventModalOpen}
        onClose={() => {
          setIsEventModalOpen(false);
          setEditingEvent(null);
          setSelectedTimeSlot(null);
        }}
        onSave={handleSaveEvent}
        onDelete={handleDeleteEvent}
        event={editingEvent}
        selectedTimeSlot={selectedTimeSlot}
        users={users}
        teams={teams}
        isLoading={isLoading}
      />

      {/* Team Availability Modal */}
      <TeamAvailabilityModal
        isOpen={isTeamAvailabilityModalOpen}
        onClose={() => setIsTeamAvailabilityModalOpen(false)}
        initialTeamId={selectedTeamId}
        initialUserId={selectedUserId}
      />

      {/* Holiday Sync Modal */}
      <HolidaySyncModal
        isOpen={isHolidaySyncModalOpen}
        onClose={() => setIsHolidaySyncModalOpen(false)}
      />

      {/* Schedule Lead/Job Modal */}
      <ScheduleLeadJobModal
        isOpen={isScheduleLeadJobModalOpen}
        onClose={() => setIsScheduleLeadJobModalOpen(false)}
        initialType={scheduleInitialType}
      />
    </div>
  );
}