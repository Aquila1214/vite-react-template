import { create } from 'zustand';
import { api } from '../lib/api';
import { generateId } from '../lib/utils';
import type { Location } from '../types';

interface LocationState {
  // Data
  locations: Location[];
  selectedLocationIds: string[];
  defaultLocationId: string | null;
  
  // UI State
  isLoading: boolean;
  error: string | null;
  
  // Actions
  setError: (error: string | null) => void;
  setLoading: (loading: boolean) => void;
  
  // Data fetching
  fetchLocations: () => Promise<void>;
  getLocationStats: (id: string) => Promise<{
    users: number;
    customers: number;
    leads: number;
    jobs: number;
    estimates: number;
    invoices: number;
  }>;
  
  // Location selection
  selectLocation: (id: string) => void;
  selectMultipleLocations: (ids: string[]) => void;
  selectAllLocations: () => void;
  clearLocationSelection: () => void;
  setDefaultLocation: (id: string | null) => void;
  
  // CRUD operations
  createLocation: (data: Partial<Location>) => Promise<Location>;
  updateLocation: (id: string, data: Partial<Location>) => Promise<void>;
  deleteLocation: (id: string) => Promise<void>;
}

// Mock data for development
const mockLocations: Location[] = [
  {
    id: '1',
    name: 'Main Office',
    address: '123 Main Street, Springfield, IL',
    phone: '(555) 123-4567',
    email: 'main@luxfoundation.com',
    createdAt: '2023-01-01T00:00:00Z',
    updatedAt: '2023-01-01T00:00:00Z',
  },
  {
    id: '2',
    name: 'North Branch',
    address: '456 North Avenue, Springfield, IL',
    phone: '(555) 987-6543',
    email: 'north@luxfoundation.com',
    createdAt: '2023-02-01T00:00:00Z',
    updatedAt: '2023-02-01T00:00:00Z',
  },
  {
    id: '3',
    name: 'South Branch',
    address: '789 South Boulevard, Springfield, IL',
    phone: '(555) 456-7890',
    email: 'south@luxfoundation.com',
    createdAt: '2023-03-01T00:00:00Z',
    updatedAt: '2023-03-01T00:00:00Z',
  },
];

export const useLocationStore = create<LocationState>((set, get) => ({
  // Initial State
  locations: mockLocations,
  selectedLocationIds: [],
  defaultLocationId: null,
  isLoading: false,
  error: null,
  
  // UI Actions
  setError: (error) => set({ error }),
  setLoading: (loading) => set({ isLoading: loading }),
  
  // Data fetching
  fetchLocations: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/locations');
      const locations = response.data;
      
      set({ 
        locations,
        isLoading: false,
        // If no location is selected and we have locations, select the first one
        selectedLocationIds: get().selectedLocationIds.length === 0 && locations.length > 0 
          ? [locations[0].id] 
          : get().selectedLocationIds
      });
      
      // If no default location is set and we have locations, set the first one as default
      if (!get().defaultLocationId && locations.length > 0) {
        set({ defaultLocationId: locations[0].id });
      }
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ isLoading: false });
      
      // If no location is selected and we have mock locations, select the first one
      if (get().selectedLocationIds.length === 0 && mockLocations.length > 0) {
        set({ selectedLocationIds: [mockLocations[0].id] });
      }
      
      // If no default location is set and we have mock locations, set the first one as default
      if (!get().defaultLocationId && mockLocations.length > 0) {
        set({ defaultLocationId: mockLocations[0].id });
      }
    }
  },
  
  getLocationStats: async (id) => {
    try {
      const response = await api.get(`/locations/${id}/stats`);
      return response.data.stats;
    } catch (error: any) {
      console.log('API not available, using mock stats');
      // Return mock stats
      return {
        users: Math.floor(Math.random() * 10) + 5,
        customers: Math.floor(Math.random() * 100) + 50,
        leads: Math.floor(Math.random() * 50) + 20,
        jobs: Math.floor(Math.random() * 30) + 10,
        estimates: Math.floor(Math.random() * 20) + 5,
        invoices: Math.floor(Math.random() * 15) + 5
      };
    }
  },
  
  // Location selection
  selectLocation: (id) => {
    set({ selectedLocationIds: [id] });
  },
  
  selectMultipleLocations: (ids) => {
    set({ selectedLocationIds: ids });
  },
  
  selectAllLocations: () => {
    const allLocationIds = get().locations.map(location => location.id);
    set({ selectedLocationIds: allLocationIds });
  },
  
  clearLocationSelection: () => {
    set({ selectedLocationIds: [] });
  },
  
  setDefaultLocation: (id) => {
    set({ defaultLocationId: id });
    
    // If setting a default location, also select it
    if (id) {
      set({ selectedLocationIds: [id] });
    }
  },
  
  // CRUD operations
  createLocation: async (data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.post('/locations', data);
      const newLocation = response.data;
      
      set((state) => ({ 
        locations: [...state.locations, newLocation], 
        isLoading: false 
      }));
      
      return newLocation;
    } catch (error: any) {
      // Mock create for development
      const newLocation: Location = {
        id: generateId(),
        name: data.name || 'New Location',
        address: data.address,
        phone: data.phone,
        email: data.email,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      set((state) => ({ 
        locations: [...state.locations, newLocation], 
        isLoading: false 
      }));
      
      return newLocation;
    }
  },
  
  updateLocation: async (id, data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.put(`/locations/${id}`, data);
      const updatedLocation = response.data;
      
      set((state) => ({
        locations: state.locations.map(location => 
          location.id === id ? updatedLocation : location
        ),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock update for development
      set((state) => ({
        locations: state.locations.map(location => 
          location.id === id ? { ...location, ...data, updatedAt: new Date().toISOString() } : location
        ),
        isLoading: false
      }));
    }
  },
  
  deleteLocation: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await api.delete(`/locations/${id}`);
      
      set((state) => ({
        locations: state.locations.filter(location => location.id !== id),
        // If the deleted location was selected, clear the selection
        selectedLocationIds: state.selectedLocationIds.includes(id) 
          ? state.selectedLocationIds.filter(locId => locId !== id)
          : state.selectedLocationIds,
        // If the deleted location was the default, clear the default
        defaultLocationId: state.defaultLocationId === id ? null : state.defaultLocationId,
        isLoading: false
      }));
    } catch (error: any) {
      // Mock delete for development
      set((state) => ({
        locations: state.locations.filter(location => location.id !== id),
        // If the deleted location was selected, clear the selection
        selectedLocationIds: state.selectedLocationIds.includes(id) 
          ? state.selectedLocationIds.filter(locId => locId !== id)
          : state.selectedLocationIds,
        // If the deleted location was the default, clear the default
        defaultLocationId: state.defaultLocationId === id ? null : state.defaultLocationId,
        isLoading: false
      }));
    }
  }
}));