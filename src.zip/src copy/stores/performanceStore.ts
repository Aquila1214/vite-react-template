import { create } from 'zustand';
import { api } from '../lib/api';
import type { 
  OverviewPerformanceData,
  SalesPerformanceData,
  OperationsPerformanceData,
  MarketingPerformanceData,
  FinancePerformanceData,
  TimePeriod,
  DashboardView,
  ExportOptions
} from '../types/performance';

interface PerformanceState {
  // Data
  overviewData: OverviewPerformanceData | null;
  salesData: SalesPerformanceData | null;
  operationsData: OperationsPerformanceData | null;
  marketingData: MarketingPerformanceData | null;
  financeData: FinancePerformanceData | null;
  
  // UI State
  isLoading: boolean;
  error: string | null;
  lastUpdated: string | null;
  
  // Actions
  setError: (error: string | null) => void;
  setLoading: (loading: boolean) => void;
  
  // Data fetching
  fetchOverviewData: (period: TimePeriod) => Promise<void>;
  fetchSalesData: (period: TimePeriod) => Promise<void>;
  fetchOperationsData: (period: TimePeriod) => Promise<void>;
  fetchMarketingData: (period: TimePeriod) => Promise<void>;
  fetchFinanceData: (period: TimePeriod) => Promise<void>;
  
  // Utility actions
  refreshAllData: () => Promise<void>;
  exportData: (view: DashboardView, period: TimePeriod, options?: ExportOptions) => Promise<void>;
}

// Mock data generators
const generateMockOverviewData = (): OverviewPerformanceData => ({
  companyMetrics: {
    totalRevenue: {
      value: 2850000,
      comparison: {
        current: 2850000,
        previous: 2650000,
        change: 200000,
        changePercentage: 7.5,
        trend: 'up'
      },
      target: 3000000,
      targetPercentage: 95.0
    },
    totalCustomers: {
      value: 1247,
      comparison: {
        current: 1247,
        previous: 1180,
        change: 67,
        changePercentage: 5.7,
        trend: 'up'
      },
      target: 1300,
      targetPercentage: 95.9
    },
    employeeCount: {
      value: 45,
      comparison: {
        current: 45,
        previous: 42,
        change: 3,
        changePercentage: 7.1,
        trend: 'up'
      }
    },
    operatingMargin: {
      value: 18.5,
      comparison: {
        current: 18.5,
        previous: 16.2,
        change: 2.3,
        changePercentage: 14.2,
        trend: 'up'
      },
      target: 20.0,
      targetPercentage: 92.5
    }
  },
  departmentSummary: {
    sales: { revenue: 2850000, target: 3000000, performance: 95.0 },
    operations: { efficiency: 87.5, target: 90.0, performance: 97.2 },
    marketing: { leads: 485, target: 500, performance: 97.0 },
    finance: { margin: 18.5, target: 20.0, performance: 92.5 }
  },
  trends: [
    { month: 'Jan', revenue: 2200000, customers: 1050, efficiency: 82 },
    { month: 'Feb', revenue: 2350000, customers: 1120, efficiency: 84 },
    { month: 'Mar', revenue: 2650000, customers: 1180, efficiency: 86 },
    { month: 'Apr', revenue: 2850000, customers: 1247, efficiency: 87.5 }
  ]
});

const generateMockSalesData = (): SalesPerformanceData => ({
  revenue: {
    total: {
      value: 2850000,
      comparison: {
        current: 2850000,
        previous: 2650000,
        change: 200000,
        changePercentage: 7.5,
        trend: 'up'
      },
      target: 3000000,
      targetPercentage: 95.0
    },
    recurring: {
      value: 1425000,
      comparison: {
        current: 1425000,
        previous: 1325000,
        change: 100000,
        changePercentage: 7.5,
        trend: 'up'
      }
    },
    newBusiness: {
      value: 1425000,
      comparison: {
        current: 1425000,
        previous: 1325000,
        change: 100000,
        changePercentage: 7.5,
        trend: 'up'
      }
    },
    averageDealSize: {
      value: 8750,
      comparison: {
        current: 8750,
        previous: 8200,
        change: 550,
        changePercentage: 6.7,
        trend: 'up'
      }
    }
  },
  pipeline: {
    totalValue: {
      value: 1250000,
      comparison: {
        current: 1250000,
        previous: 1100000,
        change: 150000,
        changePercentage: 13.6,
        trend: 'up'
      }
    },
    qualifiedLeads: {
      value: 127,
      comparison: {
        current: 127,
        previous: 118,
        change: 9,
        changePercentage: 7.6,
        trend: 'up'
      }
    },
    conversionRate: {
      value: 24.5,
      comparison: {
        current: 24.5,
        previous: 22.1,
        change: 2.4,
        changePercentage: 10.9,
        trend: 'up'
      }
    },
    averageCycleTime: {
      value: 18,
      comparison: {
        current: 18,
        previous: 21,
        change: -3,
        changePercentage: -14.3,
        trend: 'down'
      }
    }
  },
  team: {
    topPerformers: [
      { name: 'Sarah Johnson', revenue: 485000, deals: 28, performance: 121.3 },
      { name: 'Mike Wilson', revenue: 425000, deals: 24, performance: 106.3 },
      { name: 'Lisa Chen', revenue: 385000, deals: 22, performance: 96.3 }
    ],
    quotaAttainment: [
      { name: 'Sarah Johnson', quota: 400000, achieved: 485000, percentage: 121.3 },
      { name: 'Mike Wilson', quota: 400000, achieved: 425000, percentage: 106.3 },
      { name: 'Lisa Chen', quota: 400000, achieved: 385000, percentage: 96.3 }
    ]
  },
  customerAcquisition: {
    cost: {
      value: 1250,
      comparison: {
        current: 1250,
        previous: 1350,
        change: -100,
        changePercentage: -7.4,
        trend: 'down'
      }
    },
    lifetime: {
      value: 15750,
      comparison: {
        current: 15750,
        previous: 14200,
        change: 1550,
        changePercentage: 10.9,
        trend: 'up'
      }
    },
    churnRate: {
      value: 3.2,
      comparison: {
        current: 3.2,
        previous: 4.1,
        change: -0.9,
        changePercentage: -22.0,
        trend: 'down'
      }
    }
  }
});

const generateMockOperationsData = (): OperationsPerformanceData => ({
  productivity: {
    overallEfficiency: {
      value: 87.5,
      comparison: {
        current: 87.5,
        previous: 84.2,
        change: 3.3,
        changePercentage: 3.9,
        trend: 'up'
      },
      target: 90.0,
      targetPercentage: 97.2
    },
    jobsCompleted: {
      value: 156,
      comparison: {
        current: 156,
        previous: 142,
        change: 14,
        changePercentage: 9.9,
        trend: 'up'
      }
    },
    averageJobTime: {
      value: 4.2,
      comparison: {
        current: 4.2,
        previous: 4.8,
        change: -0.6,
        changePercentage: -12.5,
        trend: 'down'
      }
    },
    utilizationRate: {
      value: 82.3,
      comparison: {
        current: 82.3,
        previous: 78.9,
        change: 3.4,
        changePercentage: 4.3,
        trend: 'up'
      }
    }
  },
  quality: {
    customerSatisfaction: {
      value: 4.7,
      comparison: {
        current: 4.7,
        previous: 4.5,
        change: 0.2,
        changePercentage: 4.4,
        trend: 'up'
      },
      target: 4.8,
      targetPercentage: 97.9
    },
    defectRate: {
      value: 2.1,
      comparison: {
        current: 2.1,
        previous: 2.8,
        change: -0.7,
        changePercentage: -25.0,
        trend: 'down'
      }
    },
    reworkRate: {
      value: 3.5,
      comparison: {
        current: 3.5,
        previous: 4.2,
        change: -0.7,
        changePercentage: -16.7,
        trend: 'down'
      }
    },
    firstTimeRight: {
      value: 94.4,
      comparison: {
        current: 94.4,
        previous: 91.8,
        change: 2.6,
        changePercentage: 2.8,
        trend: 'up'
      }
    }
  },
  resources: {
    teamUtilization: [
      { teamName: 'Field Technicians', utilization: 85.2, capacity: 100, efficiency: 92.1 },
      { teamName: 'Installation Crew', utilization: 78.9, capacity: 100, efficiency: 88.5 },
      { teamName: 'Quality Control', utilization: 82.1, capacity: 100, efficiency: 95.3 }
    ],
    equipmentUptime: {
      value: 96.8,
      comparison: {
        current: 96.8,
        previous: 94.2,
        change: 2.6,
        changePercentage: 2.8,
        trend: 'up'
      }
    },
    materialWaste: {
      value: 4.2,
      comparison: {
        current: 4.2,
        previous: 5.1,
        change: -0.9,
        changePercentage: -17.6,
        trend: 'down'
      }
    }
  },
  timeline: {
    onTimeDelivery: {
      value: 92.3,
      comparison: {
        current: 92.3,
        previous: 88.7,
        change: 3.6,
        changePercentage: 4.1,
        trend: 'up'
      },
      target: 95.0,
      targetPercentage: 97.2
    },
    averageDelay: {
      value: 1.2,
      comparison: {
        current: 1.2,
        previous: 1.8,
        change: -0.6,
        changePercentage: -33.3,
        trend: 'down'
      }
    },
    scheduleAdherence: {
      value: 89.5,
      comparison: {
        current: 89.5,
        previous: 85.2,
        change: 4.3,
        changePercentage: 5.0,
        trend: 'up'
      }
    }
  }
});

const generateMockMarketingData = (): MarketingPerformanceData => ({
  campaigns: {
    active: 12,
    totalSpend: {
      value: 45000,
      comparison: {
        current: 45000,
        previous: 42000,
        change: 3000,
        changePercentage: 7.1,
        trend: 'up'
      }
    },
    averageROI: {
      value: 3.2,
      comparison: {
        current: 3.2,
        previous: 2.8,
        change: 0.4,
        changePercentage: 14.3,
        trend: 'up'
      }
    },
    topPerforming: [
      { name: 'Google Ads - Foundation Repair', spend: 12000, leads: 85, roi: 4.2 },
      { name: 'Facebook - Waterproofing', spend: 8500, leads: 62, roi: 3.8 },
      { name: 'Local SEO Campaign', spend: 6000, leads: 45, roi: 3.5 }
    ]
  },
  leadGeneration: {
    totalLeads: {
      value: 485,
      comparison: {
        current: 485,
        previous: 425,
        change: 60,
        changePercentage: 14.1,
        trend: 'up'
      },
      target: 500,
      targetPercentage: 97.0
    },
    qualifiedLeads: {
      value: 127,
      comparison: {
        current: 127,
        previous: 118,
        change: 9,
        changePercentage: 7.6,
        trend: 'up'
      }
    },
    costPerLead: {
      value: 92.78,
      comparison: {
        current: 92.78,
        previous: 98.82,
        change: -6.04,
        changePercentage: -6.1,
        trend: 'down'
      }
    },
    leadsByChannel: [
      { channel: 'Google Ads', leads: 185, cost: 12000, quality: 8.2 },
      { channel: 'Facebook Ads', leads: 125, cost: 8500, quality: 7.8 },
      { channel: 'SEO/Organic', leads: 95, cost: 6000, quality: 9.1 },
      { channel: 'Referrals', leads: 80, cost: 2500, quality: 9.5 }
    ]
  },
  engagement: {
    websiteTraffic: {
      value: 12500,
      comparison: {
        current: 12500,
        previous: 11200,
        change: 1300,
        changePercentage: 11.6,
        trend: 'up'
      }
    },
    conversionRate: {
      value: 3.88,
      comparison: {
        current: 3.88,
        previous: 3.79,
        change: 0.09,
        changePercentage: 2.4,
        trend: 'up'
      }
    },
    emailOpenRate: {
      value: 24.5,
      comparison: {
        current: 24.5,
        previous: 22.1,
        change: 2.4,
        changePercentage: 10.9,
        trend: 'up'
      }
    },
    socialEngagement: {
      value: 8.2,
      comparison: {
        current: 8.2,
        previous: 7.5,
        change: 0.7,
        changePercentage: 9.3,
        trend: 'up'
      }
    }
  },
  brand: {
    awareness: {
      value: 32.5,
      comparison: {
        current: 32.5,
        previous: 28.9,
        change: 3.6,
        changePercentage: 12.5,
        trend: 'up'
      }
    },
    sentiment: {
      value: 4.3,
      comparison: {
        current: 4.3,
        previous: 4.1,
        change: 0.2,
        changePercentage: 4.9,
        trend: 'up'
      }
    },
    shareOfVoice: {
      value: 18.7,
      comparison: {
        current: 18.7,
        previous: 16.2,
        change: 2.5,
        changePercentage: 15.4,
        trend: 'up'
      }
    }
  }
});

const generateMockFinanceData = (): FinancePerformanceData => ({
  profitLoss: {
    revenue: {
      value: 2850000,
      comparison: {
        current: 2850000,
        previous: 2650000,
        change: 200000,
        changePercentage: 7.5,
        trend: 'up'
      }
    },
    grossProfit: {
      value: 1710000,
      comparison: {
        current: 1710000,
        previous: 1590000,
        change: 120000,
        changePercentage: 7.5,
        trend: 'up'
      }
    },
    operatingIncome: {
      value: 527250,
      comparison: {
        current: 527250,
        previous: 429300,
        change: 97950,
        changePercentage: 22.8,
        trend: 'up'
      }
    },
    netIncome: {
      value: 456750,
      comparison: {
        current: 456750,
        previous: 371500,
        change: 85250,
        changePercentage: 22.9,
        trend: 'up'
      }
    }
  },
  cashFlow: {
    operating: {
      value: 485000,
      comparison: {
        current: 485000,
        previous: 425000,
        change: 60000,
        changePercentage: 14.1,
        trend: 'up'
      }
    },
    investing: {
      value: -125000,
      comparison: {
        current: -125000,
        previous: -85000,
        change: -40000,
        changePercentage: 47.1,
        trend: 'down'
      }
    },
    financing: {
      value: -85000,
      comparison: {
        current: -85000,
        previous: -95000,
        change: 10000,
        changePercentage: -10.5,
        trend: 'up'
      }
    },
    freeCashFlow: {
      value: 360000,
      comparison: {
        current: 360000,
        previous: 340000,
        change: 20000,
        changePercentage: 5.9,
        trend: 'up'
      }
    }
  },
  budgetAnalysis: {
    totalBudget: 2400000,
    actualSpend: 2322750,
    variance: 77250,
    departmentBreakdown: [
      { department: 'Sales', budget: 480000, actual: 465000, variance: 15000, variancePercentage: 3.1 },
      { department: 'Operations', budget: 960000, actual: 945000, variance: 15000, variancePercentage: 1.6 },
      { department: 'Marketing', budget: 240000, actual: 252000, variance: -12000, variancePercentage: -5.0 },
      { department: 'Administration', budget: 720000, actual: 660750, variance: 59250, variancePercentage: 8.2 }
    ]
  },
  forecasts: {
    quarterlyRevenue: [
      { quarter: 'Q1 2024', forecast: 2850000, actual: 2850000, confidence: 100 },
      { quarter: 'Q2 2024', forecast: 3100000, confidence: 85 },
      { quarter: 'Q3 2024', forecast: 3250000, confidence: 75 },
      { quarter: 'Q4 2024', forecast: 3400000, confidence: 65 }
    ],
    expenses: [
      { category: 'Personnel', current: 1200000, projected: 1260000, trend: 'up' },
      { category: 'Materials', current: 720000, projected: 750000, trend: 'up' },
      { category: 'Equipment', current: 180000, projected: 175000, trend: 'down' },
      { category: 'Marketing', current: 252000, projected: 270000, trend: 'up' }
    ]
  },
  kpis: {
    grossMargin: {
      value: 60.0,
      comparison: {
        current: 60.0,
        previous: 60.0,
        change: 0,
        changePercentage: 0,
        trend: 'neutral'
      },
      target: 62.0,
      targetPercentage: 96.8
    },
    operatingMargin: {
      value: 18.5,
      comparison: {
        current: 18.5,
        previous: 16.2,
        change: 2.3,
        changePercentage: 14.2,
        trend: 'up'
      },
      target: 20.0,
      targetPercentage: 92.5
    },
    currentRatio: {
      value: 2.1,
      comparison: {
        current: 2.1,
        previous: 1.9,
        change: 0.2,
        changePercentage: 10.5,
        trend: 'up'
      }
    },
    debtToEquity: {
      value: 0.35,
      comparison: {
        current: 0.35,
        previous: 0.42,
        change: -0.07,
        changePercentage: -16.7,
        trend: 'down'
      }
    }
  }
});

export const usePerformanceStore = create<PerformanceState>((set, get) => ({
  // Initial State
  overviewData: null,
  salesData: null,
  operationsData: null,
  marketingData: null,
  financeData: null,
  isLoading: false,
  error: null,
  lastUpdated: null,
  
  // UI Actions
  setError: (error) => set({ error }),
  setLoading: (loading) => set({ isLoading: loading }),
  
  // Data fetching
  fetchOverviewData: async (period) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/performance/overview', {
        params: { period }
      });
      set({ 
        overviewData: response.data.data, 
        isLoading: false,
        lastUpdated: new Date().toISOString()
      });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ 
        overviewData: generateMockOverviewData(), 
        isLoading: false,
        lastUpdated: new Date().toISOString()
      });
    }
  },
  
  fetchSalesData: async (period) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/performance/sales', {
        params: { period }
      });
      set({ 
        salesData: response.data.data, 
        isLoading: false,
        lastUpdated: new Date().toISOString()
      });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ 
        salesData: generateMockSalesData(), 
        isLoading: false,
        lastUpdated: new Date().toISOString()
      });
    }
  },
  
  fetchOperationsData: async (period) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/performance/operations', {
        params: { period }
      });
      set({ 
        operationsData: response.data.data, 
        isLoading: false,
        lastUpdated: new Date().toISOString()
      });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ 
        operationsData: generateMockOperationsData(), 
        isLoading: false,
        lastUpdated: new Date().toISOString()
      });
    }
  },
  
  fetchMarketingData: async (period) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/performance/marketing', {
        params: { period }
      });
      set({ 
        marketingData: response.data.data, 
        isLoading: false,
        lastUpdated: new Date().toISOString()
      });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ 
        marketingData: generateMockMarketingData(), 
        isLoading: false,
        lastUpdated: new Date().toISOString()
      });
    }
  },
  
  fetchFinanceData: async (period) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/performance/finance', {
        params: { period }
      });
      set({ 
        financeData: response.data.data, 
        isLoading: false,
        lastUpdated: new Date().toISOString()
      });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ 
        financeData: generateMockFinanceData(), 
        isLoading: false,
        lastUpdated: new Date().toISOString()
      });
    }
  },
  
  refreshAllData: async () => {
    const { fetchOverviewData, fetchSalesData, fetchOperationsData, fetchMarketingData, fetchFinanceData } = get();
    await Promise.all([
      fetchOverviewData('last30days'),
      fetchSalesData('last30days'),
      fetchOperationsData('last30days'),
      fetchMarketingData('last30days'),
      fetchFinanceData('last30days'),
    ]);
  },
  
  exportData: async (view, period, options) => {
    try {
      const response = await api.post('/performance/export', {
        view,
        period,
        options
      }, {
        responseType: 'blob'
      });
      
      // Create download link
      const blob = new Blob([response.data]);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `performance-report-${view}-${period}-${new Date().toISOString().split('T')[0]}.pdf`;
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (error: any) {
      console.log('Export not available, generating mock export');
      // Mock export functionality
      const mockData = JSON.stringify({
        view,
        period,
        exportedAt: new Date().toISOString(),
        data: 'Mock performance data export'
      }, null, 2);
      
      const blob = new Blob([mockData], { type: 'application/json' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `performance-report-${view}-${period}.json`;
      a.click();
      window.URL.revokeObjectURL(url);
    }
  },
}));