import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { api } from '../lib/api';
import type { User } from '../types';

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  setUser: (user: User) => void;
  setToken: (token: string) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      isAuthenticated: false,
      isLoading: false,

      login: async (email: string, password: string) => {
        set({ isLoading: true });
        try {
          // Try real API first
          try {
            const response = await api.post('/auth/login', { email, password });
            const { user, token } = response.data;
            
            set({ 
              user, 
              token, 
              isAuthenticated: true,
              isLoading: false 
            });
            
            // Set token for future requests
            api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
            return;
          } catch (apiError) {
            // Fall back to mock login for development
            console.log('API login failed, using mock authentication');
          }
          
          // Mock login for development
          const mockUser: User = {
            id: '1',
            name: 'John Smith',
            email,
            role: 'ADMIN',
            phone: '(555) 123-4567',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };
          
          const mockToken = 'mock-jwt-token-' + Date.now();
          
          set({ 
            user: mockUser, 
            token: mockToken, 
            isAuthenticated: true,
            isLoading: false 
          });
          
          // Set mock token for future requests
          api.defaults.headers.common['Authorization'] = `Bearer ${mockToken}`;
        } catch (error) {
          set({ isLoading: false });
          throw error;
        }
      },

      logout: () => {
        // Clear token from API headers
        delete api.defaults.headers.common['Authorization'];
        
        set({ 
          user: null, 
          token: null, 
          isAuthenticated: false 
        });
      },

      setUser: (user: User) => {
        set({ user });
      },

      setToken: (token: string) => {
        set({ token, isAuthenticated: !!token });
        // Set token for API requests
        api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      },
    }),
    {
      name: 'lux-auth-storage',
      partialize: (state) => ({
        user: state.user,
        token: state.token,
        isAuthenticated: state.isAuthenticated,
      }),
      onRehydrateStorage: () => (state) => {
        // Set token in API headers when rehydrating from storage
        if (state?.token) {
          api.defaults.headers.common['Authorization'] = `Bearer ${state.token}`;
        }
      },
    }
  )
);