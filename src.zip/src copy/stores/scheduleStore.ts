import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { api } from '../lib/api';
import { generateId } from '../lib/utils';
import type { 
  ScheduleEvent, 
  ViewType, 
  ScheduleFilters, 
  CalendarSettings, 
  GoogleCalendarConfig,
  RecurrencePattern,
  EventAttendee,
  HolidaySyncSettings
} from '../types/schedule';

interface ScheduleState {
  // Data
  events: ScheduleEvent[];
  settings: CalendarSettings;
  googleConfig: GoogleCalendarConfig;
  
  // UI State
  currentDate: Date;
  viewType: ViewType;
  filters: ScheduleFilters;
  isLoading: boolean;
  error: string | null;
  lastSyncTime: string | null;
  
  // Computed
  isGoogleConnected: boolean;
  
  // Actions
  setCurrentDate: (date: Date) => void;
  setViewType: (view: ViewType) => void;
  updateFilters: (filters: Partial<ScheduleFilters>) => void;
  setError: (error: string | null) => void;
  setLoading: (loading: boolean) => void;
  updateSettings: (settings: Partial<CalendarSettings>) => void;
  
  // Event Actions
  fetchEvents: () => Promise<void>;
  createEvent: (eventData: Partial<ScheduleEvent>) => Promise<void>;
  updateEvent: (id: string, updates: Partial<ScheduleEvent>) => Promise<void>;
  deleteEvent: (id: string) => Promise<void>;
  bulkCreateEvents: (events: Partial<ScheduleEvent>[]) => Promise<void>;
  
  // Recurrence Actions
  createRecurringEvents: (baseEvent: Partial<ScheduleEvent>, pattern: RecurrencePattern) => Promise<void>;
  updateRecurringSeries: (parentId: string, updates: Partial<ScheduleEvent>) => Promise<void>;
  deleteRecurringSeries: (parentId: string) => Promise<void>;
  
  // Google Calendar Actions
  connectGoogleCalendar: (authCode: string) => Promise<void>;
  disconnectGoogleCalendar: () => Promise<void>;
  syncWithGoogle: () => Promise<void>;
  
  // Import/Export Actions
  exportEvents: (events: ScheduleEvent[]) => Promise<void>;
  importEvents: (file: File) => Promise<void>;
  
  // Conflict Detection
  detectConflicts: (event: ScheduleEvent) => ScheduleEvent[];
  resolveConflict: (eventId: string, resolution: 'accept' | 'decline' | 'reschedule') => Promise<void>;
  
  // Availability
  checkAvailability: (userId: string, startTime: Date, endTime: Date) => boolean;
  findAvailableSlots: (userIds: string[], duration: number, dateRange: { start: Date; end: Date }) => Date[];
  
  // Activity Logging
  logEventActivity: (eventId: string, action: string, details?: string) => Promise<void>;
}

// Mock events data
const mockEvents: ScheduleEvent[] = [
  {
    id: '1',
    title: 'Foundation Inspection - Johnson Property',
    description: 'Initial assessment of foundation cracks',
    startTime: '2024-01-22T09:00:00Z',
    endTime: '2024-01-22T11:00:00Z',
    allDay: false,
    location: '123 Oak Street, Springfield, IL',
    type: 'job',
    status: 'busy',
    color: '#3B82F6',
    attendees: [
      { userId: 'user4', status: 'accepted', isRequired: true, role: 'attendee' },
      { userId: 'user3', status: 'accepted', isRequired: false, role: 'attendee' }
    ],
    isRecurring: false,
    jobId: '1',
    customerId: '1',
    createdBy: 'user3',
    createdAt: '2024-01-20T10:00:00Z',
    updatedAt: '2024-01-20T10:00:00Z',
  },
  {
    id: '2',
    title: 'Team Meeting - Weekly Standup',
    description: 'Weekly team sync and project updates',
    startTime: '2024-01-22T14:00:00Z',
    endTime: '2024-01-22T15:00:00Z',
    allDay: false,
    location: 'Conference Room A',
    type: 'meeting',
    status: 'busy',
    color: '#10B981',
    attendees: [
      { userId: 'user1', status: 'accepted', isRequired: true, role: 'organizer' },
      { userId: 'user2', status: 'accepted', isRequired: true, role: 'attendee' },
      { userId: 'user3', status: 'accepted', isRequired: true, role: 'attendee' },
      { userId: 'user4', status: 'tentative', isRequired: false, role: 'attendee' }
    ],
    isRecurring: true,
    recurrencePattern: {
      type: 'weekly',
      interval: 1,
      daysOfWeek: [1], // Monday
      endDate: '2024-12-31T23:59:59Z'
    },
    createdBy: 'user1',
    createdAt: '2024-01-15T10:00:00Z',
    updatedAt: '2024-01-15T10:00:00Z',
  },
  {
    id: '3',
    title: 'Sump Pump Installation - Davis Property',
    description: 'Complete sump pump system installation',
    startTime: '2024-01-23T08:00:00Z',
    endTime: '2024-01-23T16:00:00Z',
    allDay: false,
    location: '789 Pine Road, Springfield, IL',
    type: 'job',
    status: 'busy',
    color: '#F59E0B',
    attendees: [
      { userId: 'user5', status: 'accepted', isRequired: true, role: 'attendee' }
    ],
    isRecurring: false,
    jobId: '2',
    customerId: '3',
    createdBy: 'user3',
    createdAt: '2024-01-18T14:00:00Z',
    updatedAt: '2024-01-18T14:00:00Z',
  },
  {
    id: '4',
    title: 'Lunch Break',
    description: 'Daily lunch break',
    startTime: '2024-01-22T12:00:00Z',
    endTime: '2024-01-22T13:00:00Z',
    allDay: false,
    type: 'break',
    status: 'time_off',
    color: '#6B7280',
    attendees: [
      { userId: 'user4', status: 'accepted', isRequired: true, role: 'attendee' }
    ],
    isRecurring: true,
    recurrencePattern: {
      type: 'daily',
      interval: 1,
      endDate: '2024-12-31T23:59:59Z'
    },
    createdBy: 'user4',
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: '5',
    title: 'Customer Consultation - Brown Property',
    description: 'Discuss foundation repair options and pricing',
    startTime: '2024-01-24T10:00:00Z',
    endTime: '2024-01-24T11:30:00Z',
    allDay: false,
    location: '321 Cedar Lane, Springfield, IL',
    type: 'appointment',
    status: 'tentative',
    color: '#8B5CF6',
    attendees: [
      { userId: 'user2', status: 'accepted', isRequired: true, role: 'attendee' }
    ],
    isRecurring: false,
    leadId: '4',
    customerId: '4',
    createdBy: 'user2',
    createdAt: '2024-01-19T16:00:00Z',
    updatedAt: '2024-01-19T16:00:00Z',
  },
  {
    id: '6',
    title: 'Independence Day',
    description: 'Federal Holiday',
    startTime: '2024-07-04T00:00:00Z',
    endTime: '2024-07-04T23:59:59Z',
    allDay: true,
    type: 'personal',
    status: 'time_off',
    color: '#EF4444',
    attendees: [
      { userId: 'user1', status: 'accepted', isRequired: true, role: 'attendee' }
    ],
    isRecurring: false,
    createdBy: 'system',
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  }
];

const defaultSettings: CalendarSettings = {
  workingHours: {
    start: '08:00',
    end: '17:00'
  },
  workingDays: [1, 2, 3, 4, 5], // Monday to Friday
  timeZone: 'America/Chicago',
  defaultEventDuration: 60,
  allowOverlapping: false,
  autoSyncInterval: 15,
  defaultView: 'week',
  holidaySync: {
    enabled: false,
    lastSynced: null,
    includeFederal: true,
    includeReligious: false,
    includeObservances: false
  }
};

const defaultFilters: ScheduleFilters = {
  teamIds: [],
  userIds: [],
  eventTypes: [],
  statuses: [],
  dateRange: {
    start: null,
    end: null
  },
  showRecurringOnly: false,
  showConflictsOnly: false
};

export const useScheduleStore = create<ScheduleState>()(
  persist(
    (set, get) => ({
      // Initial State
      events: mockEvents,
      settings: defaultSettings,
      googleConfig: {
        isConnected: false,
        syncEnabled: true,
        conflictResolution: 'manual'
      },
      currentDate: new Date(),
      viewType: 'week',
      filters: defaultFilters,
      isLoading: false,
      error: null,
      lastSyncTime: null,
      
      // Computed
      get isGoogleConnected() {
        return get().googleConfig.isConnected;
      },
      
      // UI Actions
      setCurrentDate: (date) => set({ currentDate: date }),
      setViewType: (view) => set({ viewType: view }),
      updateFilters: (newFilters) => set((state) => ({
        filters: { ...state.filters, ...newFilters }
      })),
      setError: (error) => set({ error }),
      setLoading: (loading) => set({ isLoading: loading }),
      updateSettings: (newSettings) => set((state) => ({
        settings: { ...state.settings, ...newSettings }
      })),
      
      // Event Actions
      fetchEvents: async () => {
        set({ isLoading: true, error: null });
        try {
          const response = await api.get('/schedule/events');
          set({ events: response.data.events, isLoading: false });
        } catch (error: any) {
          console.log('API not available, using mock data');
          set({ isLoading: false });
        }
      },
      
      createEvent: async (eventData) => {
        set({ isLoading: true, error: null });
        try {
          const response = await api.post('/schedule/events', eventData);
          const newEvent = response.data.event;
          set((state) => ({ 
            events: [...state.events, newEvent], 
            isLoading: false 
          }));
        } catch (error: any) {
          // Mock create for development
          const newEvent: ScheduleEvent = {
            id: generateId(),
            title: eventData.title || '',
            description: eventData.description,
            startTime: eventData.startTime || new Date().toISOString(),
            endTime: eventData.endTime || new Date(Date.now() + 60 * 60 * 1000).toISOString(),
            allDay: eventData.allDay || false,
            location: eventData.location,
            type: eventData.type || 'appointment',
            status: eventData.status || 'tentative',
            color: eventData.color || '#3B82F6',
            attendees: eventData.attendees || [],
            isRecurring: eventData.isRecurring || false,
            recurrencePattern: eventData.recurrencePattern,
            jobId: eventData.jobId,
            customerId: eventData.customerId,
            leadId: eventData.leadId,
            taskId: eventData.taskId,
            createdBy: eventData.createdBy || 'current-user',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };
          
          set((state) => ({ 
            events: [...state.events, newEvent], 
            isLoading: false 
          }));
        }
      },
      
      updateEvent: async (id, updates) => {
        set({ isLoading: true, error: null });
        try {
          const response = await api.put(`/schedule/events/${id}`, updates);
          const updatedEvent = response.data.event;
          set((state) => ({
            events: state.events.map(event => 
              event.id === id ? updatedEvent : event
            ),
            isLoading: false
          }));
        } catch (error: any) {
          // Mock update for development
          set((state) => ({
            events: state.events.map(event => 
              event.id === id ? { ...event, ...updates, updatedAt: new Date().toISOString() } : event
            ),
            isLoading: false
          }));
        }
      },
      
      deleteEvent: async (id) => {
        set({ isLoading: true, error: null });
        try {
          await api.delete(`/schedule/events/${id}`);
          set((state) => ({
            events: state.events.filter(event => event.id !== id),
            isLoading: false
          }));
        } catch (error: any) {
          // Mock delete for development
          set((state) => ({
            events: state.events.filter(event => event.id !== id),
            isLoading: false
          }));
        }
      },
      
      bulkCreateEvents: async (eventsData) => {
        set({ isLoading: true, error: null });
        try {
          const response = await api.post('/schedule/events/bulk', { events: eventsData });
          const newEvents = response.data.events;
          set((state) => ({ 
            events: [...state.events, ...newEvents], 
            isLoading: false 
          }));
        } catch (error: any) {
          // Mock bulk create for development
          const newEvents = eventsData.map(eventData => ({
            id: generateId(),
            title: eventData.title || '',
            description: eventData.description,
            startTime: eventData.startTime || new Date().toISOString(),
            endTime: eventData.endTime || new Date(Date.now() + 60 * 60 * 1000).toISOString(),
            allDay: eventData.allDay || false,
            location: eventData.location,
            type: eventData.type || 'appointment',
            status: eventData.status || 'tentative',
            color: eventData.color || '#3B82F6',
            attendees: eventData.attendees || [],
            isRecurring: eventData.isRecurring || false,
            recurrencePattern: eventData.recurrencePattern,
            jobId: eventData.jobId,
            customerId: eventData.customerId,
            leadId: eventData.leadId,
            taskId: eventData.taskId,
            createdBy: eventData.createdBy || 'current-user',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          }));
          
          set((state) => ({ 
            events: [...state.events, ...newEvents], 
            isLoading: false 
          }));
        }
      },
      
      // Recurrence Actions
      createRecurringEvents: async (baseEvent, pattern) => {
        // Implementation for creating recurring events
        console.log('Creating recurring events:', baseEvent, pattern);
      },
      
      updateRecurringSeries: async (parentId, updates) => {
        // Implementation for updating recurring series
        console.log('Updating recurring series:', parentId, updates);
      },
      
      deleteRecurringSeries: async (parentId) => {
        // Implementation for deleting recurring series
        console.log('Deleting recurring series:', parentId);
      },
      
      // Google Calendar Actions
      connectGoogleCalendar: async (authCode) => {
        try {
          const response = await api.post('/schedule/google/connect', { authCode });
          set((state) => ({
            googleConfig: {
              ...state.googleConfig,
              isConnected: true,
              accessToken: response.data.accessToken,
              refreshToken: response.data.refreshToken,
              calendarId: response.data.calendarId
            }
          }));
        } catch (error: any) {
          console.error('Failed to connect Google Calendar:', error);
          throw error;
        }
      },
      
      disconnectGoogleCalendar: async () => {
        try {
          await api.post('/schedule/google/disconnect');
          set((state) => ({
            googleConfig: {
              ...state.googleConfig,
              isConnected: false,
              accessToken: undefined,
              refreshToken: undefined,
              calendarId: undefined
            }
          }));
        } catch (error: any) {
          console.error('Failed to disconnect Google Calendar:', error);
        }
      },
      
      syncWithGoogle: async () => {
        set({ isLoading: true, error: null });
        try {
          const response = await api.post('/schedule/google/sync');
          set((state) => ({
            events: response.data.events,
            lastSyncTime: new Date().toISOString(),
            isLoading: false
          }));
        } catch (error: any) {
          console.log('Google sync not available, using mock data');
          set({ 
            lastSyncTime: new Date().toISOString(),
            isLoading: false 
          });
        }
      },
      
      // Import/Export Actions
      exportEvents: async (events) => {
        try {
          const response = await api.post('/schedule/export', { events });
          // Trigger download
          const blob = new Blob([response.data], { type: 'text/calendar' });
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `schedule-export-${new Date().toISOString().split('T')[0]}.ics`;
          a.click();
          window.URL.revokeObjectURL(url);
        } catch (error: any) {
          console.error('Failed to export events:', error);
        }
      },
      
      importEvents: async (file) => {
        try {
          const formData = new FormData();
          formData.append('file', file);
          const response = await api.post('/schedule/import', formData, {
            headers: { 'Content-Type': 'multipart/form-data' }
          });
          set((state) => ({
            events: [...state.events, ...response.data.events]
          }));
        } catch (error: any) {
          console.error('Failed to import events:', error);
        }
      },
      
      // Conflict Detection
      detectConflicts: (event) => {
        const { events } = get();
        const eventStart = new Date(event.startTime);
        const eventEnd = new Date(event.endTime);
        
        return events.filter(existingEvent => {
          if (existingEvent.id === event.id) return false;
          
          const existingStart = new Date(existingEvent.startTime);
          const existingEnd = new Date(existingEvent.endTime);
          
          // Check for time overlap
          const hasTimeOverlap = eventStart < existingEnd && eventEnd > existingStart;
          
          // Check for attendee overlap
          const hasAttendeeOverlap = event.attendees?.some(attendee =>
            existingEvent.attendees?.some(existing => existing.userId === attendee.userId)
          );
          
          return hasTimeOverlap && hasAttendeeOverlap;
        });
      },
      
      resolveConflict: async (eventId, resolution) => {
        // Implementation for conflict resolution
        console.log('Resolving conflict:', eventId, resolution);
      },
      
      // Availability
      checkAvailability: (userId, startTime, endTime) => {
        const { events } = get();
        return !events.some(event => {
          const eventStart = new Date(event.startTime);
          const eventEnd = new Date(event.endTime);
          const hasTimeOverlap = startTime < eventEnd && endTime > eventStart;
          const isUserAttending = event.attendees?.some(attendee => 
            attendee.userId === userId && attendee.status === 'accepted'
          );
          return hasTimeOverlap && isUserAttending;
        });
      },
      
      findAvailableSlots: (userIds, duration, dateRange) => {
        // Implementation for finding available time slots
        const slots: Date[] = [];
        const { settings } = get();
        
        // Generate time slots based on working hours and availability
        const current = new Date(dateRange.start);
        const end = new Date(dateRange.end);
        
        while (current < end) {
          const slotEnd = new Date(current.getTime() + duration * 60 * 1000);
          
          // Check if all users are available
          const allAvailable = userIds.every(userId => 
            get().checkAvailability(userId, current, slotEnd)
          );
          
          if (allAvailable) {
            slots.push(new Date(current));
          }
          
          // Move to next 30-minute slot
          current.setMinutes(current.getMinutes() + 30);
        }
        
        return slots;
      },
      
      // Activity Logging
      logEventActivity: async (eventId, action, details) => {
        // In a real implementation, this would call an API to log the activity
        const event = get().events.find(e => e.id === eventId);
        if (!event) return;
        
        console.log(`Activity Log: ${action} for event "${event.title}" (ID: ${eventId})`);
        
        if (event.customerId) {
          console.log(`Customer Activity: ${action} for customer ${event.customerId}`);
          // Here you would call an API to log this activity to the customer record
        }
        
        if (details) {
          console.log(`Details: ${details}`);
        }
      }
    }),
    {
      name: 'lux-schedule-storage',
      partialize: (state) => ({
        settings: state.settings,
        googleConfig: state.googleConfig,
        viewType: state.viewType,
        filters: state.filters,
      }),
    }
  )
);