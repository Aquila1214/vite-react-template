import { create } from 'zustand';
import { api } from '../lib/api';
import { generateId } from '../lib/utils';
import type { 
  SalesMetrics, 
  TeamMetrics, 
  HistoricalData, 
  SalesTarget, 
  TimePeriod,
  SalesActivity,
  SalesGoal
} from '../types/sales';

interface SalesState {
  // Data
  salesMetrics: SalesMetrics | null;
  teamMetrics: TeamMetrics | null;
  historicalData: HistoricalData | null;
  targets: SalesTarget[];
  activities: SalesActivity[];
  goals: SalesGoal[];
  
  // UI State
  isLoading: boolean;
  error: string | null;
  lastUpdated: string | null;
  
  // Actions
  setError: (error: string | null) => void;
  setLoading: (loading: boolean) => void;
  
  // Data fetching
  fetchSalesMetrics: (period: TimePeriod, userId?: string | null) => Promise<void>;
  fetchTeamMetrics: (period: TimePeriod, teamId?: string | null) => Promise<void>;
  fetchHistoricalData: (period: TimePeriod) => Promise<void>;
  fetchTargets: () => Promise<void>;
  fetchActivities: (userId?: string) => Promise<void>;
  fetchGoals: (userId?: string) => Promise<void>;
  
  // Data refresh
  refreshData: () => Promise<void>;
  
  // Target management
  createTarget: (target: Partial<SalesTarget>) => Promise<void>;
  updateTarget: (id: string, updates: Partial<SalesTarget>) => Promise<void>;
  deleteTarget: (id: string) => Promise<void>;
  
  // Goal management
  createGoal: (goal: Partial<SalesGoal>) => Promise<void>;
  updateGoal: (id: string, updates: Partial<SalesGoal>) => Promise<void>;
  deleteGoal: (id: string) => Promise<void>;
}

// Mock data
const mockSalesMetrics: SalesMetrics = {
  averageRevenuePerLead: 3250,
  leadConversionRate: 24.5,
  averageProjectValue: 8750,
  totalLeadVolume: 127,
  totalRevenue: 285000,
  leadsGenerated: 127,
  leadsConverted: 31,
  projectsWon: 28,
  projectsLost: 15,
  averageSalesCycle: 18,
  
  previousPeriodComparison: {
    averageRevenuePerLead: {
      current: 3250,
      previous: 2980,
      change: 270,
      changePercentage: 9.1,
      trend: 'up'
    },
    leadConversionRate: {
      current: 24.5,
      previous: 22.1,
      change: 2.4,
      changePercentage: 10.9,
      trend: 'up'
    },
    averageProjectValue: {
      current: 8750,
      previous: 8200,
      change: 550,
      changePercentage: 6.7,
      trend: 'up'
    },
    totalLeadVolume: {
      current: 127,
      previous: 118,
      change: 9,
      changePercentage: 7.6,
      trend: 'up'
    },
    totalRevenue: {
      current: 285000,
      previous: 245000,
      change: 40000,
      changePercentage: 16.3,
      trend: 'up'
    }
  },
  
  yearOverYearComparison: {
    averageRevenuePerLead: {
      current: 3250,
      previous: 2750,
      change: 500,
      changePercentage: 18.2,
      trend: 'up'
    },
    leadConversionRate: {
      current: 24.5,
      previous: 19.8,
      change: 4.7,
      changePercentage: 23.7,
      trend: 'up'
    },
    averageProjectValue: {
      current: 8750,
      previous: 7500,
      change: 1250,
      changePercentage: 16.7,
      trend: 'up'
    },
    totalLeadVolume: {
      current: 127,
      previous: 98,
      change: 29,
      changePercentage: 29.6,
      trend: 'up'
    },
    totalRevenue: {
      current: 285000,
      previous: 195000,
      change: 90000,
      changePercentage: 46.2,
      trend: 'up'
    }
  },
  
  leadsBySource: [
    { source: 'CallRail', count: 45, conversionRate: 28.9, revenue: 125000 },
    { source: 'Web Form', count: 38, conversionRate: 23.7, revenue: 85000 },
    { source: 'Referral', count: 32, conversionRate: 31.3, revenue: 95000 },
    { source: 'Direct', count: 12, conversionRate: 16.7, revenue: 25000 },
  ],
  
  monthlyTrends: [
    { month: 'Jan', leads: 42, conversions: 9, revenue: 78000, averageProjectValue: 8667 },
    { month: 'Feb', leads: 38, conversions: 8, revenue: 65000, averageProjectValue: 8125 },
    { month: 'Mar', leads: 47, conversions: 14, revenue: 125000, averageProjectValue: 8929 },
  ],
  
  targets: {
    revenue: { target: 300000, actual: 285000, percentage: 95.0 },
    leads: { target: 150, actual: 127, percentage: 84.7 },
    conversions: { target: 35, actual: 31, percentage: 88.6 }
  }
};

const mockTeamMetrics: TeamMetrics = {
  ...mockSalesMetrics,
  teamId: 'team1',
  teamName: 'Sales Team',
  memberCount: 4,
  topPerformers: [
    { userId: 'user2', userName: 'Sarah Johnson', metric: 'Revenue', value: 125000 },
    { userId: 'user3', userName: 'Mike Wilson', metric: 'Conversions', value: 18 },
    { userId: 'user4', userName: 'Lisa Chen', metric: 'Lead Volume', value: 67 },
  ],
  teamRankings: [
    { userId: 'user2', userName: 'Sarah Johnson', revenue: 125000, leads: 45, conversions: 12, conversionRate: 26.7, rank: 1 },
    { userId: 'user3', userName: 'Mike Wilson', revenue: 95000, leads: 38, conversions: 10, conversionRate: 26.3, rank: 2 },
    { userId: 'user4', userName: 'Lisa Chen', revenue: 65000, leads: 44, conversions: 9, conversionRate: 20.5, rank: 3 },
  ]
};

const mockHistoricalData: HistoricalData = {
  daily: Array.from({ length: 30 }, (_, i) => ({
    date: new Date(Date.now() - i * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    leads: Math.floor(Math.random() * 8) + 2,
    conversions: Math.floor(Math.random() * 3) + 1,
    revenue: Math.floor(Math.random() * 15000) + 5000,
  })).reverse(),
  weekly: Array.from({ length: 12 }, (_, i) => ({
    week: `Week ${i + 1}`,
    leads: Math.floor(Math.random() * 25) + 15,
    conversions: Math.floor(Math.random() * 8) + 3,
    revenue: Math.floor(Math.random() * 50000) + 25000,
  })),
  monthly: Array.from({ length: 12 }, (_, i) => ({
    month: new Date(2024, i, 1).toLocaleDateString('en-US', { month: 'short' }),
    leads: Math.floor(Math.random() * 80) + 40,
    conversions: Math.floor(Math.random() * 25) + 10,
    revenue: Math.floor(Math.random() * 150000) + 75000,
  })),
  quarterly: [
    { quarter: 'Q1 2024', leads: 180, conversions: 45, revenue: 425000 },
    { quarter: 'Q2 2024', leads: 195, conversions: 52, revenue: 485000 },
    { quarter: 'Q3 2024', leads: 210, conversions: 58, revenue: 525000 },
    { quarter: 'Q4 2024', leads: 165, conversions: 42, revenue: 395000 },
  ],
  yearly: [
    { year: '2022', leads: 580, conversions: 125, revenue: 1250000 },
    { year: '2023', leads: 720, conversions: 165, revenue: 1650000 },
    { year: '2024', leads: 750, conversions: 197, revenue: 1830000 },
  ]
};

const mockTargets: SalesTarget[] = [
  {
    id: '1',
    userId: 'user2',
    type: 'revenue',
    period: 'monthly',
    target: 100000,
    actual: 85000,
    percentage: 85.0,
    startDate: '2024-01-01',
    endDate: '2024-01-31',
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: '2',
    teamId: 'team1',
    type: 'leads',
    period: 'quarterly',
    target: 450,
    actual: 385,
    percentage: 85.6,
    startDate: '2024-01-01',
    endDate: '2024-03-31',
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
];

export const useSalesStore = create<SalesState>((set, get) => ({
  // Initial State
  salesMetrics: mockSalesMetrics,
  teamMetrics: mockTeamMetrics,
  historicalData: mockHistoricalData,
  targets: mockTargets,
  activities: [],
  goals: [],
  isLoading: false,
  error: null,
  lastUpdated: new Date().toISOString(),
  
  // UI Actions
  setError: (error) => set({ error }),
  setLoading: (loading) => set({ isLoading: loading }),
  
  // Data fetching
  fetchSalesMetrics: async (period, userId) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/sales/metrics', {
        params: { period, userId }
      });
      set({ 
        salesMetrics: response.data.metrics, 
        isLoading: false,
        lastUpdated: new Date().toISOString()
      });
    } catch (error: any) {
      console.log('API not available, using mock data');
      // Mock data is already set in initial state
      set({ isLoading: false, lastUpdated: new Date().toISOString() });
    }
  },
  
  fetchTeamMetrics: async (period, teamId) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/sales/team-metrics', {
        params: { period, teamId }
      });
      set({ 
        teamMetrics: response.data.metrics, 
        isLoading: false,
        lastUpdated: new Date().toISOString()
      });
    } catch (error: any) {
      console.log('API not available, using mock data');
      // Mock data is already set in initial state
      set({ isLoading: false, lastUpdated: new Date().toISOString() });
    }
  },
  
  fetchHistoricalData: async (period) => {
    try {
      const response = await api.get('/sales/historical', {
        params: { period }
      });
      set({ historicalData: response.data.data });
    } catch (error: any) {
      console.log('API not available, using mock data');
      // Mock data is already set in initial state
    }
  },
  
  fetchTargets: async () => {
    try {
      const response = await api.get('/sales/targets');
      set({ targets: response.data.targets });
    } catch (error: any) {
      console.log('API not available, using mock data');
      // Mock data is already set in initial state
    }
  },
  
  fetchActivities: async (userId) => {
    try {
      const response = await api.get('/sales/activities', {
        params: { userId }
      });
      set({ activities: response.data.activities });
    } catch (error: any) {
      console.log('API not available, using mock data');
    }
  },
  
  fetchGoals: async (userId) => {
    try {
      const response = await api.get('/sales/goals', {
        params: { userId }
      });
      set({ goals: response.data.goals });
    } catch (error: any) {
      console.log('API not available, using mock data');
    }
  },
  
  refreshData: async () => {
    const { fetchSalesMetrics, fetchTeamMetrics, fetchHistoricalData, fetchTargets } = get();
    await Promise.all([
      fetchSalesMetrics('last30days'),
      fetchTeamMetrics('last30days'),
      fetchHistoricalData('last30days'),
      fetchTargets(),
    ]);
  },
  
  // Target management
  createTarget: async (targetData) => {
    try {
      const response = await api.post('/sales/targets', targetData);
      const newTarget = response.data.target;
      set((state) => ({ 
        targets: [...state.targets, newTarget]
      }));
    } catch (error: any) {
      // Mock create for development
      const newTarget: SalesTarget = {
        id: generateId(),
        type: targetData.type || 'revenue',
        period: targetData.period || 'monthly',
        target: targetData.target || 0,
        actual: 0,
        percentage: 0,
        startDate: targetData.startDate || new Date().toISOString(),
        endDate: targetData.endDate || new Date().toISOString(),
        userId: targetData.userId,
        teamId: targetData.teamId,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      set((state) => ({ 
        targets: [...state.targets, newTarget]
      }));
    }
  },
  
  updateTarget: async (id, updates) => {
    try {
      const response = await api.put(`/sales/targets/${id}`, updates);
      const updatedTarget = response.data.target;
      set((state) => ({
        targets: state.targets.map(target => 
          target.id === id ? updatedTarget : target
        )
      }));
    } catch (error: any) {
      // Mock update for development
      set((state) => ({
        targets: state.targets.map(target => 
          target.id === id ? { ...target, ...updates, updatedAt: new Date().toISOString() } : target
        )
      }));
    }
  },
  
  deleteTarget: async (id) => {
    try {
      await api.delete(`/sales/targets/${id}`);
      set((state) => ({
        targets: state.targets.filter(target => target.id !== id)
      }));
    } catch (error: any) {
      // Mock delete for development
      set((state) => ({
        targets: state.targets.filter(target => target.id !== id)
      }));
    }
  },
  
  // Goal management
  createGoal: async (goalData) => {
    try {
      const response = await api.post('/sales/goals', goalData);
      const newGoal = response.data.goal;
      set((state) => ({ 
        goals: [...state.goals, newGoal]
      }));
    } catch (error: any) {
      // Mock create for development
      const newGoal: SalesGoal = {
        id: generateId(),
        userId: goalData.userId || '',
        title: goalData.title || '',
        description: goalData.description || '',
        targetValue: goalData.targetValue || 0,
        currentValue: 0,
        unit: goalData.unit || 'currency',
        deadline: goalData.deadline || new Date().toISOString(),
        status: 'active',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      set((state) => ({ 
        goals: [...state.goals, newGoal]
      }));
    }
  },
  
  updateGoal: async (id, updates) => {
    try {
      const response = await api.put(`/sales/goals/${id}`, updates);
      const updatedGoal = response.data.goal;
      set((state) => ({
        goals: state.goals.map(goal => 
          goal.id === id ? updatedGoal : goal
        )
      }));
    } catch (error: any) {
      // Mock update for development
      set((state) => ({
        goals: state.goals.map(goal => 
          goal.id === id ? { ...goal, ...updates, updatedAt: new Date().toISOString() } : goal
        )
      }));
    }
  },
  
  deleteGoal: async (id) => {
    try {
      await api.delete(`/sales/goals/${id}`);
      set((state) => ({
        goals: state.goals.filter(goal => goal.id !== id)
      }));
    } catch (error: any) {
      // Mock delete for development
      set((state) => ({
        goals: state.goals.filter(goal => goal.id !== id)
      }));
    }
  },
}));