import { create } from 'zustand';
import { api } from '../lib/api';
import { supabase } from '../lib/supabase';
import { generateId } from '../lib/utils';
import { supabase, storageBucket } from '../lib/supabase';
import type { 
  Customer, 
  Lead, 
  Job, 
  Task, 
  Estimate, 
  Invoice, 
  User, 
  Message, 
  FileUpload, 
  UnknownContact, 
  GeneralContact, 
  ContactLabel,
  Team,
  Location,
  EstimateLineItem,
  PipelineStage,
  ActivityItem,
  DashboardStats
} from '../types';

interface CrmState {
  // Data
  customers: Customer[];
  leads: Lead[];
  jobs: Job[];
  tasks: Task[];
  estimates: Estimate[];
  invoices: Invoice[];
  users: User[];
  messages: Message[];
  files: FileUpload[];
  unknownContacts: UnknownContact[];
  generalContacts: GeneralContact[];
  contactLabels: ContactLabel[];
  teams: Team[];
  
  // UI State
  isLoading: boolean;
  error: string | null;
  selectedCustomer: Customer | null;
  selectedLead: Lead | null;
  selectedJob: Job | null;
  
  // Dashboard Data
  dashboardStats: DashboardStats | null;
  pipeline: PipelineStage[];
  recentActivity: ActivityItem[];
  
  // Actions
  setError: (error: string | null) => void;
  setLoading: (loading: boolean) => void;
  setSelectedCustomer: (customer: Customer | null) => void;
  setSelectedLead: (lead: Lead | null) => void;
  setSelectedJob: (job: Job | null) => void;
  
  // Data fetching
  fetchCustomers: () => Promise<void>;
  fetchLeads: () => Promise<void>;
  fetchJobs: () => Promise<void>;
  fetchTasks: () => Promise<void>;
  fetchEstimates: () => Promise<void>;
  fetchInvoices: () => Promise<void>;
  fetchUsers: () => Promise<void>;
  fetchMessages: () => Promise<void>;
  fetchFiles: (jobId?: string) => Promise<void>;
  fetchCustomerFiles: (customerId: string) => Promise<void>;
  fetchUnknownContacts: () => Promise<void>;
  fetchGeneralContacts: () => Promise<void>;
  fetchContactLabels: () => Promise<void>;
  fetchTeams: () => Promise<void>;
  fetchDashboardStats: () => Promise<void>;
  fetchPipeline: () => Promise<void>;
  
  // CRUD operations - Customers
  createCustomer: (data: Partial<Customer>) => Promise<Customer>;
  updateCustomer: (id: string, data: Partial<Customer>) => Promise<void>;
  deleteCustomer: (id: string) => Promise<void>;
  
  // CRUD operations - Leads
  createLead: (data: Partial<Lead>) => Promise<Lead>;
  updateLead: (id: string, data: Partial<Lead>) => Promise<void>;
  deleteLead: (id: string) => Promise<void>;
  
  // CRUD operations - Jobs
  createJob: (data: Partial<Job>) => Promise<Job>;
  updateJob: (id: string, data: Partial<Job>) => Promise<void>;
  deleteJob: (id: string) => Promise<void>;
  
  // CRUD operations - Tasks
  createTask: (data: Partial<Task>) => Promise<Task>;
  updateTask: (id: string, data: Partial<Task>) => Promise<void>;
  deleteTask: (id: string) => Promise<void>;
  
  // CRUD operations - Estimates
  createEstimate: (data: Partial<Estimate>) => Promise<Estimate>;
  updateEstimate: (id: string, data: Partial<Estimate>) => Promise<void>;
  deleteEstimate: (id: string) => Promise<void>;
  
  // CRUD operations - Invoices
  createInvoice: (data: Partial<Invoice>) => Promise<Invoice>;
  updateInvoice: (id: string, data: Partial<Invoice>) => Promise<void>;
  deleteInvoice: (id: string) => Promise<void>;
  
  // CRUD operations - Messages
  createMessage: (data: Partial<Message>) => Promise<Message>;
  updateMessage: (id: string, data: Partial<Message>) => Promise<void>;
  deleteMessage: (id: string) => Promise<void>;
  
  // CRUD operations - Files
  uploadFile: (jobId: string, file: File) => Promise<FileUpload>;
  uploadCustomerFile: (customerId: string, file: File) => Promise<FileUpload>;
  deleteFile: (id: string) => Promise<void>;
  
  // Supabase integration
  isSupabaseConnected: boolean;
  
  // CRUD operations - Unknown Contacts
  addUnknownContact: (data: Partial<UnknownContact>) => Promise<UnknownContact>;
  updateUnknownContact: (id: string, data: Partial<UnknownContact>) => Promise<void>;
  deleteUnknownContact: (id: string) => Promise<void>;
  convertUnknownToCustomer: (id: string, customerData: Partial<Customer>) => Promise<Customer>;
  linkUnknownToCustomer: (unknownId: string, customerId: string) => Promise<void>;
  
  // CRUD operations - General Contacts
  createGeneralContact: (data: Partial<GeneralContact>) => Promise<GeneralContact>;
  updateGeneralContact: (id: string, data: Partial<GeneralContact>) => Promise<void>;
  deleteGeneralContact: (id: string) => Promise<void>;
  
  // CRUD operations - Contact Labels
  createContactLabel: (data: Partial<ContactLabel>) => Promise<ContactLabel>;
  updateContactLabel: (id: string, data: Partial<ContactLabel>) => Promise<void>;
  deleteContactLabel: (id: string) => Promise<void>;
  addLabelToContact: (contactId: string, labelId: string) => Promise<void>;
  removeLabelFromContact: (contactId: string, labelId: string) => Promise<void>;
  
  // CRUD operations - Teams
  createTeam: (data: Partial<Team>) => Promise<Team>;
  updateTeam: (id: string, data: Partial<Team>) => Promise<void>;
  deleteTeam: (id: string) => Promise<void>;
}

// Mock data for development
const mockCustomers: Customer[] = [
  {
    id: '1',
    name: 'John Smith',
    phone: '(555) 123-4567',
    email: 'john.smith@example.com',
    address: '123 Main St, Springfield, IL',
    notes: 'Interested in foundation repair services.',
    leadSource: 'REFERRAL',
    createdAt: '2023-01-15T00:00:00Z',
    updatedAt: '2023-01-15T00:00:00Z',
  },
  {
    id: '2',
    name: 'Jane Doe',
    phone: '(555) 987-6543',
    email: 'jane.doe@example.com',
    address: '456 Oak Ave, Springfield, IL',
    billingAddress: '789 Billing St, Springfield, IL',
    notes: 'Previous customer, had waterproofing done in 2022.',
    leadSource: 'DIRECT',
    createdAt: '2022-11-20T00:00:00Z',
    updatedAt: '2022-11-20T00:00:00Z',
  },
  {
    id: '3',
    name: 'Bob Johnson',
    phone: '(555) 456-7890',
    email: 'bob.johnson@example.com',
    address: '789 Pine Rd, Springfield, IL',
    notes: 'Needs estimate for crawlspace repair.',
    leadSource: 'CALLRAIL',
    createdAt: '2023-02-05T00:00:00Z',
    updatedAt: '2023-02-05T00:00:00Z',
  },
  {
    id: '4',
    name: 'Sarah Williams',
    phone: '(555) 789-0123',
    email: 'sarah.williams@example.com',
    address: '321 Cedar Ln, Springfield, IL',
    notes: 'Interested in concrete leveling.',
    leadSource: 'FORM',
    createdAt: '2023-03-10T00:00:00Z',
    updatedAt: '2023-03-10T00:00:00Z',
  },
];

// Mock users
const mockUsers: User[] = [
  {
    id: 'user1',
    name: 'Admin User',
    email: 'admin@luxfoundation.com',
    role: 'ADMIN',
    phone: '(555) 111-0000',
    createdAt: '2023-01-01T00:00:00Z',
    updatedAt: '2023-01-01T00:00:00Z',
  },
  {
    id: 'user2',
    name: 'Sarah Johnson',
    email: 'sarah@luxfoundation.com',
    role: 'SALES',
    phone: '(555) 222-0000',
    teamId: 'team1',
    createdAt: '2023-01-02T00:00:00Z',
    updatedAt: '2023-01-02T00:00:00Z',
  },
  {
    id: 'user3',
    name: 'Mike Wilson',
    email: 'mike@luxfoundation.com',
    role: 'OPERATIONS',
    phone: '(555) 333-0000',
    teamId: 'team2',
    createdAt: '2023-01-03T00:00:00Z',
    updatedAt: '2023-01-03T00:00:00Z',
  },
  {
    id: 'user4',
    name: 'Lisa Chen',
    email: 'lisa@luxfoundation.com',
    role: 'TECHNICIAN',
    phone: '(555) 444-0000',
    teamId: 'team2',
    createdAt: '2023-01-04T00:00:00Z',
    updatedAt: '2023-01-04T00:00:00Z',
  },
];

// Mock teams
const mockTeams: Team[] = [
  {
    id: 'team1',
    name: 'Sales Team',
    description: 'Handles all sales and customer acquisition',
    color: '#3B82F6',
    leaderId: 'user2',
    createdAt: '2023-01-01T00:00:00Z',
    updatedAt: '2023-01-01T00:00:00Z',
  },
  {
    id: 'team2',
    name: 'Operations Team',
    description: 'Handles all project execution and field work',
    color: '#10B981',
    leaderId: 'user3',
    createdAt: '2023-01-01T00:00:00Z',
    updatedAt: '2023-01-01T00:00:00Z',
  },
];

// Mock leads
const mockLeads: Lead[] = [
  {
    id: 'lead1',
    customerId: '1',
    source: 'REFERRAL',
    status: 'QUALIFIED',
    priority: 'HIGH',
    tags: ['foundation', 'urgent'],
    notes: 'Customer has significant foundation issues that need immediate attention.',
    assignedTo: 'user2',
    leadScore: 85,
    createdAt: '2023-01-20T00:00:00Z',
    updatedAt: '2023-01-25T00:00:00Z',
  },
  {
    id: 'lead2',
    customerId: '2',
    source: 'DIRECT',
    status: 'ESTIMATE_SENT',
    priority: 'MEDIUM',
    tags: ['waterproofing', 'basement'],
    notes: 'Customer interested in basement waterproofing solutions.',
    assignedTo: 'user2',
    leadScore: 65,
    createdAt: '2022-12-05T00:00:00Z',
    updatedAt: '2022-12-10T00:00:00Z',
  },
  {
    id: 'lead3',
    customerId: '3',
    source: 'CALLRAIL',
    status: 'NEW',
    priority: 'MEDIUM',
    tags: ['crawlspace', 'inspection'],
    notes: 'Customer called about crawlspace issues, needs inspection.',
    leadScore: 45,
    createdAt: '2023-02-10T00:00:00Z',
    updatedAt: '2023-02-10T00:00:00Z',
  },
  {
    id: 'lead4',
    customerId: '4',
    source: 'FORM',
    status: 'CONTACTED',
    priority: 'LOW',
    tags: ['concrete', 'driveway'],
    notes: 'Customer submitted web form about concrete leveling for driveway.',
    assignedTo: 'user2',
    leadScore: 30,
    createdAt: '2023-03-15T00:00:00Z',
    updatedAt: '2023-03-16T00:00:00Z',
  },
];

// Mock jobs
const mockJobs: Job[] = [
  {
    id: 'job1',
    customerId: '1',
    leadId: 'lead1',
    jobAddress: '123 Main St, Springfield, IL',
    status: 'IN_PROGRESS',
    startDate: '2023-02-01T08:00:00Z',
    endDate: '2023-02-03T17:00:00Z',
    materials: 'Foundation piers, concrete mix, waterproofing membrane',
    notes: 'Major foundation repair project with multiple piers needed.',
    assignedTo: 'user4',
    projectType: 'foundation_repair',
    permitRequired: true,
    subStatus: 'Waiting for permit approval',
    tags: ['foundation', 'structural', 'permit'],
    progress: 35,
    estimatedValue: 12500,
    createdAt: '2023-01-26T00:00:00Z',
    updatedAt: '2023-01-30T00:00:00Z',
  },
  {
    id: 'job2',
    customerId: '2',
    leadId: 'lead2',
    jobAddress: '456 Oak Ave, Springfield, IL',
    status: 'SCHEDULED',
    startDate: '2023-02-15T08:00:00Z',
    endDate: '2023-02-16T17:00:00Z',
    materials: 'Waterproofing membrane, drainage system, sump pump',
    notes: 'Basement waterproofing project with new sump pump installation.',
    assignedTo: 'user4',
    projectType: 'waterproofing',
    permitRequired: false,
    tags: ['waterproofing', 'basement', 'drainage'],
    progress: 0,
    estimatedValue: 7800,
    createdAt: '2022-12-15T00:00:00Z',
    updatedAt: '2022-12-20T00:00:00Z',
  },
  {
    id: 'job3',
    customerId: '4',
    leadId: 'lead4',
    jobAddress: '321 Cedar Ln, Springfield, IL',
    status: 'SCHEDULED',
    startDate: '2023-04-01T08:00:00Z',
    endDate: '2023-04-01T17:00:00Z',
    materials: 'Concrete mix, leveling equipment',
    notes: 'Driveway concrete leveling project.',
    assignedTo: 'user4',
    projectType: 'concrete_repair',
    permitRequired: false,
    tags: ['concrete', 'driveway', 'leveling'],
    progress: 0,
    estimatedValue: 3200,
    createdAt: '2023-03-20T00:00:00Z',
    updatedAt: '2023-03-20T00:00:00Z',
  },
];

// Mock tasks
const mockTasks: Task[] = [
  {
    id: 'task1',
    description: 'Schedule initial inspection',
    dueDate: '2023-01-22T09:00:00Z',
    assignedTo: 'user2',
    status: 'COMPLETED',
    customerId: '1',
    type: 'TASK',
    priority: 'HIGH',
    notes: 'Need to schedule initial inspection for foundation issues.',
    createdAt: '2023-01-20T00:00:00Z',
    updatedAt: '2023-01-21T00:00:00Z',
  },
  {
    id: 'task2',
    description: 'Prepare estimate for waterproofing',
    dueDate: '2022-12-08T17:00:00Z',
    assignedTo: 'user2',
    status: 'COMPLETED',
    customerId: '2',
    type: 'TASK',
    priority: 'MEDIUM',
    notes: 'Create detailed estimate for basement waterproofing project.',
    createdAt: '2022-12-06T00:00:00Z',
    updatedAt: '2022-12-08T00:00:00Z',
  },
  {
    id: 'task3',
    description: 'Follow up with Bob Johnson',
    dueDate: '2023-02-15T10:00:00Z',
    assignedTo: 'user2',
    status: 'PENDING',
    customerId: '3',
    type: 'REMINDER',
    priority: 'MEDIUM',
    notes: 'Call to schedule crawlspace inspection.',
    createdAt: '2023-02-10T00:00:00Z',
    updatedAt: '2023-02-10T00:00:00Z',
  },
  {
    id: 'task4',
    description: 'Order materials for Job #1',
    dueDate: '2023-01-28T12:00:00Z',
    assignedTo: 'user3',
    status: 'COMPLETED',
    jobId: 'job1',
    type: 'TASK',
    priority: 'HIGH',
    notes: 'Order foundation piers and other materials for the Smith project.',
    createdAt: '2023-01-26T00:00:00Z',
    updatedAt: '2023-01-27T00:00:00Z',
  },
  {
    id: 'task5',
    description: 'Apply for building permit',
    dueDate: '2023-01-27T17:00:00Z',
    assignedTo: 'user3',
    status: 'COMPLETED',
    jobId: 'job1',
    type: 'TASK',
    priority: 'URGENT',
    notes: 'Submit permit application for the Smith foundation repair project.',
    createdAt: '2023-01-26T00:00:00Z',
    updatedAt: '2023-01-26T00:00:00Z',
  },
];

// Mock estimates
const mockEstimates: Estimate[] = [
  {
    id: 'estimate1',
    jobId: 'job1',
    customerId: '1',
    total: 12500,
    lineItems: [
      {
        id: 'item1-1',
        description: 'Foundation Pier Installation (6 piers)',
        quantity: 6,
        unitPrice: 1200,
        total: 7200
      },
      {
        id: 'item1-2',
        description: 'Concrete Work',
        quantity: 1,
        unitPrice: 2800,
        total: 2800
      },
      {
        id: 'item1-3',
        description: 'Waterproofing',
        quantity: 1,
        unitPrice: 1500,
        total: 1500
      },
      {
        id: 'item1-4',
        description: 'Labor',
        quantity: 20,
        unitPrice: 50,
        total: 1000
      }
    ],
    accepted: true,
    signedAt: '2023-01-25T00:00:00Z',
    expirationDate: '2023-02-25T00:00:00Z',
    notes: 'This estimate includes all materials and labor for the foundation repair project.',
    terms: 'Payment due upon completion. 1-year warranty on all work.',
    sketchData: {
      elements: [],
      materials: [
        {
          id: 'mat1',
          name: 'Foundation Pier',
          category: 'Foundation',
          quantity: 6,
          unit: 'each',
          unitPrice: 1200,
          total: 7200
        },
        {
          id: 'mat2',
          name: 'Concrete Mix',
          category: 'Concrete',
          quantity: 2,
          unit: 'cubic yd',
          unitPrice: 125,
          total: 250
        }
      ],
      totalCost: 7450
    },
    createdAt: '2023-01-22T00:00:00Z',
    updatedAt: '2023-01-25T00:00:00Z',
  },
  {
    id: 'estimate2',
    jobId: 'job2',
    customerId: '2',
    total: 7800,
    lineItems: [
      {
        id: 'item2-1',
        description: 'Interior Drainage System',
        quantity: 60,
        unitPrice: 85,
        total: 5100
      },
      {
        id: 'item2-2',
        description: 'Sump Pump Installation',
        quantity: 1,
        unitPrice: 1200,
        total: 1200
      },
      {
        id: 'item2-3',
        description: 'Waterproofing Membrane',
        quantity: 125,
        unitPrice: 12,
        total: 1500
      }
    ],
    accepted: false,
    expirationDate: '2023-01-15T00:00:00Z',
    notes: 'This estimate includes a complete basement waterproofing system with interior drainage and sump pump.',
    terms: 'Payment due upon completion. 5-year warranty on all work.',
    createdAt: '2022-12-15T00:00:00Z',
    updatedAt: '2022-12-15T00:00:00Z',
  },
  {
    id: 'estimate3',
    jobId: 'job3',
    customerId: '4',
    total: 3200,
    lineItems: [
      {
        id: 'item3-1',
        description: 'Concrete Leveling - Driveway',
        quantity: 400,
        unitPrice: 8,
        total: 3200
      }
    ],
    accepted: false,
    expirationDate: '2023-04-20T00:00:00Z',
    notes: 'This estimate is for leveling the concrete driveway at the specified address.',
    terms: 'Payment due upon completion. 1-year warranty on all work.',
    createdAt: '2023-03-20T00:00:00Z',
    updatedAt: '2023-03-20T00:00:00Z',
  },
];

// Mock invoices
const mockInvoices: Invoice[] = [
  {
    id: 'invoice1',
    estimateId: 'estimate1',
    customerId: '1',
    status: 'PAID',
    dueDate: '2023-03-01T00:00:00Z',
    amount: 12500,
    stripePaymentUrl: 'https://checkout.stripe.com/pay/cs_test_mock',
    createdAt: '2023-02-05T00:00:00Z',
    updatedAt: '2023-02-10T00:00:00Z',
  },
  {
    id: 'invoice2',
    estimateId: 'estimate2',
    customerId: '2',
    status: 'UNPAID',
    dueDate: '2023-03-15T00:00:00Z',
    amount: 7800,
    stripePaymentUrl: 'https://checkout.stripe.com/pay/cs_test_mock',
    createdAt: '2023-02-15T00:00:00Z',
    updatedAt: '2023-02-15T00:00:00Z',
  },
];

// Mock messages
const mockMessages: Message[] = [
  {
    id: 'message1',
    customerId: '1',
    userId: 'user2',
    type: 'SMS',
    content: 'Hello Mr. Smith, this is Sarah from Lux Foundation. I wanted to follow up on our conversation about your foundation repair needs.',
    timestamp: '2023-01-18T10:30:00Z',
    direction: 'OUTBOUND',
  },
  {
    id: 'message2',
    customerId: '1',
    type: 'SMS',
    content: 'Hi Sarah, thanks for reaching out. I\'m definitely interested in getting an estimate.',
    timestamp: '2023-01-18T10:45:00Z',
    direction: 'INBOUND',
    fromPhone: '(555) 123-4567',
    fromName: 'John Smith',
  },
  {
    id: 'message3',
    customerId: '2',
    userId: 'user2',
    type: 'EMAIL',
    content: 'Hello Ms. Doe, I\'ve attached the estimate for your basement waterproofing project. Please let me know if you have any questions.',
    timestamp: '2022-12-15T14:00:00Z',
    direction: 'OUTBOUND',
  },
];

// Mock pipeline stages
const mockPipeline: PipelineStage[] = [
  { status: 'NEW', count: 1, value: 5000 },
  { status: 'CONTACTED', count: 1, value: 3200 },
  { status: 'QUALIFIED', count: 1, value: 12500 },
  { status: 'ESTIMATE_SENT', count: 1, value: 7800 },
  { status: 'CONVERTED', count: 0, value: 0 },
  { status: 'LOST', count: 0, value: 0 },
];

// Mock dashboard stats
const mockDashboardStats: DashboardStats = {
  totalCustomers: 4,
  totalLeads: 4,
  activeJobs: 3,
  pendingEstimates: 2,
  monthlyRevenue: 12500,
};

export const useCrmStore = create<CrmState>((set, get) => ({
  // Initial State
  customers: mockCustomers,
  leads: mockLeads,
  isSupabaseConnected: !!supabase,
  jobs: mockJobs,
  tasks: mockTasks,
  estimates: mockEstimates,
  invoices: mockInvoices,
  users: mockUsers,
  messages: mockMessages,
  files: [],
  unknownContacts: [],
  generalContacts: [],
  contactLabels: [],
  teams: mockTeams,
  isLoading: false,
  error: null,
  selectedCustomer: null,
  selectedLead: null,
  selectedJob: null,
  dashboardStats: mockDashboardStats,
  pipeline: mockPipeline,
  recentActivity: [],
  
  // UI Actions
  setError: (error) => set({ error }),
  setLoading: (loading) => set({ isLoading: loading }),
  setSelectedCustomer: (customer) => set({ selectedCustomer: customer }),
  setSelectedLead: (lead) => set({ selectedLead: lead }),
  setSelectedJob: (job) => set({ selectedJob: job }),
  
  // Data fetching
  fetchCustomers: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/customers');
      set({ customers: response.data, isLoading: false });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ isLoading: false });
    }
  },
  
  fetchLeads: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/leads');
      set({ leads: response.data, isLoading: false });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ isLoading: false });
    }
  },
  
  fetchJobs: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/jobs');
      set({ jobs: response.data, isLoading: false });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ isLoading: false });
    }
  },
  
  fetchTasks: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/tasks');
      set({ tasks: response.data, isLoading: false });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ isLoading: false });
    }
  },
  
  fetchEstimates: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/estimates');
      set({ estimates: response.data, isLoading: false });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ isLoading: false });
    }
  },
  
  fetchInvoices: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/invoices');
      set({ invoices: response.data, isLoading: false });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ isLoading: false });
    }
  },
  
  fetchUsers: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/users');
      set({ users: response.data, isLoading: false });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ isLoading: false });
    }
  },
  
  fetchMessages: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/messages');
      set({ messages: response.data, isLoading: false });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ isLoading: false });
    }
  },
  
  fetchFiles: async (jobId) => {
    set({ isLoading: true, error: null });
    try {
      const url = jobId ? `/files/job/${jobId}` : '/files';
      const response = await api.get(url);
      set({ files: response.data, isLoading: false });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ isLoading: false });
    }
  },
  
  fetchCustomerFiles: async (customerId) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get(`/files/customer/${customerId}`);
      set({ files: response.data, isLoading: false });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ isLoading: false });
    }
  },
  
  fetchUnknownContacts: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/unknown-contacts');
      set({ unknownContacts: response.data, isLoading: false });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ isLoading: false });
    }
  },
  
  fetchGeneralContacts: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/general-contacts');
      set({ generalContacts: response.data, isLoading: false });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ isLoading: false });
    }
  },
  
  fetchContactLabels: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/contact-labels');
      set({ contactLabels: response.data, isLoading: false });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ isLoading: false });
    }
  },
  
  fetchTeams: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/teams');
      set({ teams: response.data, isLoading: false });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ isLoading: false });
    }
  },
  
  fetchDashboardStats: async () => {
    set({ isLoading: true, error: null });
    try {
      // Fetch dashboard stats
      const statsResponse = await api.get('/dashboard/stats');
      const pipelineResponse = await api.get('/dashboard/pipeline');
      const activityResponse = await api.get('/dashboard/activity');
      
      set({ 
        dashboardStats: statsResponse.data,
        pipeline: pipelineResponse.data,
        recentActivity: activityResponse.data,
        isLoading: false 
      });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ 
        dashboardStats: mockDashboardStats,
        pipeline: mockPipeline,
        isLoading: false 
      });
    }
  },
  
  fetchPipeline: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get('/dashboard/pipeline');
      set({ pipeline: response.data, isLoading: false });
    } catch (error: any) {
      console.log('API not available, using mock data');
      set({ pipeline: mockPipeline, isLoading: false });
    }
  },
  
  // CRUD operations - Customers
  createCustomer: async (data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.post('/customers', data);
      const newCustomer = response.data;
      
      set((state) => ({ 
        customers: [...state.customers, newCustomer], 
        isLoading: false 
      }));
      
      return newCustomer;
    } catch (error: any) {
      // Mock create for development
      const newCustomer: Customer = {
        id: generateId(),
        name: data.name || '',
        phone: data.phone,
        email: data.email,
        address: data.address,
        billingAddress: data.billingAddress,
        notes: data.notes,
        additionalContacts: data.additionalContacts,
        leadSource: data.leadSource,
        leadCost: data.leadCost,
        leadCampaign: data.leadCampaign,
        leadNotes: data.leadNotes,
        referredBy: data.referredBy,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      set((state) => ({ 
        customers: [...state.customers, newCustomer], 
        isLoading: false 
      }));
      
      return newCustomer;
    }
  },
  
  updateCustomer: async (id, data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.put(`/customers/${id}`, data);
      const updatedCustomer = response.data;
      
      set((state) => ({
        customers: state.customers.map(customer => 
          customer.id === id ? updatedCustomer : customer
        ),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock update for development
      set((state) => ({
        customers: state.customers.map(customer => 
          customer.id === id ? { ...customer, ...data, updatedAt: new Date().toISOString() } : customer
        ),
        isLoading: false
      }));
    }
  },
  
  deleteCustomer: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await api.delete(`/customers/${id}`);
      
      set((state) => ({
        customers: state.customers.filter(customer => customer.id !== id),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock delete for development
      set((state) => ({
        customers: state.customers.filter(customer => customer.id !== id),
        isLoading: false
      }));
    }
  },
  
  // CRUD operations - Leads
  createLead: async (data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.post('/leads', data);
      const newLead = response.data;
      
      set((state) => ({ 
        leads: [...state.leads, newLead], 
        isLoading: false 
      }));
      
      return newLead;
    } catch (error: any) {
      // Mock create for development
      const newLead: Lead = {
        id: generateId(),
        customerId: data.customer?.id || data.customerId || '1',
        source: data.source || 'FORM',
        status: data.status || 'NEW',
        priority: data.priority || 'MEDIUM',
        tags: data.tags || [],
        notes: data.notes,
        assignedTo: data.assignedTo,
        leadScore: data.leadScore || 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      set((state) => ({ 
        leads: [...state.leads, newLead], 
        isLoading: false 
      }));
      
      return newLead;
    }
  },
  
  updateLead: async (id, data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.put(`/leads/${id}`, data);
      const updatedLead = response.data;
      
      set((state) => ({
        leads: state.leads.map(lead => 
          lead.id === id ? updatedLead : lead
        ),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock update for development
      set((state) => ({
        leads: state.leads.map(lead => 
          lead.id === id ? { ...lead, ...data, updatedAt: new Date().toISOString() } : lead
        ),
        isLoading: false
      }));
    }
  },
  
  deleteLead: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await api.delete(`/leads/${id}`);
      
      set((state) => ({
        leads: state.leads.filter(lead => lead.id !== id),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock delete for development
      set((state) => ({
        leads: state.leads.filter(lead => lead.id !== id),
        isLoading: false
      }));
    }
  },
  
  // CRUD operations - Jobs
  createJob: async (data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.post('/jobs', data);
      const newJob = response.data;
      
      set((state) => ({ 
        jobs: [...state.jobs, newJob], 
        isLoading: false 
      }));
      
      return newJob;
    } catch (error: any) {
      // Mock create for development
      const newJob: Job = {
        id: generateId(),
        leadId: data.leadId || '1',
        customerId: data.customerId || '1',
        jobAddress: data.jobAddress || '',
        status: data.status || 'SCHEDULED',
        startDate: data.startDate,
        endDate: data.endDate,
        materials: data.materials,
        notes: data.notes,
        assignedTo: data.assignedTo,
        projectType: data.projectType,
        permitRequired: data.permitRequired,
        subStatus: data.subStatus,
        tags: data.tags || [],
        progress: data.progress,
        estimatedValue: data.estimatedValue,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      set((state) => ({ 
        jobs: [...state.jobs, newJob], 
        isLoading: false 
      }));
      
      return newJob;
    }
  },
  
  updateJob: async (id, data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.put(`/jobs/${id}`, data);
      const updatedJob = response.data;
      
      set((state) => ({
        jobs: state.jobs.map(job => 
          job.id === id ? updatedJob : job
        ),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock update for development
      set((state) => ({
        jobs: state.jobs.map(job => 
          job.id === id ? { ...job, ...data, updatedAt: new Date().toISOString() } : job
        ),
        isLoading: false
      }));
    }
  },
  
  deleteJob: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await api.delete(`/jobs/${id}`);
      
      set((state) => ({
        jobs: state.jobs.filter(job => job.id !== id),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock delete for development
      set((state) => ({
        jobs: state.jobs.filter(job => job.id !== id),
        isLoading: false
      }));
    }
  },
  
  // CRUD operations - Tasks
  createTask: async (data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.post('/tasks', data);
      const newTask = response.data;
      
      set((state) => ({ 
        tasks: [...state.tasks, newTask], 
        isLoading: false 
      }));
      
      return newTask;
    } catch (error: any) {
      // Mock create for development
      const newTask: Task = {
        id: generateId(),
        description: data.description || '',
        dueDate: data.dueDate || new Date().toISOString(),
        assignedTo: data.assignedTo || '1',
        status: data.status || 'PENDING',
        jobId: data.jobId,
        customerId: data.customerId,
        notes: data.notes,
        type: data.type,
        priority: data.priority,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      set((state) => ({ 
        tasks: [...state.tasks, newTask], 
        isLoading: false 
      }));
      
      return newTask;
    }
  },
  
  updateTask: async (id, data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.put(`/tasks/${id}`, data);
      const updatedTask = response.data;
      
      set((state) => ({
        tasks: state.tasks.map(task => 
          task.id === id ? updatedTask : task
        ),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock update for development
      set((state) => ({
        tasks: state.tasks.map(task => 
          task.id === id ? { ...task, ...data, updatedAt: new Date().toISOString() } : task
        ),
        isLoading: false
      }));
    }
  },
  
  deleteTask: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await api.delete(`/tasks/${id}`);
      
      set((state) => ({
        tasks: state.tasks.filter(task => task.id !== id),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock delete for development
      set((state) => ({
        tasks: state.tasks.filter(task => task.id !== id),
        isLoading: false
      }));
    }
  },
  
  // CRUD operations - Estimates
  createEstimate: async (data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.post('/estimates', data);
      const newEstimate = response.data;
      
      set((state) => ({ 
        estimates: [...state.estimates, newEstimate], 
        isLoading: false 
      }));
      
      return newEstimate;
    } catch (error: any) {
      // Mock create for development
      const lineItems: EstimateLineItem[] = data.lineItems || [
        {
          id: generateId(),
          description: 'Sample Item',
          quantity: 1,
          unitPrice: 100,
          total: 100
        }
      ];
      
      const newEstimate: Estimate = {
        id: generateId(),
        jobId: data.jobId || '1',
        customerId: data.customerId || '1',
        total: data.total || lineItems.reduce((sum, item) => sum + item.total, 0),
        lineItems: lineItems,
        accepted: data.accepted || false,
        expirationDate: data.expirationDate,
        notes: data.notes,
        terms: data.terms,
        sketchData: data.sketchData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      set((state) => ({ 
        estimates: [...state.estimates, newEstimate], 
        isLoading: false 
      }));
      
      return newEstimate;
    }
  },
  
  updateEstimate: async (id, data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.put(`/estimates/${id}`, data);
      const updatedEstimate = response.data;
      
      set((state) => ({
        estimates: state.estimates.map(estimate => 
          estimate.id === id ? updatedEstimate : estimate
        ),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock update for development
      set((state) => ({
        estimates: state.estimates.map(estimate => 
          estimate.id === id ? { ...estimate, ...data, updatedAt: new Date().toISOString() } : estimate
        ),
        isLoading: false
      }));
    }
  },
  
  deleteEstimate: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await api.delete(`/estimates/${id}`);
      
      set((state) => ({
        estimates: state.estimates.filter(estimate => estimate.id !== id),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock delete for development
      set((state) => ({
        estimates: state.estimates.filter(estimate => estimate.id !== id),
        isLoading: false
      }));
    }
  },
  
  // CRUD operations - Invoices
  createInvoice: async (data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.post('/invoices', data);
      const newInvoice = response.data;
      
      set((state) => ({ 
        invoices: [...state.invoices, newInvoice], 
        isLoading: false 
      }));
      
      return newInvoice;
    } catch (error: any) {
      // Mock create for development
      const newInvoice: Invoice = {
        id: generateId(),
        estimateId: data.estimateId || '1',
        customerId: data.customerId || '1',
        status: data.status || 'UNPAID',
        dueDate: data.dueDate || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        amount: data.amount || 0,
        stripePaymentUrl: data.stripePaymentUrl,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      set((state) => ({ 
        invoices: [...state.invoices, newInvoice], 
        isLoading: false 
      }));
      
      return newInvoice;
    }
  },
  
  updateInvoice: async (id, data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.put(`/invoices/${id}`, data);
      const updatedInvoice = response.data;
      
      set((state) => ({
        invoices: state.invoices.map(invoice => 
          invoice.id === id ? updatedInvoice : invoice
        ),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock update for development
      set((state) => ({
        invoices: state.invoices.map(invoice => 
          invoice.id === id ? { ...invoice, ...data, updatedAt: new Date().toISOString() } : invoice
        ),
        isLoading: false
      }));
    }
  },
  
  deleteInvoice: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await api.delete(`/invoices/${id}`);
      
      set((state) => ({
        invoices: state.invoices.filter(invoice => invoice.id !== id),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock delete for development
      set((state) => ({
        invoices: state.invoices.filter(invoice => invoice.id !== id),
        isLoading: false
      }));
    }
  },
  
  // CRUD operations - Messages
  createMessage: async (data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.post('/messages', data);
      const newMessage = response.data;
      
      set((state) => ({ 
        messages: [...state.messages, newMessage], 
        isLoading: false 
      }));
      
      return newMessage;
    } catch (error: any) {
      // Mock create for development
      const newMessage: Message = {
        id: generateId(),
        customerId: data.customerId,
        userId: data.userId,
        type: data.type || 'SMS',
        content: data.content || '',
        timestamp: data.timestamp || new Date().toISOString(),
        direction: data.direction || 'OUTBOUND',
        fromPhone: data.fromPhone,
        fromEmail: data.fromEmail,
        fromName: data.fromName,
        generalContactId: data.generalContactId,
        unknownContactId: data.unknownContactId,
      };
      
      set((state) => ({ 
        messages: [...state.messages, newMessage], 
        isLoading: false 
      }));
      
      return newMessage;
    }
  },
  
  updateMessage: async (id, data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.put(`/messages/${id}`, data);
      const updatedMessage = response.data;
      
      set((state) => ({
        messages: state.messages.map(message => 
          message.id === id ? updatedMessage : message
        ),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock update for development
      set((state) => ({
        messages: state.messages.map(message => 
          message.id === id ? { ...message, ...data } : message
        ),
        isLoading: false
      }));
    }
  },
  
  deleteMessage: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await api.delete(`/messages/${id}`);
      
      set((state) => ({
        messages: state.messages.filter(message => message.id !== id),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock delete for development
      set((state) => ({
        messages: state.messages.filter(message => message.id !== id),
        isLoading: false
      }));
    }
  },
  
  // CRUD operations - Files
  uploadFile: async (jobId, file) => {
    set({ isLoading: true, error: null });
    try {
      // Create form data
      const formData = new FormData();
      formData.append('file', file);
      formData.append('jobId', jobId);
      
      // Upload file
      const response = await api.post('/files/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });
      
      const newFile = response.data;
      
      set((state) => ({ 
        files: [...state.files, newFile], 
        isLoading: false 
      }));
      
      return newFile;
    } catch (error: any) {
      console.error('Error uploading file:', error);
      
      // Try to upload directly to Supabase
      try {
        const fileId = generateId();
        const fileExtension = file.name.split('.').pop();
        const fileName = `${fileId}.${fileExtension}`;
        const filePath = `jobs/${jobId}/${fileName}`;
        
        // Upload file to Supabase Storage
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from(storageBucket)
          .upload(filePath, file);
        
        if (uploadError) {
          throw uploadError;
        }
        
        // Get public URL
        const { data: { publicUrl } } = supabase.storage
          .from(storageBucket)
          .getPublicUrl(filePath);
        
        // Create mock file record
        const newFile: FileUpload = {
          id: fileId,
          jobId,
          url: publicUrl,
          type: file.type.startsWith('image/') ? 'PHOTO' : 
                file.type.startsWith('video/') ? 'VIDEO' :
                file.type.startsWith('audio/') ? 'AUDIO' :
                file.type === 'application/pdf' ? 'PDF' : 'DOCUMENT',
          uploadedBy: '1', // Assuming current user ID
          fileName: file.name,
          fileSize: file.size,
          mimeType: file.type,
          createdAt: new Date().toISOString(),
        };
        
        set((state) => ({ 
          files: [...state.files, newFile], 
          isLoading: false 
        }));
        
        return newFile;
      } catch (supabaseError) {
        console.error('Supabase upload error:', supabaseError);
        
        // Fallback to mock file
        const mockFile: FileUpload = {
          id: generateId(),
          jobId,
          url: URL.createObjectURL(file), // This URL will only work in the current session
          type: file.type.startsWith('image/') ? 'PHOTO' : 
                file.type.startsWith('video/') ? 'VIDEO' :
                file.type.startsWith('audio/') ? 'AUDIO' :
                file.type === 'application/pdf' ? 'PDF' : 'DOCUMENT',
          uploadedBy: '1', // Assuming current user ID
          fileName: file.name,
          fileSize: file.size,
          mimeType: file.type,
          createdAt: new Date().toISOString(),
        };
        
        set((state) => ({ 
          files: [...state.files, mockFile], 
          isLoading: false 
        }));
        
        return mockFile;
      }
    }
  },
  
  uploadCustomerFile: async (customerId, file) => {
    set({ isLoading: true, error: null });
    try {
      if (!supabase) {
        throw new Error('Supabase is not connected');
      }
      
      // Create form data
      const formData = new FormData();
      formData.append('file', file);
      formData.append('customerId', customerId);
      
      // Upload file
      const response = await api.post('/files/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });
      
      const newFile = response.data;
      
      set((state) => ({ 
        files: [...state.files, newFile], 
        isLoading: false 
      }));
      
      return newFile;
    } catch (error: any) {
      console.error('Error uploading file:', error);
      
      // Try to upload directly to Supabase
      try {
        const fileId = generateId();
        const fileExtension = file.name.split('.').pop();
        const fileName = `${fileId}.${fileExtension}`;
        const filePath = `customers/${customerId}/${fileName}`;
        
        // Upload file to Supabase Storage
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from(storageBucket)
          .upload(filePath, file);
        
        if (uploadError) {
          throw uploadError;
        }
        
        // Get public URL
        const { data: { publicUrl } } = supabase.storage
          .from(storageBucket)
          .getPublicUrl(filePath);
        
        // Create mock file record
        const newFile: FileUpload = {
          id: fileId,
          customerId,
          url: publicUrl,
          type: file.type.startsWith('image/') ? 'PHOTO' : 
                file.type.startsWith('video/') ? 'VIDEO' :
                file.type.startsWith('audio/') ? 'AUDIO' :
                file.type === 'application/pdf' ? 'PDF' : 'DOCUMENT',
          uploadedBy: '1', // Assuming current user ID
          fileName: file.name,
          fileSize: file.size,
          mimeType: file.type,
          createdAt: new Date().toISOString(),
        };
        
        set((state) => ({ 
          files: [...state.files, newFile], 
          isLoading: false 
        }));
        
        return newFile;
      } catch (supabaseError) {
        console.error('Supabase upload error:', supabaseError);
        
        // Fallback to mock file
        const mockFile: FileUpload = {
          id: generateId(),
          customerId,
          url: URL.createObjectURL(file), // This URL will only work in the current session
          type: file.type.startsWith('image/') ? 'PHOTO' : 
                file.type.startsWith('video/') ? 'VIDEO' :
                file.type.startsWith('audio/') ? 'AUDIO' :
                file.type === 'application/pdf' ? 'PDF' : 'DOCUMENT',
          uploadedBy: '1', // Assuming current user ID
          fileName: file.name,
          fileSize: file.size,
          mimeType: file.type,
          createdAt: new Date().toISOString(),
        };
        
        set((state) => ({ 
          files: [...state.files, mockFile], 
          isLoading: false 
        }));
        
        return mockFile;
      }
    }
  },
  
  deleteFile: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await api.delete(`/files/${id}`);
      
      set((state) => ({
        files: state.files.filter(file => file.id !== id),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock delete for development
      set((state) => ({
        files: state.files.filter(file => file.id !== id),
        isLoading: false
      }));
    }
  },
  
  // CRUD operations - Unknown Contacts
  addUnknownContact: async (data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.post('/unknown-contacts', data);
      const newContact = response.data;
      
      set((state) => ({ 
        unknownContacts: [...state.unknownContacts, newContact], 
        isLoading: false 
      }));
      
      return newContact;
    } catch (error: any) {
      // Mock create for development
      const newContact: UnknownContact = {
        id: generateId(),
        name: data.name || 'Unknown Contact',
        phone: data.phone,
        email: data.email,
        notes: data.notes,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      set((state) => ({ 
        unknownContacts: [...state.unknownContacts, newContact], 
        isLoading: false 
      }));
      
      return newContact;
    }
  },
  
  updateUnknownContact: async (id, data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.put(`/unknown-contacts/${id}`, data);
      const updatedContact = response.data;
      
      set((state) => ({
        unknownContacts: state.unknownContacts.map(contact => 
          contact.id === id ? updatedContact : contact
        ),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock update for development
      set((state) => ({
        unknownContacts: state.unknownContacts.map(contact => 
          contact.id === id ? { ...contact, ...data, updatedAt: new Date().toISOString() } : contact
        ),
        isLoading: false
      }));
    }
  },
  
  deleteUnknownContact: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await api.delete(`/unknown-contacts/${id}`);
      
      set((state) => ({
        unknownContacts: state.unknownContacts.filter(contact => contact.id !== id),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock delete for development
      set((state) => ({
        unknownContacts: state.unknownContacts.filter(contact => contact.id !== id),
        isLoading: false
      }));
    }
  },
  
  convertUnknownToCustomer: async (id, customerData) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.post(`/unknown-contacts/${id}/convert`, customerData);
      const { customer, unknownContact } = response.data;
      
      set((state) => ({
        customers: [...state.customers, customer],
        unknownContacts: state.unknownContacts.filter(contact => contact.id !== id),
        isLoading: false
      }));
      
      return customer;
    } catch (error: any) {
      // Mock conversion for development
      const unknownContact = get().unknownContacts.find(c => c.id === id);
      
      if (!unknownContact) {
        set({ isLoading: false, error: 'Unknown contact not found' });
        throw new Error('Unknown contact not found');
      }
      
      const newCustomer: Customer = {
        id: generateId(),
        name: customerData.name || unknownContact.name || 'Unknown Customer',
        phone: customerData.phone || unknownContact.phone,
        email: customerData.email || unknownContact.email,
        address: customerData.address,
        notes: customerData.notes || unknownContact.notes,
        leadSource: customerData.leadSource || 'DIRECT',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      set((state) => ({
        customers: [...state.customers, newCustomer],
        unknownContacts: state.unknownContacts.filter(contact => contact.id !== id),
        isLoading: false
      }));
      
      return newCustomer;
    }
  },
  
  linkUnknownToCustomer: async (unknownId, customerId) => {
    set({ isLoading: true, error: null });
    try {
      await api.post(`/unknown-contacts/${unknownId}/link/${customerId}`);
      
      set((state) => ({
        unknownContacts: state.unknownContacts.filter(contact => contact.id !== unknownId),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock linking for development
      set((state) => ({
        unknownContacts: state.unknownContacts.filter(contact => contact.id !== unknownId),
        isLoading: false
      }));
    }
  },
  
  // CRUD operations - General Contacts
  createGeneralContact: async (data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.post('/general-contacts', data);
      const newContact = response.data;
      
      set((state) => ({ 
        generalContacts: [...state.generalContacts, newContact], 
        isLoading: false 
      }));
      
      return newContact;
    } catch (error: any) {
      // Mock create for development
      const newContact: GeneralContact = {
        id: generateId(),
        name: data.name || '',
        businessName: data.businessName,
        phone: data.phone,
        email: data.email,
        notes: data.notes,
        labels: data.labels || [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      set((state) => ({ 
        generalContacts: [...state.generalContacts, newContact], 
        isLoading: false 
      }));
      
      return newContact;
    }
  },
  
  updateGeneralContact: async (id, data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.put(`/general-contacts/${id}`, data);
      const updatedContact = response.data;
      
      set((state) => ({
        generalContacts: state.generalContacts.map(contact => 
          contact.id === id ? updatedContact : contact
        ),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock update for development
      set((state) => ({
        generalContacts: state.generalContacts.map(contact => 
          contact.id === id ? { ...contact, ...data, updatedAt: new Date().toISOString() } : contact
        ),
        isLoading: false
      }));
    }
  },
  
  deleteGeneralContact: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await api.delete(`/general-contacts/${id}`);
      
      set((state) => ({
        generalContacts: state.generalContacts.filter(contact => contact.id !== id),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock delete for development
      set((state) => ({
        generalContacts: state.generalContacts.filter(contact => contact.id !== id),
        isLoading: false
      }));
    }
  },
  
  // CRUD operations - Contact Labels
  createContactLabel: async (data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.post('/contact-labels', data);
      const newLabel = response.data;
      
      set((state) => ({ 
        contactLabels: [...state.contactLabels, newLabel], 
        isLoading: false 
      }));
      
      return newLabel;
    } catch (error: any) {
      // Mock create for development
      const newLabel: ContactLabel = {
        id: generateId(),
        name: data.name || '',
        color: data.color || '#3B82F6',
      };
      
      set((state) => ({ 
        contactLabels: [...state.contactLabels, newLabel], 
        isLoading: false 
      }));
      
      return newLabel;
    }
  },
  
  updateContactLabel: async (id, data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.put(`/contact-labels/${id}`, data);
      const updatedLabel = response.data;
      
      set((state) => ({
        contactLabels: state.contactLabels.map(label => 
          label.id === id ? updatedLabel : label
        ),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock update for development
      set((state) => ({
        contactLabels: state.contactLabels.map(label => 
          label.id === id ? { ...label, ...data } : label
        ),
        isLoading: false
      }));
    }
  },
  
  deleteContactLabel: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await api.delete(`/contact-labels/${id}`);
      
      set((state) => ({
        contactLabels: state.contactLabels.filter(label => label.id !== id),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock delete for development
      set((state) => ({
        contactLabels: state.contactLabels.filter(label => label.id !== id),
        isLoading: false
      }));
    }
  },
  
  addLabelToContact: async (contactId, labelId) => {
    set({ isLoading: true, error: null });
    try {
      await api.post(`/general-contacts/${contactId}/labels/${labelId}`);
      
      // Refresh general contacts to get updated labels
      await get().fetchGeneralContacts();
      
      set({ isLoading: false });
    } catch (error: any) {
      // Mock adding label for development
      set((state) => {
        const label = state.contactLabels.find(l => l.id === labelId);
        
        if (!label) {
          set({ isLoading: false, error: 'Label not found' });
          return state;
        }
        
        return {
          generalContacts: state.generalContacts.map(contact => {
            if (contact.id === contactId) {
              const labels = contact.labels || [];
              if (!labels.some(l => l.id === labelId)) {
                return {
                  ...contact,
                  labels: [...labels, label]
                };
              }
            }
            return contact;
          }),
          isLoading: false
        };
      });
    }
  },
  
  removeLabelFromContact: async (contactId, labelId) => {
    set({ isLoading: true, error: null });
    try {
      await api.delete(`/general-contacts/${contactId}/labels/${labelId}`);
      
      // Refresh general contacts to get updated labels
      await get().fetchGeneralContacts();
      
      set({ isLoading: false });
    } catch (error: any) {
      // Mock removing label for development
      set((state) => ({
        generalContacts: state.generalContacts.map(contact => {
          if (contact.id === contactId && contact.labels) {
            return {
              ...contact,
              labels: contact.labels.filter(label => label.id !== labelId)
            };
          }
          return contact;
        }),
        isLoading: false
      }));
    }
  },
  
  // CRUD operations - Teams
  createTeam: async (data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.post('/teams', data);
      const newTeam = response.data;
      
      set((state) => ({ 
        teams: [...state.teams, newTeam], 
        isLoading: false 
      }));
      
      return newTeam;
    } catch (error: any) {
      // Mock create for development
      const newTeam: Team = {
        id: generateId(),
        name: data.name || '',
        description: data.description,
        color: data.color || '#3B82F6',
        leaderId: data.leaderId || '1',
        locationId: data.locationId,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      set((state) => ({ 
        teams: [...state.teams, newTeam], 
        isLoading: false 
      }));
      
      return newTeam;
    }
  },
  
  updateTeam: async (id, data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.put(`/teams/${id}`, data);
      const updatedTeam = response.data;
      
      set((state) => ({
        teams: state.teams.map(team => 
          team.id === id ? updatedTeam : team
        ),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock update for development
      set((state) => ({
        teams: state.teams.map(team => 
          team.id === id ? { ...team, ...data, updatedAt: new Date().toISOString() } : team
        ),
        isLoading: false
      }));
    }
  },
  
  deleteTeam: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await api.delete(`/teams/${id}`);
      
      set((state) => ({
        teams: state.teams.filter(team => team.id !== id),
        isLoading: false
      }));
    } catch (error: any) {
      // Mock delete for development
      set((state) => ({
        teams: state.teams.filter(team => team.id !== id),
        isLoading: false
      }));
    }
  },
}));