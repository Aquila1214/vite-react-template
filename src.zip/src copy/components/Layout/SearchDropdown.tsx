import React, { useState, useEffect, useRef } from 'react';
import { Search, User, Briefcase, FileText, Phone, Mail, MapPin } from 'lucide-react';
import { useCrmStore } from '../../stores/crmStore';
import { useNavigate } from 'react-router-dom';
import { formatPhone } from '../../lib/utils';

interface SearchResult {
  id: string;
  type: 'customer' | 'lead' | 'job' | 'estimate' | 'invoice';
  title: string;
  subtitle: string;
  description?: string;
  phone?: string;
  email?: string;
  route: string;
}

export const SearchDropdown: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [results, setResults] = useState<SearchResult[]>([]);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  
  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  
  const { leads, customers, jobs, estimates, invoices } = useCrmStore();

  // Search across all entities
  useEffect(() => {
    if (searchTerm.length < 2) {
      setResults([]);
      setIsOpen(false);
      return;
    }

    const searchResults: SearchResult[] = [];
    const term = searchTerm.toLowerCase();

    // Search customers
    customers.forEach(customer => {
      if (
        customer.name.toLowerCase().includes(term) ||
        customer.phone?.includes(term) ||
        customer.email?.toLowerCase().includes(term) ||
        customer.address?.toLowerCase().includes(term)
      ) {
        searchResults.push({
          id: customer.id,
          type: 'customer',
          title: customer.name,
          subtitle: 'Customer',
          description: customer.address,
          phone: customer.phone,
          email: customer.email,
          route: `/customers/${customer.id}`,
        });
      }
    });

    // Search leads
    leads.forEach(lead => {
      if (
        lead.customer?.name.toLowerCase().includes(term) ||
        lead.customer?.phone?.includes(term) ||
        lead.customer?.email?.toLowerCase().includes(term) ||
        lead.notes?.toLowerCase().includes(term) ||
        lead.tags?.some(tag => tag.toLowerCase().includes(term))
      ) {
        searchResults.push({
          id: lead.id,
          type: 'lead',
          title: lead.customer?.name || 'Unknown Customer',
          subtitle: `Lead - ${lead.status.replace('_', ' ')}`,
          description: lead.notes,
          phone: lead.customer?.phone,
          email: lead.customer?.email,
          route: `/leads/${lead.id}`,
        });
      }
    });

    // Search jobs
    jobs.forEach(job => {
      if (
        job.location.toLowerCase().includes(term) ||
        job.notes?.toLowerCase().includes(term) ||
        job.materials?.toLowerCase().includes(term)
      ) {
        searchResults.push({
          id: job.id,
          type: 'job',
          title: job.location,
          subtitle: `Job - ${job.status.replace('_', ' ')}`,
          description: job.notes,
          route: `/jobs/${job.id}`,
        });
      }
    });

    // Search estimates
    estimates.forEach(estimate => {
      const searchableItems = estimate.lineItems.map(item => item.description).join(' ');
      if (
        estimate.id.toLowerCase().includes(term) ||
        searchableItems.toLowerCase().includes(term) ||
        estimate.total.toString().includes(term)
      ) {
        searchResults.push({
          id: estimate.id,
          type: 'estimate',
          title: `Estimate #${estimate.id.slice(-6)}`,
          subtitle: `$${estimate.total.toLocaleString()} - ${estimate.accepted ? 'Accepted' : 'Pending'}`,
          description: estimate.lineItems[0]?.description,
          route: `/estimates/${estimate.id}`,
        });
      }
    });

    // Search invoices
    invoices.forEach(invoice => {
      if (
        invoice.id.toLowerCase().includes(term) ||
        invoice.amount.toString().includes(term)
      ) {
        searchResults.push({
          id: invoice.id,
          type: 'invoice',
          title: `Invoice #${invoice.id.slice(-6)}`,
          subtitle: `$${invoice.amount.toLocaleString()} - ${invoice.status}`,
          route: `/invoices/${invoice.id}`,
        });
      }
    });

    // Sort results by relevance (exact matches first, then partial matches)
    searchResults.sort((a, b) => {
      const aExact = a.title.toLowerCase().startsWith(term) ? 1 : 0;
      const bExact = b.title.toLowerCase().startsWith(term) ? 1 : 0;
      return bExact - aExact;
    });

    setResults(searchResults.slice(0, 8)); // Limit to 8 results
    setIsOpen(searchResults.length > 0);
    setSelectedIndex(-1);
  }, [searchTerm, customers, leads, jobs, estimates, invoices]);

  // Handle keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!isOpen) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex(prev => (prev < results.length - 1 ? prev + 1 : prev));
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex(prev => (prev > 0 ? prev - 1 : -1));
        break;
      case 'Enter':
        e.preventDefault();
        if (selectedIndex >= 0 && results[selectedIndex]) {
          handleSelectResult(results[selectedIndex]);
        }
        break;
      case 'Escape':
        setIsOpen(false);
        setSelectedIndex(-1);
        inputRef.current?.blur();
        break;
    }
  };

  // Handle result selection
  const handleSelectResult = (result: SearchResult) => {
    setSearchTerm(result.title);
    setIsOpen(false);
    setSelectedIndex(-1);
    
    // Navigate to the appropriate page
    if (result.type === 'customer') {
      navigate('/customers');
    } else if (result.type === 'lead') {
      navigate('/leads');
    } else if (result.type === 'job') {
      navigate('/jobs');
    } else if (result.type === 'estimate') {
      navigate('/estimates');
    } else if (result.type === 'invoice') {
      navigate('/invoices');
    }
    
    // Clear search after a short delay
    setTimeout(() => {
      setSearchTerm('');
    }, 1000);
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false);
        setSelectedIndex(-1);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getResultIcon = (type: string) => {
    switch (type) {
      case 'customer':
        return <User className="w-4 h-4 text-blue-600" />;
      case 'lead':
        return <User className="w-4 h-4 text-green-600" />;
      case 'job':
        return <Briefcase className="w-4 h-4 text-purple-600" />;
      case 'estimate':
        return <FileText className="w-4 h-4 text-amber-600" />;
      case 'invoice':
        return <FileText className="w-4 h-4 text-red-600" />;
      default:
        return <Search className="w-4 h-4 text-gray-400" />;
    }
  };

  return (
    <div ref={searchRef} className="relative w-full max-w-2xl">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
        <input
          ref={inputRef}
          type="text"
          placeholder="Search customers, jobs, estimates..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onKeyDown={handleKeyDown}
          onFocus={() => searchTerm.length >= 2 && setIsOpen(results.length > 0)}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>

      {/* Search Results Dropdown */}
      {isOpen && results.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-50 max-h-96 overflow-y-auto">
          <div className="py-2">
            {results.map((result, index) => (
              <button
                key={`${result.type}-${result.id}`}
                onClick={() => handleSelectResult(result)}
                className={`w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors ${
                  index === selectedIndex ? 'bg-blue-50 border-l-4 border-blue-500' : ''
                }`}
              >
                <div className="flex items-start space-x-3">
                  <div className="p-1 bg-gray-100 rounded">
                    {getResultIcon(result.type)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1">
                      <h4 className="text-sm font-medium text-gray-900 truncate">
                        {result.title}
                      </h4>
                      <span className="text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded-full">
                        {result.subtitle}
                      </span>
                    </div>
                    
                    {result.description && (
                      <p className="text-xs text-gray-600 truncate mb-1">
                        {result.description}
                      </p>
                    )}
                    
                    <div className="flex items-center space-x-3 text-xs text-gray-500">
                      {result.phone && (
                        <div className="flex items-center space-x-1">
                          <Phone className="w-3 h-3" />
                          <span>{formatPhone(result.phone)}</span>
                        </div>
                      )}
                      {result.email && (
                        <div className="flex items-center space-x-1">
                          <Mail className="w-3 h-3" />
                          <span className="truncate">{result.email}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
          
          {/* Search Tips */}
          <div className="border-t border-gray-100 px-4 py-2 bg-gray-50">
            <p className="text-xs text-gray-500">
              Use ↑↓ to navigate, Enter to select, Esc to close
            </p>
          </div>
        </div>
      )}

      {/* No Results */}
      {isOpen && results.length === 0 && searchTerm.length >= 2 && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-50">
          <div className="px-4 py-6 text-center">
            <Search className="w-8 h-8 mx-auto text-gray-300 mb-2" />
            <p className="text-sm text-gray-500">No results found for "{searchTerm}"</p>
            <p className="text-xs text-gray-400 mt-1">
              Try searching for customer names, phone numbers, or addresses
            </p>
          </div>
        </div>
      )}
    </div>
  );
};