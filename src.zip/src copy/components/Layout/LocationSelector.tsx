import React, { useState, useEffect, useRef } from 'react';
import { Building, ChevronDown, Check, X, Plus } from 'lucide-react';
import { useLocationStore } from '../../stores/locationStore';
import { useAuthStore } from '../../stores/authStore';

export const LocationSelector: React.FC = () => {
  const { 
    locations, 
    selectedLocationIds, 
    selectLocation, 
    selectMultipleLocations, 
    selectAllLocations,
    fetchLocations,
    isLoading
  } = useLocationStore();
  
  const { user } = useAuthStore();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchLocations();
  }, [fetchLocations]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Get the name of the selected location(s)
  const getDisplayText = () => {
    if (selectedLocationIds.length === 0) {
      return 'All Locations';
    } else if (selectedLocationIds.length === 1) {
      const location = locations.find(loc => loc.id === selectedLocationIds[0]);
      return location ? location.name : 'Unknown Location';
    } else if (selectedLocationIds.length === locations.length) {
      return 'All Locations';
    } else {
      return `${selectedLocationIds.length} Locations`;
    }
  };

  // Check if user has access to multiple locations
  const canAccessMultipleLocations = user?.role === 'ADMIN' || user?.role === 'OPERATIONS';

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
      >
        <Building className="h-4 w-4 text-gray-500" />
        <span className="text-sm font-medium text-gray-700">{getDisplayText()}</span>
        <ChevronDown className="h-4 w-4 text-gray-500" />
      </button>

      {isOpen && (
        <div className="absolute z-50 mt-2 w-64 bg-white rounded-lg shadow-lg border border-gray-200 overflow-hidden">
          <div className="p-2 border-b border-gray-200 flex justify-between items-center">
            <h3 className="text-sm font-medium text-gray-900">Select Location</h3>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <div className="max-h-60 overflow-y-auto p-2">
            {/* All Locations option */}
            {canAccessMultipleLocations && (
              <button
                onClick={() => {
                  selectAllLocations();
                  setIsOpen(false);
                }}
                className="flex items-center justify-between w-full px-3 py-2 text-left text-sm hover:bg-gray-100 rounded-md"
              >
                <div className="flex items-center">
                  <Building className="h-4 w-4 text-gray-500 mr-2" />
                  <span>All Locations</span>
                </div>
                {selectedLocationIds.length === locations.length && (
                  <Check className="h-4 w-4 text-green-600" />
                )}
              </button>
            )}

            {/* Individual locations */}
            {locations.map(location => (
              <button
                key={location.id}
                onClick={() => {
                  if (canAccessMultipleLocations && selectedLocationIds.includes(location.id)) {
                    // If already selected and can select multiple, deselect it
                    selectMultipleLocations(selectedLocationIds.filter(id => id !== location.id));
                  } else if (canAccessMultipleLocations && selectedLocationIds.length > 0) {
                    // If can select multiple and others are already selected, add to selection
                    selectMultipleLocations([...selectedLocationIds, location.id]);
                  } else {
                    // Otherwise, select only this location
                    selectLocation(location.id);
                  }
                  
                  // If user can't select multiple, close dropdown after selection
                  if (!canAccessMultipleLocations) {
                    setIsOpen(false);
                  }
                }}
                className="flex items-center justify-between w-full px-3 py-2 text-left text-sm hover:bg-gray-100 rounded-md"
              >
                <div className="flex items-center">
                  <Building className="h-4 w-4 text-gray-500 mr-2" />
                  <div>
                    <div>{location.name}</div>
                    {location.address && (
                      <div className="text-xs text-gray-500">{location.address}</div>
                    )}
                  </div>
                </div>
                {selectedLocationIds.includes(location.id) && (
                  <Check className="h-4 w-4 text-green-600" />
                )}
              </button>
            ))}

            {/* Add new location button (admin only) */}
            {user?.role === 'ADMIN' && (
              <button
                onClick={() => {
                  // This would open a modal to create a new location
                  console.log('Open create location modal');
                  // For now, just close the dropdown
                  setIsOpen(false);
                }}
                className="flex items-center w-full px-3 py-2 mt-2 text-left text-sm text-blue-600 hover:bg-blue-50 rounded-md border-t border-gray-100"
              >
                <Plus className="h-4 w-4 mr-2" />
                <span>Add New Location</span>
              </button>
            )}
          </div>

          {/* Apply button for multi-select */}
          {canAccessMultipleLocations && selectedLocationIds.length > 0 && (
            <div className="p-2 border-t border-gray-200">
              <button
                onClick={() => setIsOpen(false)}
                className="w-full px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors text-sm font-medium"
              >
                Apply
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};