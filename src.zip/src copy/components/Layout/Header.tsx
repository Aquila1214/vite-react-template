import React, { useState, useRef, useEffect } from 'react';
import { Bell, User, LogOut, Plus, X, CheckSquare, Users, Calendar, FileText, Menu } from 'lucide-react';
import { useAuthStore } from '../../stores/authStore';
import { SearchDropdown } from './SearchDropdown';
import { useCrmStore } from '../../stores/crmStore';
import { useNavigate } from 'react-router-dom';
import { CustomerModal } from '../Customers/CustomerModal';
import { TaskModal } from '../Tasks/TaskModal';
import { EstimateModal } from '../Estimates/EstimateModal';
import { LocationSelector } from './LocationSelector';

interface HeaderProps {
  onMenuClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onMenuClick }) => {
  const { user, logout } = useAuthStore();
  const { createCustomer, createTask, createEstimate, users, customers } = useCrmStore();
  const navigate = useNavigate();
  const [showQuickActions, setShowQuickActions] = useState(false);
  const quickActionsRef = useRef<HTMLDivElement>(null);
  
  // Modal states
  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [isEstimateModalOpen, setIsEstimateModalOpen] = useState(false);
  const [taskType, setTaskType] = useState<'TASK' | 'REMINDER'>('TASK');

  // Close quick actions dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (quickActionsRef.current && !quickActionsRef.current.contains(event.target as Node)) {
        setShowQuickActions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleCreateCustomer = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsCustomerModalOpen(true);
    setShowQuickActions(false);
  };

  const handleCreateTask = (e: React.MouseEvent) => {
    e.preventDefault();
    setTaskType('TASK');
    setIsTaskModalOpen(true);
    setShowQuickActions(false);
  };

  const handleCreateReminder = (e: React.MouseEvent) => {
    e.preventDefault();
    setTaskType('REMINDER');
    setIsTaskModalOpen(true);
    setShowQuickActions(false);
  };

  const handleCreateEstimate = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsEstimateModalOpen(true);
    setShowQuickActions(false);
  };

  const handleSaveCustomer = async (customerData: Partial<Customer>) => {
    await createCustomer(customerData);
    setIsCustomerModalOpen(false);
  };

  const handleSaveTask = async (taskData: Partial<Task>) => {
    await createTask({
      ...taskData,
      type: taskType
    });
    setIsTaskModalOpen(false);
  };

  const handleSaveEstimate = async (estimateData: Partial<Estimate>) => {
    await createEstimate(estimateData);
    setIsEstimateModalOpen(false);
  };

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="flex items-center justify-between px-3 sm:px-4 md:px-6 py-3 md:py-4">
        <div className="flex items-center">
          {/* Mobile menu button */}
          <button 
            className="lg:hidden p-2 mr-2 text-gray-600 hover:text-gray-900 focus:outline-none"
            onClick={onMenuClick}
          >
            <Menu className="h-6 w-6" />
          </button>
          
          <div className="flex-1 w-full max-w-xl">
            <SearchDropdown />
          </div>
        </div>
        
        <div className="flex items-center space-x-2 sm:space-x-4">
          {/* Location Selector */}
          <LocationSelector />
          
          {/* Quick Action Button */}
          <div className="relative" ref={quickActionsRef}>
            <button 
              onClick={(e) => {
                e.preventDefault();
                setShowQuickActions(!showQuickActions);
              }}
              className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors"
              title="Quick Actions"
            >
              {showQuickActions ? (
                <X className="w-6 h-6" />
              ) : (
                <Plus className="w-6 h-6" />
              )}
            </button>
            
            {showQuickActions && (
              <div className="absolute right-0 mt-2 w-56 bg-white rounded-md shadow-lg border border-gray-200 z-50">
                <div className="py-1">
                  <button
                    onClick={handleCreateCustomer}
                    className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    <Users className="w-4 h-4 mr-3 text-blue-600" />
                    New Customer
                  </button>
                  <button
                    onClick={handleCreateTask}
                    className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    <CheckSquare className="w-4 h-4 mr-3 text-green-600" />
                    New Task
                  </button>
                  <button
                    onClick={handleCreateReminder}
                    className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    <Calendar className="w-4 h-4 mr-3 text-amber-600" />
                    New Reminder
                  </button>
                  <button
                    onClick={handleCreateEstimate}
                    className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    <FileText className="w-4 h-4 mr-3 text-purple-600" />
                    New Estimate
                  </button>
                </div>
              </div>
            )}
          </div>
          
          <button className="relative p-2 text-gray-400 hover:text-gray-600 transition-colors">
            <Bell className="w-6 h-6" />
            <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>
          
          <div className="relative group">
            <button className="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-100 transition-colors">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-medium">
                {user?.name?.charAt(0) || 'U'}
              </div>
              <div className="hidden sm:block text-left">
                <p className="text-sm font-medium text-gray-900">{user?.name}</p>
                <p className="text-xs text-gray-500">{user?.role}</p>
              </div>
            </button>
            
            <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg border border-gray-200 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
              <div className="py-1">
                <button className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                  <User className="w-4 h-4 mr-3" />
                  Profile
                </button>
                <button 
                  onClick={logout}
                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  <LogOut className="w-4 h-4 mr-3" />
                  Sign out
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modals */}
      <CustomerModal
        isOpen={isCustomerModalOpen}
        onClose={() => setIsCustomerModalOpen(false)}
        onSave={handleSaveCustomer}
        isLoading={false}
      />

      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => setIsTaskModalOpen(false)}
        onSave={handleSaveTask}
        users={users}
        customers={customers}
        isLoading={false}
        initialTaskType={taskType}
      />

      <EstimateModal
        isOpen={isEstimateModalOpen}
        onClose={() => setIsEstimateModalOpen(false)}
        onSave={handleSaveEstimate}
        isLoading={false}
      />
    </header>
  );
};