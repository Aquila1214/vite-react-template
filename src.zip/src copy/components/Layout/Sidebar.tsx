import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Building,
  Users, 
  Briefcase, 
  Calendar, 
  FileText, 
  CreditCard, 
  MessageSquare,
  Settings,
  CheckSquare,
  BarChart3,
  ChevronDown,
  ChevronRight,
  UserPlus,
  Contact
} from 'lucide-react';
import { useAuthStore } from '../../stores/authStore';

const navigation = [
  { name: 'Dashboard', href: '/', icon: LayoutDashboard },
  { name: 'Schedule', href: '/schedule', icon: Calendar },
  { name: 'Performance Reporting', href: '/performance-reporting', icon: BarChart3, roles: ['ADMIN', 'SALES', 'OPERATIONS'] },
  { 
    name: 'Contacts', 
    icon: Users,
    subItems: [
      { name: 'Customers', href: '/customers', icon: Building },
      { name: 'General Contacts', href: '/general-contacts', icon: Contact },
    ]
  },
  { name: 'Leads', href: '/leads', icon: UserPlus },
  { name: 'Jobs', href: '/jobs', icon: Briefcase },
  { name: 'Tasks', href: '/tasks', icon: CheckSquare },
  { name: 'Estimates', href: '/estimates', icon: FileText },
  { name: 'Invoices', href: '/invoices', icon: CreditCard },
  { name: 'Messages', href: '/messages', icon: MessageSquare },
  { name: 'Settings', href: '/settings', icon: Settings },
];

export const Sidebar: React.FC = () => {
  const location = useLocation();
  const { user } = useAuthStore();
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({
    'Contacts': true, // Expand Contacts by default
  });

  // Filter navigation items based on user role
  const filteredNavigation = navigation.filter(item => {
    if (!item.roles) return true; // Show items without role restrictions
    return item.roles.includes(user?.role || '');
  });

  const toggleCollapse = (name: string) => {
    setCollapsed(prev => ({
      ...prev,
      [name]: !prev[name]
    }));
  };

  return (
    <div className="flex flex-col w-full h-full bg-gray-900 text-white">
      <div className="flex items-center justify-center h-16 bg-gray-800 border-b border-gray-700">
        <h1 className="text-xl font-bold text-amber-400">Lux Foundation</h1>
      </div>
      
      <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto">
        {filteredNavigation.map((item) => {
          const isActive = item.href 
            ? location.pathname === item.href 
            : item.subItems?.some(subItem => location.pathname === subItem.href);
          
          const hasSubItems = item.subItems && item.subItems.length > 0;
          
          return (
            <div key={item.name}>
              {hasSubItems ? (
                <div>
                  <button
                    onClick={() => toggleCollapse(item.name)}
                    className={`
                      w-full flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200
                      ${isActive ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-800 hover:text-white'}
                    `}
                  >
                    <div className="flex items-center">
                      <item.icon className="w-5 h-5 mr-3" />
                      {item.name}
                    </div>
                    {collapsed[item.name] ? (
                      <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronRight className="w-4 h-4" />
                    )}
                  </button>
                  
                  {collapsed[item.name] && item.subItems && (
                    <div className="pl-10 mt-1 space-y-1">
                      {item.subItems.map(subItem => (
                        <NavLink
                          key={subItem.name}
                          to={subItem.href}
                          className={({ isActive }) => `
                            flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200
                            ${isActive ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-800 hover:text-white'}
                          `}
                        >
                          {subItem.icon && <subItem.icon className="w-4 h-4 mr-3" />}
                          {subItem.name}
                        </NavLink>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <NavLink
                  to={item.href!}
                  className={`
                    flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200
                    ${isActive ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-800 hover:text-white'}
                  `}
                >
                  <item.icon className="w-5 h-5 mr-3" />
                  {item.name}
                </NavLink>
              )}
            </div>
          );
        })}
      </nav>
      
      <div className="p-4 border-t border-gray-700">
        <div className="flex items-center">
          <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-medium">
            {user?.name?.charAt(0) || 'U'}
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium text-white">{user?.name}</p>
            <p className="text-xs text-gray-400">{user?.role}</p>
          </div>
        </div>
      </div>
    </div>
  );
};