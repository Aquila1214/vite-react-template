import React, { useState, useRef, useEffect } from 'react';
import { Clock, User, Tag, ChevronRight, MoreVertical, Edit, Trash2, CheckSquare, Calendar, AlertTriangle, ArrowRight, Briefcase, X, Plus } from 'lucide-react';
import { formatDate, getStatusColor } from '../../lib/utils';
import { useCrmStore } from '../../stores/crmStore';
import { useNavigate } from 'react-router-dom';

interface JobTileProps {
  project: any;
  onEdit: (project: any) => void;
  onDelete: (id: string) => void;
  onStatusChange: (id: string, status: string) => void;
  onDragStart: (e: React.DragEvent, project: any) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDrop: (e: React.DragEvent, status: string) => void;
}

export const JobTile: React.FC<JobTileProps> = ({ 
  project, 
  onEdit, 
  onDelete, 
  onStatusChange,
  onDragStart,
  onDragOver,
  onDrop
}) => {
  // Guard against undefined project prop
  if (!project) {
    return null;
  }

  const { users } = useCrmStore();
  const navigate = useNavigate();
  const [isExpanded, setIsExpanded] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [editingProgress, setEditingProgress] = useState(false);
  const [progress, setProgress] = useState(project.progress || 0);
  const [showTagInput, setShowTagInput] = useState(false);
  const [newTag, setNewTag] = useState('');
  const [tags, setTags] = useState<string[]>(project.tags || []);
  
  const menuRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);
  const tagInputRef = useRef<HTMLInputElement>(null);

  // Close menus when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setShowMenu(false);
      }
      if (progressRef.current && !progressRef.current.contains(event.target as Node)) {
        setEditingProgress(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Focus tag input when shown
  useEffect(() => {
    if (showTagInput && tagInputRef.current) {
      tagInputRef.current.focus();
    }
  }, [showTagInput]);

  const getUserName = (userId?: string) => {
    if (!userId) return 'Unassigned';
    const user = users.find(u => u.id === userId);
    return user ? user.name : `User ${userId.slice(-4)}`;
  };

  const handleProgressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setProgress(parseInt(e.target.value));
  };

  const handleProgressSave = () => {
    // Here you would call an API to update the project progress
    console.log(`Updating project ${project.id} progress to ${progress}%`);
    setEditingProgress(false);
    // In a real implementation, you would update the project in the store
  };

  const handleAddTag = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && newTag.trim()) {
      const updatedTags = [...tags, newTag.trim()];
      setTags(updatedTags);
      setNewTag('');
      // Here you would call an API to update the project tags
      console.log(`Adding tag "${newTag.trim()}" to project ${project.id}`);
      // In a real implementation, you would update the project in the store
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    const updatedTags = tags.filter(tag => tag !== tagToRemove);
    setTags(updatedTags);
    // Here you would call an API to update the project tags
    console.log(`Removing tag "${tagToRemove}" from project ${project.id}`);
    // In a real implementation, you would update the project in the store
  };

  const handleTileClick = () => {
    setIsExpanded(!isExpanded);
  };

  const handleViewDetails = (e: React.MouseEvent) => {
    e.stopPropagation();
    
    try {
      // Navigate to project details page
      navigate(`/jobs/${project.id}`);
    } catch (error) {
      console.error("Navigation error:", error);
      // Fallback if navigation fails
      console.log(`View details for project ${project.id}`);
    }
  };

  const getStatusSteps = () => {
    const statuses = ['SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'];
    const currentIndex = statuses.indexOf(project.status);
    
    return (
      <div className="flex items-center space-x-1 mt-2">
        {statuses.map((status, index) => (
          <React.Fragment key={status}>
            <div 
              className={`h-2 w-2 rounded-full ${
                index <= currentIndex ? 'bg-blue-600' : 'bg-gray-300'
              }`}
              onClick={(e) => {
                e.stopPropagation();
                onStatusChange(project.id, status);
              }}
              title={`Mark as ${status.replace('_', ' ')}`}
            />
            {index < statuses.length - 1 && (
              <div className={`h-0.5 w-4 ${
                index < currentIndex ? 'bg-blue-600' : 'bg-gray-300'
              }`} />
            )}
          </React.Fragment>
        ))}
      </div>
    );
  };

  const isOverdue = () => {
    if (!project.endDate || project.status === 'COMPLETED' || project.status === 'CANCELLED') return false;
    return new Date(project.endDate) < new Date();
  };

  return (
    <div 
      className="bg-white p-3 rounded-lg border border-gray-200 hover:shadow-md transition-all cursor-pointer"
      onClick={handleTileClick}
      draggable
      onDragStart={(e) => onDragStart(e, project)}
      onDragOver={onDragOver}
      onDrop={(e) => onDrop(e, project.status)}
    >
      <div className="flex items-start justify-between mb-2">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-1">
            <span className="font-medium text-gray-900 line-clamp-1">{project.jobAddress}</span>
            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(project.status)}`}>
              {project.status.replace('_', ' ')}
            </span>
            {project.permitRequired && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
                Permit
              </span>
            )}
          </div>
          <div className="text-xs text-gray-600 mt-1">
            {project.customer?.name || 'Unknown Customer'}
          </div>
        </div>
        <div className="flex flex-col items-end">
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            {project.projectType ? project.projectType.replace(/_/g, ' ') : 'Project'}
          </span>
          {project.estimatedValue && (
            <span className="text-xs font-medium text-gray-700 mt-1">
              ${project.estimatedValue.toLocaleString()}
            </span>
          )}
          <div className="relative" ref={menuRef}>
            <button 
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setShowMenu(!showMenu);
              }}
              className="p-1 text-gray-400 hover:text-gray-600 mt-1"
            >
              <MoreVertical className="h-4 w-4" />
            </button>
            
            {showMenu && (
              <div className="absolute right-0 mt-1 w-48 bg-white rounded-md shadow-lg z-10 border border-gray-200">
                <div className="py-1">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleViewDetails(e);
                    }}
                    className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    <ChevronRight className="h-4 w-4 mr-2" />
                    View Details
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onEdit(project);
                    }}
                    className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    Edit
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDelete(project.id);
                    }}
                    className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {project.subStatus && (
        <div className="flex items-center text-xs text-gray-500 mt-1">
          <Tag className="h-3 w-3 mr-1" />
          <span>{project.subStatus}</span>
        </div>
      )}
      
      {/* Tags */}
      {(tags.length > 0 || showTagInput) && (
        <div className="flex flex-wrap gap-1 mt-2">
          {tags.map(tag => (
            <div key={tag} className="inline-flex items-center px-2 py-1 rounded text-xs bg-gray-100 text-gray-800">
              {tag}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleRemoveTag(tag);
                }}
                className="ml-1 text-gray-500 hover:text-gray-700"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          ))}
          {showTagInput && (
            <div className="inline-flex items-center px-2 py-1 rounded text-xs bg-gray-100 text-gray-800">
              <input
                ref={tagInputRef}
                type="text"
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                onKeyDown={handleAddTag}
                onBlur={() => setShowTagInput(false)}
                className="w-16 bg-transparent border-none focus:ring-0 p-0 text-xs"
                placeholder="Add tag"
              />
            </div>
          )}
          {!showTagInput && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setShowTagInput(true);
              }}
              className="inline-flex items-center px-2 py-1 rounded text-xs bg-blue-100 text-blue-800"
            >
              <Plus className="h-3 w-3 mr-1" />
              Add Tag
            </button>
          )}
        </div>
      )}
      
      <div className="flex items-center justify-between mt-2 pt-2 border-t border-gray-100">
        <div className="flex items-center text-xs text-gray-500">
          <User className="h-3 w-3 mr-1" />
          <span>{getUserName(project.assignedTo)}</span>
        </div>
        <div className="flex items-center text-xs text-gray-500">
          <Clock className="h-3 w-3 mr-1" />
          <span>{project.daysInStage || 0} days</span>
        </div>
      </div>
      
      {/* Progress Bar */}
      {project.progress !== undefined && project.status === 'IN_PROGRESS' && (
        <div className="mt-2" ref={progressRef}>
          <div className="flex justify-between text-xs text-gray-500 mb-1">
            <span>Progress</span>
            {editingProgress ? (
              <div className="flex items-center space-x-2">
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={progress}
                  onChange={handleProgressChange}
                  onClick={(e) => e.stopPropagation()}
                  className="w-12 px-1 py-0 text-xs border border-gray-300 rounded"
                />
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleProgressSave();
                  }}
                  className="text-xs text-blue-600 hover:text-blue-800"
                >
                  Save
                </button>
              </div>
            ) : (
              <span 
                className="cursor-pointer hover:text-blue-600"
                onClick={(e) => {
                  e.stopPropagation();
                  setEditingProgress(true);
                }}
              >
                {progress}%
              </span>
            )}
          </div>
          <div className="w-full bg-gray-200 rounded-full h-1.5">
            <div 
              className="bg-blue-600 h-1.5 rounded-full"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      )}
      
      {/* Expanded Content */}
      {isExpanded && (
        <div className="mt-3 pt-3 border-t border-gray-100">
          {/* Status Timeline */}
          <div className="mb-3">
            <div className="text-xs font-medium text-gray-700 mb-1">Status</div>
            {getStatusSteps()}
          </div>
          
          {/* Schedule Info */}
          {(project.startDate || project.endDate) && (
            <div className="mb-3">
              <div className="text-xs font-medium text-gray-700 mb-1">Schedule</div>
              <div className="flex items-center space-x-2 text-xs">
                <Calendar className="h-3 w-3 text-gray-500" />
                <div className="flex items-center">
                  {project.startDate && <span>{formatDate(project.startDate)}</span>}
                  {project.startDate && project.endDate && (
                    <ArrowRight className="h-3 w-3 mx-1 text-gray-400" />
                  )}
                  {project.endDate && (
                    <span className={isOverdue() ? 'text-red-600 font-medium' : ''}>
                      {formatDate(project.endDate)}
                      {isOverdue() && (
                        <span className="ml-1 text-red-600">
                          (Overdue)
                        </span>
                      )}
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}
          
          {/* Materials */}
          {project.materials && (
            <div className="mb-3">
              <div className="text-xs font-medium text-gray-700 mb-1">Materials</div>
              <div className="text-xs text-gray-600">{project.materials}</div>
            </div>
          )}
          
          {/* Notes */}
          {project.notes && (
            <div className="mb-3">
              <div className="text-xs font-medium text-gray-700 mb-1">Notes</div>
              <div className="text-xs text-gray-600">{project.notes}</div>
            </div>
          )}
          
          {/* Action Buttons */}
          <div className="flex items-center justify-end space-x-2 mt-2">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleViewDetails(e);
              }}
              className="px-2 py-1 text-xs bg-blue-600 text-white rounded hover:bg-blue-700"
            >
              View Details
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onEdit(project);
              }}
              className="px-2 py-1 text-xs bg-gray-100 text-gray-700 rounded hover:bg-gray-200"
            >
              Edit
            </button>
          </div>
        </div>
      )}
    </div>
  );
};