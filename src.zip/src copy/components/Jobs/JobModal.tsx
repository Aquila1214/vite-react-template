import React, { useState, useEffect, useRef } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { X, Calendar, User, MapPin, Briefcase, FileText, Search, Tag, Plus, Trash2, Link, Building } from 'lucide-react';
import { Job, Customer } from '../../types';
import { useCrmStore } from '../../stores/crmStore';
import { useLocationStore } from '../../stores/locationStore';

const jobSchema = z.object({
  jobAddress: z.string().min(2, 'Location is required'),
  status: z.enum(['SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED']),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  materials: z.string().optional(),
  notes: z.string().optional(),
  projectType: z.string().min(1, 'Project type is required'),
  permitRequired: z.boolean().optional(),
  subStatus: z.string().optional(),
  locationId: z.string().optional(),
});

type JobFormData = z.infer<typeof jobSchema>;

interface JobModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Partial<Job>) => Promise<void>;
  project?: Job | null;
}

export const JobModal: React.FC<JobModalProps> = ({
  isOpen,
  onClose,
  onSave,
  project,
}) => {
  const { customers, users, leads, fetchCustomers, fetchUsers, fetchLeads } = useCrmStore();
  const { locations, fetchLocations } = useLocationStore();
  const isEditing = !!project;
  
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [customerSearchTerm, setCustomerSearchTerm] = useState('');
  const [showCustomerDropdown, setShowCustomerDropdown] = useState(false);
  const [selectedAssignee, setSelectedAssignee] = useState<string | undefined>(undefined);
  const [userSearchTerm, setUserSearchTerm] = useState('');
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [tags, setTags] = useState<string[]>([]);
  const [newTag, setNewTag] = useState('');
  const [selectedLead, setSelectedLead] = useState<string | undefined>(undefined);
  const [leadSearchTerm, setLeadSearchTerm] = useState('');
  const [showLeadDropdown, setShowLeadDropdown] = useState(false);
  
  const customerDropdownRef = useRef<HTMLDivElement>(null);
  const userDropdownRef = useRef<HTMLDivElement>(null);
  const leadDropdownRef = useRef<HTMLDivElement>(null);
  
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    watch,
  } = useForm<JobFormData>({
    resolver: zodResolver(jobSchema),
    defaultValues: {
      jobAddress: project?.jobAddress || '',
      status: project?.status || 'SCHEDULED',
      startDate: project?.startDate ? new Date(project.startDate).toISOString().slice(0, 10) : '',
      endDate: project?.endDate ? new Date(project.endDate).toISOString().slice(0, 10) : '',
      materials: project?.materials || '',
      notes: project?.notes || '',
      projectType: project?.projectType || 'foundation_repair',
      permitRequired: project?.permitRequired || false,
      subStatus: project?.subStatus || '',
      locationId: project?.locationId || locations[0]?.id || '',
    },
  });

  // Fetch data when modal opens
  useEffect(() => {
    if (isOpen) {
      fetchCustomers();
      fetchUsers();
      fetchLeads();
      fetchLocations();
      
      if (project) {
        reset({
          jobAddress: project.jobAddress,
          status: project.status,
          startDate: project.startDate ? new Date(project.startDate).toISOString().slice(0, 10) : '',
          endDate: project.endDate ? new Date(project.endDate).toISOString().slice(0, 10) : '',
          materials: project.materials || '',
          notes: project.notes || '',
          projectType: project.projectType || 'foundation_repair',
          permitRequired: project.permitRequired || false,
          subStatus: project.subStatus || '',
          locationId: project.locationId || locations[0]?.id || '',
        });
        
        setSelectedAssignee(project.assignedTo);
        setTags(project.tags || []);
        setSelectedLead(project.leadId);
        
        // Find customer
        if (project.customerId) {
          const customer = customers.find(c => c.id === project.customerId);
          if (customer) {
            setSelectedCustomer(customer);
            setCustomerSearchTerm(customer.name);
          }
        }
        
        // Find lead
        if (project.leadId) {
          const lead = leads.find(l => l.id === project.leadId);
          if (lead) {
            setLeadSearchTerm(`Lead #${lead.id.slice(-6)}`);
          }
        }
      } else {
        reset({
          jobAddress: '',
          status: 'SCHEDULED',
          startDate: '',
          endDate: '',
          materials: '',
          notes: '',
          projectType: 'foundation_repair',
          permitRequired: false,
          subStatus: '',
          locationId: locations[0]?.id || '',
        });
        setSelectedCustomer(null);
        setCustomerSearchTerm('');
        setSelectedAssignee(undefined);
        setUserSearchTerm('');
        setTags([]);
        setSelectedLead(undefined);
        setLeadSearchTerm('');
      }
    }
  }, [isOpen, project, customers, reset, fetchCustomers, fetchUsers, fetchLeads, fetchLocations, locations]);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (customerDropdownRef.current && !customerDropdownRef.current.contains(event.target as Node)) {
        setShowCustomerDropdown(false);
      }
      if (userDropdownRef.current && !userDropdownRef.current.contains(event.target as Node)) {
        setShowUserDropdown(false);
      }
      if (leadDropdownRef.current && !leadDropdownRef.current.contains(event.target as Node)) {
        setShowLeadDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleCustomerSelect = (customer: Customer) => {
    setSelectedCustomer(customer);
    setCustomerSearchTerm(customer.name);
    setShowCustomerDropdown(false);
    
    // If customer has an address, use it as the job location
    if (customer.address && !watch('jobAddress')) {
      setValue('jobAddress', customer.address);
    }
    
    // Filter leads for this customer
    const customerLeads = leads.filter(lead => lead.customerId === customer.id);
    if (customerLeads.length === 1) {
      setSelectedLead(customerLeads[0].id);
      setLeadSearchTerm(`Lead #${customerLeads[0].id.slice(-6)}`);
    }
  };

  const handleLeadSelect = (leadId: string) => {
    setSelectedLead(leadId);
    const lead = leads.find(l => l.id === leadId);
    if (lead) {
      setLeadSearchTerm(`Lead #${lead.id.slice(-6)}`);
      
      // If lead has a customer, select it
      if (lead.customer && (!selectedCustomer || selectedCustomer.id !== lead.customer.id)) {
        setSelectedCustomer(lead.customer);
        setCustomerSearchTerm(lead.customer.name);
      }
    }
    setShowLeadDropdown(false);
  };

  const handleUserSelect = (userId: string, userName: string) => {
    setSelectedAssignee(userId);
    setUserSearchTerm(userName);
    setShowUserDropdown(false);
  };

  const handleAddTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      setTags([...tags, newTag.trim()]);
      setNewTag('');
    }
  };

  const handleRemoveTag = (tag: string) => {
    setTags(tags.filter(t => t !== tag));
  };

  const onSubmit = async (data: JobFormData) => {
    if (!selectedCustomer) {
      alert('Please select a customer');
      return;
    }
    
    if (!selectedLead) {
      alert('Please select a lead');
      return;
    }
    
    setIsLoading(true);
    
    try {
      const jobData: Partial<Job> = {
        customerId: selectedCustomer.id,
        leadId: selectedLead,
        jobAddress: data.jobAddress,
        status: data.status,
        startDate: data.startDate || undefined,
        endDate: data.endDate || undefined,
        materials: data.materials || undefined,
        notes: data.notes || undefined,
        assignedTo: selectedAssignee,
        projectType: data.projectType,
        permitRequired: data.permitRequired,
        subStatus: data.subStatus || undefined,
        tags: tags.length > 0 ? tags : undefined,
        locationId: data.locationId,
      };
      
      await onSave(jobData);
      onClose();
    } catch (error) {
      console.error('Failed to save job:', error);
      alert('An error occurred while saving the job');
    } finally {
      setIsLoading(false);
    }
  };

  const filteredCustomers = customers.filter(customer => 
    customer.name.toLowerCase().includes(customerSearchTerm.toLowerCase()) ||
    customer.email?.toLowerCase().includes(customerSearchTerm.toLowerCase()) ||
    customer.phone?.includes(customerSearchTerm)
  );

  const filteredLeads = leads.filter(lead => 
    (selectedCustomer ? lead.customerId === selectedCustomer.id : true) &&
    (leadSearchTerm ? 
      lead.id.toLowerCase().includes(leadSearchTerm.toLowerCase()) ||
      (lead.customer?.name || '').toLowerCase().includes(leadSearchTerm.toLowerCase())
    : true)
  );

  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(userSearchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(userSearchTerm.toLowerCase())
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">
            {isEditing ? 'Edit Project' : 'Create New Project'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-6">
          {/* Customer Selection */}
          <div ref={customerDropdownRef}>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Customer *
            </label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={customerSearchTerm}
                onChange={(e) => {
                  setCustomerSearchTerm(e.target.value);
                  setShowCustomerDropdown(true);
                  if (e.target.value === '') {
                    setSelectedCustomer(null);
                  }
                }}
                onFocus={() => setShowCustomerDropdown(true)}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Search customers..."
                disabled={isEditing} // Can't change customer when editing
              />
              
              {showCustomerDropdown && !isEditing && (
                <div className="absolute z-10 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                  {filteredCustomers.map(customer => (
                    <div 
                      key={customer.id} 
                      className="p-2 hover:bg-gray-100 cursor-pointer"
                      onClick={() => handleCustomerSelect(customer)}
                    >
                      <div className="text-sm font-medium">{customer.name}</div>
                      {customer.email && (
                        <div className="text-xs text-gray-500">{customer.email}</div>
                      )}
                    </div>
                  ))}
                  {filteredCustomers.length === 0 && (
                    <div className="p-2 text-sm text-gray-500">No customers found</div>
                  )}
                  <div className="p-2 border-t border-gray-100">
                    <button
                      type="button"
                      onClick={() => setShowCustomerDropdown(false)}
                      className="w-full text-xs text-center text-blue-600 hover:text-blue-800"
                    >
                      Close
                    </button>
                  </div>
                </div>
              )}
            </div>
            {!selectedCustomer && (
              <p className="mt-1 text-sm text-red-600">Customer is required</p>
            )}
          </div>

          {/* Lead Selection */}
          <div ref={leadDropdownRef}>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Lead *
            </label>
            <div className="relative">
              <FileText className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={leadSearchTerm}
                onChange={(e) => {
                  setLeadSearchTerm(e.target.value);
                  setShowLeadDropdown(true);
                  if (e.target.value === '') {
                    setSelectedLead(undefined);
                  }
                }}
                onFocus={() => setShowLeadDropdown(true)}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Search leads..."
                disabled={isEditing} // Can't change lead when editing
              />
              
              {showLeadDropdown && !isEditing && (
                <div className="absolute z-10 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                  {filteredLeads.map(lead => (
                    <div 
                      key={lead.id} 
                      className="p-2 hover:bg-gray-100 cursor-pointer"
                      onClick={() => handleLeadSelect(lead.id)}
                    >
                      <div className="text-sm font-medium">Lead #{lead.id.slice(-6)}</div>
                      <div className="text-xs text-gray-500">
                        {lead.customer?.name} • {lead.status.replace('_', ' ')}
                      </div>
                    </div>
                  ))}
                  {filteredLeads.length === 0 && (
                    <div className="p-2 text-sm text-gray-500">No leads found</div>
                  )}
                  <div className="p-2 border-t border-gray-100">
                    <button
                      type="button"
                      onClick={() => setShowLeadDropdown(false)}
                      className="w-full text-xs text-center text-blue-600 hover:text-blue-800"
                    >
                      Close
                    </button>
                  </div>
                </div>
              )}
            </div>
            {!selectedLead && (
              <p className="mt-1 text-sm text-red-600">Lead is required</p>
            )}
          </div>

          {/* Project Type & Permit */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Project Type *
              </label>
              <div className="relative">
                <Briefcase className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <select
                  {...register('projectType')}
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="foundation_repair">Foundation Repair</option>
                  <option value="waterproofing">Waterproofing</option>
                  <option value="crawlspace_repair">Crawlspace Repair</option>
                  <option value="concrete_repair">Concrete Repair</option>
                  <option value="general_construction">General Construction</option>
                  <option value="combination">Combination Project</option>
                </select>
              </div>
              {errors.projectType && (
                <p className="mt-1 text-sm text-red-600">{errors.projectType.message}</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Permit Required
              </label>
              <div className="flex items-center h-10 mt-1">
                <label className="inline-flex items-center">
                  <input
                    type="checkbox"
                    {...register('permitRequired')}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">This project requires a permit</span>
                </label>
              </div>
            </div>
          </div>

          {/* Location */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Project Location *
            </label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                {...register('jobAddress')}
                type="text"
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter project location"
              />
            </div>
            {errors.jobAddress && (
              <p className="mt-1 text-sm text-red-600">{errors.jobAddress.message}</p>
            )}
          </div>

          {/* Branch Location */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Branch Location
            </label>
            <div className="relative">
              <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <select
                {...register('locationId')}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {locations.map(location => (
                  <option key={location.id} value={location.id}>
                    {location.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Status & Sub-Status */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Status
              </label>
              <select
                {...register('status')}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="SCHEDULED">Scheduled</option>
                <option value="IN_PROGRESS">In Progress</option>
                <option value="COMPLETED">Completed</option>
                <option value="CANCELLED">Cancelled</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Sub-Status
              </label>
              <div className="relative">
                <Tag className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  {...register('subStatus')}
                  type="text"
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., Waiting for materials"
                />
              </div>
            </div>
          </div>

          {/* Schedule */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Start Date
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  {...register('startDate')}
                  type="date"
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                End Date
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  {...register('endDate')}
                  type="date"
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>

          {/* Assignee */}
          <div ref={userDropdownRef}>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Assigned To
            </label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={userSearchTerm}
                onChange={(e) => {
                  setUserSearchTerm(e.target.value);
                  setShowUserDropdown(true);
                  if (e.target.value === '') {
                    setSelectedAssignee(undefined);
                  }
                }}
                onFocus={() => setShowUserDropdown(true)}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Search users..."
              />
              
              {showUserDropdown && (
                <div className="absolute z-10 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                  {filteredUsers.map(user => (
                    <div 
                      key={user.id} 
                      className="p-2 hover:bg-gray-100 cursor-pointer"
                      onClick={() => handleUserSelect(user.id, user.name)}
                    >
                      <div className="text-sm font-medium">{user.name}</div>
                      <div className="text-xs text-gray-500">{user.role}</div>
                    </div>
                  ))}
                  {filteredUsers.length === 0 && (
                    <div className="p-2 text-sm text-gray-500">No users found</div>
                  )}
                  <div className="p-2 border-t border-gray-100">
                    <button
                      type="button"
                      onClick={() => setShowUserDropdown(false)}
                      className="w-full text-xs text-center text-blue-600 hover:text-blue-800"
                    >
                      Close
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Materials */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Materials
            </label>
            <textarea
              {...register('materials')}
              rows={2}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="List required materials..."
            />
          </div>

          {/* Tags */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Tags
            </label>
            <div className="flex flex-wrap gap-2 mb-2">
              {tags.map(tag => (
                <div key={tag} className="inline-flex items-center px-2 py-1 rounded text-xs bg-gray-100 text-gray-800">
                  {tag}
                  <button
                    type="button"
                    onClick={() => handleRemoveTag(tag)}
                    className="ml-1 text-gray-500 hover:text-gray-700"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
              <div className="inline-flex items-center">
                <input
                  type="text"
                  value={newTag}
                  onChange={(e) => setNewTag(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddTag();
                    }
                  }}
                  className="w-24 px-2 py-1 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Add tag"
                />
                <button
                  type="button"
                  onClick={handleAddTag}
                  className="ml-1 p-1 text-xs bg-blue-100 text-blue-800 rounded hover:bg-blue-200"
                >
                  <Plus className="h-3 w-3" />
                </button>
              </div>
            </div>
            <p className="text-xs text-gray-500">Press Enter or click + to add a tag</p>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Notes
            </label>
            <textarea
              {...register('notes')}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Additional notes about this project..."
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end space-x-3 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading || !selectedCustomer || !selectedLead}
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? 'Saving...' : isEditing ? 'Update Project' : 'Create Project'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};