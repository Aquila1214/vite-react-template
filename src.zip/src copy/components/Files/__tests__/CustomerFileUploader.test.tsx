import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { CustomerFileUploader } from '../CustomerFileUploader';
import { useCrmStore } from '../../../stores/crmStore';
import { vi } from 'vitest';

// Mock the CRM store
vi.mock('../../../stores/crmStore', () => ({
  useCrmStore: vi.fn()
}));

describe('CustomerFileUploader', () => {
  const mockUploadCustomerFile = vi.fn();
  const mockOnUploadComplete = vi.fn();
  
  beforeEach(() => {
    vi.clearAllMocks();
    
    // Setup mock store with proper promise resolution
    mockUploadCustomerFile.mockResolvedValue({ id: 'new-file-id', fileName: 'customer-doc.pdf' });
    
    (useCrmStore as any).mockReturnValue({
      uploadCustomerFile: mockUploadCustomerFile
    });
    
    // Mock file input
    global.URL.createObjectURL = vi.fn(() => 'mock-url');
    global.URL.revokeObjectURL = vi.fn();
  });

  test('renders customer file uploader', () => {
    render(
      <CustomerFileUploader 
        customerId="customer1" 
        onUploadComplete={mockOnUploadComplete} 
      />
    );
    
    expect(screen.getByText('Click to upload or drag and drop')).toBeInTheDocument();
    expect(screen.getByText('Support for images, videos, PDFs, and documents up to 100MB')).toBeInTheDocument();
  });

  test('adds files when selected via input', async () => {
    render(
      <CustomerFileUploader 
        customerId="customer1" 
        onUploadComplete={mockOnUploadComplete} 
      />
    );
    
    // Create a mock file
    const file = new File(['test content'], 'customer-doc.pdf', { type: 'application/pdf' });
    
    // Get the hidden file input
    const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement;
    
    // Simulate file selection
    fireEvent.change(fileInput, { target: { files: [file] } });
    
    // Check if file is added to the list
    await waitFor(() => {
      expect(screen.getByText('customer-doc.pdf')).toBeInTheDocument();
    });
  });

  test('removes file when remove button is clicked', async () => {
    render(
      <CustomerFileUploader 
        customerId="customer1" 
        onUploadComplete={mockOnUploadComplete} 
      />
    );
    
    // Create a mock file
    const file = new File(['test content'], 'customer-doc.pdf', { type: 'application/pdf' });
    
    // Get the hidden file input
    const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement;
    
    // Simulate file selection
    fireEvent.change(fileInput, { target: { files: [file] } });
    
    // Check if file is added to the list
    await waitFor(() => {
      expect(screen.getByText('customer-doc.pdf')).toBeInTheDocument();
    });
    
    // Find and click the remove button
    const removeButton = screen.getByRole('button', { name: /remove file/i });
    fireEvent.click(removeButton);
    
    // Check if file is removed
    await waitFor(() => {
      expect(screen.queryByText('customer-doc.pdf')).not.toBeInTheDocument();
    });
  });

  test('uploads files when upload button is clicked', async () => {
    render(
      <CustomerFileUploader 
        customerId="customer1" 
        onUploadComplete={mockOnUploadComplete} 
      />
    );
    
    // Create a mock file
    const file = new File(['test content'], 'customer-doc.pdf', { type: 'application/pdf' });
    
    // Get the hidden file input
    const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement;
    
    // Simulate file selection
    fireEvent.change(fileInput, { target: { files: [file] } });
    
    // Check if file is added to the list
    await waitFor(() => {
      expect(screen.getByText('customer-doc.pdf')).toBeInTheDocument();
    });
    
    // Find and click the upload button
    const uploadButton = screen.getByRole('button', { name: /upload files/i });
    fireEvent.click(uploadButton);
    
    // Check if upload function was called
    await waitFor(() => {
      expect(mockUploadCustomerFile).toHaveBeenCalledWith('customer1', file);
      expect(mockOnUploadComplete).toHaveBeenCalled();
    });
  });

  test('shows progress during upload', async () => {
    // Mock implementation with delay to show progress
    mockUploadCustomerFile.mockImplementation(() => {
      return new Promise(resolve => {
        setTimeout(() => {
          resolve({ id: 'new-file-id', fileName: 'customer-doc.pdf' });
        }, 100);
      });
    });
    
    render(
      <CustomerFileUploader 
        customerId="customer1" 
        onUploadComplete={mockOnUploadComplete} 
      />
    );
    
    // Create a mock file
    const file = new File(['test content'], 'customer-doc.pdf', { type: 'application/pdf' });
    
    // Get the hidden file input
    const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement;
    
    // Simulate file selection
    fireEvent.change(fileInput, { target: { files: [file] } });
    
    // Find and click the upload button
    const uploadButton = screen.getByRole('button', { name: /upload files/i });
    fireEvent.click(uploadButton);
    
    // Check if uploading text is shown
    await waitFor(() => {
      expect(screen.getByText('Uploading...')).toBeInTheDocument();
    });
    
    // Wait for upload to complete
    await waitFor(() => {
      expect(mockOnUploadComplete).toHaveBeenCalled();
    }, { timeout: 200 });
  });

  test('displays different icons based on file type', async () => {
    render(
      <CustomerFileUploader 
        customerId="customer1" 
        onUploadComplete={mockOnUploadComplete} 
      />
    );
    
    // Create mock files of different types
    const imageFile = new File(['image content'], 'image.jpg', { type: 'image/jpeg' });
    const pdfFile = new File(['pdf content'], 'document.pdf', { type: 'application/pdf' });
    const videoFile = new File(['video content'], 'video.mp4', { type: 'video/mp4' });
    
    // Get the hidden file input
    const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement;
    
    // Add image file
    fireEvent.change(fileInput, { target: { files: [imageFile] } });
    
    // Add PDF file
    fireEvent.change(fileInput, { target: { files: [pdfFile] } });
    
    // Add video file
    fireEvent.change(fileInput, { target: { files: [videoFile] } });
    
    // Check if all files are in the list
    await waitFor(() => {
      expect(screen.getByText('image.jpg')).toBeInTheDocument();
      expect(screen.getByText('document.pdf')).toBeInTheDocument();
      expect(screen.getByText('video.mp4')).toBeInTheDocument();
    });
  });
});