import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { CustomerFileGallery } from '../CustomerFileGallery';
import { useCrmStore } from '../../../stores/crmStore';
import { vi } from 'vitest';

// Mock the CRM store
vi.mock('../../../stores/crmStore', () => ({
  useCrmStore: vi.fn()
}));

// Mock file data
const mockFiles = [
  {
    id: 'file1',
    customerId: 'customer1',
    url: 'https://example.com/file1.jpg',
    type: 'PHOTO',
    uploadedBy: 'user1',
    fileName: 'test-image.jpg',
    fileSize: 1024 * 1024, // 1MB
    mimeType: 'image/jpeg',
    thumbnailUrl: 'https://example.com/thumb1.jpg',
    createdAt: '2023-01-01T00:00:00Z'
  },
  {
    id: 'file2',
    customerId: 'customer1',
    url: 'https://example.com/file2.pdf',
    type: 'PDF',
    uploadedBy: 'user1',
    fileName: 'test-document.pdf',
    fileSize: 2 * 1024 * 1024, // 2MB
    mimeType: 'application/pdf',
    createdAt: '2023-01-02T00:00:00Z'
  },
  {
    id: 'file3',
    customerId: 'customer1',
    url: 'https://example.com/file3.mp4',
    type: 'VIDEO',
    uploadedBy: 'user1',
    fileName: 'test-video.mp4',
    fileSize: 5 * 1024 * 1024, // 5MB
    mimeType: 'video/mp4',
    createdAt: '2023-01-03T00:00:00Z'
  }
];

// Mock store implementation
const mockFetchCustomerFiles = vi.fn();
const mockDeleteFile = vi.fn();

describe('CustomerFileGallery', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    
    // Setup mock store with proper promise resolution
    mockFetchCustomerFiles.mockResolvedValue(undefined);
    mockDeleteFile.mockResolvedValue(undefined);
    
    (useCrmStore as any).mockReturnValue({
      files: mockFiles,
      fetchCustomerFiles: mockFetchCustomerFiles,
      deleteFile: mockDeleteFile,
      isLoading: false
    });
  });

  test('renders file gallery with files', async () => {
    render(<CustomerFileGallery customerId="customer1" />);
    
    // Check if files are loaded
    expect(mockFetchCustomerFiles).toHaveBeenCalledWith('customer1');
    
    // Wait for files to be displayed
    await waitFor(() => {
      expect(screen.getByText('test-image.jpg')).toBeInTheDocument();
      expect(screen.getByText('test-document.pdf')).toBeInTheDocument();
      expect(screen.getByText('test-video.mp4')).toBeInTheDocument();
    });
  });

  test('opens file preview when clicking on a file', async () => {
    render(<CustomerFileGallery customerId="customer1" />);
    
    // Wait for files to be displayed
    await waitFor(() => {
      expect(screen.getByText('test-image.jpg')).toBeInTheDocument();
    });
    
    // Click on the first file (image)
    const fileItem = screen.getByText('test-image.jpg').closest('.border');
    fireEvent.click(fileItem!);
    
    // Check if preview modal is opened
    await waitFor(() => {
      expect(screen.getByText('test-image.jpg')).toBeInTheDocument();
      // Check for image preview
      const imgElement = document.querySelector('img[src="https://example.com/file1.jpg"]');
      expect(imgElement).toBeInTheDocument();
    });
    
    // Close the modal
    const closeButton = screen.getByRole('button', { name: /close/i });
    fireEvent.click(closeButton);
    
    // Check if modal is closed
    await waitFor(() => {
      const modalContent = screen.queryByRole('dialog');
      expect(modalContent).not.toBeInTheDocument();
    });
  });

  test('renders different preview types based on file type', async () => {
    render(<CustomerFileGallery customerId="customer1" />);
    
    // Wait for files to be displayed
    await waitFor(() => {
      expect(screen.getByText('test-document.pdf')).toBeInTheDocument();
    });
    
    // Test PDF preview
    const pdfFile = screen.getByText('test-document.pdf').closest('.border');
    fireEvent.click(pdfFile!);
    
    await waitFor(() => {
      const iframeElement = document.querySelector('iframe[src="https://example.com/file2.pdf"]');
      expect(iframeElement).toBeInTheDocument();
    });
    
    // Close the modal
    let closeButton = screen.getByRole('button', { name: /close/i });
    fireEvent.click(closeButton);
    
    // Wait for modal to close
    await waitFor(() => {
      const modalContent = screen.queryByRole('dialog');
      expect(modalContent).not.toBeInTheDocument();
    });
    
    // Test video preview
    const videoFile = screen.getByText('test-video.mp4').closest('.border');
    fireEvent.click(videoFile!);
    
    await waitFor(() => {
      const videoElement = document.querySelector('video[src="https://example.com/file3.mp4"]');
      expect(videoElement).toBeInTheDocument();
    });
    
    // Close the modal
    closeButton = screen.getByRole('button', { name: /close/i });
    fireEvent.click(closeButton);
  });

  test('filters files by type', async () => {
    render(<CustomerFileGallery customerId="customer1" />);
    
    // Wait for files to be displayed
    await waitFor(() => {
      expect(screen.getByText('test-image.jpg')).toBeInTheDocument();
    });
    
    // Click on Images filter
    const imagesFilter = screen.getByText('Images');
    fireEvent.click(imagesFilter);
    
    // Should only show image files
    await waitFor(() => {
      expect(screen.getByText('test-image.jpg')).toBeInTheDocument();
      expect(screen.queryByText('test-document.pdf')).not.toBeInTheDocument();
      expect(screen.queryByText('test-video.mp4')).not.toBeInTheDocument();
    });
    
    // Click on PDFs filter
    const pdfsFilter = screen.getByText('PDFs');
    fireEvent.click(pdfsFilter);
    
    // Should only show PDF files
    await waitFor(() => {
      expect(screen.queryByText('test-image.jpg')).not.toBeInTheDocument();
      expect(screen.getByText('test-document.pdf')).toBeInTheDocument();
      expect(screen.queryByText('test-video.mp4')).not.toBeInTheDocument();
    });
  });

  test('deletes a file when delete button is clicked', async () => {
    render(<CustomerFileGallery customerId="customer1" />);
    
    // Wait for files to be displayed
    await waitFor(() => {
      expect(screen.getByText('test-image.jpg')).toBeInTheDocument();
    });
    
    // Open file preview
    const fileItem = screen.getByText('test-image.jpg').closest('.border');
    fireEvent.click(fileItem!);
    
    // Find and click delete button in the modal
    const deleteButton = screen.getByRole('button', { name: /delete/i });
    
    // Mock window.confirm to return true
    const originalConfirm = window.confirm;
    window.confirm = vi.fn(() => true);
    
    fireEvent.click(deleteButton);
    
    // Restore original confirm
    window.confirm = originalConfirm;
    
    // Check if delete function was called
    expect(mockDeleteFile).toHaveBeenCalledWith('file1');
  });
});