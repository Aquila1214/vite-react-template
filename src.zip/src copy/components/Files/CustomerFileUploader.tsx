import React, { useState, useRef } from 'react';
import { Upload, X, File, Image, FileText, Film, Music, AlertTriangle } from 'lucide-react';
import { useCrmStore } from '../../stores/crmStore';
import { formatBytes } from '../../lib/utils';

interface CustomerFileUploaderProps {
  customerId: string;
  onUploadComplete?: () => void;
}

export const CustomerFileUploader: React.FC<CustomerFileUploaderProps> = ({ customerId, onUploadComplete }) => {
  const { uploadCustomerFile } = useCrmStore();
  const [files, setFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setFiles(prev => [...prev, ...newFiles]);
      
      // Reset the input value so the same file can be selected again
      e.target.value = '';
    }
  };

  const handleRemoveFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
    
    // Also remove any progress or errors for this file
    const fileId = `file-${index}`;
    setUploadProgress(prev => {
      const newProgress = { ...prev };
      delete newProgress[fileId];
      return newProgress;
    });
    
    setErrors(prev => {
      const newErrors = { ...prev };
      delete newErrors[fileId];
      return newErrors;
    });
  };

  const handleUpload = async () => {
    if (files.length === 0) return;
    
    setUploading(true);
    setErrors({});
    
    // Initialize progress for all files
    const initialProgress: Record<string, number> = {};
    files.forEach((_, index) => {
      initialProgress[`file-${index}`] = 0;
    });
    setUploadProgress(initialProgress);
    
    // Upload each file
    const uploadPromises = files.map(async (file, index) => {
      const fileId = `file-${index}`;
      
      try {
        // Simulate progress updates
        const interval = setInterval(() => {
          setUploadProgress(prev => {
            const current = prev[fileId] || 0;
            if (current < 90) {
              return { ...prev, [fileId]: current + 10 };
            }
            return prev;
          });
        }, 300);
        
        // Actual upload
        await uploadCustomerFile(customerId, file);
        
        // Complete progress
        clearInterval(interval);
        setUploadProgress(prev => ({ ...prev, [fileId]: 100 }));
        
        return { success: true, fileId };
      } catch (error) {
        console.error(`Error uploading file ${file.name}:`, error);
        setErrors(prev => ({ ...prev, [fileId]: 'Upload failed' }));
        return { success: false, fileId, error };
      }
    });
    
    // Wait for all uploads to complete
    await Promise.all(uploadPromises);
    
    // Call the onUploadComplete callback if provided
    if (onUploadComplete) {
      onUploadComplete();
    }
    
    // Reset state after a short delay to show completion
    setTimeout(() => {
      setFiles([]);
      setUploadProgress({});
      setUploading(false);
    }, 1000);
  };

  const getFileIcon = (file: File) => {
    const type = file.type;
    
    if (type.startsWith('image/')) {
      return <Image className="h-6 w-6 text-blue-500" />;
    } else if (type.startsWith('video/')) {
      return <Film className="h-6 w-6 text-purple-500" />;
    } else if (type.startsWith('audio/')) {
      return <Music className="h-6 w-6 text-green-500" />;
    } else if (type === 'application/pdf') {
      return <FileText className="h-6 w-6 text-red-500" />;
    } else {
      return <File className="h-6 w-6 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-4">
      {/* File Input */}
      <div 
        className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-500 transition-colors cursor-pointer"
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          multiple
        />
        <Upload className="h-8 w-8 mx-auto text-gray-400 mb-2" />
        <p className="text-gray-600">Click to upload or drag and drop</p>
        <p className="text-xs text-gray-500 mt-1">
          Support for images, videos, PDFs, and documents up to 100MB
        </p>
      </div>

      {/* File List */}
      {files.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium text-gray-700">Files to Upload</h3>
            <span className="text-xs text-gray-500">{files.length} file(s) selected</span>
          </div>
          
          <div className="border border-gray-200 rounded-lg divide-y divide-gray-200">
            {files.map((file, index) => {
              const fileId = `file-${index}`;
              const progress = uploadProgress[fileId] || 0;
              const error = errors[fileId];
              
              return (
                <div key={index} className="p-3 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    {getFileIcon(file)}
                    <div>
                      <div className="text-sm font-medium text-gray-900 truncate max-w-xs">
                        {file.name}
                      </div>
                      <div className="text-xs text-gray-500">
                        {formatBytes(file.size)}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    {uploading && (
                      <div className="w-24">
                        <div className="h-1.5 w-full bg-gray-200 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-blue-600 rounded-full transition-all duration-300"
                            style={{ width: `${progress}%` }}
                          />
                        </div>
                        <div className="text-xs text-gray-500 text-right mt-1">
                          {progress}%
                        </div>
                      </div>
                    )}
                    
                    {error && (
                      <div className="flex items-center text-xs text-red-600">
                        <AlertTriangle className="h-3 w-3 mr-1" />
                        {error}
                      </div>
                    )}
                    
                    {!uploading && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleRemoveFile(index);
                        }}
                        className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                        aria-label="Remove file"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          
          <div className="flex justify-end">
            <button
              onClick={handleUpload}
              disabled={uploading || files.length === 0}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {uploading ? 'Uploading...' : 'Upload Files'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};