import React, { useState, useEffect } from 'react';
import { Image, FileText, Film, Music, File as FileIcon, Download, Trash2, Eye, X, Upload, Plus } from 'lucide-react';
import { useCrmStore } from '../../stores/crmStore';
import { FileUpload } from '../../types';
import { formatBytes, formatDate } from '../../lib/utils';
import { FileUploader } from './FileUploader';

interface FileGalleryProps {
  jobId: string;
}

export const FileGallery: React.FC<FileGalleryProps> = ({ jobId }) => {
  const { files, fetchFiles, deleteFile, isLoading } = useCrmStore();
  const [selectedFile, setSelectedFile] = useState<FileUpload | null>(null);
  const [showUploader, setShowUploader] = useState(false);
  const [filter, setFilter] = useState<string>('all');

  useEffect(() => {
    fetchFiles(jobId);
  }, [fetchFiles, jobId]);

  const jobFiles = files.filter(file => file.jobId === jobId);

  const filteredFiles = filter === 'all' 
    ? jobFiles 
    : jobFiles.filter(file => file.type === filter);

  const handleDeleteFile = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this file? This action cannot be undone.')) {
      await deleteFile(id);
      if (selectedFile?.id === id) {
        setSelectedFile(null);
      }
    }
  };

  const handleUploadComplete = () => {
    fetchFiles(jobId);
    setShowUploader(false);
  };

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'PHOTO':
        return <Image className="h-6 w-6 text-blue-500" />;
      case 'VIDEO':
        return <Film className="h-6 w-6 text-purple-500" />;
      case 'AUDIO':
        return <Music className="h-6 w-6 text-green-500" />;
      case 'PDF':
        return <FileText className="h-6 w-6 text-red-500" />;
      default:
        return <FileIcon className="h-6 w-6 text-gray-500" />;
    }
  };

  const renderFilePreview = () => {
    if (!selectedFile) return null;

    switch (selectedFile.type) {
      case 'PHOTO':
        return (
          <img 
            src={selectedFile.url} 
            alt={selectedFile.fileName} 
            className="max-h-full max-w-full object-contain"
          />
        );
      case 'VIDEO':
        return (
          <video 
            src={selectedFile.url} 
            controls 
            className="max-h-full max-w-full"
          >
            Your browser does not support the video tag.
          </video>
        );
      case 'AUDIO':
        return (
          <audio 
            src={selectedFile.url} 
            controls 
            className="w-full"
          >
            Your browser does not support the audio tag.
          </audio>
        );
      case 'PDF':
        return (
          <iframe 
            src={selectedFile.url} 
            className="w-full h-full"
            title={selectedFile.fileName}
          >
            Your browser does not support PDF embedding.
          </iframe>
        );
      default:
        return (
          <div className="flex flex-col items-center justify-center p-8">
            {getFileIcon(selectedFile.type)}
            <p className="mt-4 text-gray-600">{selectedFile.fileName}</p>
            <a 
              href={selectedFile.url} 
              download 
              className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Download File
            </a>
          </div>
        );
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">Job Files</h3>
        <button
          onClick={() => setShowUploader(!showUploader)}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          {showUploader ? 'Hide Uploader' : 'Upload Files'}
        </button>
      </div>

      {/* File Uploader */}
      {showUploader && (
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
          <FileUploader jobId={jobId} onUploadComplete={handleUploadComplete} />
        </div>
      )}

      {/* File Filters */}
      <div className="flex flex-wrap gap-2">
        {[
          { id: 'all', label: 'All Files' },
          { id: 'PHOTO', label: 'Images' },
          { id: 'VIDEO', label: 'Videos' },
          { id: 'AUDIO', label: 'Audio' },
          { id: 'PDF', label: 'PDFs' },
          { id: 'DOCUMENT', label: 'Documents' },
        ].map(option => (
          <button
            key={option.id}
            onClick={() => setFilter(option.id)}
            className={`px-3 py-1 text-sm rounded-lg transition-colors ${
              filter === option.id
                ? 'bg-blue-100 text-blue-700 font-medium'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {option.label}
          </button>
        ))}
      </div>

      {/* File Preview Modal */}
      {selectedFile && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50" role="dialog" aria-modal="true">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900">{selectedFile.fileName}</h3>
              <button
                onClick={() => setSelectedFile(null)}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                aria-label="Close"
              >
                <X className="h-5 w-5 text-gray-500" />
              </button>
            </div>
            
            <div className="flex-1 overflow-auto p-4 flex items-center justify-center">
              {renderFilePreview()}
            </div>
            
            <div className="p-4 border-t border-gray-200 flex items-center justify-between">
              <div className="text-sm text-gray-600">
                <p>Uploaded on {formatDate(selectedFile.createdAt)}</p>
                <p>{formatBytes(selectedFile.fileSize)}</p>
              </div>
              
              <div className="flex items-center space-x-3">
                <a
                  href={selectedFile.url}
                  download
                  className="flex items-center px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </a>
                
                <button
                  onClick={() => handleDeleteFile(selectedFile.id)}
                  className="flex items-center px-3 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors"
                  aria-label="Delete"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* File Grid */}
      {filteredFiles.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {filteredFiles.map(file => (
            <div 
              key={file.id} 
              className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow"
            >
              <div 
                className="h-32 bg-gray-100 flex items-center justify-center cursor-pointer"
                onClick={() => setSelectedFile(file)}
              >
                {file.type === 'PHOTO' && file.thumbnailUrl ? (
                  <img 
                    src={file.thumbnailUrl} 
                    alt={file.fileName} 
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="p-4">
                    {getFileIcon(file.type)}
                  </div>
                )}
              </div>
              
              <div className="p-3">
                <div className="text-sm font-medium text-gray-900 truncate" title={file.fileName}>
                  {file.fileName}
                </div>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-xs text-gray-500">{formatBytes(file.fileSize)}</span>
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => setSelectedFile(file)}
                      className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                      title="View"
                      aria-label="View file"
                    >
                      <Eye className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteFile(file.id)}
                      className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                      title="Delete"
                      aria-label="Delete file"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <FileIcon className="h-8 w-8 mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500">
            {jobFiles.length === 0 
              ? 'No files uploaded yet. Click "Upload Files" to add files to this job.' 
              : 'No files match the selected filter.'}
          </p>
        </div>
      )}
    </div>
  );
};