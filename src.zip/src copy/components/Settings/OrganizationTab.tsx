import React, { useState } from 'react';
import { Building, Users, Plus, Edit, Trash2, Phone, Mail } from 'lucide-react';
import { Team, Location } from '../../types';

interface OrganizationTabProps {
  teams: Team[];
  locations: Location[];
  handleCreateTeam: () => void;
  handleEditTeam: (team: Team) => void;
  handleDeleteTeam: (id: string) => void;
  handleCreateLocation: () => void;
  handleEditLocation: (location: Location) => void;
  handleDeleteLocation: (id: string) => void;
}

export const OrganizationTab: React.FC<OrganizationTabProps> = ({
  teams,
  locations,
  handleCreateTeam,
  handleEditTeam,
  handleDeleteTeam,
  handleCreateLocation,
  handleEditLocation,
  handleDeleteLocation
}) => {
  const [activeView, setActiveView] = useState<'locations' | 'teams'>('locations');

  return (
    <div className="space-y-6">
      {/* Sub-navigation */}
      <div className="flex items-center space-x-4 border-b border-gray-200 pb-4">
        <button
          onClick={() => setActiveView('locations')}
          className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
            activeView === 'locations' 
              ? 'bg-blue-100 text-blue-700' 
              : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          Locations
        </button>
        <button
          onClick={() => setActiveView('teams')}
          className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
            activeView === 'teams' 
              ? 'bg-blue-100 text-blue-700' 
              : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          Teams
        </button>
      </div>

      {activeView === 'locations' ? (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Locations</h3>
              <p className="text-gray-600">Manage multiple business locations and assign users and data to specific locations</p>
            </div>
            <button
              onClick={handleCreateLocation}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Location
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {locations.map(location => (
              <div key={location.id} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h4 className="font-medium text-gray-900">{location.name}</h4>
                    {location.address && (
                      <p className="text-sm text-gray-600 mt-1">{location.address}</p>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleEditLocation(location)}
                      className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                      title="Edit"
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteLocation(location.id)}
                      className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  {location.phone && (
                    <div className="flex items-center text-sm text-gray-600">
                      <Phone className="h-4 w-4 mr-2 text-gray-400" />
                      {location.phone}
                    </div>
                  )}
                  
                  {location.email && (
                    <div className="flex items-center text-sm text-gray-600">
                      <Mail className="h-4 w-4 mr-2 text-gray-400" />
                      {location.email}
                    </div>
                  )}
                  
                  {/* Show teams associated with this location */}
                  <div className="mt-4 pt-4 border-t border-gray-100">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Teams:</span>
                      <span className="font-medium">{teams.filter(t => t.locationId === location.id).length}</span>
                    </div>
                    {teams.filter(t => t.locationId === location.id).length > 0 && (
                      <div className="mt-2 space-y-1">
                        {teams.filter(t => t.locationId === location.id).map(team => (
                          <div key={team.id} className="flex items-center text-sm">
                            <div 
                              className="w-3 h-3 rounded-full mr-2"
                              style={{ backgroundColor: team.color }}
                            />
                            <span>{team.name}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {locations.length === 0 && (
            <div className="text-center py-12">
              <Building className="h-8 w-8 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500">No locations created yet. Add your first location to organize your data.</p>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Teams & Groups</h3>
              <p className="text-gray-600">Organize users into teams for better collaboration and filtering</p>
            </div>
            <button
              onClick={handleCreateTeam}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Team
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {teams.map(team => (
              <div key={team.id} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: team.color }}
                    />
                    <div>
                      <h4 className="font-medium text-gray-900">{team.name}</h4>
                      {team.description && (
                        <p className="text-sm text-gray-600 mt-1">{team.description}</p>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleEditTeam(team)}
                      className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                      title="Edit"
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteTeam(team.id)}
                      className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Team Leader:</span>
                    <span className="font-medium">Leader {team.leaderId.slice(-1)}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Members:</span>
                    <span className="font-medium">{team.members?.length || 0}</span>
                  </div>
                  {team.location && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Location:</span>
                      <span className="font-medium">{team.location.name}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {teams.length === 0 && (
            <div className="text-center py-12">
              <Users className="h-8 w-8 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500">No teams created yet. Create your first team to organize users.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};