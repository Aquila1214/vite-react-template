import React, { useState } from 'react';
import { Users, Shield, Edit, Trash2, Plus, Save, Check, X } from 'lucide-react';

interface Permission {
  id: string;
  name: string;
  description: string;
  category: string;
  actions: {
    view: boolean;
    create: boolean;
    edit: boolean;
    delete: boolean;
    assign?: boolean;
    approve?: boolean;
  };
}

interface Role {
  id: string;
  name: string;
  description: string;
  permissions: Permission[];
  isSystem: boolean;
}

interface AccessControlTabProps {
  roles: Role[];
  selectedRole: Role | null;
  isEditingRole: boolean;
  setSelectedRole: (role: Role | null) => void;
  setIsEditingRole: (isEditing: boolean) => void;
  handleUpdateRolePermissions: (roleId: string, permissionId: string, action: keyof Permission['actions'], value: boolean) => void;
  handleDeleteRole: (roleId: string) => void;
  handleCreateRole: () => void;
  newRoleName: string;
  setNewRoleName: (name: string) => void;
  newRoleDescription: string;
  setNewRoleDescription: (description: string) => void;
}

export const AccessControlTab: React.FC<AccessControlTabProps> = ({
  roles,
  selectedRole,
  isEditingRole,
  setSelectedRole,
  setIsEditingRole,
  handleUpdateRolePermissions,
  handleDeleteRole,
  handleCreateRole,
  newRoleName,
  setNewRoleName,
  newRoleDescription,
  setNewRoleDescription
}) => {
  const [permissionsView, setPermissionsView] = useState<'roles' | 'matrix'>('roles');

  return (
    <div className="space-y-6">
      {/* Sub-navigation */}
      <div className="flex items-center space-x-4 border-b border-gray-200 pb-4">
        <button
          onClick={() => setPermissionsView('roles')}
          className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
            permissionsView === 'roles' 
              ? 'bg-blue-100 text-blue-700' 
              : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          User Roles
        </button>
        <button
          onClick={() => setPermissionsView('matrix')}
          className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
            permissionsView === 'matrix' 
              ? 'bg-blue-100 text-blue-700' 
              : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          Permission Matrix
        </button>
      </div>

      {permissionsView === 'roles' ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Roles List */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-medium text-gray-900">Available Roles</h4>
              <button
                onClick={() => setIsEditingRole(true)}
                className="flex items-center px-3 py-1 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Role
              </button>
            </div>
            <div className="space-y-3">
              {roles.map(role => (
                <div
                  key={role.id}
                  className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                    selectedRole?.id === role.id
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedRole(role)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <h5 className="font-medium text-gray-900">{role.name}</h5>
                        {role.isSystem && (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800">
                            System
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mt-1">{role.description}</p>
                      <div className="text-xs text-gray-500 mt-2">
                        {role.permissions.filter(p => Object.values(p.actions).some(Boolean)).length} permissions enabled
                      </div>
                    </div>
                    {!role.isSystem && (
                      <div className="flex items-center space-x-2 ml-4">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedRole(role);
                            setIsEditingRole(true);
                          }}
                          className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                          title="Edit"
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteRole(role.id);
                          }}
                          className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Role Details */}
          <div className="space-y-4">
            {selectedRole ? (
              <div className="border border-gray-200 rounded-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-medium text-gray-900">Role Permissions: {selectedRole.name}</h4>
                  {!selectedRole.isSystem && (
                    <button
                      onClick={() => setIsEditingRole(!isEditingRole)}
                      className="text-blue-600 hover:text-blue-800 text-sm"
                    >
                      {isEditingRole ? 'View Mode' : 'Edit Mode'}
                    </button>
                  )}
                </div>

                <div className="space-y-4">
                  {selectedRole.permissions.map(permission => (
                    <div key={permission.id} className="border border-gray-100 rounded-lg p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h5 className="font-medium text-gray-900">{permission.name}</h5>
                          <p className="text-sm text-gray-600">{permission.description}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        {Object.entries(permission.actions).map(([action, enabled]) => (
                          <label key={action} className="flex items-center space-x-2">
                            <input
                              type="checkbox"
                              checked={enabled}
                              disabled={!isEditingRole || selectedRole.isSystem}
                              onChange={(e) => handleUpdateRolePermissions(
                                selectedRole.id,
                                permission.id,
                                action as keyof Permission['actions'],
                                e.target.checked
                              )}
                              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 disabled:opacity-50"
                            />
                            <span className="text-sm text-gray-700 capitalize">{action}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                {isEditingRole && !selectedRole.isSystem && (
                  <div className="mt-6 flex items-center justify-end space-x-3">
                    <button
                      onClick={() => setIsEditingRole(false)}
                      className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => setIsEditingRole(false)}
                      className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700"
                    >
                      <Save className="h-4 w-4 mr-2" />
                      Save Changes
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="border border-gray-200 rounded-lg p-6 text-center">
                <Users className="h-8 w-8 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500">Select a role to view and edit permissions</p>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Permission Matrix</h3>
            <p className="text-gray-600">Overview of all permissions across different roles</p>
          </div>

          <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Permission
                    </th>
                    {roles.map(role => (
                      <th key={role.id} className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {role.name}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {roles[0]?.permissions.map(permission => (
                    <tr key={permission.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>
                          <div className="text-sm font-medium text-gray-900">{permission.name}</div>
                          <div className="text-sm text-gray-500">{permission.description}</div>
                        </div>
                      </td>
                      {roles.map(role => {
                        const rolePermission = role.permissions.find(p => p.id === permission.id);
                        const hasAnyPermission = rolePermission && Object.values(rolePermission.actions).some(Boolean);
                        
                        return (
                          <td key={role.id} className="px-6 py-4 whitespace-nowrap text-center">
                            {hasAnyPermission ? (
                              <Check className="h-5 w-5 text-green-600 mx-auto" />
                            ) : (
                              <X className="h-5 w-5 text-red-400 mx-auto" />
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Create Role Modal */}
      {isEditingRole && !selectedRole && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Create New Role</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Role Name
                  </label>
                  <input
                    type="text"
                    value={newRoleName}
                    onChange={(e) => setNewRoleName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter role name"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    value={newRoleDescription}
                    onChange={(e) => setNewRoleDescription(e.target.value)}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Describe this role's purpose and responsibilities"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end space-x-3 mt-6">
                <button
                  onClick={() => {
                    setIsEditingRole(false);
                    setNewRoleName('');
                    setNewRoleDescription('');
                  }}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleCreateRole}
                  disabled={!newRoleName.trim()}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Create Role
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};