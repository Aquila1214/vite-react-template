import React, { useState } from 'react';
import { Edit, Save, RotateCcw, Plus, Layout, X } from 'lucide-react';
import { useDashboard, TileType, availableTiles } from './DashboardContext';

export const DashboardToolbar: React.FC = () => {
  const { 
    isEditMode, 
    setEditMode, 
    resetToDefault, 
    addTile, 
    saveDashboardLayout 
  } = useDashboard();
  
  const [showAddMenu, setShowAddMenu] = useState(false);

  const handleSave = () => {
    saveDashboardLayout();
    setEditMode(false);
  };

  const handleAddTile = (type: TileType) => {
    addTile(type);
    setShowAddMenu(false);
  };

  return (
    <div className="mb-4 sm:mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-sm text-gray-600">
          {isEditMode 
            ? 'Customize your dashboard by dragging tiles, resizing, or adding new ones' 
            : 'Welcome to Lux Foundation Solutions CRM'}
        </p>
      </div>
      
      <div className="flex flex-wrap items-center gap-2 sm:gap-3">
        {isEditMode ? (
          <>
            <button
              onClick={resetToDefault}
              className="flex items-center px-3 py-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors text-sm"
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset
            </button>
            
            <div className="relative">
              <button
                onClick={() => setShowAddMenu(!showAddMenu)}
                className="flex items-center px-3 py-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors text-sm"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Tile
              </button>
              
              {showAddMenu && (
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
                  <div className="p-2 border-b border-gray-200 flex justify-between items-center">
                    <h3 className="text-sm font-medium text-gray-900">Add Dashboard Tile</h3>
                    <button 
                      onClick={() => setShowAddMenu(false)}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                  <div className="p-2 max-h-64 overflow-y-auto">
                    {Object.entries(availableTiles).map(([type, { title, description }]) => (
                      <button
                        key={type}
                        onClick={() => handleAddTile(type as TileType)}
                        className="w-full text-left p-2 hover:bg-gray-50 rounded transition-colors"
                      >
                        <div className="font-medium text-gray-900">{title}</div>
                        <div className="text-xs text-gray-500">{description}</div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
            
            <button
              onClick={handleSave}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
            >
              <Save className="h-4 w-4 mr-2" />
              Save Layout
            </button>
          </>
        ) : (
          <button
            onClick={() => setEditMode(true)}
            className="flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm"
          >
            <Edit className="h-4 w-4 mr-2" />
            Customize Dashboard
          </button>
        )}
      </div>
    </div>
  );
};