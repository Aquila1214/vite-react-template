import React from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { DashboardProvider, useDashboard } from './DashboardContext';
import { DashboardToolbar } from './DashboardToolbar';
import { DraggableTile } from './DraggableTile';
import { DashboardCards } from './DashboardCards';
import { LeadsPipeline } from './LeadsPipeline';
import { RecentActivity } from './RecentActivity';
import { UpcomingJobs } from './UpcomingJobs';
import { PerformanceMetrics } from './PerformanceMetrics';
import { CustomerMap } from './CustomerMap';
import { TasksOverview } from './TasksOverview';
import { InvoicesSummary } from './InvoicesSummary';
import { EstimatesSummary } from './EstimatesSummary';
import { TeamPerformance } from './TeamPerformance';

const DashboardContent: React.FC = () => {
  const { tiles, isEditMode, moveTile, removeTile, updateTileSize } = useDashboard();
  
  // Sort tiles by position
  const sortedTiles = [...tiles].sort((a, b) => a.position - b.position);
  
  // Filter visible tiles
  const visibleTiles = sortedTiles.filter(tile => tile.visible);

  // Render tile content based on type
  const renderTileContent = (type: string) => {
    switch (type) {
      case 'stats':
        return <DashboardCards />;
      case 'leads_pipeline':
        return <LeadsPipeline />;
      case 'recent_activity':
        return <RecentActivity />;
      case 'upcoming_jobs':
        return <UpcomingJobs />;
      case 'performance_metrics':
        return <PerformanceMetrics />;
      case 'customer_map':
        return <CustomerMap />;
      case 'tasks_overview':
        return <TasksOverview />;
      case 'invoices_summary':
        return <InvoicesSummary />;
      case 'estimates_summary':
        return <EstimatesSummary />;
      case 'team_performance':
        return <TeamPerformance />;
      default:
        return <div className="text-gray-500 text-center p-4">Unknown tile type</div>;
    }
  };

  return (
    <div className="space-y-6">
      <DashboardToolbar />
      
      <div className="grid grid-cols-12 gap-4 sm:gap-6">
        {visibleTiles.map((tile, index) => (
          <DraggableTile
            key={tile.id}
            tile={tile}
            index={index}
            isEditMode={isEditMode}
            onMove={moveTile}
            onRemove={removeTile}
            onResize={updateTileSize}
          >
            {renderTileContent(tile.type)}
          </DraggableTile>
        ))}
      </div>
      
      {visibleTiles.length === 0 && (
        <div className="text-center py-12 bg-white rounded-lg shadow-sm border border-gray-200">
          <p className="text-gray-500">No dashboard tiles to display. Click "Add Tile" to add content.</p>
        </div>
      )}
    </div>
  );
};

export const ModularDashboard: React.FC = () => {
  return (
    <DndProvider backend={HTML5Backend}>
      <DashboardProvider>
        <DashboardContent />
      </DashboardProvider>
    </DndProvider>
  );
};