import React from 'react';
import { TrendingUp, Users, Briefcase, DollarSign, Building } from 'lucide-react';
import { DashboardStats } from '../../types';
import { formatCurrency } from '../../lib/utils';

interface DashboardCardProps {
  title: string;
  value: string | number;
  change: string;
  changeType: 'positive' | 'negative' | 'neutral';
  icon: React.ReactNode;
}

const DashboardCard: React.FC<DashboardCardProps> = ({
  title,
  value,
  change,
  changeType,
  icon,
}) => {
  const changeColorClass = {
    positive: 'text-green-600',
    negative: 'text-red-600',
    neutral: 'text-gray-500',
  }[changeType];

  return (
    <div className="bg-white p-3 sm:p-4 md:p-6 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs sm:text-sm font-medium text-gray-600">{title}</p>
          <p className="text-xl sm:text-2xl md:text-3xl font-bold text-gray-900 mt-1 sm:mt-2">{value}</p>
          <p className={`text-xs sm:text-sm mt-1 sm:mt-2 ${changeColorClass}`}>
            {change}
          </p>
        </div>
        <div className="p-2 sm:p-3 bg-blue-50 rounded-full">
          {icon}
        </div>
      </div>
    </div>
  );
};

interface DashboardCardsProps {
  stats?: DashboardStats | null;
}

export const DashboardCards: React.FC<DashboardCardsProps> = ({ stats }) => {
  const defaultStats = {
    totalCustomers: 0,
    totalLeads: 0,
    activeJobs: 0,
    pendingEstimates: 0,
    monthlyRevenue: 0,
  };

  const currentStats = stats || defaultStats;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3 sm:gap-4 md:gap-6 mb-6 sm:mb-8">
      <DashboardCard
        title="Total Customers"
        value={currentStats.totalCustomers}
        change="+8% from last month"
        changeType="positive"
        icon={<Building className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />}
      />
      <DashboardCard
        title="Total Leads"
        value={currentStats.totalLeads}
        change="+12% from last month"
        changeType="positive"
        icon={<Users className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />}
      />
      <DashboardCard
        title="Active Jobs"
        value={currentStats.activeJobs}
        change="+5% from last month"
        changeType="positive"
        icon={<Briefcase className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />}
      />
      <DashboardCard
        title="Monthly Revenue"
        value={formatCurrency(currentStats.monthlyRevenue)}
        change="+18% from last month"
        changeType="positive"
        icon={<DollarSign className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />}
      />
      <DashboardCard
        title="Pending Estimates"
        value={currentStats.pendingEstimates}
        change="+2% from last month"
        changeType="positive"
        icon={<TrendingUp className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />}
      />
    </div>
  );
};