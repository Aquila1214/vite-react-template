import React from 'react';
import { Calendar, MapPin, User, Clock, ArrowRight } from 'lucide-react';
import { formatDate } from '../../lib/utils';
import { useCrmStore } from '../../stores/crmStore';

export const UpcomingJobs: React.FC = () => {
  const { jobs, users } = useCrmStore();
  
  // Get upcoming jobs (scheduled jobs with future start dates)
  const upcomingJobs = jobs
    .filter(job => 
      job.status === 'SCHEDULED' && 
      job.startDate && 
      new Date(job.startDate) > new Date()
    )
    .sort((a, b) => 
      new Date(a.startDate!).getTime() - new Date(b.startDate!).getTime()
    )
    .slice(0, 5); // Show only the next 5 jobs

  const getUserName = (userId?: string) => {
    if (!userId) return 'Unassigned';
    const user = users.find(u => u.id === userId);
    return user ? user.name : 'Unknown';
  };

  if (upcomingJobs.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <Calendar className="h-12 w-12 text-gray-300 mb-2" />
        <p className="text-gray-500">No upcoming jobs scheduled</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {upcomingJobs.map(job => (
        <div key={job.id} className="bg-gray-50 rounded-lg p-3 hover:bg-gray-100 transition-colors">
          <div className="flex items-start justify-between">
            <div>
              <div className="font-medium text-gray-900">{job.location}</div>
              <div className="text-sm text-gray-600 mt-1">
                {job.customer?.name || 'Unknown Customer'}
              </div>
              <div className="flex items-center text-xs text-gray-500 mt-2">
                <Calendar className="h-3 w-3 mr-1" />
                <span>{job.startDate ? formatDate(job.startDate) : 'Not scheduled'}</span>
                {job.startDate && job.endDate && (
                  <>
                    <ArrowRight className="h-3 w-3 mx-1" />
                    <span>{formatDate(job.endDate)}</span>
                  </>
                )}
              </div>
            </div>
            <div className="flex flex-col items-end">
              <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800`}>
                {job.projectType ? job.projectType.replace(/_/g, ' ') : 'Project'}
              </span>
              <div className="flex items-center text-xs text-gray-500 mt-2">
                <User className="h-3 w-3 mr-1" />
                <span>{getUserName(job.assignedTo)}</span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};