import React from 'react';
import { Clock, User, Briefcase, FileText } from 'lucide-react';
import { ActivityItem } from '../../types';

const getIcon = (type: string) => {
  switch (type) {
    case 'lead':
      return <User className="w-5 h-5 text-blue-600" />;
    case 'job':
      return <Briefcase className="w-5 h-5 text-green-600" />;
    case 'estimate':
      return <FileText className="w-5 h-5 text-amber-600" />;
    default:
      return <Clock className="w-5 h-5 text-gray-600" />;
  }
};

interface RecentActivityProps {
  activities?: ActivityItem[];
}

export const RecentActivity: React.FC<RecentActivityProps> = ({ activities = [] }) => {
  const mockActivities: ActivityItem[] = [
    {
      id: '1',
      type: 'lead',
      title: 'New lead created',
      description: 'Foundation repair inquiry from Sarah Johnson',
      time: '5 minutes ago',
      user: 'John Smith',
    },
    {
      id: '2',
      type: 'job',
      title: 'Job completed',
      description: 'Basement waterproofing at 123 Oak Street',
      time: '2 hours ago',
      user: 'Mike Wilson',
    },
    {
      id: '3',
      type: 'estimate',
      title: 'Estimate sent',
      description: '$8,500 estimate for foundation crack repair',
      time: '4 hours ago',
      user: 'Lisa Chen',
    },
    {
      id: '4',
      type: 'user',
      title: 'Customer payment received',
      description: '$12,000 payment via Stripe',
      time: '6 hours ago',
      user: 'System',
    },
  ];

  const displayActivities = activities.length > 0 ? activities : mockActivities;

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
      </div>
      <div className="p-6">
        <div className="space-y-4">
          {displayActivities.map((activity) => (
            <div key={activity.id} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors duration-150">
              <div className="p-2 bg-gray-100 rounded-full">
                {getIcon(activity.type)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900">
                  {activity.title}
                </p>
                <p className="text-sm text-gray-600">
                  {activity.description}
                </p>
                <div className="flex items-center mt-1 text-xs text-gray-500">
                  <span>{activity.time}</span>
                  <span className="mx-2">•</span>
                  <span>{activity.user}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};