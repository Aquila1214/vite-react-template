import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuthStore } from '../../stores/authStore';

// Define tile types
export type TileType = 
  | 'stats' 
  | 'leads_pipeline' 
  | 'recent_activity' 
  | 'upcoming_jobs'
  | 'performance_metrics'
  | 'customer_map'
  | 'tasks_overview'
  | 'invoices_summary'
  | 'estimates_summary'
  | 'team_performance';

export interface DashboardTile {
  id: string;
  type: TileType;
  title: string;
  width: 'full' | 'half' | 'third';
  height: 'small' | 'medium' | 'large';
  position: number;
  visible: boolean;
}

// Define dashboard templates for different user roles
const dashboardTemplates: Record<string, DashboardTile[]> = {
  ADMIN: [
    { id: 'stats', type: 'stats', title: 'Key Metrics', width: 'full', height: 'small', position: 0, visible: true },
    { id: 'leads_pipeline', type: 'leads_pipeline', title: 'Leads Pipeline', width: 'half', height: 'medium', position: 1, visible: true },
    { id: 'recent_activity', type: 'recent_activity', title: 'Recent Activity', width: 'half', height: 'medium', position: 2, visible: true },
    { id: 'performance_metrics', type: 'performance_metrics', title: 'Performance Metrics', width: 'third', height: 'medium', position: 3, visible: true },
    { id: 'upcoming_jobs', type: 'upcoming_jobs', title: 'Upcoming Jobs', width: 'third', height: 'medium', position: 4, visible: true },
    { id: 'invoices_summary', type: 'invoices_summary', title: 'Invoices Summary', width: 'third', height: 'medium', position: 5, visible: true },
  ],
  SALES: [
    { id: 'stats', type: 'stats', title: 'Key Metrics', width: 'full', height: 'small', position: 0, visible: true },
    { id: 'leads_pipeline', type: 'leads_pipeline', title: 'Leads Pipeline', width: 'full', height: 'medium', position: 1, visible: true },
    { id: 'recent_activity', type: 'recent_activity', title: 'Recent Activity', width: 'half', height: 'medium', position: 2, visible: true },
    { id: 'estimates_summary', type: 'estimates_summary', title: 'Estimates Summary', width: 'half', height: 'medium', position: 3, visible: true },
  ],
  OPERATIONS: [
    { id: 'stats', type: 'stats', title: 'Key Metrics', width: 'full', height: 'small', position: 0, visible: true },
    { id: 'upcoming_jobs', type: 'upcoming_jobs', title: 'Upcoming Jobs', width: 'half', height: 'medium', position: 1, visible: true },
    { id: 'tasks_overview', type: 'tasks_overview', title: 'Tasks Overview', width: 'half', height: 'medium', position: 2, visible: true },
    { id: 'team_performance', type: 'team_performance', title: 'Team Performance', width: 'full', height: 'medium', position: 3, visible: true },
  ],
  TECHNICIAN: [
    { id: 'stats', type: 'stats', title: 'Key Metrics', width: 'full', height: 'small', position: 0, visible: true },
    { id: 'upcoming_jobs', type: 'upcoming_jobs', title: 'My Upcoming Jobs', width: 'half', height: 'medium', position: 1, visible: true },
    { id: 'tasks_overview', type: 'tasks_overview', title: 'My Tasks', width: 'half', height: 'medium', position: 2, visible: true },
  ],
  CUSTOMER: [
    { id: 'stats', type: 'stats', title: 'Account Summary', width: 'full', height: 'small', position: 0, visible: true },
    { id: 'upcoming_jobs', type: 'upcoming_jobs', title: 'Scheduled Services', width: 'half', height: 'medium', position: 1, visible: true },
    { id: 'invoices_summary', type: 'invoices_summary', title: 'Invoices & Payments', width: 'half', height: 'medium', position: 2, visible: true },
  ],
};

// Available tiles for adding to dashboard
export const availableTiles: Record<TileType, { title: string, description: string }> = {
  stats: { 
    title: 'Key Metrics', 
    description: 'Overview of important business metrics' 
  },
  leads_pipeline: { 
    title: 'Leads Pipeline', 
    description: 'Visual representation of leads by stage' 
  },
  recent_activity: { 
    title: 'Recent Activity', 
    description: 'Latest actions and updates in the system' 
  },
  upcoming_jobs: { 
    title: 'Upcoming Jobs', 
    description: 'Jobs scheduled in the near future' 
  },
  performance_metrics: { 
    title: 'Performance Metrics', 
    description: 'Key performance indicators and trends' 
  },
  customer_map: { 
    title: 'Customer Map', 
    description: 'Geographic distribution of customers' 
  },
  tasks_overview: { 
    title: 'Tasks Overview', 
    description: 'Summary of pending and upcoming tasks' 
  },
  invoices_summary: { 
    title: 'Invoices Summary', 
    description: 'Overview of invoice status and payments' 
  },
  estimates_summary: { 
    title: 'Estimates Summary', 
    description: 'Summary of estimates and conversion rates' 
  },
  team_performance: { 
    title: 'Team Performance', 
    description: 'Productivity and efficiency metrics by team' 
  },
};

interface DashboardContextType {
  tiles: DashboardTile[];
  isEditMode: boolean;
  setEditMode: (mode: boolean) => void;
  moveTile: (dragIndex: number, hoverIndex: number) => void;
  toggleTileVisibility: (id: string) => void;
  resetToDefault: () => void;
  addTile: (type: TileType) => void;
  removeTile: (id: string) => void;
  updateTileSize: (id: string, width: DashboardTile['width'], height: DashboardTile['height']) => void;
  saveDashboardLayout: () => void;
}

const DashboardContext = createContext<DashboardContextType | undefined>(undefined);

export const DashboardProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuthStore();
  const [tiles, setTiles] = useState<DashboardTile[]>([]);
  const [isEditMode, setIsEditMode] = useState(false);

  // Initialize dashboard based on user role
  useEffect(() => {
    if (user) {
      // Try to load saved layout from localStorage
      const savedLayout = localStorage.getItem(`dashboard_layout_${user.id}`);
      if (savedLayout) {
        try {
          setTiles(JSON.parse(savedLayout));
        } catch (error) {
          console.error('Failed to parse saved dashboard layout:', error);
          setTiles(dashboardTemplates[user.role] || dashboardTemplates.ADMIN);
        }
      } else {
        // Use default template for user role
        setTiles(dashboardTemplates[user.role] || dashboardTemplates.ADMIN);
      }
    }
  }, [user]);

  const moveTile = (dragIndex: number, hoverIndex: number) => {
    const draggedTile = tiles[dragIndex];
    if (!draggedTile) return;

    setTiles(prevTiles => {
      const newTiles = [...prevTiles];
      // Remove the dragged tile
      newTiles.splice(dragIndex, 1);
      // Insert it at the new position
      newTiles.splice(hoverIndex, 0, draggedTile);
      
      // Update positions
      return newTiles.map((tile, index) => ({
        ...tile,
        position: index
      }));
    });
  };

  const toggleTileVisibility = (id: string) => {
    setTiles(prevTiles => 
      prevTiles.map(tile => 
        tile.id === id ? { ...tile, visible: !tile.visible } : tile
      )
    );
  };

  const resetToDefault = () => {
    if (user) {
      setTiles(dashboardTemplates[user.role] || dashboardTemplates.ADMIN);
    }
  };

  const addTile = (type: TileType) => {
    const newTile: DashboardTile = {
      id: `${type}_${Date.now()}`,
      type,
      title: availableTiles[type].title,
      width: 'half',
      height: 'medium',
      position: tiles.length,
      visible: true
    };
    
    setTiles(prevTiles => [...prevTiles, newTile]);
  };

  const removeTile = (id: string) => {
    setTiles(prevTiles => {
      const newTiles = prevTiles.filter(tile => tile.id !== id);
      // Update positions
      return newTiles.map((tile, index) => ({
        ...tile,
        position: index
      }));
    });
  };

  const updateTileSize = (id: string, width: DashboardTile['width'], height: DashboardTile['height']) => {
    setTiles(prevTiles => 
      prevTiles.map(tile => 
        tile.id === id ? { ...tile, width, height } : tile
      )
    );
  };

  const saveDashboardLayout = () => {
    if (user) {
      localStorage.setItem(`dashboard_layout_${user.id}`, JSON.stringify(tiles));
    }
  };

  return (
    <DashboardContext.Provider value={{
      tiles,
      isEditMode,
      setEditMode: setIsEditMode,
      moveTile,
      toggleTileVisibility,
      resetToDefault,
      addTile,
      removeTile,
      updateTileSize,
      saveDashboardLayout
    }}>
      {children}
    </DashboardContext.Provider>
  );
};

export const useDashboard = () => {
  const context = useContext(DashboardContext);
  if (context === undefined) {
    throw new Error('useDashboard must be used within a DashboardProvider');
  }
  return context;
};