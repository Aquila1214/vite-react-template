import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Users, Award, Target } from 'lucide-react';
import { useCrmStore } from '../../stores/crmStore';

export const TeamPerformance: React.FC = () => {
  const { users, teams, jobs } = useCrmStore();
  
  // Group users by team
  const usersByTeam = users.reduce((acc, user) => {
    if (user.teamId) {
      if (!acc[user.teamId]) {
        acc[user.teamId] = [];
      }
      acc[user.teamId].push(user);
    }
    return acc;
  }, {} as Record<string, typeof users>);
  
  // Calculate jobs completed by team
  const jobsByTeam = teams.map(team => {
    const teamUsers = usersByTeam[team.id] || [];
    const teamUserIds = teamUsers.map(user => user.id);
    
    const completedJobs = jobs.filter(job => 
      job.status === 'COMPLETED' && 
      teamUserIds.includes(job.assignedTo || '')
    ).length;
    
    const inProgressJobs = jobs.filter(job => 
      job.status === 'IN_PROGRESS' && 
      teamUserIds.includes(job.assignedTo || '')
    ).length;
    
    return {
      team: team.name,
      completed: completedJobs,
      inProgress: inProgressJobs,
      color: team.color
    };
  });
  
  // Find top performer
  const jobsByUser = users.map(user => {
    const completedJobs = jobs.filter(job => 
      job.status === 'COMPLETED' && 
      job.assignedTo === user.id
    ).length;
    
    return {
      userId: user.id,
      name: user.name,
      completedJobs
    };
  }).sort((a, b) => b.completedJobs - a.completedJobs);
  
  const topPerformer = jobsByUser[0];

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium text-gray-900">{label}</p>
          <p className="text-green-600">
            Completed: {payload[0].value}
          </p>
          <p className="text-blue-600">
            In Progress: {payload[1].value}
          </p>
        </div>
      );
    }
    return null;
  };

  if (teams.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <Users className="h-12 w-12 text-gray-300 mb-2" />
        <p className="text-gray-500">No team data available</p>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {topPerformer && topPerformer.completedJobs > 0 && (
        <div className="bg-blue-50 rounded-lg p-3 mb-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-blue-600">Top Performer</div>
              <div className="font-medium text-blue-900">{topPerformer.name}</div>
            </div>
            <div className="flex items-center">
              <Award className="h-5 w-5 text-blue-500 mr-2" />
              <span className="text-lg font-bold text-blue-700">{topPerformer.completedJobs} jobs</span>
            </div>
          </div>
        </div>
      )}
      
      <div className="flex-1">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={jobsByTeam}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="team" />
            <YAxis allowDecimals={false} />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="completed" fill="#10B981" name="Completed Jobs" />
            <Bar dataKey="inProgress" fill="#3B82F6" name="In Progress Jobs" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};