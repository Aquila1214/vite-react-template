import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { FileText, CheckCircle, XCircle } from 'lucide-react';
import { formatCurrency } from '../../lib/utils';
import { useCrmStore } from '../../stores/crmStore';

export const EstimatesSummary: React.FC = () => {
  const { estimates } = useCrmStore();
  
  // Calculate estimate statistics
  const totalEstimates = estimates.length;
  const acceptedEstimates = estimates.filter(est => est.accepted).length;
  const pendingEstimates = totalEstimates - acceptedEstimates;
  
  const totalValue = estimates.reduce((sum, est) => sum + est.total, 0);
  const acceptedValue = estimates
    .filter(est => est.accepted)
    .reduce((sum, est) => sum + est.total, 0);
  
  const conversionRate = totalEstimates > 0
    ? (acceptedEstimates / totalEstimates) * 100
    : 0;
  
  // Prepare data for bar chart - last 4 months
  const months = ['Jan', 'Feb', 'Mar', 'Apr'];
  const chartData = months.map(month => {
    // In a real implementation, this would filter by actual dates
    // For now, we'll use random data
    const total = Math.floor(Math.random() * 5) + 1;
    const accepted = Math.floor(Math.random() * total) + 1;
    
    return {
      month,
      total,
      accepted
    };
  });

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium text-gray-900">{label}</p>
          <p className="text-blue-600">
            Total: {payload[0].value}
          </p>
          <p className="text-green-600">
            Accepted: {payload[1].value}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="h-full flex flex-col">
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="bg-blue-50 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <div className="text-sm text-blue-600">Total Value</div>
            <FileText className="h-5 w-5 text-blue-500" />
          </div>
          <div className="text-lg font-bold text-blue-700">
            {formatCurrency(totalValue)}
          </div>
        </div>
        
        <div className="bg-green-50 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <div className="text-sm text-green-600">Accepted</div>
            <CheckCircle className="h-5 w-5 text-green-500" />
          </div>
          <div className="text-lg font-bold text-green-700">
            {acceptedEstimates} ({conversionRate.toFixed(0)}%)
          </div>
        </div>
        
        <div className="bg-yellow-50 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <div className="text-sm text-yellow-600">Pending</div>
            <XCircle className="h-5 w-5 text-yellow-500" />
          </div>
          <div className="text-lg font-bold text-yellow-700">
            {pendingEstimates}
          </div>
        </div>
      </div>
      
      <div className="flex-1">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis allowDecimals={false} />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="total" fill="#3B82F6" name="Total Estimates" />
            <Bar dataKey="accepted" fill="#10B981" name="Accepted" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};