import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { CreditCard, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import { formatCurrency } from '../../lib/utils';
import { useCrmStore } from '../../stores/crmStore';

export const InvoicesSummary: React.FC = () => {
  const { invoices } = useCrmStore();
  
  // Calculate invoice statistics
  const totalDue = invoices
    .filter(inv => inv.status === 'UNPAID' || inv.status === 'OVERDUE')
    .reduce((sum, inv) => sum + inv.amount, 0);
  
  const totalOverdue = invoices
    .filter(inv => inv.status === 'OVERDUE')
    .reduce((sum, inv) => sum + inv.amount, 0);
  
  const totalPaid = invoices
    .filter(inv => inv.status === 'PAID')
    .reduce((sum, inv) => sum + inv.amount, 0);
  
  // Prepare data for pie chart
  const data = [
    { name: 'Paid', value: totalPaid, color: '#10B981' },
    { name: 'Due', value: totalDue - totalOverdue, color: '#3B82F6' },
    { name: 'Overdue', value: totalOverdue, color: '#EF4444' },
  ].filter(item => item.value > 0);

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium text-gray-900">{payload[0].name}</p>
          <p style={{ color: payload[0].payload.color }}>
            {formatCurrency(payload[0].value)}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="h-full flex flex-col">
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="bg-blue-50 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <div className="text-sm text-blue-600">Due</div>
            <Clock className="h-5 w-5 text-blue-500" />
          </div>
          <div className="text-lg font-bold text-blue-700">
            {formatCurrency(totalDue - totalOverdue)}
          </div>
        </div>
        
        <div className="bg-red-50 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <div className="text-sm text-red-600">Overdue</div>
            <AlertTriangle className="h-5 w-5 text-red-500" />
          </div>
          <div className="text-lg font-bold text-red-700">
            {formatCurrency(totalOverdue)}
          </div>
        </div>
        
        <div className="bg-green-50 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <div className="text-sm text-green-600">Paid</div>
            <CheckCircle className="h-5 w-5 text-green-500" />
          </div>
          <div className="text-lg font-bold text-green-700">
            {formatCurrency(totalPaid)}
          </div>
        </div>
      </div>
      
      <div className="flex-1 flex items-center justify-center">
        {data.length > 0 ? (
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        ) : (
          <div className="flex flex-col items-center justify-center">
            <CreditCard className="h-12 w-12 text-gray-300 mb-2" />
            <p className="text-gray-500">No invoice data available</p>
          </div>
        )}
      </div>
    </div>
  );
};