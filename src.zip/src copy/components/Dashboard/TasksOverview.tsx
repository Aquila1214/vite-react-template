import React from 'react';
import { CheckSquare, Clock, AlertTriangle } from 'lucide-react';
import { formatDate } from '../../lib/utils';
import { useCrmStore } from '../../stores/crmStore';
import { useAuthStore } from '../../stores/authStore';

export const TasksOverview: React.FC = () => {
  const { tasks, users } = useCrmStore();
  const { user: currentUser } = useAuthStore();
  
  // Filter tasks based on user role
  const filteredTasks = tasks.filter(task => {
    if (currentUser?.role === 'TECHNICIAN') {
      return task.assignedTo === currentUser.id;
    }
    if (currentUser?.role === 'SALES') {
      // Show tasks assigned to the current user or their team
      const assignedUser = users.find(u => u.id === task.assignedTo);
      return task.assignedTo === currentUser.id || assignedUser?.teamId === currentUser.teamId;
    }
    return true;
  });
  
  // Sort by due date (closest first)
  const sortedTasks = [...filteredTasks].sort((a, b) => 
    new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
  );
  
  // Get pending tasks
  const pendingTasks = sortedTasks.filter(task => 
    task.status === 'PENDING' || task.status === 'IN_PROGRESS'
  ).slice(0, 5);
  
  // Calculate task statistics
  const overdueTasks = sortedTasks.filter(task => 
    (task.status === 'PENDING' || task.status === 'IN_PROGRESS') && 
    new Date(task.dueDate) < new Date()
  ).length;
  
  const dueTodayTasks = sortedTasks.filter(task => {
    if (task.status === 'COMPLETED' || task.status === 'CANCELLED') return false;
    
    const dueDate = new Date(task.dueDate);
    const today = new Date();
    return dueDate.getDate() === today.getDate() &&
           dueDate.getMonth() === today.getMonth() &&
           dueDate.getFullYear() === today.getFullYear();
  }).length;
  
  const completedTasks = sortedTasks.filter(task => 
    task.status === 'COMPLETED'
  ).length;

  const getUserName = (userId: string) => {
    const user = users.find(u => u.id === userId);
    return user ? user.name : 'Unknown';
  };

  return (
    <div className="h-full flex flex-col">
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="bg-red-50 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <div className="text-xl font-bold text-red-700">{overdueTasks}</div>
            <AlertTriangle className="h-5 w-5 text-red-500" />
          </div>
          <div className="text-sm text-red-600">Overdue</div>
        </div>
        
        <div className="bg-yellow-50 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <div className="text-xl font-bold text-yellow-700">{dueTodayTasks}</div>
            <Clock className="h-5 w-5 text-yellow-500" />
          </div>
          <div className="text-sm text-yellow-600">Due Today</div>
        </div>
        
        <div className="bg-green-50 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <div className="text-xl font-bold text-green-700">{completedTasks}</div>
            <CheckSquare className="h-5 w-5 text-green-500" />
          </div>
          <div className="text-sm text-green-600">Completed</div>
        </div>
      </div>
      
      <div className="flex-1 overflow-auto">
        <h4 className="text-sm font-medium text-gray-700 mb-2">Upcoming Tasks</h4>
        
        {pendingTasks.length > 0 ? (
          <div className="space-y-2">
            {pendingTasks.map(task => {
              const isOverdue = new Date(task.dueDate) < new Date();
              
              return (
                <div key={task.id} className="bg-gray-50 rounded-lg p-3 hover:bg-gray-100 transition-colors">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-medium text-gray-900">{task.description}</div>
                      <div className="flex items-center text-xs text-gray-500 mt-1">
                        <Clock className="h-3 w-3 mr-1" />
                        <span className={isOverdue ? 'text-red-600 font-medium' : ''}>
                          {formatDate(task.dueDate)}
                          {isOverdue && ' (Overdue)'}
                        </span>
                      </div>
                    </div>
                    <div className="text-xs text-gray-500">
                      {getUserName(task.assignedTo)}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="flex items-center justify-center h-32 bg-gray-50 rounded-lg">
            <p className="text-gray-500">No pending tasks</p>
          </div>
        )}
      </div>
    </div>
  );
};