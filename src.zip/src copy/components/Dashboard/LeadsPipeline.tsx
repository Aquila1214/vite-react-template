import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { PipelineStage } from '../../types';
import { formatCurrency } from '../../lib/utils';

interface LeadsPipelineProps {
  pipeline?: PipelineStage[];
}

export const LeadsPipeline: React.FC<LeadsPipelineProps> = ({ pipeline = [] }) => {
  const mockPipelineData = [
    { stage: 'New', count: 24, value: 125000, color: '#3B82F6' },
    { stage: 'Contacted', count: 18, value: 95000, color: '#10B981' },
    { stage: 'Qualified', count: 12, value: 78000, color: '#F59E0B' },
    { stage: 'Estimate Sent', count: 8, value: 52000, color: '#8B5CF6' },
    { stage: 'Converted', count: 15, value: 185000, color: '#059669' },
    { stage: 'Lost', count: 6, value: 0, color: '#EF4444' },
  ];

  const chartData = pipeline.length > 0 
    ? pipeline.map(stage => ({
        stage: stage.status.replace('_', ' '),
        count: stage.count,
        value: stage.value,
      }))
    : mockPipelineData;

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium text-gray-900">{label}</p>
          <p className="text-blue-600">
            Count: <span className="font-medium">{payload[0].value}</span>
          </p>
          {payload[0].payload.value > 0 && (
            <p className="text-green-600">
              Value: <span className="font-medium">{formatCurrency(payload[0].payload.value)}</span>
            </p>
          )}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900">Leads Pipeline</h3>
      </div>
      <div className="p-6">
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              dataKey="stage" 
              tick={{ fontSize: 12 }}
              angle={-45}
              textAnchor="end"
              height={80}
            />
            <YAxis />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="count" fill="#3B82F6" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};