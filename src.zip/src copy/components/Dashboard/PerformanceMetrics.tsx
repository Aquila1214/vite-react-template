import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { formatCurrency } from '../../lib/utils';

export const PerformanceMetrics: React.FC = () => {
  // Mock performance data
  const performanceData = {
    revenue: {
      current: 11200,
      previous: 9500,
      change: 1700,
      changePercentage: 17.9
    },
    jobs: {
      current: 12,
      previous: 10,
      change: 2,
      changePercentage: 20
    },
    avgJobValue: {
      current: 933.33,
      previous: 950,
      change: -16.67,
      changePercentage: -1.75
    }
  };

  // Mock monthly data
  const monthlyData = [
    { month: 'Jan', revenue: 8500 },
    { month: 'Feb', revenue: 9200 },
    { month: 'Mar', revenue: 9500 },
    { month: 'Apr', revenue: 11200 },
  ];

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium text-gray-900">{label}</p>
          <p className="text-blue-600">
            Revenue: {formatCurrency(payload[0].value)}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="h-full flex flex-col">
      <div className="grid grid-cols-1 gap-4 mb-4">
        <div className="bg-gray-50 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-gray-600">Monthly Revenue</div>
              <div className="text-xl font-bold text-gray-900">
                {formatCurrency(performanceData.revenue.current)}
              </div>
            </div>
            <div className="flex items-center">
              {performanceData.revenue.change > 0 ? (
                <TrendingUp className="h-5 w-5 text-green-600 mr-1" />
              ) : (
                <TrendingDown className="h-5 w-5 text-red-600 mr-1" />
              )}
              <span className={`text-sm font-medium ${
                performanceData.revenue.change > 0 ? 'text-green-600' : 'text-red-600'
              }`}>
                {performanceData.revenue.change > 0 ? '+' : ''}
                {performanceData.revenue.changePercentage.toFixed(1)}%
              </span>
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex-1">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={monthlyData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="revenue" fill="#3B82F6" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};