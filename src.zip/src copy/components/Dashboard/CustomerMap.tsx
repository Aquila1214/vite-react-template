import React from 'react';
import { MapPin } from 'lucide-react';
import { useCrmStore } from '../../stores/crmStore';

export const CustomerMap: React.FC = () => {
  const { customers } = useCrmStore();
  
  // In a real implementation, this would use a mapping library like Leaflet or Google Maps
  // For now, we'll just show a placeholder with customer locations
  
  return (
    <div className="h-full flex flex-col">
      <div className="flex-1 bg-gray-100 rounded-lg relative overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center">
          <p className="text-gray-500">Map visualization would appear here</p>
        </div>
        
        <div className="absolute inset-0 p-4">
          <div className="grid grid-cols-2 gap-2">
            {customers.slice(0, 6).map(customer => (
              <div key={customer.id} className="bg-white bg-opacity-90 rounded-lg p-2 shadow-sm">
                <div className="flex items-start">
                  <MapPin className="h-4 w-4 text-red-500 mt-0.5 mr-2 flex-shrink-0" />
                  <div>
                    <div className="text-sm font-medium text-gray-900">{customer.name}</div>
                    <div className="text-xs text-gray-600 line-clamp-1">{customer.address}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      <div className="mt-3 text-xs text-gray-500 text-center">
        Showing {Math.min(customers.length, 6)} of {customers.length} customer locations
      </div>
    </div>
  );
};