import React, { useRef } from 'react';
import { useDrag, useDrop } from 'react-dnd';
import { XCircle, Move, Maximize, Minimize, Settings } from 'lucide-react';
import { DashboardTile } from './DashboardContext';

interface DraggableTileProps {
  tile: DashboardTile;
  index: number;
  isEditMode: boolean;
  onMove: (dragIndex: number, hoverIndex: number) => void;
  onRemove: (id: string) => void;
  onResize: (id: string, width: DashboardTile['width'], height: DashboardTile['height']) => void;
  children: React.ReactNode;
}

interface DragItem {
  index: number;
  id: string;
  type: string;
}

export const DraggableTile: React.FC<DraggableTileProps> = ({
  tile,
  index,
  isEditMode,
  onMove,
  onRemove,
  onResize,
  children
}) => {
  const ref = useRef<HTMLDivElement>(null);

  // Set up drag
  const [{ isDragging }, drag] = useDrag({
    type: 'DASHBOARD_TILE',
    item: { index, id: tile.id },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
    canDrag: isEditMode,
  });

  // Set up drop
  const [, drop] = useDrop({
    accept: 'DASHBOARD_TILE',
    hover(item: DragItem, monitor) {
      if (!ref.current) {
        return;
      }
      const dragIndex = item.index;
      const hoverIndex = index;

      // Don't replace items with themselves
      if (dragIndex === hoverIndex) {
        return;
      }

      // Determine rectangle on screen
      const hoverBoundingRect = ref.current?.getBoundingClientRect();

      // Get vertical middle
      const hoverMiddleY = (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2;

      // Determine mouse position
      const clientOffset = monitor.getClientOffset();

      // Get pixels to the top
      const hoverClientY = clientOffset!.y - hoverBoundingRect.top;

      // Only perform the move when the mouse has crossed half of the items height
      // When dragging downwards, only move when the cursor is below 50%
      // When dragging upwards, only move when the cursor is above 50%
      
      // Dragging downwards
      if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
        return;
      }

      // Dragging upwards
      if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
        return;
      }

      // Time to actually perform the action
      onMove(dragIndex, hoverIndex);

      // Note: we're mutating the monitor item here!
      // Generally it's better to avoid mutations,
      // but it's good here for the sake of performance
      // to avoid expensive index searches.
      item.index = hoverIndex;
    },
    canDrop: () => isEditMode,
  });

  // Initialize drag and drop
  drag(drop(ref));

  // Determine width class based on tile width
  const widthClass = {
    full: 'col-span-12',
    half: 'col-span-12 md:col-span-6',
    third: 'col-span-12 md:col-span-6 lg:col-span-4',
  }[tile.width];

  // Determine height class based on tile height
  const heightClass = {
    small: 'h-auto',
    medium: 'h-[300px]',
    large: 'h-[500px]',
  }[tile.height];

  // Cycle through width options
  const cycleWidth = () => {
    const widths: DashboardTile['width'][] = ['third', 'half', 'full'];
    const currentIndex = widths.indexOf(tile.width);
    const nextWidth = widths[(currentIndex + 1) % widths.length];
    onResize(tile.id, nextWidth, tile.height);
  };

  // Cycle through height options
  const cycleHeight = () => {
    const heights: DashboardTile['height'][] = ['small', 'medium', 'large'];
    const currentIndex = heights.indexOf(tile.height);
    const nextHeight = heights[(currentIndex + 1) % heights.length];
    onResize(tile.id, tile.width, nextHeight);
  };

  return (
    <div 
      ref={ref}
      className={`${widthClass} ${isEditMode ? 'cursor-move' : ''} transition-all duration-300 ease-in-out`}
      style={{ opacity: isDragging ? 0.5 : 1 }}
    >
      <div className={`bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden ${heightClass} flex flex-col`}>
        <div className="p-3 sm:p-4 border-b border-gray-200 flex items-center justify-between">
          <h3 className="text-base sm:text-lg font-semibold text-gray-900 truncate">{tile.title}</h3>
          
          {isEditMode && (
            <div className="flex items-center space-x-1 sm:space-x-2">
              <button 
                onClick={() => cycleWidth()} 
                className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                title="Change width"
              >
                <Maximize className="h-4 w-4" />
              </button>
              <button 
                onClick={() => cycleHeight()} 
                className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                title="Change height"
              >
                <Minimize className="h-4 w-4" />
              </button>
              <button 
                onClick={() => onRemove(tile.id)} 
                className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                title="Remove tile"
              >
                <XCircle className="h-4 w-4" />
              </button>
              {isEditMode && (
                <div className="p-1 text-blue-600">
                  <Move className="h-4 w-4" />
                </div>
              )}
            </div>
          )}
        </div>
        
        <div className="flex-1 overflow-auto p-3 sm:p-4">
          {children}
        </div>
      </div>
    </div>
  );
};