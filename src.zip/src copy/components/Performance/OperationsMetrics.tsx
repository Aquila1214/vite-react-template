import React from 'react';
import { Wrench, Clock, CheckCircle, Users, TrendingUp, ArrowUp, ArrowDown, Target } from 'lucide-react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadialBarChart, RadialBar } from 'recharts';
import { formatCurrency } from '../../lib/utils';
import type { OperationsPerformanceData, TimePeriod } from '../../types/performance';

interface OperationsMetricsProps {
  data: OperationsPerformanceData | null;
  timePeriod: TimePeriod;
}

export const OperationsMetrics: React.FC<OperationsMetricsProps> = ({ data, timePeriod }) => {
  if (!data) {
    return (
      <div className="space-y-6">
        <div className="h-64 bg-gray-200 rounded-lg animate-pulse" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-32 bg-gray-200 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium text-gray-900">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }}>
              {entry.name}: {entry.value.toFixed(1)}%
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900">Operations Performance</h2>
        <p className="text-gray-600">Productivity metrics, quality control, and resource utilization</p>
      </div>

      {/* Productivity Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Overall Efficiency</p>
              <p className="text-2xl font-bold text-gray-900">
                {data.productivity.overallEfficiency.value.toFixed(1)}%
              </p>
              <div className="flex items-center mt-2">
                {data.productivity.overallEfficiency.comparison.trend === 'up' ? (
                  <ArrowUp className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowDown className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.productivity.overallEfficiency.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.productivity.overallEfficiency.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <Wrench className="h-8 w-8 text-blue-600" />
          </div>
          {data.productivity.overallEfficiency.target && (
            <div className="mt-4">
              <div className="flex justify-between text-xs text-gray-600 mb-1">
                <span>Target Progress</span>
                <span>{data.productivity.overallEfficiency.targetPercentage?.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(data.productivity.overallEfficiency.targetPercentage || 0, 100)}%` }}
                />
              </div>
            </div>
          )}
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Jobs Completed</p>
              <p className="text-2xl font-bold text-gray-900">
                {data.productivity.jobsCompleted.value}
              </p>
              <div className="flex items-center mt-2">
                {data.productivity.jobsCompleted.comparison.trend === 'up' ? (
                  <ArrowUp className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowDown className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.productivity.jobsCompleted.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.productivity.jobsCompleted.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Avg Job Time</p>
              <p className="text-2xl font-bold text-gray-900">
                {data.productivity.averageJobTime.value.toFixed(1)}h
              </p>
              <div className="flex items-center mt-2">
                {data.productivity.averageJobTime.comparison.trend === 'down' ? (
                  <ArrowDown className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowUp className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.productivity.averageJobTime.comparison.trend === 'down' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.productivity.averageJobTime.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <Clock className="h-8 w-8 text-purple-600" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Utilization Rate</p>
              <p className="text-2xl font-bold text-gray-900">
                {data.productivity.utilizationRate.value.toFixed(1)}%
              </p>
              <div className="flex items-center mt-2">
                {data.productivity.utilizationRate.comparison.trend === 'up' ? (
                  <ArrowUp className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowDown className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.productivity.utilizationRate.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.productivity.utilizationRate.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <Users className="h-8 w-8 text-amber-600" />
          </div>
        </div>
      </div>

      {/* Quality Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Customer Satisfaction</h4>
            <Target className="h-6 w-6 text-green-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.quality.customerSatisfaction.value.toFixed(1)}/5.0
          </div>
          <div className="flex items-center">
            {data.quality.customerSatisfaction.comparison.trend === 'up' ? (
              <ArrowUp className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowDown className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.quality.customerSatisfaction.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.quality.customerSatisfaction.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
          {data.quality.customerSatisfaction.target && (
            <div className="mt-4">
              <div className="flex justify-between text-xs text-gray-600 mb-1">
                <span>Target Progress</span>
                <span>{data.quality.customerSatisfaction.targetPercentage?.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-green-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(data.quality.customerSatisfaction.targetPercentage || 0, 100)}%` }}
                />
              </div>
            </div>
          )}
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Defect Rate</h4>
            <CheckCircle className="h-6 w-6 text-red-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.quality.defectRate.value.toFixed(1)}%
          </div>
          <div className="flex items-center">
            {data.quality.defectRate.comparison.trend === 'down' ? (
              <ArrowDown className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowUp className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.quality.defectRate.comparison.trend === 'down' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.quality.defectRate.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Rework Rate</h4>
            <Wrench className="h-6 w-6 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.quality.reworkRate.value.toFixed(1)}%
          </div>
          <div className="flex items-center">
            {data.quality.reworkRate.comparison.trend === 'down' ? (
              <ArrowDown className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowUp className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.quality.reworkRate.comparison.trend === 'down' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.quality.reworkRate.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">First Time Right</h4>
            <TrendingUp className="h-6 w-6 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.quality.firstTimeRight.value.toFixed(1)}%
          </div>
          <div className="flex items-center">
            {data.quality.firstTimeRight.comparison.trend === 'up' ? (
              <ArrowUp className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowDown className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.quality.firstTimeRight.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.quality.firstTimeRight.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
        </div>
      </div>

      {/* Team Utilization */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Team Utilization</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data.resources.teamUtilization}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="teamName" />
            <YAxis />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="utilization" fill="#3B82F6" name="Utilization %" />
            <Bar dataKey="efficiency" fill="#10B981" name="Efficiency %" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Timeline Performance */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">On-Time Delivery</h4>
            <Clock className="h-6 w-6 text-green-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.timeline.onTimeDelivery.value.toFixed(1)}%
          </div>
          <div className="flex items-center">
            {data.timeline.onTimeDelivery.comparison.trend === 'up' ? (
              <ArrowUp className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowDown className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.timeline.onTimeDelivery.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.timeline.onTimeDelivery.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
          {data.timeline.onTimeDelivery.target && (
            <div className="mt-4">
              <div className="flex justify-between text-xs text-gray-600 mb-1">
                <span>Target Progress</span>
                <span>{data.timeline.onTimeDelivery.targetPercentage?.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-green-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(data.timeline.onTimeDelivery.targetPercentage || 0, 100)}%` }}
                />
              </div>
            </div>
          )}
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Average Delay</h4>
            <Clock className="h-6 w-6 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.timeline.averageDelay.value.toFixed(1)} days
          </div>
          <div className="flex items-center">
            {data.timeline.averageDelay.comparison.trend === 'down' ? (
              <ArrowDown className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowUp className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.timeline.averageDelay.comparison.trend === 'down' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.timeline.averageDelay.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Schedule Adherence</h4>
            <Target className="h-6 w-6 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.timeline.scheduleAdherence.value.toFixed(1)}%
          </div>
          <div className="flex items-center">
            {data.timeline.scheduleAdherence.comparison.trend === 'up' ? (
              <ArrowUp className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowDown className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.timeline.scheduleAdherence.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.timeline.scheduleAdherence.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
        </div>
      </div>

      {/* Resource Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Equipment Uptime</h4>
            <Wrench className="h-6 w-6 text-green-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.resources.equipmentUptime.value.toFixed(1)}%
          </div>
          <div className="flex items-center">
            {data.resources.equipmentUptime.comparison.trend === 'up' ? (
              <ArrowUp className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowDown className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.resources.equipmentUptime.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.resources.equipmentUptime.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Material Waste</h4>
            <TrendingUp className="h-6 w-6 text-red-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.resources.materialWaste.value.toFixed(1)}%
          </div>
          <div className="flex items-center">
            {data.resources.materialWaste.comparison.trend === 'down' ? (
              <ArrowDown className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowUp className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.resources.materialWaste.comparison.trend === 'down' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.resources.materialWaste.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};