import React from 'react';
import { DollarSign, TrendingUp, Users, Target, ArrowUp, ArrowDown, Award } from 'lucide-react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { formatCurrency } from '../../lib/utils';
import type { SalesPerformanceData, TimePeriod } from '../../types/performance';

interface SalesMetricsProps {
  data: SalesPerformanceData | null;
  timePeriod: TimePeriod;
}

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

export const SalesMetrics: React.FC<SalesMetricsProps> = ({ data, timePeriod }) => {
  if (!data) {
    return (
      <div className="space-y-6">
        <div className="h-64 bg-gray-200 rounded-lg animate-pulse" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-32 bg-gray-200 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium text-gray-900">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }}>
              {entry.name}: {
                entry.name.toLowerCase().includes('revenue') || entry.name.toLowerCase().includes('deal')
                  ? formatCurrency(entry.value)
                  : entry.value.toLocaleString()
              }
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900">Sales Performance</h2>
        <p className="text-gray-600">Revenue metrics, pipeline analysis, and team performance</p>
      </div>

      {/* Revenue Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Revenue</p>
              <p className="text-2xl font-bold text-gray-900">
                {formatCurrency(data.revenue.total.value)}
              </p>
              <div className="flex items-center mt-2">
                {data.revenue.total.comparison.trend === 'up' ? (
                  <ArrowUp className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowDown className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.revenue.total.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.revenue.total.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <DollarSign className="h-8 w-8 text-blue-600" />
          </div>
          {data.revenue.total.target && (
            <div className="mt-4">
              <div className="flex justify-between text-xs text-gray-600 mb-1">
                <span>Target Progress</span>
                <span>{data.revenue.total.targetPercentage?.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(data.revenue.total.targetPercentage || 0, 100)}%` }}
                />
              </div>
            </div>
          )}
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Average Deal Size</p>
              <p className="text-2xl font-bold text-gray-900">
                {formatCurrency(data.revenue.averageDealSize.value)}
              </p>
              <div className="flex items-center mt-2">
                {data.revenue.averageDealSize.comparison.trend === 'up' ? (
                  <ArrowUp className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowDown className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.revenue.averageDealSize.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.revenue.averageDealSize.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <Target className="h-8 w-8 text-green-600" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Conversion Rate</p>
              <p className="text-2xl font-bold text-gray-900">
                {data.pipeline.conversionRate.value.toFixed(1)}%
              </p>
              <div className="flex items-center mt-2">
                {data.pipeline.conversionRate.comparison.trend === 'up' ? (
                  <ArrowUp className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowDown className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.pipeline.conversionRate.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.pipeline.conversionRate.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <TrendingUp className="h-8 w-8 text-purple-600" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Pipeline Value</p>
              <p className="text-2xl font-bold text-gray-900">
                {formatCurrency(data.pipeline.totalValue.value)}
              </p>
              <div className="flex items-center mt-2">
                {data.pipeline.totalValue.comparison.trend === 'up' ? (
                  <ArrowUp className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowDown className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.pipeline.totalValue.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.pipeline.totalValue.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <Users className="h-8 w-8 text-amber-600" />
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Breakdown */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Revenue Breakdown</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={[
                  { name: 'Recurring Revenue', value: data.revenue.recurring.value },
                  { name: 'New Business', value: data.revenue.newBusiness.value }
                ]}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {[0, 1].map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => formatCurrency(value as number)} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Team Performance */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Performers</h3>
          <div className="space-y-4">
            {data.team.topPerformers.map((performer, index) => (
              <div key={performer.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="flex items-center justify-center w-8 h-8 bg-blue-100 rounded-full">
                    <span className="text-sm font-medium text-blue-800">#{index + 1}</span>
                  </div>
                  <div>
                    <div className="font-medium text-gray-900">{performer.name}</div>
                    <div className="text-sm text-gray-600">{performer.deals} deals</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-gray-900">{formatCurrency(performer.revenue)}</div>
                  <div className="text-sm text-green-600">{performer.performance.toFixed(1)}% of quota</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quota Attainment */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Quota Attainment</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data.team.quotaAttainment}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="achieved" fill="#3B82F6" name="Achieved" />
            <Bar dataKey="quota" fill="#E5E7EB" name="Quota" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Customer Acquisition Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Customer Acquisition Cost</h4>
            <Award className="h-6 w-6 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {formatCurrency(data.customerAcquisition.cost.value)}
          </div>
          <div className="flex items-center">
            {data.customerAcquisition.cost.comparison.trend === 'down' ? (
              <ArrowDown className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowUp className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.customerAcquisition.cost.comparison.trend === 'down' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.customerAcquisition.cost.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Customer Lifetime Value</h4>
            <TrendingUp className="h-6 w-6 text-green-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {formatCurrency(data.customerAcquisition.lifetime.value)}
          </div>
          <div className="flex items-center">
            {data.customerAcquisition.lifetime.comparison.trend === 'up' ? (
              <ArrowUp className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowDown className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.customerAcquisition.lifetime.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.customerAcquisition.lifetime.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Churn Rate</h4>
            <Users className="h-6 w-6 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.customerAcquisition.churnRate.value.toFixed(1)}%
          </div>
          <div className="flex items-center">
            {data.customerAcquisition.churnRate.comparison.trend === 'down' ? (
              <ArrowDown className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowUp className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.customerAcquisition.churnRate.comparison.trend === 'down' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.customerAcquisition.churnRate.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};