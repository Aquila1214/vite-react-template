import React from 'react';
import { Megaphone, TrendingUp, Users, Eye, Mail, ArrowUp, ArrowDown } from 'lucide-react';
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { formatCurrency } from '../../lib/utils';
import type { MarketingPerformanceData, TimePeriod } from '../../types/performance';

interface MarketingMetricsProps {
  data: MarketingPerformanceData | null;
  timePeriod: TimePeriod;
}

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

export const MarketingMetrics: React.FC<MarketingMetricsProps> = ({ data, timePeriod }) => {
  if (!data) {
    return (
      <div className="space-y-6">
        <div className="h-64 bg-gray-200 rounded-lg animate-pulse" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-32 bg-gray-200 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium text-gray-900">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }}>
              {entry.name}: {
                entry.name.toLowerCase().includes('roi') || entry.name.toLowerCase().includes('revenue')
                  ? formatCurrency(entry.value)
                  : entry.value.toLocaleString()
              }
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900">Marketing Performance</h2>
        <p className="text-gray-600">Campaign performance, lead generation, and engagement metrics</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Leads</p>
              <p className="text-2xl font-bold text-gray-900">
                {data.leadGeneration.totalLeads.value.toLocaleString()}
              </p>
              <div className="flex items-center mt-2">
                {data.leadGeneration.totalLeads.comparison.trend === 'up' ? (
                  <ArrowUp className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowDown className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.leadGeneration.totalLeads.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.leadGeneration.totalLeads.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <Users className="h-8 w-8 text-blue-600" />
          </div>
          {data.leadGeneration.totalLeads.target && (
            <div className="mt-4">
              <div className="flex justify-between text-xs text-gray-600 mb-1">
                <span>Target Progress</span>
                <span>{data.leadGeneration.totalLeads.targetPercentage?.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(data.leadGeneration.totalLeads.targetPercentage || 0, 100)}%` }}
                />
              </div>
            </div>
          )}
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Cost per Lead</p>
              <p className="text-2xl font-bold text-gray-900">
                {formatCurrency(data.leadGeneration.costPerLead.value)}
              </p>
              <div className="flex items-center mt-2">
                {data.leadGeneration.costPerLead.comparison.trend === 'down' ? (
                  <ArrowDown className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowUp className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.leadGeneration.costPerLead.comparison.trend === 'down' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.leadGeneration.costPerLead.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <Megaphone className="h-8 w-8 text-green-600" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Website Traffic</p>
              <p className="text-2xl font-bold text-gray-900">
                {data.engagement.websiteTraffic.value.toLocaleString()}
              </p>
              <div className="flex items-center mt-2">
                {data.engagement.websiteTraffic.comparison.trend === 'up' ? (
                  <ArrowUp className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowDown className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.engagement.websiteTraffic.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.engagement.websiteTraffic.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <Eye className="h-8 w-8 text-purple-600" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Average ROI</p>
              <p className="text-2xl font-bold text-gray-900">
                {data.campaigns.averageROI.value.toFixed(1)}x
              </p>
              <div className="flex items-center mt-2">
                {data.campaigns.averageROI.comparison.trend === 'up' ? (
                  <ArrowUp className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowDown className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.campaigns.averageROI.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.campaigns.averageROI.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <TrendingUp className="h-8 w-8 text-amber-600" />
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Lead Generation by Channel */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Leads by Channel</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data.leadGeneration.leadsByChannel}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="channel" />
              <YAxis />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="leads" fill="#3B82F6" name="Leads" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Campaign Performance */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Performing Campaigns</h3>
          <div className="space-y-4">
            {data.campaigns.topPerforming.map((campaign, index) => (
              <div key={campaign.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="flex items-center justify-center w-8 h-8 bg-blue-100 rounded-full">
                    <span className="text-sm font-medium text-blue-800">#{index + 1}</span>
                  </div>
                  <div>
                    <div className="font-medium text-gray-900">{campaign.name}</div>
                    <div className="text-sm text-gray-600">{campaign.leads} leads</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-gray-900">{formatCurrency(campaign.spend)}</div>
                  <div className="text-sm text-green-600">{campaign.roi.toFixed(1)}x ROI</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Engagement Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Conversion Rate</h4>
            <TrendingUp className="h-6 w-6 text-green-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.engagement.conversionRate.value.toFixed(2)}%
          </div>
          <div className="flex items-center">
            {data.engagement.conversionRate.comparison.trend === 'up' ? (
              <ArrowUp className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowDown className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.engagement.conversionRate.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.engagement.conversionRate.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Email Open Rate</h4>
            <Mail className="h-6 w-6 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.engagement.emailOpenRate.value.toFixed(1)}%
          </div>
          <div className="flex items-center">
            {data.engagement.emailOpenRate.comparison.trend === 'up' ? (
              <ArrowUp className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowDown className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.engagement.emailOpenRate.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.engagement.emailOpenRate.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Social Engagement</h4>
            <Users className="h-6 w-6 text-purple-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.engagement.socialEngagement.value.toFixed(1)}%
          </div>
          <div className="flex items-center">
            {data.engagement.socialEngagement.comparison.trend === 'up' ? (
              <ArrowUp className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowDown className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.engagement.socialEngagement.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.engagement.socialEngagement.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Brand Awareness</h4>
            <Eye className="h-6 w-6 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.brand.awareness.value.toFixed(1)}%
          </div>
          <div className="flex items-center">
            {data.brand.awareness.comparison.trend === 'up' ? (
              <ArrowUp className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowDown className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.brand.awareness.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.brand.awareness.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
        </div>
      </div>

      {/* Channel Performance Details */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Channel Performance Details</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Channel
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Leads
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Cost
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Cost per Lead
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Quality Score
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {data.leadGeneration.leadsByChannel.map((channel, index) => (
                <tr key={channel.channel} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div 
                        className="w-3 h-3 rounded-full mr-3"
                        style={{ backgroundColor: COLORS[index % COLORS.length] }}
                      />
                      <span className="text-sm font-medium text-gray-900">{channel.channel}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {channel.leads}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {formatCurrency(channel.cost)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {formatCurrency(channel.cost / channel.leads)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="text-sm text-gray-900 mr-2">
                        {channel.quality.toFixed(1)}/10
                      </div>
                      <div className="w-16 bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full"
                          style={{ width: `${(channel.quality / 10) * 100}%` }}
                        />
                      </div>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Brand Performance */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Brand Sentiment</h4>
            <TrendingUp className="h-6 w-6 text-green-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.brand.sentiment.value.toFixed(1)}/5.0
          </div>
          <div className="flex items-center">
            {data.brand.sentiment.comparison.trend === 'up' ? (
              <ArrowUp className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowDown className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.brand.sentiment.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.brand.sentiment.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Share of Voice</h4>
            <Megaphone className="h-6 w-6 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.brand.shareOfVoice.value.toFixed(1)}%
          </div>
          <div className="flex items-center">
            {data.brand.shareOfVoice.comparison.trend === 'up' ? (
              <ArrowUp className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowDown className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.brand.shareOfVoice.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.brand.shareOfVoice.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Active Campaigns</h4>
            <Users className="h-6 w-6 text-purple-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.campaigns.active}
          </div>
          <div className="text-sm text-gray-600">
            Total spend: {formatCurrency(data.campaigns.totalSpend.value)}
          </div>
        </div>
      </div>
    </div>
  );
};