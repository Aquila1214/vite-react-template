import React from 'react';
import { TrendingUp, TrendingDown, Users, DollarSign, Building, Target, ArrowUp, ArrowDown } from 'lucide-react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { formatCurrency } from '../../lib/utils';
import type { OverviewPerformanceData, TimePeriod } from '../../types/performance';

interface OverviewMetricsProps {
  data: OverviewPerformanceData | null;
  timePeriod: TimePeriod;
}

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444'];

export const OverviewMetrics: React.FC<OverviewMetricsProps> = ({ data, timePeriod }) => {
  if (!data) {
    return (
      <div className="space-y-6">
        <div className="h-64 bg-gray-200 rounded-lg animate-pulse" />
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-32 bg-gray-200 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium text-gray-900">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }}>
              {entry.name}: {
                entry.name.toLowerCase().includes('revenue')
                  ? formatCurrency(entry.value)
                  : entry.value.toLocaleString()
              }
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const departmentData = [
    { name: 'Sales', performance: data.departmentSummary.sales.performance, target: 100 },
    { name: 'Operations', performance: data.departmentSummary.operations.performance, target: 100 },
    { name: 'Marketing', performance: data.departmentSummary.marketing.performance, target: 100 },
    { name: 'Finance', performance: data.departmentSummary.finance.performance, target: 100 },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900">Company Overview</h2>
        <p className="text-gray-600">High-level performance metrics across all departments</p>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Revenue</p>
              <p className="text-2xl font-bold text-gray-900">
                {formatCurrency(data.companyMetrics.totalRevenue.value)}
              </p>
              <div className="flex items-center mt-2">
                {data.companyMetrics.totalRevenue.comparison.trend === 'up' ? (
                  <ArrowUp className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowDown className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.companyMetrics.totalRevenue.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.companyMetrics.totalRevenue.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <DollarSign className="h-8 w-8 text-blue-600" />
          </div>
          {data.companyMetrics.totalRevenue.target && (
            <div className="mt-4">
              <div className="flex justify-between text-xs text-gray-600 mb-1">
                <span>Target Progress</span>
                <span>{data.companyMetrics.totalRevenue.targetPercentage?.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(data.companyMetrics.totalRevenue.targetPercentage || 0, 100)}%` }}
                />
              </div>
            </div>
          )}
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Customers</p>
              <p className="text-2xl font-bold text-gray-900">
                {data.companyMetrics.totalCustomers.value.toLocaleString()}
              </p>
              <div className="flex items-center mt-2">
                {data.companyMetrics.totalCustomers.comparison.trend === 'up' ? (
                  <ArrowUp className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowDown className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.companyMetrics.totalCustomers.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.companyMetrics.totalCustomers.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <Users className="h-8 w-8 text-green-600" />
          </div>
          {data.companyMetrics.totalCustomers.target && (
            <div className="mt-4">
              <div className="flex justify-between text-xs text-gray-600 mb-1">
                <span>Target Progress</span>
                <span>{data.companyMetrics.totalCustomers.targetPercentage?.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-green-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(data.companyMetrics.totalCustomers.targetPercentage || 0, 100)}%` }}
                />
              </div>
            </div>
          )}
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Employee Count</p>
              <p className="text-2xl font-bold text-gray-900">
                {data.companyMetrics.employeeCount.value}
              </p>
              <div className="flex items-center mt-2">
                {data.companyMetrics.employeeCount.comparison.trend === 'up' ? (
                  <ArrowUp className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowDown className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.companyMetrics.employeeCount.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.companyMetrics.employeeCount.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <Building className="h-8 w-8 text-purple-600" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Operating Margin</p>
              <p className="text-2xl font-bold text-gray-900">
                {data.companyMetrics.operatingMargin.value.toFixed(1)}%
              </p>
              <div className="flex items-center mt-2">
                {data.companyMetrics.operatingMargin.comparison.trend === 'up' ? (
                  <ArrowUp className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowDown className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.companyMetrics.operatingMargin.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.companyMetrics.operatingMargin.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <Target className="h-8 w-8 text-amber-600" />
          </div>
          {data.companyMetrics.operatingMargin.target && (
            <div className="mt-4">
              <div className="flex justify-between text-xs text-gray-600 mb-1">
                <span>Target Progress</span>
                <span>{data.companyMetrics.operatingMargin.targetPercentage?.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-amber-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(data.companyMetrics.operatingMargin.targetPercentage || 0, 100)}%` }}
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Trends Chart */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance Trends</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={data.trends}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip content={<CustomTooltip />} />
              <Line yAxisId="right" type="monotone" dataKey="revenue" stroke="#3B82F6" strokeWidth={2} name="Revenue" />
              <Line yAxisId="left" type="monotone" dataKey="customers" stroke="#10B981" strokeWidth={2} name="Customers" />
              <Line yAxisId="left" type="monotone" dataKey="efficiency" stroke="#F59E0B" strokeWidth={2} name="Efficiency" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Department Performance */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Department Performance vs Target</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={departmentData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="performance" fill="#3B82F6" name="Performance %" />
              <Bar dataKey="target" fill="#E5E7EB" name="Target %" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Department Summary */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Department Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600 mb-1">
              {formatCurrency(data.departmentSummary.sales.revenue)}
            </div>
            <div className="text-sm text-gray-600 mb-2">Sales Revenue</div>
            <div className="text-xs text-gray-500">
              {data.departmentSummary.sales.performance.toFixed(1)}% of target
            </div>
          </div>
          
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600 mb-1">
              {data.departmentSummary.operations.efficiency.toFixed(1)}%
            </div>
            <div className="text-sm text-gray-600 mb-2">Operations Efficiency</div>
            <div className="text-xs text-gray-500">
              {data.departmentSummary.operations.performance.toFixed(1)}% of target
            </div>
          </div>
          
          <div className="text-center">
            <div className="text-2xl font-bold text-amber-600 mb-1">
              {data.departmentSummary.marketing.leads}
            </div>
            <div className="text-sm text-gray-600 mb-2">Marketing Leads</div>
            <div className="text-xs text-gray-500">
              {data.departmentSummary.marketing.performance.toFixed(1)}% of target
            </div>
          </div>
          
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600 mb-1">
              {data.departmentSummary.finance.margin.toFixed(1)}%
            </div>
            <div className="text-sm text-gray-600 mb-2">Finance Margin</div>
            <div className="text-xs text-gray-500">
              {data.departmentSummary.finance.performance.toFixed(1)}% of target
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};