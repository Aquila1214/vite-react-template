import React from 'react';
import { Calculator, TrendingUp, TrendingDown, DollarSign, PieChart, BarChart3, ArrowUp, ArrowDown } from 'lucide-react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart as RechartsPieChart, Pie, Cell } from 'recharts';
import { formatCurrency } from '../../lib/utils';
import type { FinancePerformanceData, TimePeriod } from '../../types/performance';

interface FinanceMetricsProps {
  data: FinancePerformanceData | null;
  timePeriod: TimePeriod;
}

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

export const FinanceMetrics: React.FC<FinanceMetricsProps> = ({ data, timePeriod }) => {
  if (!data) {
    return (
      <div className="space-y-6">
        <div className="h-64 bg-gray-200 rounded-lg animate-pulse" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-32 bg-gray-200 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium text-gray-900">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }}>
              {entry.name}: {formatCurrency(entry.value)}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const budgetVarianceData = data.budgetAnalysis.departmentBreakdown.map(dept => ({
    ...dept,
    varianceAmount: dept.variance
  }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900">Finance Performance</h2>
        <p className="text-gray-600">P&L overview, cash flow analysis, and financial forecasts</p>
      </div>

      {/* P&L Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Revenue</p>
              <p className="text-2xl font-bold text-gray-900">
                {formatCurrency(data.profitLoss.revenue.value)}
              </p>
              <div className="flex items-center mt-2">
                {data.profitLoss.revenue.comparison.trend === 'up' ? (
                  <ArrowUp className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowDown className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.profitLoss.revenue.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.profitLoss.revenue.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <DollarSign className="h-8 w-8 text-blue-600" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Gross Profit</p>
              <p className="text-2xl font-bold text-gray-900">
                {formatCurrency(data.profitLoss.grossProfit.value)}
              </p>
              <div className="flex items-center mt-2">
                {data.profitLoss.grossProfit.comparison.trend === 'up' ? (
                  <ArrowUp className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowDown className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.profitLoss.grossProfit.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.profitLoss.grossProfit.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <TrendingUp className="h-8 w-8 text-green-600" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Operating Income</p>
              <p className="text-2xl font-bold text-gray-900">
                {formatCurrency(data.profitLoss.operatingIncome.value)}
              </p>
              <div className="flex items-center mt-2">
                {data.profitLoss.operatingIncome.comparison.trend === 'up' ? (
                  <ArrowUp className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowDown className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.profitLoss.operatingIncome.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.profitLoss.operatingIncome.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <Calculator className="h-8 w-8 text-purple-600" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Net Income</p>
              <p className="text-2xl font-bold text-gray-900">
                {formatCurrency(data.profitLoss.netIncome.value)}
              </p>
              <div className="flex items-center mt-2">
                {data.profitLoss.netIncome.comparison.trend === 'up' ? (
                  <ArrowUp className="h-4 w-4 text-green-600" />
                ) : (
                  <ArrowDown className="h-4 w-4 text-red-600" />
                )}
                <span className={`text-sm ml-1 ${
                  data.profitLoss.netIncome.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {Math.abs(data.profitLoss.netIncome.comparison.changePercentage).toFixed(1)}%
                </span>
              </div>
            </div>
            <BarChart3 className="h-8 w-8 text-amber-600" />
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Cash Flow */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Cash Flow Analysis</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={[
              { name: 'Operating', value: data.cashFlow.operating.value },
              { name: 'Investing', value: data.cashFlow.investing.value },
              { name: 'Financing', value: data.cashFlow.financing.value },
              { name: 'Free Cash Flow', value: data.cashFlow.freeCashFlow.value }
            ]}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="value" fill="#3B82F6" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Budget vs Actual */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Budget vs Actual by Department</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={budgetVarianceData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="department" />
              <YAxis />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="budget" fill="#E5E7EB" name="Budget" />
              <Bar dataKey="actual" fill="#3B82F6" name="Actual" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Gross Margin</h4>
            <TrendingUp className="h-6 w-6 text-green-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.kpis.grossMargin.value.toFixed(1)}%
          </div>
          <div className="flex items-center">
            {data.kpis.grossMargin.comparison.trend === 'up' ? (
              <ArrowUp className="h-4 w-4 text-green-600" />
            ) : data.kpis.grossMargin.comparison.trend === 'down' ? (
              <ArrowDown className="h-4 w-4 text-red-600" />
            ) : (
              <div className="h-4 w-4" />
            )}
            <span className={`text-sm ml-1 ${
              data.kpis.grossMargin.comparison.trend === 'up' ? 'text-green-600' : 
              data.kpis.grossMargin.comparison.trend === 'down' ? 'text-red-600' : 'text-gray-600'
            }`}>
              {data.kpis.grossMargin.comparison.trend === 'neutral' ? 'No change' : 
               `${Math.abs(data.kpis.grossMargin.comparison.changePercentage).toFixed(1)}%`}
            </span>
          </div>
          {data.kpis.grossMargin.target && (
            <div className="mt-4">
              <div className="flex justify-between text-xs text-gray-600 mb-1">
                <span>Target Progress</span>
                <span>{data.kpis.grossMargin.targetPercentage?.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-green-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(data.kpis.grossMargin.targetPercentage || 0, 100)}%` }}
                />
              </div>
            </div>
          )}
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Operating Margin</h4>
            <Calculator className="h-6 w-6 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.kpis.operatingMargin.value.toFixed(1)}%
          </div>
          <div className="flex items-center">
            {data.kpis.operatingMargin.comparison.trend === 'up' ? (
              <ArrowUp className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowDown className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.kpis.operatingMargin.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.kpis.operatingMargin.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
          {data.kpis.operatingMargin.target && (
            <div className="mt-4">
              <div className="flex justify-between text-xs text-gray-600 mb-1">
                <span>Target Progress</span>
                <span>{data.kpis.operatingMargin.targetPercentage?.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(data.kpis.operatingMargin.targetPercentage || 0, 100)}%` }}
                />
              </div>
            </div>
          )}
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Current Ratio</h4>
            <PieChart className="h-6 w-6 text-purple-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.kpis.currentRatio.value.toFixed(1)}
          </div>
          <div className="flex items-center">
            {data.kpis.currentRatio.comparison.trend === 'up' ? (
              <ArrowUp className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowDown className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.kpis.currentRatio.comparison.trend === 'up' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.kpis.currentRatio.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium text-gray-900">Debt to Equity</h4>
            <BarChart3 className="h-6 w-6 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-2">
            {data.kpis.debtToEquity.value.toFixed(2)}
          </div>
          <div className="flex items-center">
            {data.kpis.debtToEquity.comparison.trend === 'down' ? (
              <ArrowDown className="h-4 w-4 text-green-600" />
            ) : (
              <ArrowUp className="h-4 w-4 text-red-600" />
            )}
            <span className={`text-sm ml-1 ${
              data.kpis.debtToEquity.comparison.trend === 'down' ? 'text-green-600' : 'text-red-600'
            }`}>
              {Math.abs(data.kpis.debtToEquity.comparison.changePercentage).toFixed(1)}%
            </span>
          </div>
        </div>
      </div>

      {/* Budget Analysis */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Budget Analysis</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900 mb-1">
              {formatCurrency(data.budgetAnalysis.totalBudget)}
            </div>
            <div className="text-sm text-gray-600">Total Budget</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900 mb-1">
              {formatCurrency(data.budgetAnalysis.actualSpend)}
            </div>
            <div className="text-sm text-gray-600">Actual Spend</div>
          </div>
          <div className="text-center">
            <div className={`text-2xl font-bold mb-1 ${
              data.budgetAnalysis.variance >= 0 ? 'text-green-600' : 'text-red-600'
            }`}>
              {formatCurrency(Math.abs(data.budgetAnalysis.variance))}
            </div>
            <div className="text-sm text-gray-600">
              {data.budgetAnalysis.variance >= 0 ? 'Under Budget' : 'Over Budget'}
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Department
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Budget
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actual
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Variance
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Variance %
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {data.budgetAnalysis.departmentBreakdown.map((dept) => (
                <tr key={dept.department} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {dept.department}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {formatCurrency(dept.budget)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {formatCurrency(dept.actual)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span className={dept.variance >= 0 ? 'text-green-600' : 'text-red-600'}>
                      {dept.variance >= 0 ? '+' : ''}{formatCurrency(dept.variance)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span className={dept.variancePercentage >= 0 ? 'text-green-600' : 'text-red-600'}>
                      {dept.variancePercentage >= 0 ? '+' : ''}{dept.variancePercentage.toFixed(1)}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Forecasts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Forecast */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Quarterly Revenue Forecast</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={data.forecasts.quarterlyRevenue}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="quarter" />
              <YAxis />
              <Tooltip content={<CustomTooltip />} />
              <Line type="monotone" dataKey="forecast" stroke="#3B82F6" strokeWidth={2} name="Forecast" />
              <Line type="monotone" dataKey="actual" stroke="#10B981" strokeWidth={2} name="Actual" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Expense Forecast */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Expense Projections</h3>
          <div className="space-y-4">
            {data.forecasts.expenses.map((expense) => (
              <div key={expense.category} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <div className="font-medium text-gray-900">{expense.category}</div>
                  <div className="text-sm text-gray-600">
                    Current: {formatCurrency(expense.current)}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-gray-900">
                    {formatCurrency(expense.projected)}
                  </div>
                  <div className="flex items-center text-sm">
                    {expense.trend === 'up' ? (
                      <ArrowUp className="h-3 w-3 text-red-600 mr-1" />
                    ) : expense.trend === 'down' ? (
                      <ArrowDown className="h-3 w-3 text-green-600 mr-1" />
                    ) : (
                      <div className="h-3 w-3 mr-1" />
                    )}
                    <span className={
                      expense.trend === 'up' ? 'text-red-600' : 
                      expense.trend === 'down' ? 'text-green-600' : 'text-gray-600'
                    }>
                      {expense.trend === 'stable' ? 'Stable' : `${expense.trend === 'up' ? '+' : '-'}${Math.abs(((expense.projected - expense.current) / expense.current) * 100).toFixed(1)}%`}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};