import React, { useState, useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { PipelineStage } from '../../types';
import { formatCurrency, formatPhone } from '../../lib/utils';
import { Clock, User, Tag, ChevronRight, MoreVertical, Edit, Trash2, CheckSquare, Calendar, AlertTriangle, ArrowRight, Briefcase, X, Plus, Phone, Mail, Star } from 'lucide-react';
import { Lead } from '../../types';
import { formatDate, getStatusColor, getPriorityIcon } from '../../lib/utils';
import { useCrmStore } from '../../stores/crmStore';

interface LeadsPipelineProps {
  leads: Lead[];
  pipeline: PipelineStage[];
  onLeadClick: (lead: Lead) => void;
  onStatusChange: (leadId: string, newStatus: Lead['status']) => void;
}

const statusOrder: Lead['status'][] = ['NEW', 'CONTACTED', 'QUALIFIED', 'ESTIMATE_SENT', 'CONVERTED', 'LOST'];

const statusLabels: Record<Lead['status'], string> = {
  NEW: 'New Leads',
  CONTACTED: 'Contacted',
  QUALIFIED: 'Qualified',
  ESTIMATE_SENT: 'Estimate Sent',
  CONVERTED: 'Converted',
  LOST: 'Lost',
};

export const LeadsPipeline: React.FC<LeadsPipelineProps> = ({
  leads,
  pipeline,
  onLeadClick,
  onStatusChange,
}) => {
  const { users } = useCrmStore();
  const [selectedStatus, setSelectedStatus] = useState<Lead['status'] | 'ALL'>('ALL');
  const [draggedLead, setDraggedLead] = useState<Lead | null>(null);
  const [dragOverStatus, setDragOverStatus] = useState<string | null>(null);

  // Filter leads based on selected status
  const filteredLeads = selectedStatus === 'ALL' 
    ? leads 
    : leads.filter(lead => lead.status === selectedStatus);

  // Group leads by status
  const leadsByStatus = useMemo(() => {
    return filteredLeads.reduce((acc, lead) => {
      if (!acc[lead.status]) {
        acc[lead.status] = [];
      }
      acc[lead.status].push(lead);
      return acc;
    }, {} as Record<Lead['status'], Lead[]>);
  }, [filteredLeads]);

  const getAssigneeName = (userId?: string) => {
    if (!userId) return 'Unassigned';
    const user = users.find(u => u.id === userId);
    return user ? user.name : 'Unknown';
  };

  const handleDragStart = (e: React.DragEvent, lead: Lead) => {
    setDraggedLead(lead);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', lead.id);
    
    // Create a ghost image that's less visible
    const ghostElement = document.createElement('div');
    ghostElement.textContent = lead.customer?.name || 'Lead';
    ghostElement.style.opacity = '0.5';
    ghostElement.style.position = 'absolute';
    ghostElement.style.top = '-1000px';
    document.body.appendChild(ghostElement);
    
    e.dataTransfer.setDragImage(ghostElement, 0, 0);
    
    // Clean up the ghost element after drag starts
    setTimeout(() => {
      document.body.removeChild(ghostElement);
    }, 0);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    
    // Add visual feedback for the drop target
    const target = e.currentTarget as HTMLElement;
    const status = target.getAttribute('data-status');
    
    if (status && status !== dragOverStatus) {
      setDragOverStatus(status);
      
      // Remove highlight from all other stages
      document.querySelectorAll('.lead-stage').forEach(el => {
        if (el !== target) {
          el.classList.remove('bg-blue-50', 'border-blue-300');
        }
      });
      
      // Add highlight to current stage
      target.classList.add('bg-blue-50', 'border-blue-300');
    }
  };

  const handleDragLeave = (e: React.DragEvent) => {
    const target = e.currentTarget as HTMLElement;
    
    // Only remove highlight if we're leaving the element (not entering a child)
    if (!target.contains(e.relatedTarget as Node)) {
      target.classList.remove('bg-blue-50', 'border-blue-300');
    }
  };

  const handleDrop = (e: React.DragEvent, newStatus: Lead['status']) => {
    e.preventDefault();
    e.stopPropagation();
    
    // Reset drag state
    setDragOverStatus(null);
    
    // Remove any lingering highlights
    document.querySelectorAll('.lead-stage').forEach(el => {
      el.classList.remove('bg-blue-50', 'border-blue-300');
    });
    
    if (!draggedLead) return;
    
    if (draggedLead.status !== newStatus) {
      // Add a small delay to improve visual feedback
      setTimeout(() => {
        onStatusChange(draggedLead.id, newStatus);
      }, 100);
    }
    
    setDraggedLead(null);
  };

  const getPipelineStageData = (status: Lead['status']) => {
    return pipeline.find(stage => stage.status === status) || { status, count: 0, value: 0 };
  };

  return (
    <div className="space-y-6">
      {/* Pipeline Overview */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Sales Pipeline</h3>
          <div className="flex items-center space-x-2">
            <div className="text-sm text-gray-600">
              {filteredLeads.length} leads • {formatCurrency(filteredLeads.reduce((sum, lead) => {
                const stageData = getPipelineStageData(lead.status);
                return sum + (stageData.value / stageData.count || 0);
              }, 0))} estimated value
            </div>
          </div>
        </div>

        {/* Pipeline Stats */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
          {statusOrder.map((status, index) => {
            const stageData = getPipelineStageData(status);
            const isActive = selectedStatus === status || selectedStatus === 'ALL';
            
            return (
              <div
                key={status}
                className={`relative p-4 rounded-lg border-2 transition-all duration-200 cursor-pointer ${
                  isActive 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-gray-200 bg-white hover:border-gray-300'
                }`}
                onClick={() => setSelectedStatus(selectedStatus === status ? 'ALL' : status)}
              >
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-900">
                    {stageData.count}
                  </div>
                  <div className="text-sm font-medium text-gray-600 mb-1">
                    {statusLabels[status]}
                  </div>
                  {stageData.value > 0 && (
                    <div className="text-xs text-gray-500">
                      {formatCurrency(stageData.value)}
                    </div>
                  )}
                </div>
                
                {/* Arrow connector */}
                {index < statusOrder.length - 1 && (
                  <ChevronRight className="absolute -right-3 top-1/2 transform -translate-y-1/2 h-6 w-6 text-gray-400 bg-white rounded-full border border-gray-200" />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Pipeline Board */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">
            Pipeline Board
            <span className="ml-2 text-sm font-normal text-gray-500">
              ({filteredLeads.length} leads)
            </span>
          </h3>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-6 gap-6">
            {statusOrder.map(status => {
              const statusLeads = leadsByStatus[status] || [];
              
              return (
                <div
                  key={status}
                  data-status={status}
                  className="lead-stage space-y-3 transition-colors duration-150 bg-gray-50 rounded-lg p-4 border border-gray-200"
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={(e) => handleDrop(e, status)}
                >
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium text-gray-900">
                      {statusLabels[status]}
                    </h4>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(status)}`}>
                      {statusLeads.length}
                    </span>
                  </div>
                  
                  <div className="space-y-2 min-h-[200px]">
                    {statusLeads.length > 0 ? (
                      statusLeads.map(lead => (
                        <div
                          key={lead.id}
                          draggable
                          onDragStart={(e) => handleDragStart(e, lead)}
                          onClick={() => onLeadClick(lead)}
                          className="p-3 bg-white rounded-lg border border-gray-200 hover:shadow-md transition-all duration-200 cursor-pointer group"
                        >
                          <div className="space-y-2">
                            <div className="flex items-start justify-between">
                              <h5 className="font-medium text-gray-900 text-sm group-hover:text-blue-600">
                                {lead.customer?.name}
                              </h5>
                              <div className="flex items-center space-x-1">
                                <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium ${getStatusColor(lead.priority)}`}>
                                  {lead.priority}
                                </span>
                                {lead.leadScore && lead.leadScore > 0 && (
                                  <span className="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-yellow-100 text-yellow-800">
                                    <Star className="h-3 w-3 mr-1" />
                                    {lead.leadScore}
                                  </span>
                                )}
                              </div>
                            </div>
                            
                            <div className="flex items-center text-xs text-gray-600">
                              <span className="font-medium">ID:</span>
                              <span className="ml-1">#{lead.id.slice(-6)}</span>
                            </div>
                            
                            {lead.customer?.phone && (
                              <div className="flex items-center text-xs text-gray-600">
                                <Phone className="h-3 w-3 mr-1" />
                                <span>{formatPhone(lead.customer.phone)}</span>
                              </div>
                            )}
                            
                            {lead.customer?.email && (
                              <div className="flex items-center text-xs text-gray-600">
                                <Mail className="h-3 w-3 mr-1" />
                                <span className="truncate">{lead.customer.email}</span>
                              </div>
                            )}
                            
                            {lead.assignedTo && (
                              <div className="flex items-center text-xs text-gray-600">
                                <User className="h-3 w-3 mr-1" />
                                <span>{getAssigneeName(lead.assignedTo)}</span>
                              </div>
                            )}
                            
                            <div className="flex items-center justify-between">
                              <span className="text-xs text-gray-500 capitalize">
                                {lead.source.toLowerCase()}
                              </span>
                              <span className="text-xs text-gray-500">
                                {formatDate(lead.createdAt)}
                              </span>
                            </div>
                            
                            {lead.notes && (
                              <div className="text-xs text-gray-600 line-clamp-2 italic">
                                "{lead.notes}"
                              </div>
                            )}
                            
                            {lead.tags && lead.tags.length > 0 && (
                              <div className="flex flex-wrap gap-1 mt-1">
                                {lead.tags.slice(0, 2).map(tag => (
                                  <span
                                    key={tag}
                                    className="inline-flex items-center px-1.5 py-0.5 rounded text-xs bg-blue-100 text-blue-800"
                                  >
                                    {tag}
                                  </span>
                                ))}
                                {lead.tags.length > 2 && (
                                  <span className="text-xs text-gray-500">
                                    +{lead.tags.length - 2}
                                  </span>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="flex flex-col items-center justify-center h-32 text-gray-400 text-sm">
                        <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center mb-2">
                          <Tag className="h-5 w-5 text-gray-400" />
                        </div>
                        <p>No leads in this stage</p>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};