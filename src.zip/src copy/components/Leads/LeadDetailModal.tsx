import React, { useState } from 'react';
import { X, User, Phone, Mail, MapPin, Tag, Calendar, Clock, Edit, Trash2, MessageSquare, Briefcase, CheckSquare, FileText, ExternalLink, ArrowRight, Building, Star } from 'lucide-react';
import { Lead } from '../../types';
import { formatDate, formatPhone, getPriorityIcon } from '../../lib/utils';
import { useCrmStore } from '../../stores/crmStore';
import { useLocationStore } from '../../stores/locationStore';

interface LeadDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  lead: Lead | null;
  onEdit: (lead: Lead) => void;
  onDelete: (id: string) => void;
}

export const LeadDetailModal: React.FC<LeadDetailModalProps> = ({
  isOpen,
  onClose,
  lead,
  onEdit,
  onDelete
}) => {
  const { users, customers } = useCrmStore();
  const { locations } = useLocationStore();
  const [activeTab, setActiveTab] = useState<'overview' | 'activity' | 'notes'>('overview');

  if (!isOpen || !lead) return null;

  const customer = lead.customer || customers.find(c => c.id === lead.customerId);
  const assignedUser = lead.assignedTo ? users.find(u => u.id === lead.assignedTo) : null;
  const location = lead.location || locations.find(l => l.id === lead.locationId);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'NEW': return 'bg-blue-100 text-blue-800';
      case 'CONTACTED': return 'bg-yellow-100 text-yellow-800';
      case 'QUALIFIED': return 'bg-green-100 text-green-800';
      case 'ESTIMATE_SENT': return 'bg-purple-100 text-purple-800';
      case 'CONVERTED': return 'bg-green-100 text-green-800';
      case 'LOST': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'LOW': return 'bg-gray-100 text-gray-800';
      case 'MEDIUM': return 'bg-blue-100 text-blue-800';
      case 'HIGH': return 'bg-orange-100 text-orange-800';
      case 'URGENT': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getSourceIcon = (source: string) => {
    switch (source) {
      case 'CALLRAIL': return <Phone className="h-4 w-4 text-blue-600" />;
      case 'FORM': return <FileText className="h-4 w-4 text-green-600" />;
      case 'REFERRAL': return <User className="h-4 w-4 text-purple-600" />;
      case 'DIRECT': return <ExternalLink className="h-4 w-4 text-amber-600" />;
      default: return <ExternalLink className="h-4 w-4 text-gray-600" />;
    }
  };

  const renderOverviewTab = () => (
    <div className="space-y-6">
      {/* Lead Information */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Customer Information */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
            <User className="h-5 w-5 text-gray-500 mr-2" />
            Customer Information
          </h3>
          
          {customer ? (
            <div className="space-y-3">
              <div className="text-lg font-semibold text-gray-900">{customer.name}</div>
              
              {customer.phone && (
                <div className="flex items-center text-gray-600">
                  <Phone className="h-4 w-4 text-gray-400 mr-2" />
                  <a href={`tel:${customer.phone}`} className="hover:text-blue-600">
                    {formatPhone(customer.phone)}
                  </a>
                </div>
              )}
              
              {customer.email && (
                <div className="flex items-center text-gray-600">
                  <Mail className="h-4 w-4 text-gray-400 mr-2" />
                  <a href={`mailto:${customer.email}`} className="hover:text-blue-600">
                    {customer.email}
                  </a>
                </div>
              )}
              
              {customer.address && (
                <div className="flex items-start text-gray-600">
                  <MapPin className="h-4 w-4 text-gray-400 mr-2 mt-1" />
                  <span>{customer.address}</span>
                </div>
              )}
              
              <div className="flex items-center text-gray-600">
                <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                <span>Customer since {formatDate(customer.createdAt)}</span>
              </div>
            </div>
          ) : (
            <div className="text-gray-500 italic">Customer information not available</div>
          )}
        </div>

        {/* Lead Details */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
            <Tag className="h-5 w-5 text-gray-500 mr-2" />
            Lead Details
          </h3>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-600">Status:</div>
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(lead.status)}`}>
                {lead.status.replace('_', ' ')}
              </span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-600">Priority:</div>
              <div className="flex items-center">
                {getPriorityIcon(lead.priority)}
                <span className={`ml-1 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getPriorityColor(lead.priority)}`}>
                  {lead.priority}
                </span>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-600">Lead Score:</div>
              <div className="flex items-center">
                <Star className={`h-4 w-4 mr-1 ${lead.leadScore && lead.leadScore > 50 ? 'text-yellow-500' : 'text-gray-400'}`} />
                <span className="text-sm font-medium text-gray-900">
                  {lead.leadScore || 0}/100
                </span>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-600">Source:</div>
              <div className="flex items-center">
                {getSourceIcon(lead.source)}
                <span className="ml-1 text-sm font-medium text-gray-900">
                  {lead.source}
                </span>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-600">Created:</div>
              <span className="text-sm text-gray-900">{formatDate(lead.createdAt)}</span>
            </div>
            
            {assignedUser && (
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-600">Assigned To:</div>
                <span className="text-sm font-medium text-gray-900">{assignedUser.name}</span>
              </div>
            )}
            
            {location && (
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-600">Location:</div>
                <div className="flex items-center">
                  <Building className="h-4 w-4 text-gray-400 mr-1" />
                  <span className="text-sm font-medium text-gray-900">{location.name}</span>
                </div>
              </div>
            )}
            
            {lead.tags && lead.tags.length > 0 && (
              <div className="pt-2">
                <div className="text-sm text-gray-600 mb-2">Tags:</div>
                <div className="flex flex-wrap gap-2">
                  {lead.tags.map(tag => (
                    <span key={tag} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Notes Section */}
      {lead.notes && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
            <MessageSquare className="h-5 w-5 text-gray-500 mr-2" />
            Notes
          </h3>
          <p className="text-gray-700 whitespace-pre-wrap">{lead.notes}</p>
        </div>
      )}

      {/* Related Jobs */}
      {lead.jobs && lead.jobs.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
            <Briefcase className="h-5 w-5 text-gray-500 mr-2" />
            Related Jobs
          </h3>
          
          <div className="space-y-3">
            {lead.jobs.map(job => (
              <div key={job.id} className="flex items-start p-3 bg-gray-50 rounded-lg">
                <Briefcase className="h-5 w-5 text-gray-500 mr-3 mt-0.5" />
                <div>
                  <div className="text-sm font-medium text-gray-900">{job.location}</div>
                  <div className="flex items-center text-xs text-gray-500 mt-1">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                      job.status === 'COMPLETED' ? 'bg-green-100 text-green-800' :
                      job.status === 'IN_PROGRESS' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-blue-100 text-blue-800'
                    }`}>
                      {job.status}
                    </span>
                    {job.startDate && (
                      <span className="ml-2 flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        {formatDate(job.startDate)}
                        {job.endDate && (
                          <>
                            <ArrowRight className="h-3 w-3 mx-1" />
                            {formatDate(job.endDate)}
                          </>
                        )}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tasks */}
      {lead.tasks && lead.tasks.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
            <CheckSquare className="h-5 w-5 text-gray-500 mr-2" />
            Related Tasks
          </h3>
          
          <div className="space-y-3">
            {lead.tasks.map(task => (
              <div key={task.id} className="flex items-start p-3 bg-gray-50 rounded-lg">
                <CheckSquare className="h-5 w-5 text-gray-500 mr-3 mt-0.5" />
                <div>
                  <div className="text-sm font-medium text-gray-900">{task.description}</div>
                  <div className="flex items-center text-xs text-gray-500 mt-1">
                    <Clock className="h-3 w-3 mr-1" />
                    <span>Due: {formatDate(task.dueDate)}</span>
                    <span className="mx-2">•</span>
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                      task.status === 'COMPLETED' ? 'bg-green-100 text-green-800' :
                      task.status === 'IN_PROGRESS' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {task.status}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  const renderActivityTab = () => (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Activity History</h3>
      
      <div className="space-y-4">
        {/* Status change activity */}
        <div className="flex items-start">
          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
            <Tag className="h-4 w-4 text-blue-600" />
          </div>
          <div className="ml-3">
            <div className="text-sm font-medium text-gray-900">Status changed to {lead.status}</div>
            <div className="text-xs text-gray-500">{formatDate(lead.updatedAt)}</div>
          </div>
        </div>
        
        {/* Creation activity */}
        <div className="flex items-start">
          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
            <User className="h-4 w-4 text-green-600" />
          </div>
          <div className="ml-3">
            <div className="text-sm font-medium text-gray-900">Lead created</div>
            <div className="text-xs text-gray-500">{formatDate(lead.createdAt)}</div>
          </div>
        </div>
        
        {/* Assignment activity (if assigned) */}
        {assignedUser && (
          <div className="flex items-start">
            <div className="flex-shrink-0 h-8 w-8 rounded-full bg-purple-100 flex items-center justify-center">
              <User className="h-4 w-4 text-purple-600" />
            </div>
            <div className="ml-3">
              <div className="text-sm font-medium text-gray-900">Assigned to {assignedUser.name}</div>
              <div className="text-xs text-gray-500">{formatDate(lead.updatedAt)}</div>
            </div>
          </div>
        )}
        
        {/* Location assignment (if available) */}
        {location && (
          <div className="flex items-start">
            <div className="flex-shrink-0 h-8 w-8 rounded-full bg-amber-100 flex items-center justify-center">
              <Building className="h-4 w-4 text-amber-600" />
            </div>
            <div className="ml-3">
              <div className="text-sm font-medium text-gray-900">Assigned to {location.name} location</div>
              <div className="text-xs text-gray-500">{formatDate(lead.updatedAt)}</div>
            </div>
          </div>
        )}
        
        {/* Lead score activity (if available) */}
        {lead.leadScore && lead.leadScore > 0 && (
          <div className="flex items-start">
            <div className="flex-shrink-0 h-8 w-8 rounded-full bg-yellow-100 flex items-center justify-center">
              <Star className="h-4 w-4 text-yellow-600" />
            </div>
            <div className="ml-3">
              <div className="text-sm font-medium text-gray-900">Lead scored {lead.leadScore}/100</div>
              <div className="text-xs text-gray-500">{formatDate(lead.updatedAt)}</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  const renderNotesTab = () => (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Notes</h3>
      
      {lead.notes ? (
        <div className="bg-gray-50 p-4 rounded-lg">
          <p className="text-gray-700 whitespace-pre-wrap">{lead.notes}</p>
        </div>
      ) : (
        <div className="text-center py-8 text-gray-500">
          <MessageSquare className="h-8 w-8 mx-auto text-gray-300 mb-2" />
          <p>No notes have been added to this lead yet.</p>
        </div>
      )}
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-40">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Lead Details</h2>
            <p className="text-gray-600">
              {customer?.name || 'Unknown Customer'} • Lead #{lead.id.slice(-6)}
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => onEdit(lead)}
              className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
              title="Edit Lead"
            >
              <Edit className="h-5 w-5" />
            </button>
            <button
              onClick={() => {
                if (window.confirm('Are you sure you want to delete this lead?')) {
                  onDelete(lead.id);
                  onClose();
                }
              }}
              className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              title="Delete Lead"
            >
              <Trash2 className="h-5 w-5" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              title="Close"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { id: 'overview', label: 'Overview' },
              { id: 'activity', label: 'Activity' },
              { id: 'notes', label: 'Notes' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto" style={{ maxHeight: 'calc(90vh - 200px)' }}>
          {activeTab === 'overview' && renderOverviewTab()}
          {activeTab === 'activity' && renderActivityTab()}
          {activeTab === 'notes' && renderNotesTab()}
        </div>
      </div>
    </div>
  );
};