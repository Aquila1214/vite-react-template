import React, { useState, useEffect, useRef } from 'react';
import { User, Users, ChevronDown } from 'lucide-react';
import { useAuthStore } from '../../stores/authStore';
import { useCrmStore } from '../../stores/crmStore';
import type { User as UserType, Team } from '../../types';

interface UserFilterProps {
  selectedUserId: string | null;
  selectedTeamId: string | null;
  onUserChange: (userId: string | null) => void;
  onTeamChange: (teamId: string | null) => void;
  showTeamFilter?: boolean;
  className?: string;
}

export const UserFilter: React.FC<UserFilterProps> = ({
  selectedUserId,
  selectedTeamId,
  onUserChange,
  onTeamChange,
  showTeamFilter = true,
  className = '',
}) => {
  const { user: currentUser } = useAuthStore();
  const { users, teams } = useCrmStore();
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const [showTeamDropdown, setShowTeamDropdown] = useState(false);
  
  const userDropdownRef = useRef<HTMLDivElement>(null);
  const teamDropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (userDropdownRef.current && !userDropdownRef.current.contains(event.target as Node)) {
        setShowUserDropdown(false);
      }
      if (teamDropdownRef.current && !teamDropdownRef.current.contains(event.target as Node)) {
        setShowTeamDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Filter users based on current user's role and permissions
  const getFilteredUsers = () => {
    if (currentUser?.role === 'ADMIN') {
      return users; // Admins can see all users
    }
    
    if (currentUser?.role === 'OPERATIONS') {
      // Operations can see all users in their team and technicians
      const teamUsers = users.filter(u => u.teamId === currentUser.teamId);
      const technicians = users.filter(u => u.role === 'TECHNICIAN');
      return [...teamUsers, ...technicians].filter((user, index, self) => 
        index === self.findIndex(u => u.id === user.id)
      );
    }
    
    if (currentUser?.role === 'SALES') {
      // Sales can see their team members
      return users.filter(u => u.teamId === currentUser.teamId || u.id === currentUser.id);
    }
    
    // Technicians can only see themselves
    return users.filter(u => u.id === currentUser?.id);
  };

  // Filter teams based on user's location
  const getFilteredTeams = () => {
    if (currentUser?.role === 'ADMIN') {
      return teams; // Admins can see all teams
    }
    
    // Filter teams by user's location
    if (currentUser?.locationId) {
      return teams.filter(team => team.locationId === currentUser.locationId);
    }
    
    return teams;
  };

  const filteredUsers = getFilteredUsers();
  const filteredTeams = getFilteredTeams();

  const selectedUser = users.find(u => u.id === selectedUserId);
  const selectedTeam = teams.find(t => t.id === selectedTeamId);

  return (
    <div className={`flex gap-3 ${className}`}>
      {/* User Filter */}
      <div className="relative" ref={userDropdownRef}>
        <div 
          className="appearance-none bg-white border border-gray-300 rounded-lg px-4 py-2 pr-8 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent cursor-pointer"
          onClick={() => setShowUserDropdown(!showUserDropdown)}
        >
          {selectedUser ? selectedUser.name : 'All Users'}
          <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
        </div>
        
        {showUserDropdown && (
          <div className="absolute z-10 mt-1 w-48 bg-white rounded-lg shadow-lg border border-gray-200">
            <div className="py-1">
              <div 
                className="px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer"
                onClick={() => {
                  onUserChange(null);
                  setShowUserDropdown(false);
                }}
              >
                All Users
              </div>
              {filteredUsers.map(user => (
                <div 
                  key={user.id} 
                  className="px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer"
                  onClick={() => {
                    onUserChange(user.id);
                    setShowUserDropdown(false);
                  }}
                >
                  {user.name} {user.id === currentUser?.id ? '(Me)' : ''}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
      
      {/* Team Filter */}
      {showTeamFilter && filteredTeams.length > 0 && (
        <div className="relative" ref={teamDropdownRef}>
          <div
            className="appearance-none bg-white border border-gray-300 rounded-lg px-4 py-2 pr-8 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent cursor-pointer"
            onClick={() => setShowTeamDropdown(!showTeamDropdown)}
          >
            {selectedTeam ? selectedTeam.name : 'All Teams'}
            <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
          </div>
          
          {showTeamDropdown && (
            <div className="absolute z-10 mt-1 w-48 bg-white rounded-lg shadow-lg border border-gray-200">
              <div className="py-1">
                <div 
                  className="px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer"
                  onClick={() => {
                    onTeamChange(null);
                    setShowTeamDropdown(false);
                  }}
                >
                  All Teams
                </div>
                {filteredTeams.map(team => (
                  <div 
                    key={team.id} 
                    className="px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer"
                    onClick={() => {
                      onTeamChange(team.id);
                      setShowTeamDropdown(false);
                    }}
                  >
                    <div className="flex items-center space-x-2">
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: team.color }}
                      />
                      <span>{team.name}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Current Selection Display */}
      <div className="flex items-center space-x-2 text-sm text-gray-600">
        {selectedUser && (
          <div className="flex items-center space-x-1 bg-blue-100 text-blue-800 px-2 py-1 rounded">
            <User className="h-3 w-3" />
            <span>{selectedUser.name}</span>
          </div>
        )}
        {selectedTeam && (
          <div className="flex items-center space-x-1 bg-green-100 text-green-800 px-2 py-1 rounded">
            <Users className="h-3 w-3" />
            <span>{selectedTeam.name}</span>
          </div>
        )}
      </div>
    </div>
  );
};