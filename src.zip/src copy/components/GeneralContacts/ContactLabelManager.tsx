import React, { useState, useEffect } from 'react';
import { X, Plus, Edit, Trash2, Save, Check } from 'lucide-react';
import { ContactLabel } from '../../types';
import { useCrmStore } from '../../stores/crmStore';

interface ContactLabelManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ContactLabelManager: React.FC<ContactLabelManagerProps> = ({
  isOpen,
  onClose,
}) => {
  const { contactLabels, createContactLabel, updateContactLabel, deleteContactLabel } = useCrmStore();
  const [labels, setLabels] = useState<ContactLabel[]>([]);
  const [newLabelName, setNewLabelName] = useState('');
  const [newLabelColor, setNewLabelColor] = useState('#3B82F6');
  const [editingLabelId, setEditingLabelId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editColor, setEditColor] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setLabels(contactLabels);
    }
  }, [isOpen, contactLabels]);

  const handleAddLabel = async () => {
    if (!newLabelName.trim()) return;
    
    setIsLoading(true);
    try {
      const newLabel = await createContactLabel({
        name: newLabelName.trim(),
        color: newLabelColor,
      });
      
      setLabels([...labels, newLabel]);
      setNewLabelName('');
      setNewLabelColor('#3B82F6');
    } catch (error) {
      console.error('Failed to create label:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditLabel = (label: ContactLabel) => {
    setEditingLabelId(label.id);
    setEditName(label.name);
    setEditColor(label.color);
  };

  const handleSaveEdit = async () => {
    if (!editingLabelId || !editName.trim()) return;
    
    setIsLoading(true);
    try {
      await updateContactLabel(editingLabelId, {
        name: editName.trim(),
        color: editColor,
      });
      
      setLabels(labels.map(label => 
        label.id === editingLabelId
          ? { ...label, name: editName.trim(), color: editColor }
          : label
      ));
      
      setEditingLabelId(null);
    } catch (error) {
      console.error('Failed to update label:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancelEdit = () => {
    setEditingLabelId(null);
  };

  const handleDeleteLabel = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this label? It will be removed from all contacts.')) return;
    
    setIsLoading(true);
    try {
      await deleteContactLabel(id);
      setLabels(labels.filter(label => label.id !== id));
    } catch (error) {
      console.error('Failed to delete label:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  const colorOptions = [
    '#3B82F6', // Blue
    '#10B981', // Green
    '#F59E0B', // Amber
    '#EF4444', // Red
    '#8B5CF6', // Purple
    '#EC4899', // Pink
    '#06B6D4', // Cyan
    '#84CC16', // Lime
    '#6B7280', // Gray
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Manage Contact Labels</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Add New Label */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-gray-900">Create New Label</h3>
            
            <div className="flex items-end gap-3">
              <div className="flex-1">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Label Name
                </label>
                <input
                  type="text"
                  value={newLabelName}
                  onChange={(e) => setNewLabelName(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter label name"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Color
                </label>
                <div className="flex items-center space-x-2">
                  <input
                    type="color"
                    value={newLabelColor}
                    onChange={(e) => setNewLabelColor(e.target.value)}
                    className="w-10 h-10 rounded border border-gray-300"
                  />
                </div>
              </div>
              
              <button
                type="button"
                onClick={handleAddLabel}
                disabled={!newLabelName.trim() || isLoading}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add
              </button>
            </div>
            
            <div className="flex flex-wrap gap-2 mt-2">
              {colorOptions.map(color => (
                <button
                  key={color}
                  type="button"
                  onClick={() => setNewLabelColor(color)}
                  className={`w-8 h-8 rounded-full border-2 ${newLabelColor === color ? 'border-gray-900' : 'border-gray-200'}`}
                  style={{ backgroundColor: color }}
                  title={`Select ${color}`}
                />
              ))}
            </div>
          </div>

          {/* Existing Labels */}
          <div className="space-y-4 pt-6 border-t border-gray-200">
            <h3 className="text-lg font-medium text-gray-900">Existing Labels</h3>
            
            <div className="space-y-3">
              {labels.length > 0 ? (
                labels.map(label => (
                  <div key={label.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    {editingLabelId === label.id ? (
                      <>
                        <div className="flex items-center space-x-3 flex-1">
                          <input
                            type="color"
                            value={editColor}
                            onChange={(e) => setEditColor(e.target.value)}
                            className="w-8 h-8 rounded border border-gray-300"
                          />
                          <input
                            type="text"
                            value={editName}
                            onChange={(e) => setEditName(e.target.value)}
                            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          />
                        </div>
                        <div className="flex items-center space-x-2 ml-3">
                          <button
                            type="button"
                            onClick={handleSaveEdit}
                            disabled={!editName.trim() || isLoading}
                            className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                            title="Save"
                          >
                            <Check className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            onClick={handleCancelEdit}
                            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                            title="Cancel"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="flex items-center space-x-3">
                          <div 
                            className="w-6 h-6 rounded-full" 
                            style={{ backgroundColor: label.color }}
                          />
                          <span className="font-medium text-gray-900">{label.name}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            type="button"
                            onClick={() => handleEditLabel(label)}
                            className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="Edit"
                          >
                            <Edit className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteLabel(label.id)}
                            className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                ))
              ) : (
                <div className="text-center py-6">
                  <p className="text-gray-500">No labels created yet. Create your first label above.</p>
                </div>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};