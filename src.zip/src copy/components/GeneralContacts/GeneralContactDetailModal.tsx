import React, { useState } from 'react';
import { X, User, Phone, Mail, Building, Tag, Edit, Trash2, MessageSquare, Plus, Clock, Activity } from 'lucide-react';
import { GeneralContact, ContactLabel, Message } from '../../types';
import { formatDate, formatPhone } from '../../lib/utils';
import { useCrmStore } from '../../stores/crmStore';
import { MessageComposer } from '../Messages/MessageComposer';

interface GeneralContactDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  contact: GeneralContact | null;
  onEdit: (contact: GeneralContact) => void;
  onAddLabel: (contactId: string, labelId: string) => Promise<void>;
  onRemoveLabel: (contactId: string, labelId: string) => Promise<void>;
  availableLabels: ContactLabel[];
}

export const GeneralContactDetailModal: React.FC<GeneralContactDetailModalProps> = ({
  isOpen,
  onClose,
  contact,
  onEdit,
  onAddLabel,
  onRemoveLabel,
  availableLabels,
}) => {
  const { messages } = useCrmStore();
  const [activeTab, setActiveTab] = useState<'overview' | 'messages' | 'labels'>('overview');
  const [showLabelSelector, setShowLabelSelector] = useState(false);

  if (!isOpen || !contact) return null;

  // Get messages for this contact
  const contactMessages = messages.filter(message => 
    message.generalContactId === contact.id
  ).sort((a, b) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  // Get labels not already assigned to this contact
  const unassignedLabels = availableLabels.filter(label => 
    !contact.labels?.some(l => l.id === label.id)
  );

  const handleAddLabel = async (labelId: string) => {
    await onAddLabel(contact.id, labelId);
    setShowLabelSelector(false);
  };

  const handleRemoveLabel = async (labelId: string) => {
    await onRemoveLabel(contact.id, labelId);
  };

  const tabs = [
    { id: 'overview', label: 'Overview', count: null },
    { id: 'messages', label: 'Messages', count: contactMessages.length },
    { id: 'labels', label: 'Labels', count: contact.labels?.length || 0 },
  ];

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Contact Info */}
      <div className="bg-gray-50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <User className="h-5 w-5 text-gray-400" />
              <div>
                <div className="text-sm font-medium text-gray-900">{contact.name}</div>
                <div className="text-xs text-gray-500">Contact since {formatDate(contact.createdAt)}</div>
              </div>
            </div>
            
            {contact.phone && (
              <a href={`tel:${contact.phone}`} className="flex items-center space-x-3 hover:text-blue-600">
                <Phone className="h-5 w-5 text-gray-400" />
                <div>
                  <div className="text-sm text-gray-900">{formatPhone(contact.phone)}</div>
                  <div className="text-xs text-gray-500">Phone</div>
                </div>
              </a>
            )}
            
            {contact.email && (
              <a href={`mailto:${contact.email}`} className="flex items-center space-x-3 hover:text-blue-600">
                <Mail className="h-5 w-5 text-gray-400" />
                <div>
                  <div className="text-sm text-gray-900">{contact.email}</div>
                  <div className="text-xs text-gray-500">Email</div>
                </div>
              </a>
            )}
          </div>
          
          <div className="space-y-3">
            {contact.businessName && (
              <div className="flex items-start space-x-3">
                <Building className="h-5 w-5 text-gray-400 mt-0.5" />
                <div>
                  <div className="text-sm text-gray-900">{contact.businessName}</div>
                  <div className="text-xs text-gray-500">Business</div>
                </div>
              </div>
            )}

            {contact.labels && contact.labels.length > 0 && (
              <div className="flex items-start space-x-3">
                <Tag className="h-5 w-5 text-gray-400 mt-0.5" />
                <div>
                  <div className="flex flex-wrap gap-2">
                    {contact.labels.map(label => (
                      <span 
                        key={label.id} 
                        className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium text-white"
                        style={{ backgroundColor: label.color }}
                      >
                        {label.name}
                      </span>
                    ))}
                  </div>
                  <div className="text-xs text-gray-500 mt-1">Labels</div>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {contact.notes && (
          <div className="mt-4 pt-4 border-t border-gray-200">
            <h4 className="text-sm font-medium text-gray-900 mb-2">Notes</h4>
            <p className="text-sm text-gray-600">{contact.notes}</p>
          </div>
        )}
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-blue-50 rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-blue-900">{contactMessages.length}</div>
          <div className="text-sm text-blue-600">Messages</div>
        </div>
        
        <div className="bg-green-50 rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-green-900">{contact.labels?.length || 0}</div>
          <div className="text-sm text-green-600">Labels</div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white border border-gray-200 rounded-lg">
        <div className="p-4 border-b border-gray-200 flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
        </div>
        <div className="p-4 max-h-[300px] overflow-y-auto">
          {contactMessages.length > 0 ? (
            <div className="space-y-3">
              {contactMessages.slice(0, 5).map(message => (
                <div key={message.id} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors duration-150">
                  <div className="p-2 bg-gray-100 rounded-full">
                    <MessageSquare className="h-4 w-4 text-blue-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900">
                      {message.content.length > 100 
                        ? `${message.content.substring(0, 100)}...` 
                        : message.content}
                    </p>
                    <div className="flex items-center mt-1 text-xs text-gray-500">
                      <Clock className="h-3 w-3 mr-1" />
                      <span>{formatDate(message.timestamp)}</span>
                      <span className="mx-2">•</span>
                      <span>{message.direction === 'INBOUND' ? 'Received' : 'Sent'}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              No activity found for this contact.
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderMessages = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">Contact Messages</h3>
        <MessageComposer
          generalContact={contact}
          onMessageSent={() => {/* Optionally refresh messages */}}
        />
      </div>
      
      <div className="bg-white border border-gray-200 rounded-lg">
        <div className="divide-y divide-gray-200">
          {contactMessages.length > 0 ? (
            contactMessages.map((message) => (
              <div key={message.id} className="p-6 hover:bg-gray-50 transition-colors">
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      message.direction === 'OUTBOUND' 
                        ? 'bg-blue-100' 
                        : 'bg-gray-100'
                    }`}>
                      <MessageSquare className="h-4 w-4 text-blue-600" />
                    </div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center space-x-2">
                        <span className="font-medium text-gray-900">
                          {message.direction === 'INBOUND' 
                            ? contact.name
                            : message.userId ? 'Company User' : 'System'
                          }
                        </span>
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                          message.type === 'SMS' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                        }`}>
                          {message.type}
                        </span>
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                          message.direction === 'INBOUND' 
                            ? 'bg-yellow-100 text-yellow-800' 
                            : 'bg-green-100 text-green-800'
                        }`}>
                          {message.direction === 'INBOUND' ? 'Received' : 'Sent'}
                        </span>
                      </div>
                      <span className="text-xs text-gray-500">
                        {formatDate(message.timestamp)}
                      </span>
                    </div>
                    
                    <p className="text-gray-700 whitespace-pre-wrap">
                      {message.content}
                    </p>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-12">
              <MessageSquare className="h-8 w-8 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500">No messages with this contact yet.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderLabels = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">Contact Labels</h3>
        <button
          onClick={() => setShowLabelSelector(!showLabelSelector)}
          className="flex items-center px-3 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Label
        </button>
      </div>
      
      {showLabelSelector && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h4 className="text-sm font-medium text-blue-900 mb-3">Select Label to Add</h4>
          <div className="flex flex-wrap gap-2">
            {unassignedLabels.length > 0 ? (
              unassignedLabels.map(label => (
                <button
                  key={label.id}
                  onClick={() => handleAddLabel(label.id)}
                  className="inline-flex items-center px-3 py-2 rounded-lg text-white transition-colors"
                  style={{ backgroundColor: label.color }}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  {label.name}
                </button>
              ))
            ) : (
              <p className="text-sm text-blue-700">All available labels are already assigned to this contact.</p>
            )}
          </div>
        </div>
      )}
      
      <div className="bg-white border border-gray-200 rounded-lg">
        <div className="p-4 border-b border-gray-200">
          <h4 className="font-medium text-gray-900">Assigned Labels</h4>
        </div>
        <div className="divide-y divide-gray-200">
          {contact.labels && contact.labels.length > 0 ? (
            contact.labels.map(label => (
              <div key={label.id} className="p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-6 h-6 rounded-full" 
                      style={{ backgroundColor: label.color }}
                    />
                    <span className="font-medium text-gray-900">{label.name}</span>
                  </div>
                  <button
                    onClick={() => handleRemoveLabel(label.id)}
                    className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    title="Remove Label"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8">
              <Tag className="h-8 w-8 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500">No labels assigned to this contact.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview': return renderOverview();
      case 'messages': return renderMessages();
      case 'labels': return renderLabels();
      default: return renderOverview();
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-6xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900">{contact.name}</h2>
            <p className="text-gray-600">
              {contact.businessName ? `${contact.businessName} • ` : ''}
              Contact Details
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-6 w-6 text-gray-500" />
          </button>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200 overflow-x-auto">
          <div className="flex space-x-1 px-6 min-w-max">
            {tabs.map((tab) => {
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 px-3 border-b-2 font-medium text-sm transition-colors whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <span>{tab.label}</span>
                  {tab.count !== null && tab.count > 0 && (
                    <span className="bg-gray-100 text-gray-600 py-0.5 px-2 rounded-full text-xs">
                      {tab.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
          {renderTabContent()}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-gray-200 bg-gray-50">
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-500">
              Last updated: {formatDate(contact.updatedAt)}
            </div>
            <div className="flex items-center space-x-3">
              <button
                onClick={() => onEdit(contact)}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Edit className="h-4 w-4 mr-2" />
                Edit Contact
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};