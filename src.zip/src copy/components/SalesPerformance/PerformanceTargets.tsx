import React, { useState } from 'react';
import { Target, Plus, Edit, Trash2, CheckCircle, AlertCircle, Clock } from 'lucide-react';
import { formatCurrency, formatDate } from '../../lib/utils';
import type { SalesMetrics, SalesTarget } from '../../types/sales';

interface PerformanceTargetsProps {
  metrics: SalesMetrics | null;
  targets: SalesTarget[];
  userId?: string | null;
}

export const PerformanceTargets: React.FC<PerformanceTargetsProps> = ({
  metrics,
  targets,
  userId,
}) => {
  const [showCreateModal, setShowCreateModal] = useState(false);

  if (!metrics) {
    return (
      <div className="h-64 bg-gray-200 rounded-lg animate-pulse" />
    );
  }

  const getTargetStatus = (percentage: number) => {
    if (percentage >= 100) return { icon: CheckCircle, color: 'text-green-600', bg: 'bg-green-100', label: 'Achieved' };
    if (percentage >= 80) return { icon: Clock, color: 'text-blue-600', bg: 'bg-blue-100', label: 'On Track' };
    return { icon: AlertCircle, color: 'text-red-600', bg: 'bg-red-100', label: 'Behind' };
  };

  const userTargets = targets.filter(target => !userId || target.userId === userId);

  return (
    <div className="space-y-6">
      {/* Current Period Targets */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Performance vs Targets</h3>
          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center px-3 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="h-4 w-4 mr-2" />
            Set Target
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Revenue Target */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium text-gray-700">Revenue Target</h4>
              <div className="flex items-center space-x-2">
                {(() => {
                  const status = getTargetStatus(metrics.targets.revenue.percentage);
                  const Icon = status.icon;
                  return (
                    <>
                      <Icon className={`h-4 w-4 ${status.color}`} />
                      <span className={`text-xs px-2 py-1 rounded-full ${status.bg} ${status.color}`}>
                        {status.label}
                      </span>
                    </>
                  );
                })()}
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Progress</span>
                <span className="font-medium">
                  {formatCurrency(metrics.targets.revenue.actual)} / {formatCurrency(metrics.targets.revenue.target)}
                </span>
              </div>
              
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className={`h-3 rounded-full transition-all duration-300 ${
                    metrics.targets.revenue.percentage >= 100 ? 'bg-green-500' :
                    metrics.targets.revenue.percentage >= 80 ? 'bg-blue-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${Math.min(metrics.targets.revenue.percentage, 100)}%` }}
                />
              </div>
              
              <div className="flex justify-between text-xs text-gray-600">
                <span>{metrics.targets.revenue.percentage.toFixed(1)}% complete</span>
                <span>
                  {metrics.targets.revenue.percentage >= 100 
                    ? `+${formatCurrency(metrics.targets.revenue.actual - metrics.targets.revenue.target)} over target`
                    : `${formatCurrency(metrics.targets.revenue.target - metrics.targets.revenue.actual)} remaining`
                  }
                </span>
              </div>
            </div>
          </div>

          {/* Leads Target */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium text-gray-700">Leads Target</h4>
              <div className="flex items-center space-x-2">
                {(() => {
                  const status = getTargetStatus(metrics.targets.leads.percentage);
                  const Icon = status.icon;
                  return (
                    <>
                      <Icon className={`h-4 w-4 ${status.color}`} />
                      <span className={`text-xs px-2 py-1 rounded-full ${status.bg} ${status.color}`}>
                        {status.label}
                      </span>
                    </>
                  );
                })()}
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Progress</span>
                <span className="font-medium">
                  {metrics.targets.leads.actual} / {metrics.targets.leads.target}
                </span>
              </div>
              
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className={`h-3 rounded-full transition-all duration-300 ${
                    metrics.targets.leads.percentage >= 100 ? 'bg-green-500' :
                    metrics.targets.leads.percentage >= 80 ? 'bg-blue-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${Math.min(metrics.targets.leads.percentage, 100)}%` }}
                />
              </div>
              
              <div className="flex justify-between text-xs text-gray-600">
                <span>{metrics.targets.leads.percentage.toFixed(1)}% complete</span>
                <span>
                  {metrics.targets.leads.percentage >= 100 
                    ? `+${metrics.targets.leads.actual - metrics.targets.leads.target} over target`
                    : `${metrics.targets.leads.target - metrics.targets.leads.actual} remaining`
                  }
                </span>
              </div>
            </div>
          </div>

          {/* Conversions Target */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium text-gray-700">Conversions Target</h4>
              <div className="flex items-center space-x-2">
                {(() => {
                  const status = getTargetStatus(metrics.targets.conversions.percentage);
                  const Icon = status.icon;
                  return (
                    <>
                      <Icon className={`h-4 w-4 ${status.color}`} />
                      <span className={`text-xs px-2 py-1 rounded-full ${status.bg} ${status.color}`}>
                        {status.label}
                      </span>
                    </>
                  );
                })()}
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Progress</span>
                <span className="font-medium">
                  {metrics.targets.conversions.actual} / {metrics.targets.conversions.target}
                </span>
              </div>
              
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className={`h-3 rounded-full transition-all duration-300 ${
                    metrics.targets.conversions.percentage >= 100 ? 'bg-green-500' :
                    metrics.targets.conversions.percentage >= 80 ? 'bg-blue-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${Math.min(metrics.targets.conversions.percentage, 100)}%` }}
                />
              </div>
              
              <div className="flex justify-between text-xs text-gray-600">
                <span>{metrics.targets.conversions.percentage.toFixed(1)}% complete</span>
                <span>
                  {metrics.targets.conversions.percentage >= 100 
                    ? `+${metrics.targets.conversions.actual - metrics.targets.conversions.target} over target`
                    : `${metrics.targets.conversions.target - metrics.targets.conversions.actual} remaining`
                  }
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Historical Targets */}
      {userTargets.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Target History</h3>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Target
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Period
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Target Value
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actual
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Achievement
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {userTargets.map((target) => {
                  const status = getTargetStatus(target.percentage);
                  const Icon = status.icon;
                  
                  return (
                    <tr key={target.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <Target className="h-4 w-4 text-gray-400 mr-2" />
                          <span className="text-sm font-medium text-gray-900 capitalize">
                            {target.type}
                          </span>
                        </div>
                      </td>
                      
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900 capitalize">{target.period}</div>
                        <div className="text-xs text-gray-500">
                          {formatDate(target.startDate)} - {formatDate(target.endDate)}
                        </div>
                      </td>
                      
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {target.type === 'revenue' 
                            ? formatCurrency(target.target)
                            : target.target.toLocaleString()
                          }
                        </div>
                      </td>
                      
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {target.type === 'revenue' 
                            ? formatCurrency(target.actual)
                            : target.actual.toLocaleString()
                          }
                        </div>
                      </td>
                      
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">
                          {target.percentage.toFixed(1)}%
                        </div>
                      </td>
                      
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <Icon className={`h-4 w-4 mr-2 ${status.color}`} />
                          <span className={`text-sm ${status.color}`}>
                            {status.label}
                          </span>
                        </div>
                      </td>
                      
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex items-center justify-end space-x-2">
                          <button className="text-blue-600 hover:text-blue-800">
                            <Edit className="h-4 w-4" />
                          </button>
                          <button className="text-red-600 hover:text-red-800">
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};