import React from 'react';
import { TrendingUp, TrendingDown, DollarSign, Users, Target, Percent, ArrowUp, ArrowDown, Minus } from 'lucide-react';
import { formatCurrency } from '../../lib/utils';
import type { SalesMetrics, TimePeriod } from '../../types/sales';

interface SalesKPICardsProps {
  metrics: SalesMetrics | null;
  timePeriod: TimePeriod;
  selectedUser: string;
  isTeamView?: boolean;
}

interface KPICardProps {
  title: string;
  value: string | number;
  change: number;
  changePercentage: number;
  trend: 'up' | 'down' | 'neutral';
  icon: React.ReactNode;
  tooltip?: string;
  yearOverYear?: {
    change: number;
    changePercentage: number;
  };
}

const KPICard: React.FC<KPICardProps> = ({
  title,
  value,
  change,
  changePercentage,
  trend,
  icon,
  tooltip,
  yearOverYear,
}) => {
  const getTrendIcon = () => {
    switch (trend) {
      case 'up':
        return <ArrowUp className="h-4 w-4 text-green-600" />;
      case 'down':
        return <ArrowDown className="h-4 w-4 text-red-600" />;
      default:
        return <Minus className="h-4 w-4 text-gray-600" />;
    }
  };

  const getTrendColor = () => {
    switch (trend) {
      case 'up':
        return 'text-green-600';
      case 'down':
        return 'text-red-600';
      default:
        return 'text-gray-600';
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between mb-4">
        <div className="p-3 bg-blue-50 rounded-full">
          {icon}
        </div>
        {tooltip && (
          <div className="text-xs text-gray-500" title={tooltip}>
            ℹ️
          </div>
        )}
      </div>
      
      <div className="space-y-2">
        <h3 className="text-sm font-medium text-gray-600">{title}</h3>
        <p className="text-3xl font-bold text-gray-900">{value}</p>
        
        {/* Week over Week / Period over Period */}
        <div className="flex items-center space-x-2">
          {getTrendIcon()}
          <span className={`text-sm font-medium ${getTrendColor()}`}>
            {Math.abs(changePercentage).toFixed(1)}%
          </span>
          <span className="text-sm text-gray-500">vs previous period</span>
        </div>
        
        {/* Year over Year */}
        {yearOverYear && (
          <div className="flex items-center space-x-2 pt-2 border-t border-gray-100">
            {yearOverYear.changePercentage > 0 ? (
              <ArrowUp className="h-3 w-3 text-blue-600" />
            ) : yearOverYear.changePercentage < 0 ? (
              <ArrowDown className="h-3 w-3 text-blue-600" />
            ) : (
              <Minus className="h-3 w-3 text-blue-600" />
            )}
            <span className="text-xs text-blue-600 font-medium">
              {Math.abs(yearOverYear.changePercentage).toFixed(1)}% YoY
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

export const SalesKPICards: React.FC<SalesKPICardsProps> = ({
  metrics,
  timePeriod,
  selectedUser,
  isTeamView = false,
}) => {
  if (!metrics) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="h-40 bg-gray-200 rounded-lg animate-pulse" />
        ))}
      </div>
    );
  }

  const kpis = [
    {
      title: 'Average Revenue per Lead',
      value: formatCurrency(metrics.averageRevenuePerLead),
      change: metrics.previousPeriodComparison.averageRevenuePerLead.change,
      changePercentage: metrics.previousPeriodComparison.averageRevenuePerLead.changePercentage,
      trend: metrics.previousPeriodComparison.averageRevenuePerLead.trend,
      icon: <DollarSign className="h-6 w-6 text-blue-600" />,
      tooltip: 'Total revenue from converted leads divided by number of converted leads',
      yearOverYear: {
        change: metrics.yearOverYearComparison.averageRevenuePerLead.change,
        changePercentage: metrics.yearOverYearComparison.averageRevenuePerLead.changePercentage,
      },
    },
    {
      title: 'Lead Conversion Rate',
      value: `${metrics.leadConversionRate.toFixed(1)}%`,
      change: metrics.previousPeriodComparison.leadConversionRate.change,
      changePercentage: metrics.previousPeriodComparison.leadConversionRate.changePercentage,
      trend: metrics.previousPeriodComparison.leadConversionRate.trend,
      icon: <Percent className="h-6 w-6 text-blue-600" />,
      tooltip: 'Percentage of leads that convert to paying customers',
      yearOverYear: {
        change: metrics.yearOverYearComparison.leadConversionRate.change,
        changePercentage: metrics.yearOverYearComparison.leadConversionRate.changePercentage,
      },
    },
    {
      title: 'Average Project Value',
      value: formatCurrency(metrics.averageProjectValue),
      change: metrics.previousPeriodComparison.averageProjectValue.change,
      changePercentage: metrics.previousPeriodComparison.averageProjectValue.changePercentage,
      trend: metrics.previousPeriodComparison.averageProjectValue.trend,
      icon: <Target className="h-6 w-6 text-blue-600" />,
      tooltip: 'Average value of completed projects',
      yearOverYear: {
        change: metrics.yearOverYearComparison.averageProjectValue.change,
        changePercentage: metrics.yearOverYearComparison.averageProjectValue.changePercentage,
      },
    },
    {
      title: 'Total Lead Volume',
      value: metrics.totalLeadVolume.toLocaleString(),
      change: metrics.previousPeriodComparison.totalLeadVolume.change,
      changePercentage: metrics.previousPeriodComparison.totalLeadVolume.changePercentage,
      trend: metrics.previousPeriodComparison.totalLeadVolume.trend,
      icon: <Users className="h-6 w-6 text-blue-600" />,
      tooltip: 'Total number of leads generated',
      yearOverYear: {
        change: metrics.yearOverYearComparison.totalLeadVolume.change,
        changePercentage: metrics.yearOverYearComparison.totalLeadVolume.changePercentage,
      },
    },
  ];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">
            {isTeamView ? 'Team' : 'Individual'} Performance KPIs
          </h2>
          <p className="text-sm text-gray-600">
            {selectedUser} • {timePeriod.replace(/([A-Z])/g, ' $1').toLowerCase()}
          </p>
        </div>
        
        <div className="flex items-center space-x-4 text-sm text-gray-600">
          <div className="flex items-center space-x-1">
            <div className="w-2 h-2 bg-green-500 rounded-full" />
            <span>Positive trend</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-2 h-2 bg-red-500 rounded-full" />
            <span>Negative trend</span>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpis.map((kpi, index) => (
          <KPICard key={index} {...kpi} />
        ))}
      </div>

      {/* Additional Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Revenue</p>
              <p className="text-2xl font-bold text-gray-900">
                {formatCurrency(metrics.totalRevenue)}
              </p>
            </div>
            <TrendingUp className="h-8 w-8 text-green-600" />
          </div>
          <div className="mt-2 text-sm text-gray-600">
            {metrics.projectsWon} projects won, {metrics.projectsLost} lost
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Sales Cycle</p>
              <p className="text-2xl font-bold text-gray-900">
                {metrics.averageSalesCycle} days
              </p>
            </div>
            <Target className="h-8 w-8 text-blue-600" />
          </div>
          <div className="mt-2 text-sm text-gray-600">
            Average time from lead to close
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Win Rate</p>
              <p className="text-2xl font-bold text-gray-900">
                {((metrics.projectsWon / (metrics.projectsWon + metrics.projectsLost)) * 100).toFixed(1)}%
              </p>
            </div>
            <Percent className="h-8 w-8 text-purple-600" />
          </div>
          <div className="mt-2 text-sm text-gray-600">
            Projects won vs total opportunities
          </div>
        </div>
      </div>
    </div>
  );
};