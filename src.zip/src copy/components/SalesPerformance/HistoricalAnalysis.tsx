import React, { useState } from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Calendar, TrendingUp, BarChart3, Activity, Download } from 'lucide-react';
import { formatCurrency, formatDate } from '../../lib/utils';
import type { HistoricalData, TimePeriod } from '../../types/sales';

interface HistoricalAnalysisProps {
  historicalData: HistoricalData | null;
  timePeriod: TimePeriod;
  selectedUserId?: string | null;
  selectedTeamId?: string | null;
}

export const HistoricalAnalysis: React.FC<HistoricalAnalysisProps> = ({
  historicalData,
  timePeriod,
  selectedUserId,
  selectedTeamId,
}) => {
  const [chartType, setChartType] = useState<'line' | 'bar'>('line');
  const [dataView, setDataView] = useState<'daily' | 'weekly' | 'monthly' | 'quarterly' | 'yearly'>('monthly');

  if (!historicalData) {
    return (
      <div className="space-y-6">
        <div className="h-80 bg-gray-200 rounded-lg animate-pulse" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-32 bg-gray-200 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  const getDataForView = () => {
    switch (dataView) {
      case 'daily':
        return historicalData.daily;
      case 'weekly':
        return historicalData.weekly;
      case 'monthly':
        return historicalData.monthly;
      case 'quarterly':
        return historicalData.quarterly;
      case 'yearly':
        return historicalData.yearly;
      default:
        return historicalData.monthly;
    }
  };

  const data = getDataForView();

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-4 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium text-gray-900 mb-2">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }} className="text-sm">
              {entry.name}: {
                entry.name.toLowerCase().includes('revenue')
                  ? formatCurrency(entry.value)
                  : entry.value.toLocaleString()
              }
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const calculateTrends = () => {
    if (data.length < 2) return { leads: 0, conversions: 0, revenue: 0 };
    
    const recent = data.slice(-3);
    const previous = data.slice(-6, -3);
    
    const recentAvg = {
      leads: recent.reduce((sum, d) => sum + d.leads, 0) / recent.length,
      conversions: recent.reduce((sum, d) => sum + d.conversions, 0) / recent.length,
      revenue: recent.reduce((sum, d) => sum + d.revenue, 0) / recent.length,
    };
    
    const previousAvg = {
      leads: previous.reduce((sum, d) => sum + d.leads, 0) / previous.length,
      conversions: previous.reduce((sum, d) => sum + d.conversions, 0) / previous.length,
      revenue: previous.reduce((sum, d) => sum + d.revenue, 0) / previous.length,
    };
    
    return {
      leads: ((recentAvg.leads - previousAvg.leads) / previousAvg.leads) * 100,
      conversions: ((recentAvg.conversions - previousAvg.conversions) / previousAvg.conversions) * 100,
      revenue: ((recentAvg.revenue - previousAvg.revenue) / previousAvg.revenue) * 100,
    };
  };

  const trends = calculateTrends();

  const renderChart = () => {
    const ChartComponent = chartType === 'line' ? LineChart : BarChart;
    
    return (
      <ResponsiveContainer width="100%" height={400}>
        <ChartComponent data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis 
            dataKey={dataView === 'daily' ? 'date' : 
                    dataView === 'weekly' ? 'week' :
                    dataView === 'monthly' ? 'month' :
                    dataView === 'quarterly' ? 'quarter' : 'year'} 
          />
          <YAxis yAxisId="left" />
          <YAxis yAxisId="right" orientation="right" />
          <Tooltip content={<CustomTooltip />} />
          <Legend />
          
          {chartType === 'line' ? (
            <>
              <Line yAxisId="left" type="monotone" dataKey="leads" stroke="#3B82F6" strokeWidth={2} name="Leads" />
              <Line yAxisId="left" type="monotone" dataKey="conversions" stroke="#10B981" strokeWidth={2} name="Conversions" />
              <Line yAxisId="right" type="monotone" dataKey="revenue" stroke="#8B5CF6" strokeWidth={2} name="Revenue" />
            </>
          ) : (
            <>
              <Bar yAxisId="left" dataKey="leads" fill="#3B82F6" name="Leads" />
              <Bar yAxisId="left" dataKey="conversions" fill="#10B981" name="Conversions" />
              <Bar yAxisId="right" dataKey="revenue" fill="#8B5CF6" name="Revenue" />
            </>
          )}
        </ChartComponent>
      </ResponsiveContainer>
    );
  };

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Historical Analysis</h2>
            <p className="text-sm text-gray-600">
              Long-term trends and seasonal patterns in sales performance
            </p>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Data View Selector */}
            <div className="flex items-center bg-gray-100 rounded-lg p-1">
              {[
                { id: 'daily', label: 'Daily' },
                { id: 'weekly', label: 'Weekly' },
                { id: 'monthly', label: 'Monthly' },
                { id: 'quarterly', label: 'Quarterly' },
                { id: 'yearly', label: 'Yearly' },
              ].map(({ id, label }) => (
                <button
                  key={id}
                  onClick={() => setDataView(id as any)}
                  className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                    dataView === id
                      ? 'bg-white text-gray-900 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            {/* Chart Type Toggle */}
            <div className="flex items-center bg-gray-100 rounded-lg p-1">
              <button
                onClick={() => setChartType('line')}
                className={`flex items-center px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                  chartType === 'line'
                    ? 'bg-white text-gray-900 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Activity className="h-4 w-4 mr-1" />
                Line
              </button>
              <button
                onClick={() => setChartType('bar')}
                className={`flex items-center px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                  chartType === 'bar'
                    ? 'bg-white text-gray-900 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <BarChart3 className="h-4 w-4 mr-1" />
                Bar
              </button>
            </div>

            <button className="flex items-center px-3 py-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors">
              <Download className="h-4 w-4 mr-2" />
              Export
            </button>
          </div>
        </div>
      </div>

      {/* Trend Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Lead Trend</p>
              <p className="text-2xl font-bold text-gray-900">
                {trends.leads > 0 ? '+' : ''}{trends.leads.toFixed(1)}%
              </p>
            </div>
            <TrendingUp className={`h-8 w-8 ${trends.leads > 0 ? 'text-green-600' : 'text-red-600'}`} />
          </div>
          <p className="text-sm text-gray-600 mt-2">vs previous period</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Conversion Trend</p>
              <p className="text-2xl font-bold text-gray-900">
                {trends.conversions > 0 ? '+' : ''}{trends.conversions.toFixed(1)}%
              </p>
            </div>
            <TrendingUp className={`h-8 w-8 ${trends.conversions > 0 ? 'text-green-600' : 'text-red-600'}`} />
          </div>
          <p className="text-sm text-gray-600 mt-2">vs previous period</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Revenue Trend</p>
              <p className="text-2xl font-bold text-gray-900">
                {trends.revenue > 0 ? '+' : ''}{trends.revenue.toFixed(1)}%
              </p>
            </div>
            <TrendingUp className={`h-8 w-8 ${trends.revenue > 0 ? 'text-green-600' : 'text-red-600'}`} />
          </div>
          <p className="text-sm text-gray-600 mt-2">vs previous period</p>
        </div>
      </div>

      {/* Historical Chart */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">
            {dataView.charAt(0).toUpperCase() + dataView.slice(1)} Performance Trends
          </h3>
          <div className="flex items-center space-x-4 text-sm text-gray-600">
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-blue-500 rounded" />
              <span>Leads</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-green-500 rounded" />
              <span>Conversions</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-purple-500 rounded" />
              <span>Revenue</span>
            </div>
          </div>
        </div>
        
        {renderChart()}
      </div>

      {/* Seasonal Patterns */}
      {dataView === 'monthly' && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Seasonal Patterns</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-3">Best Performing Months</h4>
              <div className="space-y-2">
                {data
                  .sort((a, b) => b.revenue - a.revenue)
                  .slice(0, 3)
                  .map((month, index) => (
                    <div key={month.month} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <span className="text-sm font-medium text-green-800">#{index + 1}</span>
                        <span className="text-sm text-gray-900">{month.month}</span>
                      </div>
                      <span className="text-sm font-medium text-green-800">
                        {formatCurrency(month.revenue)}
                      </span>
                    </div>
                  ))}
              </div>
            </div>

            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-3">Conversion Rate Leaders</h4>
              <div className="space-y-2">
                {data
                  .sort((a, b) => (b.conversions / b.leads) - (a.conversions / a.leads))
                  .slice(0, 3)
                  .map((month, index) => (
                    <div key={month.month} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <span className="text-sm font-medium text-blue-800">#{index + 1}</span>
                        <span className="text-sm text-gray-900">{month.month}</span>
                      </div>
                      <span className="text-sm font-medium text-blue-800">
                        {((month.conversions / month.leads) * 100).toFixed(1)}%
                      </span>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Year-to-Date Progress */}
      {dataView === 'yearly' && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Year-to-Date Progress</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {data.slice(-3).map((year) => (
              <div key={year.year} className="text-center">
                <div className="text-3xl font-bold text-gray-900 mb-2">{year.year}</div>
                <div className="space-y-2">
                  <div className="text-sm text-gray-600">
                    <span className="font-medium">{year.leads.toLocaleString()}</span> leads
                  </div>
                  <div className="text-sm text-gray-600">
                    <span className="font-medium">{year.conversions.toLocaleString()}</span> conversions
                  </div>
                  <div className="text-sm text-gray-600">
                    <span className="font-medium">{formatCurrency(year.revenue)}</span> revenue
                  </div>
                  <div className="text-sm text-blue-600 font-medium">
                    {((year.conversions / year.leads) * 100).toFixed(1)}% conversion rate
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};