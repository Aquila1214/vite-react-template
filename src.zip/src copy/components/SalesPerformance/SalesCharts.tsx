import React, { useState } from 'react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { TrendingUp, BarChart3, PieChart as PieChartIcon, Calendar } from 'lucide-react';
import { formatCurrency } from '../../lib/utils';
import type { SalesMetrics, HistoricalData, TimePeriod } from '../../types/sales';

interface SalesChartsProps {
  metrics: SalesMetrics | null;
  historicalData: HistoricalData | null;
  timePeriod: TimePeriod;
  isTeamView?: boolean;
}

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#06B6D4'];

export const SalesCharts: React.FC<SalesChartsProps> = ({
  metrics,
  historicalData,
  timePeriod,
  isTeamView = false,
}) => {
  const [activeChart, setActiveChart] = useState<'trends' | 'sources' | 'targets'>('trends');

  if (!metrics || !historicalData) {
    return (
      <div className="space-y-6">
        <div className="h-80 bg-gray-200 rounded-lg animate-pulse" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="h-64 bg-gray-200 rounded-lg animate-pulse" />
          <div className="h-64 bg-gray-200 rounded-lg animate-pulse" />
        </div>
      </div>
    );
  }

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium text-gray-900">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }}>
              {entry.name}: {
                entry.name.toLowerCase().includes('revenue') || entry.name.toLowerCase().includes('value')
                  ? formatCurrency(entry.value)
                  : entry.value.toLocaleString()
              }
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const renderTrendsChart = () => {
    const data = metrics.monthlyTrends;
    
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Performance Trends</h3>
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-blue-500 rounded" />
              <span>Leads</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-green-500 rounded" />
              <span>Conversions</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-purple-500 rounded" />
              <span>Revenue</span>
            </div>
          </div>
        </div>
        
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis yAxisId="left" />
            <YAxis yAxisId="right" orientation="right" />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            <Bar yAxisId="left" dataKey="leads" fill="#3B82F6" name="Leads" />
            <Bar yAxisId="left" dataKey="conversions" fill="#10B981" name="Conversions" />
            <Line yAxisId="right" type="monotone" dataKey="revenue" stroke="#8B5CF6" strokeWidth={3} name="Revenue" />
          </LineChart>
        </ResponsiveContainer>
      </div>
    );
  };

  const renderSourcesChart = () => {
    const data = metrics.leadsBySource;
    
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Lead Sources Performance</h3>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Pie Chart */}
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-4">Lead Distribution</h4>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ source, count }) => `${source}: ${count}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="count"
                >
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          
          {/* Bar Chart */}
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-4">Conversion Rate by Source</h4>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="source" />
                <YAxis />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="conversionRate" fill="#10B981" name="Conversion Rate %" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        {/* Source Details Table */}
        <div className="mt-6">
          <h4 className="text-sm font-medium text-gray-700 mb-3">Source Performance Details</h4>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Source
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Leads
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Conversion Rate
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Revenue
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Revenue per Lead
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {data.map((source, index) => (
                  <tr key={source.source}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div 
                          className="w-3 h-3 rounded-full mr-3"
                          style={{ backgroundColor: COLORS[index % COLORS.length] }}
                        />
                        <span className="text-sm font-medium text-gray-900">{source.source}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {source.count}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {source.conversionRate.toFixed(1)}%
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {formatCurrency(source.revenue)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {formatCurrency(source.revenue / source.count)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  const renderTargetsChart = () => {
    const targetData = [
      { name: 'Revenue', target: metrics.targets.revenue.target, actual: metrics.targets.revenue.actual, percentage: metrics.targets.revenue.percentage },
      { name: 'Leads', target: metrics.targets.leads.target, actual: metrics.targets.leads.actual, percentage: metrics.targets.leads.percentage },
      { name: 'Conversions', target: metrics.targets.conversions.target, actual: metrics.targets.conversions.actual, percentage: metrics.targets.conversions.percentage },
    ];
    
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Performance vs Targets</h3>
        </div>
        
        <div className="space-y-6">
          {targetData.map((item, index) => (
            <div key={item.name} className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700">{item.name}</span>
                <span className="text-sm text-gray-600">
                  {item.name === 'Revenue' ? formatCurrency(item.actual) : item.actual.toLocaleString()} / {item.name === 'Revenue' ? formatCurrency(item.target) : item.target.toLocaleString()}
                </span>
              </div>
              
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className={`h-3 rounded-full transition-all duration-300 ${
                    item.percentage >= 100 ? 'bg-green-500' :
                    item.percentage >= 80 ? 'bg-blue-500' :
                    item.percentage >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${Math.min(item.percentage, 100)}%` }}
                />
              </div>
              
              <div className="flex items-center justify-between text-xs text-gray-600">
                <span>{item.percentage.toFixed(1)}% of target</span>
                <span className={`font-medium ${
                  item.percentage >= 100 ? 'text-green-600' :
                  item.percentage >= 80 ? 'text-blue-600' :
                  item.percentage >= 60 ? 'text-yellow-600' : 'text-red-600'
                }`}>
                  {item.percentage >= 100 ? 'Target Exceeded' :
                   item.percentage >= 80 ? 'On Track' :
                   item.percentage >= 60 ? 'Behind' : 'Needs Attention'}
                </span>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-6 pt-6 border-t border-gray-200">
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={targetData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="percentage" fill="#3B82F6" name="Achievement %" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Chart Navigation */}
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-900">Sales Analytics</h2>
        
        <div className="flex items-center bg-gray-100 rounded-lg p-1">
          {[
            { id: 'trends', label: 'Trends', icon: TrendingUp },
            { id: 'sources', label: 'Sources', icon: PieChartIcon },
            { id: 'targets', label: 'Targets', icon: BarChart3 },
          ].map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveChart(id as any)}
              className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeChart === id
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Icon className="h-4 w-4 mr-2" />
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Chart Content */}
      {activeChart === 'trends' && renderTrendsChart()}
      {activeChart === 'sources' && renderSourcesChart()}
      {activeChart === 'targets' && renderTargetsChart()}
    </div>
  );
};