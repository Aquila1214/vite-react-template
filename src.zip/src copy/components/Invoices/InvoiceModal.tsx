import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { X, Calendar, User, DollarSign, FileText, CreditCard, Plus, Trash2, Search, Building } from 'lucide-react';
import { Invoice, Customer, Estimate } from '../../types';
import { formatDate, formatCurrency } from '../../lib/utils';
import { useCrmStore } from '../../stores/crmStore';
import { useLocationStore } from '../../stores/locationStore';

const invoiceSchema = z.object({
  amount: z.number().min(0.01, 'Amount must be greater than 0'),
  dueDate: z.string().min(1, 'Due date is required'),
  status: z.enum(['PAID', 'UNPAID', 'OVERDUE', 'CANCELLED']),
  stripePaymentUrl: z.string().optional(),
  locationId: z.string().optional(),
});

type InvoiceFormData = z.infer<typeof invoiceSchema>;

interface InvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice?: Invoice | null;
  customers: Customer[];
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({
  isOpen,
  onClose,
  invoice,
  customers,
}) => {
  const { estimates, createInvoice, updateInvoice } = useCrmStore();
  const { locations, fetchLocations } = useLocationStore();
  const isEditing = !!invoice;
  
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [selectedEstimate, setSelectedEstimate] = useState<Estimate | null>(null);
  const [customerSearchTerm, setCustomerSearchTerm] = useState('');
  const [showCustomerDropdown, setShowCustomerDropdown] = useState(false);
  const [estimateSearchTerm, setEstimateSearchTerm] = useState('');
  const [showEstimateDropdown, setShowEstimateDropdown] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [generatePaymentLink, setGeneratePaymentLink] = useState(true);
  
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    watch,
  } = useForm<InvoiceFormData>({
    resolver: zodResolver(invoiceSchema),
    defaultValues: {
      amount: invoice?.amount || 0,
      dueDate: invoice?.dueDate ? new Date(invoice.dueDate).toISOString().slice(0, 10) : '',
      status: invoice?.status || 'UNPAID',
      stripePaymentUrl: invoice?.stripePaymentUrl || '',
      locationId: invoice?.locationId || locations[0]?.id || '',
    },
  });

  useEffect(() => {
    fetchLocations();
  }, [fetchLocations]);

  // Set initial values when invoice changes
  useEffect(() => {
    if (isOpen) {
      if (invoice) {
        reset({
          amount: invoice.amount,
          dueDate: new Date(invoice.dueDate).toISOString().slice(0, 10),
          status: invoice.status,
          stripePaymentUrl: invoice.stripePaymentUrl || '',
          locationId: invoice.locationId || locations[0]?.id || '',
        });
        
        // Find related customer and estimate
        const customer = customers.find(c => c.id === invoice.customerId);
        setSelectedCustomer(customer || null);
        
        const estimate = estimates.find(e => e.id === invoice.estimateId);
        setSelectedEstimate(estimate || null);
        
        setGeneratePaymentLink(!invoice.stripePaymentUrl);
      } else {
        // Default values for new invoice
        const today = new Date();
        const dueDate = new Date();
        dueDate.setDate(today.getDate() + 30); // Due in 30 days
        
        reset({
          amount: 0,
          dueDate: dueDate.toISOString().slice(0, 10),
          status: 'UNPAID',
          stripePaymentUrl: '',
          locationId: locations[0]?.id || '',
        });
        
        setSelectedCustomer(null);
        setSelectedEstimate(null);
        setGeneratePaymentLink(true);
      }
    }
  }, [isOpen, invoice, customers, estimates, reset, locations]);

  // Update amount when estimate is selected
  useEffect(() => {
    if (selectedEstimate) {
      setValue('amount', selectedEstimate.total);
    }
  }, [selectedEstimate, setValue]);

  const onSubmit = async (data: InvoiceFormData) => {
    if (!selectedCustomer) {
      alert('Please select a customer');
      return;
    }
    
    setIsLoading(true);
    
    try {
      const invoiceData: Partial<Invoice> = {
        customerId: selectedCustomer.id,
        estimateId: selectedEstimate?.id,
        amount: data.amount,
        dueDate: data.dueDate,
        status: data.status,
        stripePaymentUrl: generatePaymentLink ? 'https://checkout.stripe.com/pay/cs_test_mock' : data.stripePaymentUrl,
        locationId: data.locationId,
      };
      
      if (isEditing && invoice) {
        await updateInvoice(invoice.id, invoiceData);
      } else {
        await createInvoice(invoiceData);
      }
      
      onClose();
    } catch (error) {
      console.error('Failed to save invoice:', error);
      alert('An error occurred while saving the invoice');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCustomerSelect = (customer: Customer) => {
    setSelectedCustomer(customer);
    setCustomerSearchTerm(customer.name);
    setShowCustomerDropdown(false);
    
    // Reset estimate when customer changes
    setSelectedEstimate(null);
    setEstimateSearchTerm('');
  };

  const handleEstimateSelect = (estimate: Estimate) => {
    setSelectedEstimate(estimate);
    setEstimateSearchTerm(`Estimate #${estimate.id.slice(-6)} - ${formatCurrency(estimate.total)}`);
    setShowEstimateDropdown(false);
    setValue('amount', estimate.total);
  };

  const filteredCustomers = customers.filter(customer => 
    customer.name.toLowerCase().includes(customerSearchTerm.toLowerCase()) ||
    customer.email?.toLowerCase().includes(customerSearchTerm.toLowerCase()) ||
    customer.phone?.includes(customerSearchTerm)
  );

  const filteredEstimates = estimates.filter(estimate => 
    (!selectedCustomer || estimate.customerId === selectedCustomer.id) &&
    (estimateSearchTerm === '' || 
     estimate.id.toLowerCase().includes(estimateSearchTerm.toLowerCase()) ||
     estimate.total.toString().includes(estimateSearchTerm))
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">
            {isEditing ? 'Edit Invoice' : 'Create New Invoice'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-6">
          {/* Customer Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Customer *
            </label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={customerSearchTerm}
                onChange={(e) => {
                  setCustomerSearchTerm(e.target.value);
                  setShowCustomerDropdown(true);
                  if (e.target.value === '') {
                    setSelectedCustomer(null);
                  }
                }}
                onFocus={() => setShowCustomerDropdown(true)}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Search customers..."
                disabled={isEditing} // Can't change customer when editing
              />
              
              {showCustomerDropdown && !isEditing && (
                <div className="absolute z-10 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                  {filteredCustomers.map(customer => (
                    <div 
                      key={customer.id} 
                      className="p-2 hover:bg-gray-100 cursor-pointer"
                      onClick={() => handleCustomerSelect(customer)}
                    >
                      <div className="text-sm font-medium">{customer.name}</div>
                      {customer.email && (
                        <div className="text-xs text-gray-500">{customer.email}</div>
                      )}
                    </div>
                  ))}
                  {filteredCustomers.length === 0 && (
                    <div className="p-2 text-sm text-gray-500">No customers found</div>
                  )}
                  <div className="p-2 border-t border-gray-100">
                    <button
                      type="button"
                      onClick={() => setShowCustomerDropdown(false)}
                      className="w-full text-xs text-center text-blue-600 hover:text-blue-800"
                    >
                      Close
                    </button>
                  </div>
                </div>
              )}
            </div>
            {!selectedCustomer && (
              <p className="mt-1 text-sm text-red-600">Customer is required</p>
            )}
          </div>

          {/* Estimate Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Related Estimate
            </label>
            <div className="relative">
              <FileText className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={estimateSearchTerm}
                onChange={(e) => {
                  setEstimateSearchTerm(e.target.value);
                  setShowEstimateDropdown(true);
                  if (e.target.value === '') {
                    setSelectedEstimate(null);
                  }
                }}
                onFocus={() => setShowEstimateDropdown(true)}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Search estimates..."
                disabled={!selectedCustomer || isEditing} // Disabled if no customer selected or editing
              />
              
              {showEstimateDropdown && selectedCustomer && !isEditing && (
                <div className="absolute z-10 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                  {filteredEstimates.map(estimate => (
                    <div 
                      key={estimate.id} 
                      className="p-2 hover:bg-gray-100 cursor-pointer"
                      onClick={() => handleEstimateSelect(estimate)}
                    >
                      <div className="text-sm font-medium">
                        Estimate #{estimate.id.slice(-6)}
                      </div>
                      <div className="text-xs text-gray-500">
                        {formatCurrency(estimate.total)} • Created {formatDate(estimate.createdAt)}
                      </div>
                    </div>
                  ))}
                  {filteredEstimates.length === 0 && (
                    <div className="p-2 text-sm text-gray-500">No estimates found for this customer</div>
                  )}
                  <div className="p-2 border-t border-gray-100">
                    <button
                      type="button"
                      onClick={() => setShowEstimateDropdown(false)}
                      className="w-full text-xs text-center text-blue-600 hover:text-blue-800"
                    >
                      Close
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Amount */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Amount *
            </label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="number"
                step="0.01"
                min="0"
                {...register('amount', { valueAsNumber: true })}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="0.00"
              />
            </div>
            {errors.amount && (
              <p className="mt-1 text-sm text-red-600">{errors.amount.message}</p>
            )}
          </div>

          {/* Due Date */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Due Date *
            </label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="date"
                {...register('dueDate')}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            {errors.dueDate && (
              <p className="mt-1 text-sm text-red-600">{errors.dueDate.message}</p>
            )}
          </div>

          {/* Status */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Status
            </label>
            <div className="relative">
              <CreditCard className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <select
                {...register('status')}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="UNPAID">Unpaid</option>
                <option value="PAID">Paid</option>
                <option value="OVERDUE">Overdue</option>
                <option value="CANCELLED">Cancelled</option>
              </select>
            </div>
          </div>

          {/* Location */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Branch Location
            </label>
            <div className="relative">
              <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <select
                {...register('locationId')}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {locations.map(location => (
                  <option key={location.id} value={location.id}>
                    {location.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Payment Link */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-sm font-medium text-gray-700">
                Payment Link
              </label>
              {!isEditing && (
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="generate-payment-link"
                    checked={generatePaymentLink}
                    onChange={(e) => setGeneratePaymentLink(e.target.checked)}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 mr-2"
                  />
                  <label htmlFor="generate-payment-link" className="text-xs text-gray-500">
                    Generate payment link
                  </label>
                </div>
              )}
            </div>
            {isEditing || !generatePaymentLink ? (
              <div className="relative">
                <CreditCard className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  {...register('stripePaymentUrl')}
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="https://checkout.stripe.com/..."
                />
              </div>
            ) : (
              <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                A payment link will be automatically generated when the invoice is created.
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end space-x-3 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading || !selectedCustomer}
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? 'Saving...' : isEditing ? 'Update Invoice' : 'Create Invoice'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};