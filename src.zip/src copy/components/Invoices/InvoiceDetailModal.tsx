import React, { useState } from 'react';
import { X, CreditCard, Calendar, User, FileText, DollarSign, CheckCircle, Clock, AlertTriangle, ExternalLink, Printer, Download, Mail, Edit, RefreshCw } from 'lucide-react';
import { Invoice, Customer } from '../../types';
import { formatDate, formatCurrency, getStatusColor } from '../../lib/utils';
import { useCrmStore } from '../../stores/crmStore';

interface InvoiceDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: Invoice | null;
  onEdit: (invoice: Invoice) => void;
}

export const InvoiceDetailModal: React.FC<InvoiceDetailModalProps> = ({
  isOpen,
  onClose,
  invoice,
  onEdit,
}) => {
  const { customers, estimates } = useCrmStore();
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen || !invoice) return null;

  const customer = customers.find(c => c.id === invoice.customerId);
  const estimate = estimates.find(e => e.id === invoice.estimateId);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'PAID':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'OVERDUE':
        return <AlertTriangle className="h-5 w-5 text-red-600" />;
      default:
        return <Clock className="h-5 w-5 text-yellow-600" />;
    }
  };

  const handleSendReminder = () => {
    setIsProcessing(true);
    // Simulate API call
    setTimeout(() => {
      setIsProcessing(false);
      alert('Payment reminder sent successfully!');
    }, 1500);
  };

  const handleMarkAsPaid = () => {
    setIsProcessing(true);
    // Simulate API call
    setTimeout(() => {
      setIsProcessing(false);
      alert('Invoice marked as paid!');
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Invoice #{invoice.id.slice(-6)}</h2>
            <p className="text-gray-600">
              {customer?.name || 'Unknown Customer'} • {formatDate(invoice.createdAt)}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            {/* Invoice Status */}
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center space-x-3 mb-2">
                {getStatusIcon(invoice.status)}
                <h3 className="text-lg font-medium text-gray-900">Status</h3>
              </div>
              <div className="flex items-center space-x-2">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(invoice.status)}`}>
                  {invoice.status}
                </span>
                {invoice.status === 'PAID' && (
                  <span className="text-sm text-gray-600">
                    on {formatDate(invoice.updatedAt)}
                  </span>
                )}
              </div>
            </div>

            {/* Amount */}
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center space-x-3 mb-2">
                <DollarSign className="h-5 w-5 text-gray-600" />
                <h3 className="text-lg font-medium text-gray-900">Amount</h3>
              </div>
              <div className="text-2xl font-bold text-gray-900">
                {formatCurrency(invoice.amount)}
              </div>
            </div>

            {/* Due Date */}
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center space-x-3 mb-2">
                <Calendar className="h-5 w-5 text-gray-600" />
                <h3 className="text-lg font-medium text-gray-900">Due Date</h3>
              </div>
              <div className={`text-lg font-medium ${
                new Date(invoice.dueDate) < new Date() && invoice.status !== 'PAID'
                  ? 'text-red-600'
                  : 'text-gray-900'
              }`}>
                {formatDate(invoice.dueDate)}
                {new Date(invoice.dueDate) < new Date() && invoice.status !== 'PAID' && (
                  <span className="text-sm ml-2">(Overdue)</span>
                )}
              </div>
            </div>
          </div>

          {/* Customer & Estimate Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            {/* Customer Info */}
            <div className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center space-x-3 mb-4">
                <User className="h-5 w-5 text-gray-600" />
                <h3 className="text-lg font-medium text-gray-900">Customer Information</h3>
              </div>
              
              {customer ? (
                <div className="space-y-2">
                  <p className="text-sm font-medium text-gray-900">{customer.name}</p>
                  {customer.email && (
                    <p className="text-sm text-gray-600">{customer.email}</p>
                  )}
                  {customer.phone && (
                    <p className="text-sm text-gray-600">{customer.phone}</p>
                  )}
                  {customer.billingAddress ? (
                    <p className="text-sm text-gray-600">{customer.billingAddress}</p>
                  ) : customer.address ? (
                    <p className="text-sm text-gray-600">{customer.address}</p>
                  ) : null}
                </div>
              ) : (
                <p className="text-sm text-gray-500">Customer information not available</p>
              )}
            </div>

            {/* Estimate Info */}
            <div className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center space-x-3 mb-4">
                <FileText className="h-5 w-5 text-gray-600" />
                <h3 className="text-lg font-medium text-gray-900">Estimate Information</h3>
              </div>
              
              {estimate ? (
                <div className="space-y-2">
                  <p className="text-sm font-medium text-gray-900">
                    Estimate #{estimate.id.slice(-6)}
                  </p>
                  <p className="text-sm text-gray-600">
                    Total: {formatCurrency(estimate.total)}
                  </p>
                  <p className="text-sm text-gray-600">
                    Status: {estimate.accepted ? 'Accepted' : 'Pending'}
                  </p>
                  <p className="text-sm text-gray-600">
                    Created: {formatDate(estimate.createdAt)}
                  </p>
                </div>
              ) : (
                <p className="text-sm text-gray-500">Estimate information not available</p>
              )}
            </div>
          </div>

          {/* Payment Information */}
          <div className="border border-gray-200 rounded-lg p-4 mb-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <CreditCard className="h-5 w-5 text-gray-600" />
                <h3 className="text-lg font-medium text-gray-900">Payment Information</h3>
              </div>
              
              {invoice.status === 'PAID' && (
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
                  <CheckCircle className="h-4 w-4 mr-1" />
                  Payment Received
                </span>
              )}
            </div>
            
            {invoice.status === 'PAID' ? (
              <div className="bg-green-50 p-4 rounded-lg">
                <p className="text-sm text-green-800">
                  This invoice has been paid in full. Thank you!
                </p>
                <p className="text-sm text-gray-600 mt-2">
                  Payment received on {formatDate(invoice.updatedAt)}
                </p>
              </div>
            ) : (
              <div>
                {invoice.stripePaymentUrl ? (
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <p className="text-sm text-blue-800 mb-3">
                      Online payment is available for this invoice.
                    </p>
                    <a
                      href={invoice.stripePaymentUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Pay Online
                    </a>
                  </div>
                ) : (
                  <div className="bg-yellow-50 p-4 rounded-lg">
                    <p className="text-sm text-yellow-800">
                      No online payment link has been generated for this invoice.
                    </p>
                    <button className="inline-flex items-center px-4 py-2 mt-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Generate Payment Link
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => onEdit(invoice)}
              className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Edit className="h-4 w-4 mr-2" />
              Edit Invoice
            </button>
            
            <button className="inline-flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors">
              <Printer className="h-4 w-4 mr-2" />
              Print Invoice
            </button>
            
            <button className="inline-flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors">
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </button>
            
            {invoice.status !== 'PAID' && (
              <>
                <button
                  onClick={handleSendReminder}
                  disabled={isProcessing}
                  className="inline-flex items-center px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors disabled:opacity-50"
                >
                  {isProcessing ? (
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Mail className="h-4 w-4 mr-2" />
                  )}
                  Send Reminder
                </button>
                
                <button
                  onClick={handleMarkAsPaid}
                  disabled={isProcessing}
                  className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
                >
                  {isProcessing ? (
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <CheckCircle className="h-4 w-4 mr-2" />
                  )}
                  Mark as Paid
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};