import React, { useState } from 'react';
import { Send, Mail, MessageSquare, AlertTriangle, Plus } from 'lucide-react';
import { useCrmStore } from '../../stores/crmStore';
import { useAuthStore } from '../../stores/authStore';
import { Customer, Message, UnknownContact, GeneralContact } from '../../types';
import { formatPhone } from '../../lib/utils';

interface MessageComposerProps {
  customer?: Customer;
  unknownContact?: UnknownContact;
  generalContact?: GeneralContact;
  onMessageSent?: () => void;
  compact?: boolean;
}

export const MessageComposer: React.FC<MessageComposerProps> = ({
  customer,
  unknownContact,
  generalContact,
  onMessageSent,
  compact = false
}) => {
  const { user: currentUser } = useAuthStore();
  const { createMessage } = useCrmStore();
  const [messageContent, setMessageContent] = useState('');
  const [selectedSendTypes, setSelectedSendTypes] = useState<('SMS' | 'EMAIL')[]>(['SMS']);
  const [isSending, setIsSending] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  const handleToggleMessageType = (type: 'SMS' | 'EMAIL') => {
    setSelectedSendTypes(prev => {
      if (prev.includes(type)) {
        // Don't allow removing the last type
        if (prev.length === 1) return prev;
        return prev.filter(t => t !== type);
      } else {
        return [...prev, type];
      }
    });
  };

  const handleSendMessage = async () => {
    if (!messageContent.trim() || selectedSendTypes.length === 0) return;
    
    setIsSending(true);
    
    try {
      // Create a message for each selected type
      for (const type of selectedSendTypes) {
        let messageData: Partial<Message> = {
          type: type,
          content: messageContent,
          direction: 'OUTBOUND',
          timestamp: new Date().toISOString(),
          userId: currentUser?.id
        };
        
        if (customer) {
          messageData.customerId = customer.id;
        } else if (unknownContact) {
          messageData.unknownContactId = unknownContact.id;
          messageData.fromPhone = unknownContact.phone;
          messageData.fromEmail = unknownContact.email;
          messageData.fromName = unknownContact.name;
        } else if (generalContact) {
          messageData.generalContactId = generalContact.id;
        }
        
        await createMessage(messageData);
      }
      
      setMessageContent('');
      if (onMessageSent) onMessageSent();
      if (compact) setIsExpanded(false);
    } catch (error) {
      console.error('Failed to send message:', error);
    } finally {
      setIsSending(false);
    }
  };

  // Determine recipient details
  const recipient = customer || unknownContact || generalContact;
  if (!recipient) return null;

  if (compact && !isExpanded) {
    return (
      <button
        onClick={() => setIsExpanded(true)}
        className="flex items-center px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
      >
        <Plus className="h-4 w-4 mr-2" />
        Send Message
      </button>
    );
  }

  return (
    <div className={`${compact ? 'absolute right-0 top-full mt-2 z-10 w-80' : ''} bg-white rounded-lg shadow-sm border border-gray-200 p-4`}>
      <div className="flex flex-col space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-medium text-gray-900">
            Send Message
          </h3>
          {compact && (
            <button
              onClick={() => setIsExpanded(false)}
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        
        <div className="flex flex-wrap gap-2">
          <label className={`inline-flex items-center px-3 py-2 border rounded-lg cursor-pointer ${
            selectedSendTypes.includes('SMS') 
              ? 'bg-blue-100 border-blue-300 text-blue-800' 
              : 'border-gray-300 hover:bg-gray-50'
          }`}>
            <input
              type="checkbox"
              checked={selectedSendTypes.includes('SMS')}
              onChange={() => handleToggleMessageType('SMS')}
              className="sr-only"
            />
            <MessageSquare className="h-4 w-4 mr-2" />
            SMS {recipient?.phone ? `(${formatPhone(recipient.phone)})` : ''}
          </label>
          
          <label className={`inline-flex items-center px-3 py-2 border rounded-lg cursor-pointer ${
            selectedSendTypes.includes('EMAIL') 
              ? 'bg-green-100 border-green-300 text-green-800' 
              : 'border-gray-300 hover:bg-gray-50'
          }`}>
            <input
              type="checkbox"
              checked={selectedSendTypes.includes('EMAIL')}
              onChange={() => handleToggleMessageType('EMAIL')}
              className="sr-only"
            />
            <Mail className="h-4 w-4 mr-2" />
            Email {recipient?.email ? `(${recipient.email})` : ''}
          </label>
        </div>
        
        <div className="flex gap-3">
          <textarea
            value={messageContent}
            onChange={(e) => setMessageContent(e.target.value)}
            placeholder={`Type your message to ${recipient.name || 'contact'}...`}
            className={`flex-1 px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
              selectedSendTypes.length === 1 && selectedSendTypes[0] === 'SMS'
                ? 'border-blue-200 bg-blue-50'
                : selectedSendTypes.length === 1 && selectedSendTypes[0] === 'EMAIL'
                ? 'border-green-200 bg-green-50'
                : 'border-purple-200 bg-purple-50'
            }`}
            rows={3}
          />
          <div className="flex flex-col justify-end">
            <button
              onClick={handleSendMessage}
              disabled={!messageContent.trim() || isSending || selectedSendTypes.length === 0}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSending ? (
                <span className="flex items-center">
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Sending...
                </span>
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Send
                </>
              )}
            </button>
          </div>
        </div>
        
        <div className="text-xs text-gray-500">
          {selectedSendTypes.includes('SMS') && selectedSendTypes.length === 1 && (
            <div className="flex items-center">
              <AlertTriangle className="h-3 w-3 mr-1 text-amber-500" />
              <span>SMS messages are limited to 160 characters. Longer messages will be split.</span>
            </div>
          )}
          {selectedSendTypes.includes('EMAIL') && selectedSendTypes.length === 1 && (
            <div className="flex items-center">
              <Mail className="h-3 w-3 mr-1 text-gray-400" />
              <span>Email will be sent from your company email address.</span>
            </div>
          )}
          {selectedSendTypes.length > 1 && (
            <div className="flex items-center">
              <AlertTriangle className="h-3 w-3 mr-1 text-purple-500" />
              <span>Message will be sent via {selectedSendTypes.join(' and ')}.</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};