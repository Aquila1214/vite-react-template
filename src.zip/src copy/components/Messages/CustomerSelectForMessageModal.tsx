import React, { useState, useEffect } from 'react';
import { X, Search, User, Phone, Mail, Plus, Link } from 'lucide-react';
import { Customer, UnknownContact } from '../../types';
import { useCrmStore } from '../../stores/crmStore';
import { formatPhone } from '../../lib/utils';

interface CustomerSelectForMessageModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectCustomer: (customer: Customer) => void;
  onSelectUnknownContact?: (contact: UnknownContact) => void;
  forLinking?: boolean;
  unknownContactId?: string;
}

export const CustomerSelectForMessageModal: React.FC<CustomerSelectForMessageModalProps> = ({
  isOpen,
  onClose,
  onSelectCustomer,
  onSelectUnknownContact,
  forLinking = false,
  unknownContactId
}) => {
  const { customers, unknownContacts, linkUnknownToCustomer } = useCrmStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [recentCustomers, setRecentCustomers] = useState<Customer[]>([]);

  useEffect(() => {
    // Get recent customers (in a real app, this might come from an API or local storage)
    // For now, just take the first 5 customers as "recent"
    setRecentCustomers(customers.slice(0, 5));
  }, [customers]);

  if (!isOpen) return null;

  const filteredCustomers = customers.filter(customer => 
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.phone?.includes(searchTerm) ||
    customer.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.address?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleLinkToCustomer = (customerId: string) => {
    if (forLinking && unknownContactId) {
      linkUnknownToCustomer(unknownContactId, customerId);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">
            {forLinking ? 'Link to Customer' : 'Select Customer'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <div className="p-4">
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search customers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              autoFocus
            />
          </div>

          <div className="max-h-[60vh] overflow-y-auto">
            {searchTerm === '' && recentCustomers.length > 0 && (
              <div className="mb-4">
                <h3 className="text-sm font-medium text-gray-700 mb-2">Recent Customers</h3>
                <div className="space-y-2">
                  {recentCustomers.map(customer => (
                    <div
                      key={customer.id}
                      className="p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                      onClick={() => forLinking ? handleLinkToCustomer(customer.id) : onSelectCustomer(customer)}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="flex-shrink-0">
                          <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                            <User className="h-5 w-5 text-gray-500" />
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">{customer.name}</p>
                          <div className="flex items-center space-x-2 text-xs text-gray-500">
                            {customer.phone && (
                              <span className="flex items-center">
                                <Phone className="h-3 w-3 mr-1" />
                                {formatPhone(customer.phone)}
                              </span>
                            )}
                            {customer.email && (
                              <span className="flex items-center">
                                <Mail className="h-3 w-3 mr-1" />
                                <span className="truncate max-w-[150px]">{customer.email}</span>
                              </span>
                            )}
                          </div>
                        </div>
                        {forLinking && (
                          <Link className="h-4 w-4 text-blue-500" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {filteredCustomers.length > 0 ? (
              <div>
                {searchTerm !== '' && <h3 className="text-sm font-medium text-gray-700 mb-2">Search Results</h3>}
                <div className="space-y-2">
                  {filteredCustomers.map(customer => (
                    <div
                      key={customer.id}
                      className="p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                      onClick={() => forLinking ? handleLinkToCustomer(customer.id) : onSelectCustomer(customer)}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="flex-shrink-0">
                          <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                            <User className="h-5 w-5 text-gray-500" />
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">{customer.name}</p>
                          <div className="flex items-center space-x-2 text-xs text-gray-500">
                            {customer.phone && (
                              <span className="flex items-center">
                                <Phone className="h-3 w-3 mr-1" />
                                {formatPhone(customer.phone)}
                              </span>
                            )}
                            {customer.email && (
                              <span className="flex items-center">
                                <Mail className="h-3 w-3 mr-1" />
                                <span className="truncate max-w-[150px]">{customer.email}</span>
                              </span>
                            )}
                          </div>
                        </div>
                        {forLinking && (
                          <Link className="h-4 w-4 text-blue-500" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <User className="h-8 w-8 mx-auto text-gray-300 mb-2" />
                <p className="text-gray-500">No customers found matching your search.</p>
                <button
                  className="mt-2 inline-flex items-center px-3 py-2 text-sm font-medium text-blue-600 hover:text-blue-800"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Create New Customer
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};