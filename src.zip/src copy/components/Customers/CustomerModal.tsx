import React, { useState, useEffect, useRef } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { X, User, Phone, Mail, MapPin, CreditCard, Plus, Trash2, Save, Building } from 'lucide-react';
import { Customer, AdditionalContact, Location } from '../../types';
import { useCrmStore } from '../../stores/crmStore';
import { useLocationStore } from '../../stores/locationStore';

const customerSchema = z.object({
  name: z.string().min(2, 'Customer name is required'),
  phone: z.string().min(7, 'Valid phone number is required'),
  email: z.string().email('Valid email is required'),
  address: z.string().min(5, 'Service address is required'),
  billingAddress: z.string().optional(),
  notes: z.string().optional(),
  leadSource: z.string().min(1, 'Lead source is required'),
  projectType: z.string().min(1, 'Project type is required'),
  locationId: z.string().optional(),
});

type CustomerFormData = z.infer<typeof customerSchema>;

interface CustomerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Partial<Customer>) => Promise<void>;
  customer?: Customer | null;
  isLoading?: boolean;
}

export const CustomerModal: React.FC<CustomerModalProps> = ({
  isOpen,
  onClose,
  onSave,
  customer,
  isLoading = false,
}) => {
  const { users } = useCrmStore();
  const { locations, fetchLocations } = useLocationStore();
  const isEditing = !!customer;
  const [additionalContacts, setAdditionalContacts] = useState<AdditionalContact[]>([]);
  const [useSeparateBillingAddress, setUseSeparateBillingAddress] = useState(false);
  
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    watch,
  } = useForm<CustomerFormData>({
    resolver: zodResolver(customerSchema),
    defaultValues: {
      name: customer?.name || '',
      phone: customer?.phone || '',
      email: customer?.email || '',
      address: customer?.address || '',
      billingAddress: customer?.billingAddress || '',
      notes: customer?.notes || '',
      leadSource: customer?.leadSource || '',
      projectType: '',
      locationId: customer?.locationId || locations[0]?.id || '',
    },
  });

  useEffect(() => {
    fetchLocations();
  }, [fetchLocations]);

  useEffect(() => {
    if (isOpen) {
      if (customer) {
        reset({
          name: customer.name,
          phone: customer.phone || '',
          email: customer.email || '',
          address: customer.address || '',
          billingAddress: customer.billingAddress || '',
          notes: customer.notes || '',
          leadSource: customer.leadSource || '',
          projectType: '',
          locationId: customer.locationId || locations[0]?.id || '',
        });
        setAdditionalContacts(customer.additionalContacts || []);
        setUseSeparateBillingAddress(!!customer.billingAddress);
      } else {
        reset({
          name: '',
          phone: '',
          email: '',
          address: '',
          billingAddress: '',
          notes: '',
          leadSource: '',
          projectType: '',
          locationId: locations[0]?.id || '',
        });
        setAdditionalContacts([]);
        setUseSeparateBillingAddress(false);
      }
    }
  }, [isOpen, customer, reset, locations]);

  const onSubmit = async (data: CustomerFormData) => {
    try {
      const customerData: Partial<Customer> = {
        name: data.name,
        phone: data.phone,
        email: data.email,
        address: data.address,
        billingAddress: useSeparateBillingAddress ? data.billingAddress : undefined,
        notes: data.notes,
        additionalContacts: additionalContacts.length > 0 ? additionalContacts : undefined,
        leadSource: data.leadSource,
        leadCost: 0, // Default value, can be updated later
        leadCampaign: '',
        leadNotes: '',
        locationId: data.locationId,
      };

      await onSave(customerData);
      onClose();
    } catch (error) {
      console.error('Failed to save customer:', error);
    }
  };

  const addContact = () => {
    setAdditionalContacts([...additionalContacts, { name: '', phone: '', email: '', role: '' }]);
  };

  const updateContact = (index: number, field: keyof AdditionalContact, value: string) => {
    const updatedContacts = [...additionalContacts];
    updatedContacts[index] = { ...updatedContacts[index], [field]: value };
    setAdditionalContacts(updatedContacts);
  };

  const removeContact = (index: number) => {
    setAdditionalContacts(additionalContacts.filter((_, i) => i !== index));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">
            {isEditing ? 'Edit Customer' : 'Create New Customer'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-6">
          {/* Customer Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-gray-900 flex items-center">
              <User className="h-5 w-5 mr-2 text-gray-400" />
              Customer Information
            </h3>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Customer Name *
              </label>
              <input
                {...register('name')}
                type="text"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter customer name"
              />
              {errors.name && (
                <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Location
              </label>
              <div className="relative">
                <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <select
                  {...register('locationId')}
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  {locations.map(location => (
                    <option key={location.id} value={location.id}>
                      {location.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Phone Number *
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  {...register('phone')}
                  type="tel"
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="(555) 123-4567"
                />
              </div>
              {errors.phone && (
                <p className="mt-1 text-sm text-red-600">{errors.phone.message}</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email Address *
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  {...register('email')}
                  type="email"
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="customer@email.com"
                />
              </div>
              {errors.email && (
                <p className="mt-1 text-sm text-red-600">{errors.email.message}</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Service Address *
              </label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  {...register('address')}
                  type="text"
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="123 Main St, City, State"
                />
              </div>
              {errors.address && (
                <p className="mt-1 text-sm text-red-600">{errors.address.message}</p>
              )}
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-sm font-medium text-gray-700">
                  Billing Address
                </label>
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="separate-billing"
                    checked={useSeparateBillingAddress}
                    onChange={(e) => setUseSeparateBillingAddress(e.target.checked)}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 mr-2"
                  />
                  <label htmlFor="separate-billing" className="text-xs text-gray-500">
                    Different from service address
                  </label>
                </div>
              </div>
              {useSeparateBillingAddress && (
                <div className="relative">
                  <CreditCard className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <input
                    {...register('billingAddress')}
                    type="text"
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Billing address (if different)"
                  />
                </div>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Notes
              </label>
              <textarea
                {...register('notes')}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Additional notes about this customer..."
              />
            </div>
          </div>

          {/* Lead Information */}
          <div className="space-y-4 pt-4 border-t border-gray-200">
            <h3 className="text-lg font-medium text-gray-900">Lead Information</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Lead Source *
                </label>
                <select
                  {...register('leadSource')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Select Lead Source</option>
                  <option value="CALLRAIL">CallRail</option>
                  <option value="FORM">Web Form</option>
                  <option value="REFERRAL">Referral</option>
                  <option value="DIRECT">Direct</option>
                  <option value="GOOGLE">Google</option>
                  <option value="FACEBOOK">Facebook</option>
                  <option value="OTHER">Other</option>
                </select>
                {errors.leadSource && (
                  <p className="mt-1 text-sm text-red-600">{errors.leadSource.message}</p>
                )}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Project Type *
                </label>
                <select
                  {...register('projectType')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Select Project Type</option>
                  <option value="foundation_repair">Foundation Repair</option>
                  <option value="waterproofing">Waterproofing</option>
                  <option value="crawlspace_repair">Crawlspace Repair</option>
                  <option value="concrete_repair">Concrete Repair</option>
                  <option value="general_construction">General Construction</option>
                  <option value="combination">Combination Project</option>
                </select>
                {errors.projectType && (
                  <p className="mt-1 text-sm text-red-600">{errors.projectType.message}</p>
                )}
              </div>
            </div>
          </div>

          {/* Additional Contacts */}
          <div className="space-y-4 pt-4 border-t border-gray-200">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium text-gray-900">Additional Contacts</h3>
              <button
                type="button"
                onClick={addContact}
                className="flex items-center text-sm text-blue-600 hover:text-blue-800"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Contact
              </button>
            </div>
            
            {additionalContacts.length > 0 ? (
              <div className="space-y-4">
                {additionalContacts.map((contact, index) => (
                  <div key={index} className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-sm font-medium text-gray-900">Contact #{index + 1}</h4>
                      <button
                        type="button"
                        onClick={() => removeContact(index)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-gray-700 mb-1">
                          Name
                        </label>
                        <input
                          type="text"
                          value={contact.name}
                          onChange={(e) => updateContact(index, 'name', e.target.value)}
                          className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-xs font-medium text-gray-700 mb-1">
                          Role
                        </label>
                        <input
                          type="text"
                          value={contact.role || ''}
                          onChange={(e) => updateContact(index, 'role', e.target.value)}
                          className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg"
                          placeholder="e.g., Spouse, Assistant"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-xs font-medium text-gray-700 mb-1">
                          Phone
                        </label>
                        <input
                          type="tel"
                          value={contact.phone || ''}
                          onChange={(e) => updateContact(index, 'phone', e.target.value)}
                          className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-xs font-medium text-gray-700 mb-1">
                          Email
                        </label>
                        <input
                          type="email"
                          value={contact.email || ''}
                          onChange={(e) => updateContact(index, 'email', e.target.value)}
                          className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-500 italic">No additional contacts added.</p>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end space-x-3 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? 'Saving...' : isEditing ? 'Update Customer' : 'Create Customer'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};