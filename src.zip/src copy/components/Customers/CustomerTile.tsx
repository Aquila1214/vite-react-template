import React, { useState, useRef, useEffect } from 'react';
import { Phone, Mail, MapPin, Eye, Edit, Trash2, Users, Briefcase, FileText, MessageSquare, CheckSquare, CreditCard, User, DollarSign, Tag, ExternalLink, X, Plus } from 'lucide-react';
import { Customer } from '../../types';
import { formatDate, formatPhone } from '../../lib/utils';

interface CustomerTileProps {
  customer: Customer;
  onView: (customer: Customer) => void;
  onEdit: (customer: Customer) => void;
  onDelete: (id: string) => void;
}

export const CustomerTile: React.FC<CustomerTileProps> = ({ customer, onView, onEdit, onDelete }) => {
  const { customers } = useCrmStore();
  const [isEditing, setIsEditing] = useState(false);
  const [editedCustomer, setEditedCustomer] = useState<Customer>(customer);
  const [showBillingAddress, setShowBillingAddress] = useState(!!customer.billingAddress);
  const [billingAddress, setBillingAddress] = useState(customer.billingAddress || '');
  const [additionalContacts, setAdditionalContacts] = useState(customer.additionalContacts || []);
  const [leadInfo, setLeadInfo] = useState({
    cost: customer.leadCost || 0,
    source: customer.leadSource || '',
    campaign: customer.leadCampaign || '',
    notes: customer.leadNotes || '',
    referredBy: customer.referredBy || ''
  });
  const [newLeadSource, setNewLeadSource] = useState('');
  const [showNewLeadSourceInput, setShowNewLeadSourceInput] = useState(false);
  const [referralSearch, setReferralSearch] = useState('');
  const [showReferralDropdown, setShowReferralDropdown] = useState(false);
  
  const referralDropdownRef = useRef<HTMLDivElement>(null);

  // Close referral dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (referralDropdownRef.current && !referralDropdownRef.current.contains(event.target as Node)) {
        setShowReferralDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const stats = {
    leads: customer.leads?.length || 0,
    jobs: customer.jobs?.length || 0,
    tasks: customer.tasks?.filter(t => t.status !== 'COMPLETED').length || 0,
    messages: customer.messages?.length || 0,
    files: customer.files?.length || 0,
  };

  const handleSave = () => {
    // Here you would call an API to update the customer
    // For now, we'll just update the local state
    const updatedCustomer = {
      ...editedCustomer,
      billingAddress: showBillingAddress ? billingAddress : undefined,
      additionalContacts: additionalContacts,
      leadCost: leadInfo.cost,
      leadSource: showNewLeadSourceInput ? newLeadSource : leadInfo.source,
      leadCampaign: leadInfo.campaign,
      leadNotes: leadInfo.notes,
      referredBy: leadInfo.referredBy
    };
    
    onEdit(updatedCustomer);
    setIsEditing(false);
    setShowNewLeadSourceInput(false);
  };

  const handleCancel = () => {
    setEditedCustomer(customer);
    setBillingAddress(customer.billingAddress || '');
    setShowBillingAddress(!!customer.billingAddress);
    setAdditionalContacts(customer.additionalContacts || []);
    setLeadInfo({
      cost: customer.leadCost || 0,
      source: customer.leadSource || '',
      campaign: customer.leadCampaign || '',
      notes: customer.leadNotes || '',
      referredBy: customer.referredBy || ''
    });
    setNewLeadSource('');
    setShowNewLeadSourceInput(false);
    setIsEditing(false);
  };

  const addContact = () => {
    setAdditionalContacts([...additionalContacts, { name: '', phone: '', email: '', role: '' }]);
  };

  const updateContact = (index: number, field: string, value: string) => {
    const updatedContacts = [...additionalContacts];
    updatedContacts[index] = { ...updatedContacts[index], [field]: value };
    setAdditionalContacts(updatedContacts);
  };

  const removeContact = (index: number) => {
    setAdditionalContacts(additionalContacts.filter((_, i) => i !== index));
  };

  const handleLeadSourceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    if (value === "ADD_NEW") {
      setShowNewLeadSourceInput(true);
    } else {
      setLeadInfo({...leadInfo, source: value});
    }
  };

  const filteredCustomers = customers.filter(c => 
    c.id !== customer.id && 
    c.name.toLowerCase().includes(referralSearch.toLowerCase())
  );

  const handleReferralSelect = (customerName: string) => {
    setLeadInfo({...leadInfo, referredBy: customerName});
    setReferralSearch(customerName);
    setShowReferralDropdown(false);
  };

  const handleReferralInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setReferralSearch(value);
    setLeadInfo({...leadInfo, referredBy: value});
    if (value.length > 0) {
      setShowReferralDropdown(true);
    } else {
      setShowReferralDropdown(false);
    }
  };

  if (isEditing) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
        {/* Edit Form */}
        <div className="p-4 sm:p-6 border-b border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Edit Customer</h3>
            <div className="flex items-center space-x-2">
              <button
                onClick={handleCancel}
                className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                title="Cancel"
              >
                <Trash2 className="h-4 w-4" />
              </button>
              <button
                onClick={handleSave}
                className="p-2 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                title="Save"
              >
                <CheckSquare className="h-4 w-4" />
              </button>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
              <input
                type="text"
                value={editedCustomer.name}
                onChange={(e) => setEditedCustomer({...editedCustomer, name: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
              <input
                type="text"
                value={editedCustomer.phone || ''}
                onChange={(e) => setEditedCustomer({...editedCustomer, phone: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <input
                type="email"
                value={editedCustomer.email || ''}
                onChange={(e) => setEditedCustomer({...editedCustomer, email: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Service Address</label>
              <input
                type="text"
                value={editedCustomer.address || ''}
                onChange={(e) => setEditedCustomer({...editedCustomer, address: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-sm font-medium text-gray-700">Billing Address</label>
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    checked={showBillingAddress}
                    onChange={(e) => setShowBillingAddress(e.target.checked)}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 mr-2"
                  />
                  <span className="text-xs text-gray-500">Different from service address</span>
                </div>
              </div>
              {showBillingAddress && (
                <input
                  type="text"
                  value={billingAddress}
                  onChange={(e) => setBillingAddress(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
              <textarea
                value={editedCustomer.notes || ''}
                onChange={(e) => setEditedCustomer({...editedCustomer, notes: e.target.value})}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          
          {/* Additional Contacts Section */}
          <div className="mt-6 pt-4 border-t border-gray-200">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-medium text-gray-900">Additional Contacts</h4>
              <button
                onClick={addContact}
                className="flex items-center text-xs px-2 py-1 bg-blue-50 text-blue-600 rounded hover:bg-blue-100 transition-colors"
              >
                <Plus className="h-3 w-3 mr-1" />
                Add Contact
              </button>
            </div>
            
            {additionalContacts.length === 0 ? (
              <p className="text-sm text-gray-500">No additional contacts added</p>
            ) : (
              <div className="space-y-3">
                {additionalContacts.map((contact, index) => (
                  <div key={index} className="p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h5 className="text-sm font-medium text-gray-900">Contact #{index + 1}</h5>
                      <button
                        onClick={() => removeContact(index)}
                        className="text-xs text-red-600 hover:text-red-800"
                      >
                        Remove
                      </button>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <div>
                        <input
                          type="text"
                          placeholder="Name"
                          value={contact.name}
                          onChange={(e) => updateContact(index, 'name', e.target.value)}
                          className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg"
                        />
                      </div>
                      <div>
                        <input
                          type="text"
                          placeholder="Role (e.g., Spouse, Assistant)"
                          value={contact.role}
                          onChange={(e) => updateContact(index, 'role', e.target.value)}
                          className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg"
                        />
                      </div>
                      <div>
                        <input
                          type="text"
                          placeholder="Phone"
                          value={contact.phone}
                          onChange={(e) => updateContact(index, 'phone', e.target.value)}
                          className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg"
                        />
                      </div>
                      <div>
                        <input
                          type="email"
                          placeholder="Email"
                          value={contact.email}
                          onChange={(e) => updateContact(index, 'email', e.target.value)}
                          className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          {/* Lead Marketing Information */}
          <div className="mt-6 pt-4 border-t border-gray-200">
            <h4 className="text-sm font-medium text-gray-900 mb-3">Lead Marketing Information</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-gray-700 mb-1">Lead Source</label>
                {showNewLeadSourceInput ? (
                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={newLeadSource}
                      onChange={(e) => setNewLeadSource(e.target.value)}
                      className="flex-1 px-3 py-2 text-sm border border-gray-300 rounded-lg"
                      placeholder="Enter new lead source"
                    />
                    <button
                      onClick={() => setShowNewLeadSourceInput(false)}
                      className="text-xs text-gray-500 hover:text-gray-700"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <select
                    value={leadInfo.source}
                    onChange={handleLeadSourceChange}
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg"
                  >
                    <option value="">Select Source</option>
                    <option value="CALLRAIL">CallRail</option>
                    <option value="FORM">Web Form</option>
                    <option value="REFERRAL">Referral</option>
                    <option value="DIRECT">Direct</option>
                    <option value="GOOGLE">Google</option>
                    <option value="FACEBOOK">Facebook</option>
                    <option value="OTHER">Other</option>
                    <option value="ADD_NEW">+ Add New Source</option>
                  </select>
                )}
              </div>
              <div>
                <label className="block text-xs text-gray-700 mb-1">Lead Cost</label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <input
                    type="number"
                    value={leadInfo.cost}
                    onChange={(e) => setLeadInfo({...leadInfo, cost: parseFloat(e.target.value) || 0})}
                    className="w-full pl-10 pr-3 py-2 text-sm border border-gray-300 rounded-lg"
                    placeholder="0.00"
                    step="0.01"
                    min="0"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs text-gray-700 mb-1">Campaign</label>
                <input
                  type="text"
                  value={leadInfo.campaign}
                  onChange={(e) => setLeadInfo({...leadInfo, campaign: e.target.value})}
                  className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg"
                  placeholder="Campaign name"
                />
              </div>
              <div className="relative" ref={referralDropdownRef}>
                <label className="block text-xs text-gray-700 mb-1">Referred By</label>
                <input
                  type="text"
                  value={referralSearch}
                  onChange={handleReferralInputChange}
                  onFocus={() => referralSearch && setShowReferralDropdown(true)}
                  className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg"
                  placeholder="Search existing customers"
                />
                {showReferralDropdown && (
                  <div className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-48 overflow-y-auto">
                    {filteredCustomers.length > 0 ? (
                      <div>
                        {filteredCustomers.map(c => (
                          <div 
                            key={c.id} 
                            className="px-3 py-2 hover:bg-gray-100 cursor-pointer text-sm"
                            onClick={() => handleReferralSelect(c.name)}
                          >
                            {c.name}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="px-3 py-2 text-sm text-gray-500">
                        No matches found. Enter name to add as new referral.
                      </div>
                    )}
                  </div>
                )}
              </div>
              <div className="col-span-1 sm:col-span-2">
                <label className="block text-xs text-gray-700 mb-1">Marketing Notes</label>
                <input
                  type="text"
                  value={leadInfo.notes}
                  onChange={(e) => setLeadInfo({...leadInfo, notes: e.target.value})}
                  className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg"
                  placeholder="Additional marketing details"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
      {/* Customer Header */}
      <div className="p-4 sm:p-6 border-b border-gray-100">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              {customer.name}
            </h3>
            
            <div className="space-y-2">
              {customer.phone && (
                <div className="flex items-center text-sm text-gray-600">
                  <Phone className="h-4 w-4 mr-2 text-gray-400" />
                  {formatPhone(customer.phone)}
                </div>
              )}
              
              {customer.email && (
                <div className="flex items-center text-sm text-gray-600">
                  <Mail className="h-4 w-4 mr-2 text-gray-400" />
                  {customer.email}
                </div>
              )}
              
              {customer.address && (
                <div className="flex items-start text-sm text-gray-600">
                  <MapPin className="h-4 w-4 mr-2 text-gray-400 mt-0.5 flex-shrink-0" />
                  <span className="line-clamp-2">{customer.address}</span>
                </div>
              )}

              {customer.billingAddress && customer.billingAddress !== customer.address && (
                <div className="flex items-start text-sm text-gray-600">
                  <CreditCard className="h-4 w-4 mr-2 text-gray-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <span className="text-xs font-medium text-gray-500">Billing Address:</span>
                    <span className="block line-clamp-2">{customer.billingAddress}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Lead Marketing Information - Compact View */}
            {(customer.leadSource || customer.leadCost || customer.referredBy) && (
              <div className="mt-3 pt-3 border-t border-gray-100">
                <div className="flex flex-wrap gap-2">
                  {customer.leadSource && (
                    <div className="flex items-center text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded">
                      <Tag className="h-3 w-3 mr-1" />
                      <span>{customer.leadSource}</span>
                    </div>
                  )}
                  {customer.leadCost > 0 && (
                    <div className="flex items-center text-xs bg-green-50 text-green-700 px-2 py-1 rounded">
                      <DollarSign className="h-3 w-3 mr-1" />
                      <span>${customer.leadCost.toFixed(2)}</span>
                    </div>
                  )}
                  {customer.leadCampaign && (
                    <div className="flex items-center text-xs bg-purple-50 text-purple-700 px-2 py-1 rounded">
                      <ExternalLink className="h-3 w-3 mr-1" />
                      <span>{customer.leadCampaign}</span>
                    </div>
                  )}
                  {customer.referredBy && (
                    <div className="flex items-center text-xs bg-amber-50 text-amber-700 px-2 py-1 rounded">
                      <User className="h-3 w-3 mr-1" />
                      <span>Referred by: {customer.referredBy}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Additional Contacts - Compact View */}
            {customer.additionalContacts && customer.additionalContacts.length > 0 && (
              <div className="mt-3 pt-3 border-t border-gray-100">
                <h4 className="text-xs font-medium text-gray-500 mb-2">Additional Contacts:</h4>
                <div className="space-y-2">
                  {customer.additionalContacts.map((contact, index) => (
                    <div key={index} className="flex items-center text-sm text-gray-600">
                      <User className="h-3 w-3 mr-2 text-gray-400" />
                      <span>{contact.name}</span>
                      {contact.role && <span className="text-xs text-gray-500 ml-1">({contact.role})</span>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          <div className="flex items-center space-x-2 ml-4">
            <button
              onClick={() => onView(customer)}
              className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
              title="View Details"
            >
              <Eye className="h-4 w-4" />
            </button>
            <button
              onClick={() => setIsEditing(true)}
              className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
              title="Edit"
            >
              <Edit className="h-4 w-4" />
            </button>
            <button
              onClick={() => onDelete(customer.id)}
              className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              title="Delete"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        </div>
        
        {customer.notes && (
          <div className="mb-4">
            <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg line-clamp-2">
              {customer.notes}
            </p>
          </div>
        )}
      </div>

      {/* Customer Stats */}
      <div className="p-4">
        <div className="grid grid-cols-2 gap-3">
          <div className="flex items-center space-x-2 p-2 bg-blue-50 rounded-lg">
            <Users className="h-4 w-4 text-blue-600" />
            <div>
              <div className="text-sm font-medium text-blue-900">{stats.leads}</div>
              <div className="text-xs text-blue-600">Leads</div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 p-2 bg-green-50 rounded-lg">
            <Briefcase className="h-4 w-4 text-green-600" />
            <div>
              <div className="text-sm font-medium text-green-900">{stats.jobs}</div>
              <div className="text-xs text-green-600">Jobs</div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 p-2 bg-amber-50 rounded-lg">
            <CheckSquare className="h-4 w-4 text-amber-600" />
            <div>
              <div className="text-sm font-medium text-amber-900">{stats.tasks}</div>
              <div className="text-xs text-amber-600">Tasks</div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 p-2 bg-purple-50 rounded-lg">
            <MessageSquare className="h-4 w-4 text-purple-600" />
            <div>
              <div className="text-sm font-medium text-purple-900">{stats.messages}</div>
              <div className="text-xs text-purple-600">Messages</div>
            </div>
          </div>
        </div>
      </div>

      {/* Customer Footer */}
      <div className="px-4 sm:px-6 py-3 bg-gray-50 border-t border-gray-100 rounded-b-lg">
        <div className="flex items-center justify-between text-xs text-gray-500">
          <span>Customer since {formatDate(customer.createdAt)}</span>
          {stats.files > 0 && (
            <div className="flex items-center space-x-1">
              <FileText className="h-3 w-3" />
              <span>{stats.files} files</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Import at the top
import { useCrmStore } from '../../stores/crmStore';