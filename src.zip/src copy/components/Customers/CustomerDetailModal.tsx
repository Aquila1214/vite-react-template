import React, { useState, useEffect } from 'react';
import { X, User, Phone, Mail, MapPin, Eye, Edit, Trash2, Users, Briefcase, FileText, MessageSquare, CheckSquare, CreditCard, DollarSign, Tag, ExternalLink, FileImage, Clock, Calendar, Plus, Save } from 'lucide-react';
import { Customer, Estimate, Invoice, FileUpload } from '../../types';
import { formatDate, formatPhone, formatCurrency } from '../../lib/utils';
import { CustomerFileGallery } from '../Files/CustomerFileGallery';
import { useCrmStore } from '../../stores/crmStore';

interface CustomerDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  customer: Customer | null;
}

export const CustomerDetailModal: React.FC<CustomerDetailModalProps> = ({ isOpen, onClose, customer }) => {
  const { estimates, invoices, updateCustomer } = useCrmStore();
  const [activeTab, setActiveTab] = useState<'overview' | 'files' | 'jobs' | 'leads' | 'messages' | 'estimates' | 'invoices' | 'activity' | 'notes'>('overview');
  const [notesValue, setNotesValue] = useState('');
  const [isEditingNotes, setIsEditingNotes] = useState(false);

  useEffect(() => {
    if (customer) {
      setNotesValue(customer.notes || '');
    }
  }, [customer]);

  if (!isOpen || !customer) return null;

  const stats = {
    leads: customer.leads?.length || 0,
    jobs: customer.jobs?.length || 0,
    tasks: customer.tasks?.filter(t => t.status !== 'COMPLETED').length || 0,
    messages: customer.messages?.length || 0,
    files: customer.files?.length || 0,
    estimates: estimates.filter(e => e.customerId === customer.id).length || 0,
    invoices: invoices.filter(i => i.customerId === customer.id).length || 0,
  };

  // Get customer-specific estimates and invoices
  const customerEstimates = estimates.filter(e => e.customerId === customer.id);
  const customerInvoices = invoices.filter(i => i.customerId === customer.id);

  // Generate activity items from various sources
  const generateActivityItems = () => {
    const activities: {
      id: string;
      type: string;
      title: string;
      description: string;
      timestamp: string;
      icon: React.ReactNode;
    }[] = [];

    // Add lead activities
    if (customer.leads) {
      customer.leads.forEach(lead => {
        activities.push({
          id: `lead-${lead.id}`,
          type: 'lead',
          title: 'Lead Created',
          description: `New lead with status: ${lead.status.replace('_', ' ')}`,
          timestamp: lead.createdAt,
          icon: <Users className="h-5 w-5 text-blue-600" />
        });
      });
    }

    // Add job activities
    if (customer.jobs) {
      customer.jobs.forEach(job => {
        activities.push({
          id: `job-${job.id}`,
          type: 'job',
          title: 'Job Created',
          description: `New job at ${job.location}`,
          timestamp: job.createdAt,
          icon: <Briefcase className="h-5 w-5 text-green-600" />
        });
      });
    }

    // Add message activities
    if (customer.messages) {
      customer.messages.forEach(message => {
        activities.push({
          id: `message-${message.id}`,
          type: 'message',
          title: message.direction === 'INBOUND' ? 'Message Received' : 'Message Sent',
          description: message.content.length > 100 ? `${message.content.substring(0, 100)}...` : message.content,
          timestamp: message.timestamp,
          icon: <MessageSquare className="h-5 w-5 text-purple-600" />
        });
      });
    }

    // Add estimate activities
    customerEstimates.forEach(estimate => {
      activities.push({
        id: `estimate-${estimate.id}`,
        type: 'estimate',
        title: 'Estimate Created',
        description: `Estimate for ${formatCurrency(estimate.total)}`,
        timestamp: estimate.createdAt,
        icon: <FileText className="h-5 w-5 text-amber-600" />
      });

      if (estimate.accepted) {
        activities.push({
          id: `estimate-accepted-${estimate.id}`,
          type: 'estimate',
          title: 'Estimate Accepted',
          description: `Estimate for ${formatCurrency(estimate.total)} was accepted`,
          timestamp: estimate.signedAt || estimate.updatedAt,
          icon: <CheckSquare className="h-5 w-5 text-green-600" />
        });
      }
    });

    // Add invoice activities
    customerInvoices.forEach(invoice => {
      activities.push({
        id: `invoice-${invoice.id}`,
        type: 'invoice',
        title: 'Invoice Created',
        description: `Invoice for ${formatCurrency(invoice.amount)}`,
        timestamp: invoice.createdAt,
        icon: <CreditCard className="h-5 w-5 text-red-600" />
      });

      if (invoice.status === 'PAID') {
        activities.push({
          id: `invoice-paid-${invoice.id}`,
          type: 'invoice',
          title: 'Invoice Paid',
          description: `Payment received for ${formatCurrency(invoice.amount)}`,
          timestamp: invoice.updatedAt,
          icon: <DollarSign className="h-5 w-5 text-green-600" />
        });
      }
    });

    // Sort by timestamp (newest first)
    return activities.sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  };

  const sortedActivityItems = generateActivityItems();

  const handleSaveNotes = () => {
    // In a real implementation, this would call an API to update the customer notes
    console.log('Saving notes:', notesValue);
    updateCustomer(customer.id, { notes: notesValue });
    setIsEditingNotes(false);
  };

  const renderOverviewTab = () => (
    <div className="space-y-6">
      {/* Customer Information */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Customer Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <div className="text-sm text-gray-500">Name</div>
              <div className="text-lg font-medium text-gray-900">{customer.name}</div>
            </div>
            
            {customer.phone && (
              <div>
                <div className="text-sm text-gray-500">Phone</div>
                <div className="text-lg font-medium text-gray-900">{formatPhone(customer.phone)}</div>
              </div>
            )}
            
            {customer.email && (
              <div>
                <div className="text-sm text-gray-500">Email</div>
                <div className="text-lg font-medium text-gray-900">{customer.email}</div>
              </div>
            )}
          </div>
          
          <div className="space-y-4">
            {customer.address && (
              <div>
                <div className="text-sm text-gray-500">Service Address</div>
                <div className="text-lg font-medium text-gray-900">{customer.address}</div>
              </div>
            )}
            
            {customer.billingAddress && (
              <div>
                <div className="text-sm text-gray-500">Billing Address</div>
                <div className="text-lg font-medium text-gray-900">{customer.billingAddress}</div>
              </div>
            )}
            
            <div>
              <div className="text-sm text-gray-500">Customer Since</div>
              <div className="text-lg font-medium text-gray-900">{formatDate(customer.createdAt)}</div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Lead Information */}
      {customer.leadSource && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Lead Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <div className="text-sm text-gray-500">Lead Source</div>
                <div className="text-lg font-medium text-gray-900">{customer.leadSource}</div>
              </div>
              
              {customer.leadCampaign && (
                <div>
                  <div className="text-sm text-gray-500">Campaign</div>
                  <div className="text-lg font-medium text-gray-900">{customer.leadCampaign}</div>
                </div>
              )}
            </div>
            
            <div className="space-y-4">
              {customer.leadCost !== undefined && customer.leadCost > 0 && (
                <div>
                  <div className="text-sm text-gray-500">Lead Cost</div>
                  <div className="text-lg font-medium text-gray-900">${customer.leadCost.toFixed(2)}</div>
                </div>
              )}
              
              {customer.referredBy && (
                <div>
                  <div className="text-sm text-gray-500">Referred By</div>
                  <div className="text-lg font-medium text-gray-900">{customer.referredBy}</div>
                </div>
              )}
            </div>
          </div>
          
          {customer.leadNotes && (
            <div className="mt-4 pt-4 border-t border-gray-100">
              <div className="text-sm text-gray-500">Lead Notes</div>
              <div className="text-base text-gray-900 mt-1">{customer.leadNotes}</div>
            </div>
          )}
        </div>
      )}
      
      {/* Additional Contacts */}
      {customer.additionalContacts && customer.additionalContacts.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Additional Contacts</h3>
          <div className="space-y-4">
            {customer.additionalContacts.map((contact, index) => (
              <div key={index} className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-base font-medium text-gray-900">{contact.name}</div>
                  {contact.role && (
                    <div className="text-sm text-gray-500">{contact.role}</div>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {contact.phone && (
                    <div className="flex items-center text-sm text-gray-600">
                      <Phone className="h-4 w-4 mr-2 text-gray-400" />
                      {formatPhone(contact.phone)}
                    </div>
                  )}
                  
                  {contact.email && (
                    <div className="flex items-center text-sm text-gray-600">
                      <Mail className="h-4 w-4 mr-2 text-gray-400" />
                      {contact.email}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Notes */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Notes</h3>
        {customer.notes ? (
          <div className="text-base text-gray-900">{customer.notes}</div>
        ) : (
          <div className="text-base text-gray-500 italic">No notes available for this customer.</div>
        )}
      </div>
    </div>
  );

  const renderFilesTab = () => (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <CustomerFileGallery customerId={customer.id} />
    </div>
  );

  const renderJobsTab = () => (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-medium text-gray-900">Jobs</h3>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          Create Job
        </button>
      </div>
      
      {customer.jobs && customer.jobs.length > 0 ? (
        <div className="space-y-4">
          {customer.jobs.map(job => (
            <div key={job.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-base font-medium text-gray-900">{job.location}</div>
                  <div className="flex items-center space-x-4 mt-2">
                    <div className="flex items-center text-sm text-gray-600">
                      <Calendar className="h-4 w-4 mr-1" />
                      {job.startDate ? formatDate(job.startDate) : 'Not scheduled'}
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Tag className="h-4 w-4 mr-1" />
                      {job.status}
                    </div>
                  </div>
                </div>
                
                <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors">
                  <Eye className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <Briefcase className="h-8 w-8 mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500">No jobs found for this customer</p>
        </div>
      )}
    </div>
  );

  const renderLeadsTab = () => (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-medium text-gray-900">Leads</h3>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          Create Lead
        </button>
      </div>
      
      {customer.leads && customer.leads.length > 0 ? (
        <div className="space-y-4">
          {customer.leads.map(lead => (
            <div key={lead.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-base font-medium text-gray-900">Lead #{lead.id.slice(-6)}</div>
                  <div className="flex items-center space-x-4 mt-2">
                    <div className="flex items-center text-sm text-gray-600">
                      <Tag className="h-4 w-4 mr-1" />
                      {lead.status.replace('_', ' ')}
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Calendar className="h-4 w-4 mr-1" />
                      {formatDate(lead.createdAt)}
                    </div>
                  </div>
                </div>
                
                <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors">
                  <Eye className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <Users className="h-8 w-8 mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500">No leads found for this customer</p>
        </div>
      )}
    </div>
  );

  const renderMessagesTab = () => (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-medium text-gray-900">Messages</h3>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          Send Message
        </button>
      </div>
      
      {customer.messages && customer.messages.length > 0 ? (
        <div className="space-y-4">
          {customer.messages.map(message => (
            <div key={message.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
              <div className="flex items-start">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <div className="text-base font-medium text-gray-900">
                      {message.direction === 'INBOUND' ? customer.name : 'Company'}
                    </div>
                    <div className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-800">
                      {message.type}
                    </div>
                    <div className="text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-800">
                      {message.direction}
                    </div>
                  </div>
                  
                  <div className="text-sm text-gray-600">{message.content}</div>
                  
                  <div className="text-xs text-gray-500 mt-2">
                    {formatDate(message.timestamp)}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <MessageSquare className="h-8 w-8 mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500">No messages found for this customer</p>
        </div>
      )}
    </div>
  );

  const renderEstimatesTab = () => (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-medium text-gray-900">Estimates</h3>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          <Plus className="h-4 w-4 mr-2 inline" />
          Create Estimate
        </button>
      </div>
      
      {customerEstimates.length > 0 ? (
        <div className="space-y-4">
          {customerEstimates.map(estimate => (
            <div key={estimate.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-base font-medium text-gray-900">
                    Estimate #{estimate.id.slice(-6)}
                  </div>
                  <div className="text-lg font-bold text-gray-900 mt-1">
                    {formatCurrency(estimate.total)}
                  </div>
                  <div className="flex items-center space-x-4 mt-2">
                    <div className="flex items-center text-sm text-gray-600">
                      <Calendar className="h-4 w-4 mr-1" />
                      {formatDate(estimate.createdAt)}
                    </div>
                    <div className="flex items-center text-sm">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                        estimate.accepted ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {estimate.accepted ? 'Accepted' : 'Pending'}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors">
                    <Eye className="h-4 w-4" />
                  </button>
                  <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors">
                    <Edit className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <FileText className="h-8 w-8 mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500">No estimates found for this customer</p>
        </div>
      )}
    </div>
  );

  const renderInvoicesTab = () => (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-medium text-gray-900">Invoices</h3>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          <Plus className="h-4 w-4 mr-2 inline" />
          Create Invoice
        </button>
      </div>
      
      {customerInvoices.length > 0 ? (
        <div className="space-y-4">
          {customerInvoices.map(invoice => (
            <div key={invoice.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-base font-medium text-gray-900">
                    Invoice #{invoice.id.slice(-6)}
                  </div>
                  <div className="text-lg font-bold text-gray-900 mt-1">
                    {formatCurrency(invoice.amount)}
                  </div>
                  <div className="flex items-center space-x-4 mt-2">
                    <div className="flex items-center text-sm text-gray-600">
                      <Calendar className="h-4 w-4 mr-1" />
                      Due: {formatDate(invoice.dueDate)}
                    </div>
                    <div className="flex items-center text-sm">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                        invoice.status === 'PAID' ? 'bg-green-100 text-green-800' : 
                        invoice.status === 'OVERDUE' ? 'bg-red-100 text-red-800' : 
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {invoice.status}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  {invoice.stripePaymentUrl && (
                    <a 
                      href={invoice.stripePaymentUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                    >
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  )}
                  <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors">
                    <Eye className="h-4 w-4" />
                  </button>
                  <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors">
                    <Edit className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <CreditCard className="h-8 w-8 mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500">No invoices found for this customer</p>
        </div>
      )}
    </div>
  );

  const renderActivityTab = () => (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-6">Activity History</h3>
      
      {sortedActivityItems.length > 0 ? (
        <div className="space-y-6">
          {sortedActivityItems.map((activity, index) => (
            <div key={activity.id} className="relative">
              {/* Timeline connector */}
              {index < sortedActivityItems.length - 1 && (
                <div className="absolute top-8 bottom-0 left-4 w-0.5 bg-gray-200"></div>
              )}
              
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 mt-1">
                  <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                    {activity.icon}
                  </div>
                </div>
                
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <h4 className="text-base font-medium text-gray-900">{activity.title}</h4>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-800">
                      {activity.type}
                    </span>
                  </div>
                  
                  <p className="text-sm text-gray-600 mt-1">{activity.description}</p>
                  
                  <div className="flex items-center text-xs text-gray-500 mt-2">
                    <Clock className="h-3 w-3 mr-1" />
                    {formatDate(activity.timestamp)}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <Clock className="h-8 w-8 mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500">No activity found for this customer</p>
        </div>
      )}
    </div>
  );

  const renderNotesTab = () => (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-gray-900">Notes</h3>
        {!isEditingNotes ? (
          <button 
            onClick={() => setIsEditingNotes(true)}
            className="px-3 py-1 text-sm bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            <Edit className="h-4 w-4 mr-1 inline" />
            Edit Notes
          </button>
        ) : (
          <div className="flex items-center space-x-2">
            <button 
              onClick={() => {
                setIsEditingNotes(false);
                setNotesValue(customer.notes || '');
              }}
              className="px-3 py-1 text-sm bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
            >
              <X className="h-4 w-4 mr-1 inline" />
              Cancel
            </button>
            <button 
              onClick={handleSaveNotes}
              className="px-3 py-1 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Save className="h-4 w-4 mr-1 inline" />
              Save
            </button>
          </div>
        )}
      </div>
      
      {isEditingNotes ? (
        <textarea
          value={notesValue}
          onChange={(e) => setNotesValue(e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          rows={10}
          placeholder="Add notes about this customer..."
        />
      ) : (
        <div className="bg-gray-50 p-4 rounded-lg">
          {customer.notes ? (
            <p className="text-gray-700 whitespace-pre-wrap">{customer.notes}</p>
          ) : (
            <p className="text-gray-500 italic">No notes available for this customer.</p>
          )}
        </div>
      )}
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview': return renderOverviewTab();
      case 'files': return renderFilesTab();
      case 'jobs': return renderJobsTab();
      case 'leads': return renderLeadsTab();
      case 'messages': return renderMessagesTab();
      case 'estimates': return renderEstimatesTab();
      case 'invoices': return renderInvoicesTab();
      case 'activity': return renderActivityTab();
      case 'notes': return renderNotesTab();
      default: return renderOverviewTab();
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-6xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900">{customer.name}</h2>
            <p className="text-gray-600">Customer Details</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-6 w-6 text-gray-500" />
          </button>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200 overflow-x-auto">
          <nav className="flex space-x-8 px-6 min-w-max">
            {[
              { id: 'overview', label: 'Overview', icon: User },
              { id: 'files', label: 'Files', icon: FileImage, count: stats.files },
              { id: 'jobs', label: 'Jobs', icon: Briefcase, count: stats.jobs },
              { id: 'leads', label: 'Leads', icon: Users, count: stats.leads },
              { id: 'messages', label: 'Messages', icon: MessageSquare, count: stats.messages },
              { id: 'estimates', label: 'Estimates', icon: FileText, count: stats.estimates },
              { id: 'invoices', label: 'Invoices', icon: CreditCard, count: stats.invoices },
              { id: 'activity', label: 'Activity Log', icon: Clock, count: sortedActivityItems.length },
              { id: 'notes', label: 'Notes', icon: MessageSquare },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                  {tab.count !== undefined && tab.count > 0 && (
                    <span className="bg-gray-100 text-gray-600 py-0.5 px-2 rounded-full text-xs">
                      {tab.count}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto" style={{ maxHeight: 'calc(90vh - 200px)' }}>
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
};