import React, { useState, useEffect, useRef } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { X, Calendar, User, Users, FileText, Clock, Search, Bell, Tag, Building } from 'lucide-react';
import { Task, User as UserType, Customer, Location } from '../../types';
import { formatDate } from '../../lib/utils';
import { useCrmStore } from '../../stores/crmStore';
import { useLocationStore } from '../../stores/locationStore';

const taskSchema = z.object({
  description: z.string().min(2, 'Description is required'),
  dueDate: z.string().min(1, 'Due date is required'),
  status: z.enum(['PENDING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED']),
  notes: z.string().optional(),
  type: z.enum(['TASK', 'REMINDER']),
  priority: z.enum(['LOW', 'MEDIUM', 'HIGH', 'URGENT']),
  locationId: z.string().optional(),
});

type TaskFormData = z.infer<typeof taskSchema>;

interface TaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Partial<Task>) => Promise<void>;
  task?: Task | null;
  users: UserType[];
  customers: Customer[];
  isLoading?: boolean;
  initialTaskType?: 'TASK' | 'REMINDER';
}

export const TaskModal: React.FC<TaskModalProps> = ({
  isOpen,
  onClose,
  onSave,
  task,
  users,
  customers,
  isLoading = false,
  initialTaskType = 'TASK',
}) => {
  const { locations, fetchLocations } = useLocationStore();
  const isEditing = !!task;
  const [selectedAssignees, setSelectedAssignees] = useState<string[]>([]);
  const [customerSearchTerm, setCustomerSearchTerm] = useState('');
  const [showCustomerDropdown, setShowCustomerDropdown] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [userSearchTerm, setUserSearchTerm] = useState('');
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  
  const userDropdownRef = useRef<HTMLDivElement>(null);
  const customerDropdownRef = useRef<HTMLDivElement>(null);
  
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    watch,
  } = useForm<TaskFormData>({
    resolver: zodResolver(taskSchema),
    defaultValues: {
      description: task?.description || '',
      dueDate: task?.dueDate ? new Date(task.dueDate).toISOString().slice(0, 16) : '',
      status: task?.status || 'PENDING',
      notes: task?.notes || '',
      type: task?.type || initialTaskType,
      priority: task?.priority || 'MEDIUM',
      locationId: task?.locationId || locations[0]?.id || '',
    },
  });

  const taskType = watch('type');

  useEffect(() => {
    fetchLocations();
  }, [fetchLocations]);

  useEffect(() => {
    if (isOpen && task) {
      reset({
        description: task.description,
        dueDate: new Date(task.dueDate).toISOString().slice(0, 16),
        status: task.status,
        notes: task.notes || '',
        type: task.type || 'TASK',
        priority: task.priority || 'MEDIUM',
        locationId: task.locationId || locations[0]?.id || '',
      });
      setSelectedAssignees(task.assignedTo ? [task.assignedTo] : []);
      
      if (task.customerId) {
        const customer = customers.find(c => c.id === task.customerId);
        setSelectedCustomer(customer || null);
      } else {
        setSelectedCustomer(null);
      }
    } else if (isOpen && !task) {
      // Set default due date to tomorrow
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(9, 0, 0, 0);
      
      reset({
        description: '',
        dueDate: tomorrow.toISOString().slice(0, 16),
        status: 'PENDING',
        notes: '',
        type: initialTaskType,
        priority: 'MEDIUM',
        locationId: locations[0]?.id || '',
      });
      setSelectedAssignees([]);
      setSelectedCustomer(null);
    }
  }, [isOpen, task, reset, customers, initialTaskType, locations]);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (userDropdownRef.current && !userDropdownRef.current.contains(event.target as Node)) {
        setShowUserDropdown(false);
      }
      if (customerDropdownRef.current && !customerDropdownRef.current.contains(event.target as Node)) {
        setShowCustomerDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const onSubmit = async (data: TaskFormData) => {
    try {
      if (selectedAssignees.length === 0) {
        alert("Please select at least one assignee");
        return;
      }

      // Create a task for each assignee
      for (const assigneeId of selectedAssignees) {
        const taskData: Partial<Task> = {
          description: data.description,
          dueDate: data.dueDate,
          assignedTo: assigneeId,
          status: data.status,
          customerId: selectedCustomer?.id,
          notes: data.notes,
          type: data.type,
          priority: data.priority,
          locationId: data.locationId,
        };

        await onSave(taskData);
      }
      
      onClose();
    } catch (error) {
      console.error('Failed to save task:', error);
    }
  };

  const handleAssigneeToggle = (userId: string) => {
    setSelectedAssignees(prev => 
      prev.includes(userId)
        ? prev.filter(id => id !== userId)
        : [...prev, userId]
    );
  };

  const handleCustomerSelect = (customer: Customer) => {
    setSelectedCustomer(customer);
    setCustomerSearchTerm(customer.name);
    setShowCustomerDropdown(false);
  };

  const filteredCustomers = customers.filter(customer => 
    customer.name.toLowerCase().includes(customerSearchTerm.toLowerCase()) ||
    customer.email?.toLowerCase().includes(customerSearchTerm.toLowerCase()) ||
    customer.phone?.includes(customerSearchTerm)
  );

  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(userSearchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(userSearchTerm.toLowerCase())
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">
            {isEditing ? `Edit ${taskType === 'TASK' ? 'Task' : 'Reminder'}` : `Create New ${taskType === 'TASK' ? 'Task' : 'Reminder'}`}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-6">
          {/* Task Type */}
          <div className="flex items-center space-x-4">
            <label className="inline-flex items-center">
              <input
                type="radio"
                {...register('type')}
                value="TASK"
                className="form-radio h-4 w-4 text-blue-600"
              />
              <span className="ml-2 text-sm text-gray-700">Task</span>
            </label>
            <label className="inline-flex items-center">
              <input
                type="radio"
                {...register('type')}
                value="REMINDER"
                className="form-radio h-4 w-4 text-amber-600"
              />
              <span className="ml-2 text-sm text-gray-700">Reminder</span>
            </label>
          </div>

          {/* Task Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {taskType === 'TASK' ? 'Task Description' : 'Reminder'} *
            </label>
            <input
              {...register('description')}
              type="text"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder={taskType === 'TASK' ? "Enter task description" : "Enter reminder description"}
            />
            {errors.description && (
              <p className="mt-1 text-sm text-red-600">{errors.description.message}</p>
            )}
          </div>

          {/* Due Date & Status */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Due Date & Time *
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  {...register('dueDate')}
                  type="datetime-local"
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              {errors.dueDate && (
                <p className="mt-1 text-sm text-red-600">{errors.dueDate.message}</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Status
              </label>
              <div className="relative">
                <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <select
                  {...register('status')}
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="PENDING">Pending</option>
                  <option value="IN_PROGRESS">In Progress</option>
                  <option value="COMPLETED">Completed</option>
                  <option value="CANCELLED">Cancelled</option>
                </select>
              </div>
            </div>
          </div>

          {/* Priority */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Priority
            </label>
            <div className="relative">
              <Tag className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <select
                {...register('priority')}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="LOW">Low</option>
                <option value="MEDIUM">Medium</option>
                <option value="HIGH">High</option>
                <option value="URGENT">Urgent</option>
              </select>
            </div>
          </div>

          {/* Location */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Location
            </label>
            <div className="relative">
              <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <select
                {...register('locationId')}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {locations.map(location => (
                  <option key={location.id} value={location.id}>
                    {location.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Assignee & Related Customer */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div ref={userDropdownRef}>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Assigned To *
              </label>
              <div className="relative">
                <div className="relative">
                  <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <input
                    type="text"
                    value={userSearchTerm}
                    onChange={(e) => {
                      setUserSearchTerm(e.target.value);
                      setShowUserDropdown(true);
                    }}
                    onFocus={() => setShowUserDropdown(true)}
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Search users..."
                  />
                </div>

                {showUserDropdown && (
                  <div className="absolute z-10 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                    {filteredUsers.map(user => (
                      <div key={user.id} className="p-2 hover:bg-gray-100">
                        <label className="flex items-center space-x-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={selectedAssignees.includes(user.id)}
                            onChange={() => handleAssigneeToggle(user.id)}
                            className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                          />
                          <div>
                            <div className="text-sm font-medium">{user.name}</div>
                            <div className="text-xs text-gray-500">{user.role}</div>
                          </div>
                        </label>
                      </div>
                    ))}
                    {filteredUsers.length === 0 && (
                      <div className="p-2 text-sm text-gray-500">No users found</div>
                    )}
                    <div className="p-2 border-t border-gray-100">
                      <button
                        type="button"
                        onClick={() => setShowUserDropdown(false)}
                        className="w-full text-xs text-center text-blue-600 hover:text-blue-800"
                      >
                        Close
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Selected Assignees */}
              {selectedAssignees.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-2">
                  {selectedAssignees.map(userId => {
                    const user = users.find(u => u.id === userId);
                    return user ? (
                      <div key={userId} className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">
                        {user.name}
                        <button
                          type="button"
                          onClick={() => handleAssigneeToggle(userId)}
                          className="ml-1 text-blue-600 hover:text-blue-800"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    ) : null;
                  })}
                </div>
              )}
            </div>
            
            <div ref={customerDropdownRef}>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Related Customer
              </label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  value={customerSearchTerm}
                  onChange={(e) => {
                    setCustomerSearchTerm(e.target.value);
                    setShowCustomerDropdown(true);
                    if (e.target.value === '') {
                      setSelectedCustomer(null);
                    }
                  }}
                  onFocus={() => setShowCustomerDropdown(true)}
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Search customers..."
                />
                
                {showCustomerDropdown && (
                  <div className="absolute z-10 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                    {filteredCustomers.map(customer => (
                      <div 
                        key={customer.id} 
                        className="p-2 hover:bg-gray-100 cursor-pointer"
                        onClick={() => handleCustomerSelect(customer)}
                      >
                        <div className="text-sm font-medium">{customer.name}</div>
                        {customer.email && (
                          <div className="text-xs text-gray-500">{customer.email}</div>
                        )}
                      </div>
                    ))}
                    {filteredCustomers.length === 0 && (
                      <div className="p-2 text-sm text-gray-500">No customers found</div>
                    )}
                    <div className="p-2 border-t border-gray-100">
                      <button
                        type="button"
                        onClick={() => setShowCustomerDropdown(false)}
                        className="w-full text-xs text-center text-blue-600 hover:text-blue-800"
                      >
                        Close
                      </button>
                    </div>
                  </div>
                )}
              </div>
              
              {selectedCustomer && (
                <div className="mt-2 inline-flex items-center px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">
                  {selectedCustomer.name}
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedCustomer(null);
                      setCustomerSearchTerm('');
                    }}
                    className="ml-1 text-green-600 hover:text-green-800"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Notes
            </label>
            <div className="relative">
              <FileText className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <textarea
                {...register('notes')}
                rows={3}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder={`Additional notes about this ${taskType === 'TASK' ? 'task' : 'reminder'}...`}
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end space-x-3 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? 'Saving...' : isEditing ? `Update ${taskType === 'TASK' ? 'Task' : 'Reminder'}` : `Create ${taskType === 'TASK' ? 'Task' : 'Reminder'}`}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};