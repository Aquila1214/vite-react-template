import React, { useState, useEffect, useRef } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { X, User, Calendar, DollarSign, FileText, Plus, Trash2, Search, Building } from 'lucide-react';
import { Estimate, Customer, EstimateLineItem } from '../../types';
import { formatDate, formatCurrency } from '../../lib/utils';
import { useCrmStore } from '../../stores/crmStore';
import { useLocationStore } from '../../stores/locationStore';

const estimateSchema = z.object({
  total: z.number().min(0, 'Total must be a positive number'),
  expirationDate: z.string().min(1, 'Expiration date is required'),
  notes: z.string().optional(),
  terms: z.string().optional(),
  locationId: z.string().optional(),
});

type EstimateFormData = z.infer<typeof estimateSchema>;

interface EstimateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Partial<Estimate>) => Promise<void>;
  estimate?: Estimate | null;
  isLoading?: boolean;
}

export const EstimateModal: React.FC<EstimateModalProps> = ({
  isOpen,
  onClose,
  onSave,
  estimate,
  isLoading = false,
}) => {
  const { customers, jobs } = useCrmStore();
  const { locations, fetchLocations } = useLocationStore();
  const isEditing = !!estimate;
  
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [customerSearchTerm, setCustomerSearchTerm] = useState('');
  const [showCustomerDropdown, setShowCustomerDropdown] = useState(false);
  const [lineItems, setLineItems] = useState<EstimateLineItem[]>([]);
  const [jobId, setJobId] = useState<string | undefined>(undefined);
  
  const customerDropdownRef = useRef<HTMLDivElement>(null);
  
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    watch,
  } = useForm<EstimateFormData>({
    resolver: zodResolver(estimateSchema),
    defaultValues: {
      total: estimate?.total || 0,
      expirationDate: estimate?.expirationDate ? new Date(estimate.expirationDate).toISOString().slice(0, 10) : '',
      notes: estimate?.notes || '',
      terms: estimate?.terms || 'This estimate is valid for 30 days from the date of issue. Payment terms are net 30 days from invoice date.',
      locationId: estimate?.locationId || locations[0]?.id || '',
    },
  });

  useEffect(() => {
    fetchLocations();
  }, [fetchLocations]);

  // Set initial values when estimate changes
  useEffect(() => {
    if (isOpen) {
      if (estimate) {
        reset({
          total: estimate.total,
          expirationDate: estimate.expirationDate ? new Date(estimate.expirationDate).toISOString().slice(0, 10) : '',
          notes: estimate.notes || '',
          terms: estimate.terms || 'This estimate is valid for 30 days from the date of issue. Payment terms are net 30 days from invoice date.',
          locationId: estimate.locationId || locations[0]?.id || '',
        });
        
        setLineItems(estimate.lineItems || []);
        setJobId(estimate.jobId);
        
        // Find related customer
        const customer = customers.find(c => c.id === estimate.customerId);
        setSelectedCustomer(customer || null);
        setCustomerSearchTerm(customer?.name || '');
      } else {
        // Default values for new estimate
        const expirationDate = new Date();
        expirationDate.setDate(expirationDate.getDate() + 30); // Expires in 30 days
        
        reset({
          total: 0,
          expirationDate: expirationDate.toISOString().slice(0, 10),
          notes: '',
          terms: 'This estimate is valid for 30 days from the date of issue. Payment terms are net 30 days from invoice date.',
          locationId: locations[0]?.id || '',
        });
        
        setLineItems([]);
        setJobId(undefined);
        setSelectedCustomer(null);
        setCustomerSearchTerm('');
      }
    }
  }, [isOpen, estimate, customers, reset, locations]);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (customerDropdownRef.current && !customerDropdownRef.current.contains(event.target as Node)) {
        setShowCustomerDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Calculate total when line items change
  useEffect(() => {
    const total = lineItems.reduce((sum, item) => sum + item.total, 0);
    setValue('total', total);
  }, [lineItems, setValue]);

  const onSubmit = async (data: EstimateFormData) => {
    if (!selectedCustomer) {
      alert('Please select a customer');
      return;
    }
    
    if (lineItems.length === 0) {
      alert('Please add at least one line item');
      return;
    }
    
    try {
      const estimateData: Partial<Estimate> = {
        customerId: selectedCustomer.id,
        jobId: jobId,
        total: data.total,
        lineItems: lineItems,
        expirationDate: data.expirationDate,
        notes: data.notes,
        terms: data.terms,
        accepted: estimate?.accepted || false,
        signedAt: estimate?.signedAt,
        locationId: data.locationId,
      };
      
      await onSave(estimateData);
      onClose();
    } catch (error) {
      console.error('Failed to save estimate:', error);
    }
  };

  const handleCustomerSelect = (customer: Customer) => {
    setSelectedCustomer(customer);
    setCustomerSearchTerm(customer.name);
    setShowCustomerDropdown(false);
    
    // Find jobs for this customer
    const customerJobs = jobs.filter(job => job.customerId === customer.id);
    if (customerJobs.length === 1) {
      setJobId(customerJobs[0].id);
    }
  };

  const addLineItem = () => {
    const newItem: EstimateLineItem = {
      id: Date.now().toString(),
      description: '',
      quantity: 1,
      unitPrice: 0,
      total: 0,
    };
    setLineItems([...lineItems, newItem]);
  };

  const updateLineItem = (index: number, field: keyof EstimateLineItem, value: any) => {
    const updatedItems = [...lineItems];
    updatedItems[index] = { ...updatedItems[index], [field]: value };
    
    // Recalculate total if quantity or unitPrice changes
    if (field === 'quantity' || field === 'unitPrice') {
      const quantity = field === 'quantity' ? value : updatedItems[index].quantity;
      const unitPrice = field === 'unitPrice' ? value : updatedItems[index].unitPrice;
      updatedItems[index].total = quantity * unitPrice;
    }
    
    setLineItems(updatedItems);
  };

  const removeLineItem = (index: number) => {
    setLineItems(lineItems.filter((_, i) => i !== index));
  };

  const filteredCustomers = customers.filter(customer => 
    customer.name.toLowerCase().includes(customerSearchTerm.toLowerCase()) ||
    customer.email?.toLowerCase().includes(customerSearchTerm.toLowerCase()) ||
    customer.phone?.includes(customerSearchTerm)
  );

  const customerJobs = selectedCustomer 
    ? jobs.filter(job => job.customerId === selectedCustomer.id)
    : [];

  // Price book items (mock data)
  const priceBookItems = [
    { category: 'Foundation Repair', items: [
      { id: 'fr1', description: 'Foundation Pier Installation', unitPrice: 1200 },
      { id: 'fr2', description: 'Foundation Crack Repair (per linear foot)', unitPrice: 125 },
      { id: 'fr3', description: 'Wall Anchor System (per anchor)', unitPrice: 1500 },
      { id: 'fr4', description: 'Carbon Fiber Reinforcement Strip', unitPrice: 650 },
    ]},
    { category: 'Waterproofing', items: [
      { id: 'wp1', description: 'Interior Drainage System (per linear foot)', unitPrice: 85 },
      { id: 'wp2', description: 'Sump Pump Installation', unitPrice: 1200 },
      { id: 'wp3', description: 'Exterior Waterproofing Membrane (per sq ft)', unitPrice: 12 },
      { id: 'wp4', description: 'Basement Waterproofing Package', unitPrice: 4500 },
    ]},
    { category: 'Concrete Work', items: [
      { id: 'cw1', description: 'Concrete Slab Repair (per sq ft)', unitPrice: 18 },
      { id: 'cw2', description: 'Concrete Driveway Installation (per sq ft)', unitPrice: 15 },
      { id: 'cw3', description: 'Concrete Steps Repair', unitPrice: 1200 },
      { id: 'cw4', description: 'Concrete Leveling (per sq ft)', unitPrice: 8 },
    ]},
    { category: 'Labor & Services', items: [
      { id: 'ls1', description: 'Technician Labor (per hour)', unitPrice: 95 },
      { id: 'ls2', description: 'Engineering Consultation', unitPrice: 350 },
      { id: 'ls3', description: 'Project Management Fee', unitPrice: 750 },
      { id: 'ls4', description: 'Cleanup & Debris Removal', unitPrice: 250 },
    ]},
  ];

  const addFromPriceBook = (item: { description: string, unitPrice: number }) => {
    const newItem: EstimateLineItem = {
      id: Date.now().toString(),
      description: item.description,
      quantity: 1,
      unitPrice: item.unitPrice,
      total: item.unitPrice,
    };
    setLineItems([...lineItems, newItem]);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-5xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">
            {isEditing ? 'Edit Estimate' : 'Create New Estimate'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Customer & Job Info */}
            <div className="lg:col-span-1 space-y-6">
              {/* Customer Selection */}
              <div ref={customerDropdownRef}>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Customer *
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <input
                    type="text"
                    value={customerSearchTerm}
                    onChange={(e) => {
                      setCustomerSearchTerm(e.target.value);
                      setShowCustomerDropdown(true);
                      if (e.target.value === '') {
                        setSelectedCustomer(null);
                      }
                    }}
                    onFocus={() => setShowCustomerDropdown(true)}
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Search customers..."
                    disabled={isEditing} // Can't change customer when editing
                  />
                  
                  {showCustomerDropdown && !isEditing && (
                    <div className="absolute z-10 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                      {filteredCustomers.map(customer => (
                        <div 
                          key={customer.id} 
                          className="p-2 hover:bg-gray-100 cursor-pointer"
                          onClick={() => handleCustomerSelect(customer)}
                        >
                          <div className="text-sm font-medium">{customer.name}</div>
                          {customer.email && (
                            <div className="text-xs text-gray-500">{customer.email}</div>
                          )}
                        </div>
                      ))}
                      {filteredCustomers.length === 0 && (
                        <div className="p-2 text-sm text-gray-500">No customers found</div>
                      )}
                      <div className="p-2 border-t border-gray-100">
                        <button
                          type="button"
                          onClick={() => setShowCustomerDropdown(false)}
                          className="w-full text-xs text-center text-blue-600 hover:text-blue-800"
                        >
                          Close
                        </button>
                      </div>
                    </div>
                  )}
                </div>
                {!selectedCustomer && (
                  <p className="mt-1 text-sm text-red-600">Customer is required</p>
                )}
              </div>

              {/* Customer Details */}
              {selectedCustomer && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-gray-900 mb-2">Customer Details</h3>
                  <div className="space-y-1 text-sm">
                    <p className="text-gray-900">{selectedCustomer.name}</p>
                    {selectedCustomer.phone && (
                      <p className="text-gray-600">{selectedCustomer.phone}</p>
                    )}
                    {selectedCustomer.email && (
                      <p className="text-gray-600">{selectedCustomer.email}</p>
                    )}
                    {selectedCustomer.address && (
                      <p className="text-gray-600">{selectedCustomer.address}</p>
                    )}
                  </div>
                </div>
              )}

              {/* Job Selection */}
              {selectedCustomer && customerJobs.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Related Job
                  </label>
                  <select
                    value={jobId || ''}
                    onChange={(e) => setJobId(e.target.value || undefined)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Select a job (optional)</option>
                    {customerJobs.map(job => (
                      <option key={job.id} value={job.id}>
                        {job.location} - {job.status}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Branch Location */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Branch Location
                </label>
                <div className="relative">
                  <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <select
                    {...register('locationId')}
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    {locations.map(location => (
                      <option key={location.id} value={location.id}>
                        {location.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Estimate Details */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Expiration Date *
                </label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <input
                    type="date"
                    {...register('expirationDate')}
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                {errors.expirationDate && (
                  <p className="mt-1 text-sm text-red-600">{errors.expirationDate.message}</p>
                )}
              </div>

              {/* Notes */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Notes
                </label>
                <textarea
                  {...register('notes')}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Additional notes about this estimate..."
                />
              </div>

              {/* Terms & Conditions */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Terms & Conditions
                </label>
                <textarea
                  {...register('terms')}
                  rows={4}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            {/* Right Column - Line Items */}
            <div className="lg:col-span-2 space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium text-gray-900">Line Items</h3>
                <button
                  type="button"
                  onClick={addLineItem}
                  className="flex items-center px-3 py-1 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Add Item
                </button>
              </div>

              {/* Line Items Table */}
              <div className="border border-gray-200 rounded-lg overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Description
                      </th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Quantity
                      </th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Unit Price
                      </th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Total
                      </th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {lineItems.map((item, index) => (
                      <tr key={item.id}>
                        <td className="px-4 py-2">
                          <input
                            type="text"
                            value={item.description}
                            onChange={(e) => updateLineItem(index, 'description', e.target.value)}
                            className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent"
                            placeholder="Item description"
                          />
                        </td>
                        <td className="px-4 py-2">
                          <input
                            type="number"
                            min="1"
                            step="1"
                            value={item.quantity}
                            onChange={(e) => updateLineItem(index, 'quantity', parseFloat(e.target.value) || 0)}
                            className="w-20 px-2 py-1 text-sm text-right border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent"
                          />
                        </td>
                        <td className="px-4 py-2">
                          <div className="relative">
                            <DollarSign className="absolute left-2 top-1/2 transform -translate-y-1/2 h-3 w-3 text-gray-400" />
                            <input
                              type="number"
                              min="0"
                              step="0.01"
                              value={item.unitPrice}
                              onChange={(e) => updateLineItem(index, 'unitPrice', parseFloat(e.target.value) || 0)}
                              className="w-24 pl-6 pr-2 py-1 text-sm text-right border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent"
                            />
                          </div>
                        </td>
                        <td className="px-4 py-2 text-right text-sm font-medium text-gray-900">
                          {formatCurrency(item.total)}
                        </td>
                        <td className="px-4 py-2 text-right">
                          <button
                            type="button"
                            onClick={() => removeLineItem(index)}
                            className="text-red-600 hover:text-red-800"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                    {lineItems.length === 0 && (
                      <tr>
                        <td colSpan={5} className="px-4 py-4 text-center text-sm text-gray-500">
                          No line items added. Click "Add Item" to add a line item.
                        </td>
                      </tr>
                    )}
                  </tbody>
                  <tfoot className="bg-gray-50">
                    <tr>
                      <td colSpan={3} className="px-4 py-3 text-right text-sm font-medium text-gray-900">
                        Total:
                      </td>
                      <td className="px-4 py-3 text-right text-sm font-bold text-gray-900">
                        {formatCurrency(watch('total'))}
                      </td>
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* Price Book */}
              <div className="border border-gray-200 rounded-lg overflow-hidden">
                <div className="p-4 bg-gray-50 border-b border-gray-200">
                  <h4 className="text-sm font-medium text-gray-900">Price Book</h4>
                  <p className="text-xs text-gray-600">Click on an item to add it to the estimate</p>
                </div>
                <div className="p-4 max-h-60 overflow-y-auto">
                  <div className="space-y-4">
                    {priceBookItems.map((category) => (
                      <div key={category.category}>
                        <h5 className="text-sm font-medium text-gray-900 mb-2">{category.category}</h5>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          {category.items.map((item) => (
                            <div 
                              key={item.id}
                              onClick={() => addFromPriceBook(item)}
                              className="flex items-center justify-between p-2 bg-gray-50 rounded border border-gray-200 hover:bg-blue-50 hover:border-blue-200 cursor-pointer transition-colors"
                            >
                              <span className="text-sm text-gray-900">{item.description}</span>
                              <span className="text-sm font-medium text-gray-900">{formatCurrency(item.unitPrice)}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end space-x-3 mt-6 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading || !selectedCustomer || lineItems.length === 0}
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? 'Saving...' : isEditing ? 'Update Estimate' : 'Create Estimate'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};