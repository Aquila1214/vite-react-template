import React, { useState, useRef, useEffect } from 'react';
import { X, Save, Trash2, Plus, Undo, Redo, Download, PenTool, Square, Circle, Link as Line, Type, Image, Layers, Move, Grid, Ruler, DollarSign, Maximize, Minimize, Copy, Scissors, Eraser, Pipette, Sliders, Crop, Palette, Aperture, Compass, Anchor, Box, Clipboard, Zap, Minus } from 'lucide-react';
import { formatCurrency } from '../../lib/utils';
import axios from 'axios';

interface Material {
  id: string;
  name: string;
  category: string;
  quantity: number;
  unit: string;
  unitPrice: number;
  total: number;
}

interface SketchData {
  elements: any[];
  materials: Material[];
  totalCost: number;
}

interface ArchitecturalSketchProps {
  customerId: string;
  customer: any;
  onSave: (data: SketchData) => void;
  initialData?: SketchData | null;
}

export const ArchitecturalSketch: React.FC<ArchitecturalSketchProps> = ({
  customerId,
  customer,
  onSave,
  initialData,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [activeTab, setActiveTab] = useState<'draw' | 'materials'>('draw');
  const [activeTool, setActiveTool] = useState<string>('pen');
  const [materials, setMaterials] = useState<Material[]>(initialData?.materials || []);
  const [isDrawing, setIsDrawing] = useState(false);
  const [elements, setElements] = useState<any[]>(initialData?.elements || []);
  const [currentElement, setCurrentElement] = useState<any>(null);
  const [history, setHistory] = useState<any[][]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [zoom, setZoom] = useState(1);
  const [showGrid, setShowGrid] = useState(true);
  const [measurementUnit, setMeasurementUnit] = useState<'imperial' | 'metric'>('imperial');
  const [selectedElement, setSelectedElement] = useState<any>(null);
  const [selectedMaterial, setSelectedMaterial] = useState<Material | null>(null);
  const [newMaterial, setNewMaterial] = useState<Partial<Material>>({
    name: '',
    category: 'Foundation',
    quantity: 1,
    unit: 'sq ft',
    unitPrice: 0
  });
  const [clipboardElements, setClipboardElements] = useState<any[]>([]);
  const [showLayersPanel, setShowLayersPanel] = useState(false);
  const [layers, setLayers] = useState<{id: string, name: string, visible: boolean}[]>([
    {id: 'layer1', name: 'Base Layer', visible: true},
    {id: 'layer2', name: 'Foundation', visible: true},
    {id: 'layer3', name: 'Waterproofing', visible: true}
  ]);
  const [activeLayer, setActiveLayer] = useState('layer1');
  const [backgroundImage, setBackgroundImage] = useState<string | null>(null);
  const [showColorPalette, setShowColorPalette] = useState(false);
  const [activeColor, setActiveColor] = useState('#000000');
  const [lineWidth, setLineWidth] = useState(2);
  const [opacity, setOpacity] = useState(1);
  const [showPropertiesPanel, setShowPropertiesPanel] = useState(false);
  const [isCropping, setIsCropping] = useState(false);
  const [cropStart, setCropStart] = useState<{x: number, y: number} | null>(null);
  const [cropEnd, setCropEnd] = useState<{x: number, y: number} | null>(null);
  const [isAngleMeasuring, setIsAngleMeasuring] = useState(false);
  const [anglePoints, setAnglePoints] = useState<{x: number, y: number}[]>([]);
  const [measuredAngle, setMeasuredAngle] = useState<number | null>(null);

  // Material categories
  const materialCategories = [
    'Foundation',
    'Structural',
    'Waterproofing',
    'Concrete',
    'Drainage',
    'Hardware',
    'Other'
  ];

  // Units of measurement
  const units = [
    'sq ft',
    'linear ft',
    'cubic yd',
    'piece',
    'each',
    'gallon',
    'ton'
  ];

  // Pre-built library items
  const libraryItems = [
    { category: 'Architectural', items: [
      { name: 'Door', icon: <Square className="h-4 w-4" /> },
      { name: 'Window', icon: <Square className="h-4 w-4" /> },
      { name: 'Stairs', icon: <Square className="h-4 w-4" /> },
      { name: 'Wall', icon: <Square className="h-4 w-4" /> },
    ]},
    { category: 'Foundation', items: [
      { name: 'Footing', icon: <Square className="h-4 w-4" /> },
      { name: 'Pier', icon: <Circle className="h-4 w-4" /> },
      { name: 'Wall Anchor', icon: <Anchor className="h-4 w-4" /> },
      { name: 'Crack', icon: <Zap className="h-4 w-4" /> },
    ]},
    { category: 'Waterproofing', items: [
      { name: 'Drain Tile', icon: <Line className="h-4 w-4" /> },
      { name: 'Sump Pump', icon: <Circle className="h-4 w-4" /> },
      { name: 'Membrane', icon: <Square className="h-4 w-4" /> },
      { name: 'Vapor Barrier', icon: <Square className="h-4 w-4" /> },
    ]},
  ];

  // Common materials with prices
  const commonMaterials = [
    { name: 'Foundation Pier', category: 'Foundation', unitPrice: 1200, unit: 'each' },
    { name: 'Wall Anchor', category: 'Structural', unitPrice: 1500, unit: 'each' },
    { name: 'Carbon Fiber Strip', category: 'Structural', unitPrice: 650, unit: 'each' },
    { name: 'Concrete Mix', category: 'Concrete', unitPrice: 125, unit: 'cubic yd' },
    { name: 'Waterproofing Membrane', category: 'Waterproofing', unitPrice: 12, unit: 'sq ft' },
    { name: 'Drain Tile', category: 'Drainage', unitPrice: 18, unit: 'linear ft' },
    { name: 'Sump Pump', category: 'Drainage', unitPrice: 850, unit: 'each' },
    { name: 'Epoxy Injection', category: 'Foundation', unitPrice: 125, unit: 'linear ft' },
  ];

  // Color palette
  const colorPalette = [
    '#000000', '#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF', '#00FFFF',
    '#FFA500', '#800080', '#008000', '#800000', '#008080', '#000080', '#808080'
  ];

  // Initialize canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    // Draw grid
    if (showGrid) {
      drawGrid(ctx);
    }

    // Draw background image if exists
    if (backgroundImage) {
      const img = new Image();
      img.src = backgroundImage;
      img.onload = () => {
        ctx.globalAlpha = 0.3; // Semi-transparent
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        ctx.globalAlpha = 1.0;
        drawElements(ctx);
      };
    } else {
      // Draw elements
      drawElements(ctx);
    }

    // Draw crop overlay if cropping
    if (isCropping && cropStart && cropEnd) {
      drawCropOverlay(ctx);
    }

    // Draw angle measurement if measuring
    if (isAngleMeasuring && anglePoints.length > 0) {
      drawAngleMeasurement(ctx);
    }

  }, [elements, showGrid, zoom, backgroundImage, isCropping, cropStart, cropEnd, isAngleMeasuring, anglePoints, layers]);

  // Add to history when elements change
  useEffect(() => {
    if (elements.length > 0 && (historyIndex === -1 || elements !== history[historyIndex])) {
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push([...elements]);
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
    }
  }, [elements]);

  // Calculate total cost when materials change
  useEffect(() => {
    const total = materials.reduce((sum, material) => sum + material.total, 0);
    // Update total cost in state
  }, [materials]);

  const drawGrid = (ctx: CanvasRenderingContext2D) => {
    const { width, height } = ctx.canvas;
    const gridSize = 20 * zoom;

    ctx.beginPath();
    ctx.strokeStyle = '#e5e7eb';
    ctx.lineWidth = 1;

    // Draw vertical lines
    for (let x = 0; x <= width; x += gridSize) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
    }

    // Draw horizontal lines
    for (let y = 0; y <= height; y += gridSize) {
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
    }

    ctx.stroke();
  };

  const drawElements = (ctx: CanvasRenderingContext2D) => {
    // Only draw elements on visible layers
    elements.forEach(element => {
      if (layers.find(layer => layer.id === element.layerId)?.visible) {
        if (element.type === 'pen') {
          drawPenElement(ctx, element);
        } else if (element.type === 'line') {
          drawLineElement(ctx, element);
        } else if (element.type === 'rectangle') {
          drawRectangleElement(ctx, element);
        } else if (element.type === 'circle') {
          drawCircleElement(ctx, element);
        } else if (element.type === 'text') {
          drawTextElement(ctx, element);
        }
      }
    });
  };

  const drawPenElement = (ctx: CanvasRenderingContext2D, element: any) => {
    const { points, color, width, opacity = 1 } = element;
    if (points.length < 2) return;

    ctx.beginPath();
    ctx.strokeStyle = color || '#000000';
    ctx.lineWidth = width || 2;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.globalAlpha = opacity;

    ctx.moveTo(points[0].x, points[0].y);
    for (let i = 1; i < points.length; i++) {
      ctx.lineTo(points[i].x, points[i].y);
    }

    ctx.stroke();
    ctx.globalAlpha = 1.0;
  };

  const drawLineElement = (ctx: CanvasRenderingContext2D, element: any) => {
    const { start, end, color, width, opacity = 1 } = element;
    
    ctx.beginPath();
    ctx.strokeStyle = color || '#000000';
    ctx.lineWidth = width || 2;
    ctx.globalAlpha = opacity;
    ctx.moveTo(start.x, start.y);
    ctx.lineTo(end.x, end.y);
    ctx.stroke();
    ctx.globalAlpha = 1.0;
  };

  const drawRectangleElement = (ctx: CanvasRenderingContext2D, element: any) => {
    const { start, end, color, width, fill, opacity = 1 } = element;
    
    ctx.beginPath();
    ctx.strokeStyle = color || '#000000';
    ctx.lineWidth = width || 2;
    ctx.globalAlpha = opacity;
    
    const x = Math.min(start.x, end.x);
    const y = Math.min(start.y, end.y);
    const w = Math.abs(end.x - start.x);
    const h = Math.abs(end.y - start.y);
    
    if (fill) {
      ctx.fillStyle = fill;
      ctx.fillRect(x, y, w, h);
    }
    
    ctx.strokeRect(x, y, w, h);
    ctx.globalAlpha = 1.0;
  };

  const drawCircleElement = (ctx: CanvasRenderingContext2D, element: any) => {
    const { start, end, color, width, fill, opacity = 1 } = element;
    
    const x1 = start.x;
    const y1 = start.y;
    const x2 = end.x;
    const y2 = end.y;
    
    const radius = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    
    ctx.beginPath();
    ctx.arc(x1, y1, radius, 0, 2 * Math.PI);
    ctx.strokeStyle = color || '#000000';
    ctx.lineWidth = width || 2;
    ctx.globalAlpha = opacity;
    
    if (fill) {
      ctx.fillStyle = fill;
      ctx.fill();
    }
    
    ctx.stroke();
    ctx.globalAlpha = 1.0;
  };

  const drawTextElement = (ctx: CanvasRenderingContext2D, element: any) => {
    const { x, y, text, color, fontSize, fontFamily, opacity = 1 } = element;
    
    ctx.font = `${fontSize || 16}px ${fontFamily || 'Arial'}`;
    ctx.fillStyle = color || '#000000';
    ctx.globalAlpha = opacity;
    ctx.fillText(text, x, y);
    ctx.globalAlpha = 1.0;
  };

  const drawCropOverlay = (ctx: CanvasRenderingContext2D) => {
    if (!cropStart || !cropEnd) return;
    
    const x = Math.min(cropStart.x, cropEnd.x);
    const y = Math.min(cropStart.y, cropEnd.y);
    const width = Math.abs(cropEnd.x - cropStart.x);
    const height = Math.abs(cropEnd.y - cropStart.y);
    
    // Draw semi-transparent overlay
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    
    // Clear the crop area
    ctx.clearRect(x, y, width, height);
    
    // Draw crop border
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, width, height);
  };

  const drawAngleMeasurement = (ctx: CanvasRenderingContext2D) => {
    if (anglePoints.length < 2) return;
    
    ctx.beginPath();
    ctx.strokeStyle = '#FF0000';
    ctx.lineWidth = 2;
    
    // Draw lines
    ctx.moveTo(anglePoints[0].x, anglePoints[0].y);
    for (let i = 1; i < anglePoints.length; i++) {
      ctx.lineTo(anglePoints[i].x, anglePoints[i].y);
    }
    
    ctx.stroke();
    
    // Draw angle if we have 3 points
    if (anglePoints.length === 3 && measuredAngle !== null) {
      const centerPoint = anglePoints[1];
      ctx.font = '14px Arial';
      ctx.fillStyle = '#FF0000';
      ctx.fillText(`${measuredAngle.toFixed(1)}°`, centerPoint.x + 10, centerPoint.y - 10);
    }
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / zoom;
    const y = (e.clientY - rect.top) / zoom;
    
    if (isCropping) {
      setCropStart({ x, y });
      setCropEnd({ x, y });
      return;
    }
    
    if (isAngleMeasuring) {
      if (anglePoints.length < 3) {
        setAnglePoints([...anglePoints, { x, y }]);
        
        // Calculate angle if we have 3 points
        if (anglePoints.length === 2) {
          const p1 = anglePoints[0];
          const p2 = anglePoints[1]; // center point
          const p3 = { x, y };
          
          // Calculate vectors
          const v1 = { x: p1.x - p2.x, y: p1.y - p2.y };
          const v2 = { x: p3.x - p2.x, y: p3.y - p2.y };
          
          // Calculate dot product
          const dot = v1.x * v2.x + v1.y * v2.y;
          
          // Calculate magnitudes
          const mag1 = Math.sqrt(v1.x * v1.x + v1.y * v1.y);
          const mag2 = Math.sqrt(v2.x * v2.x + v2.y * v2.y);
          
          // Calculate angle in radians and convert to degrees
          const angle = Math.acos(dot / (mag1 * mag2)) * (180 / Math.PI);
          setMeasuredAngle(angle);
        }
      } else {
        // Reset for a new measurement
        setAnglePoints([{ x, y }]);
        setMeasuredAngle(null);
      }
      return;
    }
    
    setIsDrawing(true);
    
    if (activeTool === 'pipette') {
      // Sample color from canvas
      const ctx = canvasRef.current.getContext('2d');
      if (ctx) {
        const pixel = ctx.getImageData(x, y, 1, 1).data;
        const color = `#${pixel[0].toString(16).padStart(2, '0')}${pixel[1].toString(16).padStart(2, '0')}${pixel[2].toString(16).padStart(2, '0')}`;
        setActiveColor(color);
      }
      setActiveTool('pen'); // Switch back to pen after sampling
      return;
    }
    
    if (activeTool === 'pen') {
      const newElement = {
        type: 'pen',
        points: [{ x, y }],
        color: activeColor,
        width: lineWidth,
        opacity,
        layerId: activeLayer
      };
      setCurrentElement(newElement);
    } else if (activeTool === 'line') {
      const newElement = {
        type: 'line',
        start: { x, y },
        end: { x, y },
        color: activeColor,
        width: lineWidth,
        opacity,
        layerId: activeLayer
      };
      setCurrentElement(newElement);
    } else if (activeTool === 'rectangle') {
      const newElement = {
        type: 'rectangle',
        start: { x, y },
        end: { x, y },
        color: activeColor,
        width: lineWidth,
        opacity,
        layerId: activeLayer
      };
      setCurrentElement(newElement);
    } else if (activeTool === 'circle') {
      const newElement = {
        type: 'circle',
        start: { x, y },
        end: { x, y },
        color: activeColor,
        width: lineWidth,
        opacity,
        layerId: activeLayer
      };
      setCurrentElement(newElement);
    } else if (activeTool === 'text') {
      const text = prompt('Enter text:');
      if (text) {
        const newElement = {
          type: 'text',
          x,
          y,
          text,
          color: activeColor,
          fontSize: 16,
          fontFamily: 'Arial',
          opacity,
          layerId: activeLayer
        };
        setElements([...elements, newElement]);
      }
    } else if (activeTool === 'select') {
      // Find if we clicked on an element
      const clickedElement = elements.find(element => {
        // Check if point is inside element (simplified)
        if (element.type === 'rectangle') {
          const minX = Math.min(element.start.x, element.end.x);
          const maxX = Math.max(element.start.x, element.end.x);
          const minY = Math.min(element.start.y, element.end.y);
          const maxY = Math.max(element.start.y, element.end.y);
          
          return x >= minX && x <= maxX && y >= minY && y <= maxY;
        }
        return false;
      });
      
      setSelectedElement(clickedElement || null);
      if (clickedElement) {
        setShowPropertiesPanel(true);
      }
    } else if (activeTool === 'eraser') {
      // Find elements under the eraser and remove them
      const erasedElements = elements.filter(element => {
        // Simple hit detection (can be improved)
        if (element.type === 'rectangle') {
          const minX = Math.min(element.start.x, element.end.x);
          const maxX = Math.max(element.start.x, element.end.x);
          const minY = Math.min(element.start.y, element.end.y);
          const maxY = Math.max(element.start.y, element.end.y);
          
          return !(x >= minX && x <= maxX && y >= minY && y <= maxY);
        } else if (element.type === 'circle') {
          const centerX = element.start.x;
          const centerY = element.start.y;
          const radius = Math.sqrt(
            Math.pow(element.end.x - centerX, 2) + 
            Math.pow(element.end.y - centerY, 2)
          );
          const distance = Math.sqrt(
            Math.pow(x - centerX, 2) + 
            Math.pow(y - centerY, 2)
          );
          
          return distance > radius;
        }
        return true;
      });
      
      setElements(erasedElements);
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / zoom;
    const y = (e.clientY - rect.top) / zoom;
    
    if (isCropping && cropStart) {
      setCropEnd({ x, y });
      return;
    }
    
    if (!isDrawing || !currentElement) return;
    
    if (currentElement.type === 'pen') {
      setCurrentElement({
        ...currentElement,
        points: [...currentElement.points, { x, y }],
      });
    } else if (['line', 'rectangle', 'circle'].includes(currentElement.type)) {
      setCurrentElement({
        ...currentElement,
        end: { x, y },
      });
    }
  };

  const handleMouseUp = () => {
    if (isCropping && cropStart && cropEnd) {
      handleCrop();
      setIsCropping(false);
      setCropStart(null);
      setCropEnd(null);
      return;
    }
    
    if (!isDrawing || !currentElement) return;
    
    setIsDrawing(false);
    setElements([...elements, currentElement]);
    setCurrentElement(null);
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setElements(history[historyIndex - 1]);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setElements(history[historyIndex + 1]);
    }
  };

  const handleZoomIn = () => {
    setZoom(Math.min(zoom + 0.1, 3));
  };

  const handleZoomOut = () => {
    setZoom(Math.max(zoom - 0.1, 0.5));
  };

  const handleAddMaterial = () => {
    if (!newMaterial.name || !newMaterial.category || !newMaterial.quantity || !newMaterial.unitPrice) {
      alert('Please fill in all required fields');
      return;
    }
    
    const material: Material = {
      id: Date.now().toString(),
      name: newMaterial.name || '',
      category: newMaterial.category || 'Other',
      quantity: newMaterial.quantity || 0,
      unit: newMaterial.unit || 'each',
      unitPrice: newMaterial.unitPrice || 0,
      total: (newMaterial.quantity || 0) * (newMaterial.unitPrice || 0),
    };
    
    setMaterials([...materials, material]);
    setNewMaterial({
      name: '',
      category: 'Foundation',
      quantity: 1,
      unit: 'sq ft',
      unitPrice: 0
    });
  };

  const handleUpdateMaterial = () => {
    if (!selectedMaterial) return;
    
    setMaterials(materials.map(m => 
      m.id === selectedMaterial.id ? selectedMaterial : m
    ));
    
    setSelectedMaterial(null);
  };

  const handleDeleteMaterial = (id: string) => {
    setMaterials(materials.filter(m => m.id !== id));
    if (selectedMaterial?.id === id) {
      setSelectedMaterial(null);
    }
  };

  const handleAddCommonMaterial = (material: any) => {
    const newMat: Material = {
      id: Date.now().toString(),
      name: material.name,
      category: material.category,
      quantity: 1,
      unit: material.unit,
      unitPrice: material.unitPrice,
      total: material.unitPrice,
    };
    
    setMaterials([...materials, newMat]);
  };

  const handleSaveSketch = async () => {
    const totalCost = materials.reduce((sum, material) => sum + material.total, 0);
    
    // Save sketch data
    const sketchData: SketchData = {
      elements,
      materials,
      totalCost
    };
    
    // Call the onSave callback
    onSave(sketchData);
    
    // Convert canvas to image and save to files
    if (canvasRef.current && customer.jobs && customer.jobs.length > 0) {
      try {
        const canvas = canvasRef.current;
        const imageData = canvas.toDataURL('image/png');
        
        // In a real implementation, this would be an API call to your backend
        // For now, we'll simulate the API call
        console.log('Saving sketch as file...');
        
        // Simulate API call to convert sketch to file
        // In a real implementation, you would use axios to call your backend API
        /*
        await axios.post(`/api/files/sketch/${customer.jobs[0].id}`, {
          sketchData: imageData,
          fileName: `sketch-${customerId}-${new Date().toISOString().slice(0, 10)}.png`
        });
        */
        
        console.log('Sketch saved as file successfully');
      } catch (error) {
        console.error('Failed to save sketch as file:', error);
      }
    }
  };

  const handleExportImage = () => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const image = canvas.toDataURL('image/png');
    
    const link = document.createElement('a');
    link.href = image;
    link.download = `sketch-${customerId}-${new Date().toISOString().slice(0, 10)}.png`;
    link.click();
  };

  const handleCopy = () => {
    if (selectedElement) {
      setClipboardElements([selectedElement]);
    }
  };

  const handleCut = () => {
    if (selectedElement) {
      setClipboardElements([selectedElement]);
      setElements(elements.filter(el => el !== selectedElement));
      setSelectedElement(null);
    }
  };

  const handlePaste = () => {
    if (clipboardElements.length > 0) {
      const newElements = clipboardElements.map(el => ({
        ...el,
        id: Date.now().toString(),
        // Offset pasted elements slightly
        ...(el.type === 'pen' ? {
          points: el.points.map((p: {x: number, y: number}) => ({
            x: p.x + 20,
            y: p.y + 20
          }))
        } : el.type === 'text' ? {
          x: el.x + 20,
          y: el.y + 20
        } : {
          start: { x: el.start.x + 20, y: el.start.y + 20 },
          end: { x: el.end.x + 20, y: el.end.y + 20 }
        })
      }));
      
      setElements([...elements, ...newElements]);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setBackgroundImage(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddLayer = () => {
    const newLayerId = `layer${layers.length + 1}`;
    const newLayerName = `Layer ${layers.length + 1}`;
    setLayers([...layers, { id: newLayerId, name: newLayerName, visible: true }]);
    setActiveLayer(newLayerId);
  };

  const handleToggleLayerVisibility = (layerId: string) => {
    setLayers(layers.map(layer => 
      layer.id === layerId ? { ...layer, visible: !layer.visible } : layer
    ));
  };

  const handleRemoveLayer = (layerId: string) => {
    // Don't remove if it's the only layer
    if (layers.length <= 1) return;
    
    // Remove the layer
    setLayers(layers.filter(layer => layer.id !== layerId));
    
    // Remove elements on this layer
    setElements(elements.filter(el => el.layerId !== layerId));
    
    // Set active layer to the first available layer
    if (activeLayer === layerId) {
      setActiveLayer(layers.filter(layer => layer.id !== layerId)[0].id);
    }
  };

  const handleCrop = () => {
    if (!canvasRef.current || !cropStart || !cropEnd) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const x = Math.min(cropStart.x, cropEnd.x);
    const y = Math.min(cropStart.y, cropEnd.y);
    const width = Math.abs(cropEnd.x - cropStart.x);
    const height = Math.abs(cropEnd.y - cropStart.y);
    
    // Create a temporary canvas to hold the cropped image
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = width;
    tempCanvas.height = height;
    const tempCtx = tempCanvas.getContext('2d');
    if (!tempCtx) return;
    
    // Draw the cropped portion to the temp canvas
    tempCtx.drawImage(
      canvas,
      x, y, width, height,
      0, 0, width, height
    );
    
    // Clear the original canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Resize the original canvas to the crop size
    canvas.width = width;
    canvas.height = height;
    
    // Draw the cropped image back to the original canvas
    ctx.drawImage(tempCanvas, 0, 0);
    
    // Filter elements to keep only those within the crop area
    const croppedElements = elements.filter(element => {
      // Simple check - this could be improved for more complex elements
      if (element.type === 'pen') {
        return element.points.some((p: {x: number, y: number}) => 
          p.x >= x && p.x <= x + width && p.y >= y && p.y <= y + height
        );
      } else if (element.type === 'text') {
        return element.x >= x && element.x <= x + width && 
               element.y >= y && element.y <= y + height;
      } else {
        const elX = Math.min(element.start.x, element.end.x);
        const elY = Math.min(element.start.y, element.end.y);
        const elWidth = Math.abs(element.end.x - element.start.x);
        const elHeight = Math.abs(element.end.y - element.start.y);
        
        return (elX + elWidth >= x && elX <= x + width &&
                elY + elHeight >= y && elY <= y + height);
      }
    }).map(element => {
      // Adjust coordinates relative to the new canvas
      if (element.type === 'pen') {
        return {
          ...element,
          points: element.points.map((p: {x: number, y: number}) => ({
            x: p.x - x,
            y: p.y - y
          }))
        };
      } else if (element.type === 'text') {
        return {
          ...element,
          x: element.x - x,
          y: element.y - y
        };
      } else {
        return {
          ...element,
          start: {
            x: element.start.x - x,
            y: element.start.y - y
          },
          end: {
            x: element.end.x - x,
            y: element.end.y - y
          }
        };
      }
    });
    
    setElements(croppedElements);
  };

  const handleCompassDraw = () => {
    if (!canvasRef.current) return;
    
    const centerX = canvasRef.current.width / 2;
    const centerY = canvasRef.current.height / 2;
    const radius = 100;
    
    const newElement = {
      type: 'circle',
      start: { x: centerX, y: centerY },
      end: { x: centerX + radius, y: centerY },
      color: activeColor,
      width: lineWidth,
      opacity,
      layerId: activeLayer
    };
    
    setElements([...elements, newElement]);
  };

  const handleBoxDraw = () => {
    if (!canvasRef.current) return;
    
    const centerX = canvasRef.current.width / 2;
    const centerY = canvasRef.current.height / 2;
    const size = 100;
    
    const newElement = {
      type: 'rectangle',
      start: { x: centerX - size/2, y: centerY - size/2 },
      end: { x: centerX + size/2, y: centerY + size/2 },
      color: activeColor,
      width: lineWidth,
      opacity,
      layerId: activeLayer
    };
    
    setElements([...elements, newElement]);
  };

  const handleRemoveMaterial = (id: string) => {
    setMaterials(materials.filter(m => m.id !== id));
  };

  return (
    <div className="flex flex-col h-full">
      {/* Tabs */}
      <div className="flex border-b border-gray-200 mb-4">
        <button
          onClick={() => setActiveTab('draw')}
          className={`px-4 py-2 text-sm font-medium ${
            activeTab === 'draw'
              ? 'text-blue-600 border-b-2 border-blue-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Drawing Tools
        </button>
        <button
          onClick={() => setActiveTab('materials')}
          className={`px-4 py-2 text-sm font-medium ${
            activeTab === 'materials'
              ? 'text-blue-600 border-b-2 border-blue-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Materials & Cost Estimation
        </button>
      </div>

      {activeTab === 'draw' ? (
        <div className="flex flex-col h-full">
          {/* Toolbar */}
          <div className="flex flex-wrap gap-2 mb-4 p-2 bg-gray-50 rounded-lg">
            <button
              onClick={() => setActiveTool('pen')}
              className={`p-2 rounded ${activeTool === 'pen' ? 'bg-blue-100 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}
              title="Pen Tool"
            >
              <PenTool className="h-5 w-5" />
            </button>
            <button
              onClick={() => setActiveTool('line')}
              className={`p-2 rounded ${activeTool === 'line' ? 'bg-blue-100 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}
              title="Line Tool"
            >
              <Line className="h-5 w-5" />
            </button>
            <button
              onClick={() => setActiveTool('rectangle')}
              className={`p-2 rounded ${activeTool === 'rectangle' ? 'bg-blue-100 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}
              title="Rectangle Tool"
            >
              <Square className="h-5 w-5" />
            </button>
            <button
              onClick={() => setActiveTool('circle')}
              className={`p-2 rounded ${activeTool === 'circle' ? 'bg-blue-100 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}
              title="Circle Tool"
            >
              <Circle className="h-5 w-5" />
            </button>
            <button
              onClick={() => setActiveTool('text')}
              className={`p-2 rounded ${activeTool === 'text' ? 'bg-blue-100 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}
              title="Text Tool"
            >
              <Type className="h-5 w-5" />
            </button>
            <button
              onClick={() => setActiveTool('select')}
              className={`p-2 rounded ${activeTool === 'select' ? 'bg-blue-100 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}
              title="Select Tool"
            >
              <Move className="h-5 w-5" />
            </button>
            <button
              onClick={() => setActiveTool('eraser')}
              className={`p-2 rounded ${activeTool === 'eraser' ? 'bg-blue-100 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}
              title="Eraser Tool"
            >
              <Eraser className="h-5 w-5" />
            </button>
            <button
              onClick={() => setActiveTool('pipette')}
              className={`p-2 rounded ${activeTool === 'pipette' ? 'bg-blue-100 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}
              title="Color Picker"
            >
              <Pipette className="h-5 w-5" />
            </button>
            
            <div className="h-6 border-l border-gray-300 mx-1"></div>
            
            <button
              onClick={() => fileInputRef.current?.click()}
              className="p-2 rounded text-gray-700 hover:bg-gray-100"
              title="Import Image"
            >
              <Image className="h-5 w-5" />
              <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                accept="image/*"
                onChange={handleImageUpload}
              />
            </button>
            <button
              onClick={() => setShowLayersPanel(!showLayersPanel)}
              className={`p-2 rounded ${showLayersPanel ? 'bg-blue-100 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}
              title="Layers"
            >
              <Layers className="h-5 w-5" />
            </button>
            <button
              onClick={() => setShowPropertiesPanel(!showPropertiesPanel)}
              className={`p-2 rounded ${showPropertiesPanel ? 'bg-blue-100 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}
              title="Properties"
            >
              <Sliders className="h-5 w-5" />
            </button>
            <button
              onClick={() => setIsCropping(!isCropping)}
              className={`p-2 rounded ${isCropping ? 'bg-blue-100 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}
              title="Crop"
            >
              <Crop className="h-5 w-5" />
            </button>
            <button
              onClick={() => setShowColorPalette(!showColorPalette)}
              className={`p-2 rounded ${showColorPalette ? 'bg-blue-100 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}
              title="Color Palette"
            >
              <Palette className="h-5 w-5" />
            </button>
            <button
              onClick={() => {
                setIsAngleMeasuring(!isAngleMeasuring);
                if (!isAngleMeasuring) {
                  setAnglePoints([]);
                  setMeasuredAngle(null);
                }
              }}
              className={`p-2 rounded ${isAngleMeasuring ? 'bg-blue-100 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}
              title="Measure Angle"
            >
              <Aperture className="h-5 w-5" />
            </button>
            <button
              onClick={handleCompassDraw}
              className="p-2 rounded text-gray-700 hover:bg-gray-100"
              title="Draw Circle (Compass)"
            >
              <Compass className="h-5 w-5" />
            </button>
            <button
              onClick={handleBoxDraw}
              className="p-2 rounded text-gray-700 hover:bg-gray-100"
              title="Draw Box"
            >
              <Box className="h-5 w-5" />
            </button>
            
            <div className="h-6 border-l border-gray-300 mx-1"></div>
            
            <button
              onClick={handleUndo}
              disabled={historyIndex <= 0}
              className="p-2 rounded text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
              title="Undo"
            >
              <Undo className="h-5 w-5" />
            </button>
            <button
              onClick={handleRedo}
              disabled={historyIndex >= history.length - 1}
              className="p-2 rounded text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
              title="Redo"
            >
              <Redo className="h-5 w-5" />
            </button>
            
            <div className="h-6 border-l border-gray-300 mx-1"></div>
            
            <button
              onClick={() => setShowGrid(!showGrid)}
              className={`p-2 rounded ${showGrid ? 'bg-blue-100 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}
              title="Toggle Grid"
            >
              <Grid className="h-5 w-5" />
            </button>
            <button
              onClick={() => setMeasurementUnit(measurementUnit === 'imperial' ? 'metric' : 'imperial')}
              className="p-2 rounded text-gray-700 hover:bg-gray-100"
              title={`Measurement Unit: ${measurementUnit === 'imperial' ? 'Imperial' : 'Metric'}`}
            >
              <Ruler className="h-5 w-5" />
            </button>
            
            <div className="h-6 border-l border-gray-300 mx-1"></div>
            
            <button
              onClick={handleZoomIn}
              className="p-2 rounded text-gray-700 hover:bg-gray-100"
              title="Zoom In"
            >
              <Maximize className="h-5 w-5" />
            </button>
            <button
              onClick={handleZoomOut}
              className="p-2 rounded text-gray-700 hover:bg-gray-100"
              title="Zoom Out"
            >
              <Minimize className="h-5 w-5" />
            </button>
            <div className="p-2 text-sm text-gray-600">
              {Math.round(zoom * 100)}%
            </div>
            
            <div className="h-6 border-l border-gray-300 mx-1"></div>
            
            <button
              onClick={handleCopy}
              disabled={!selectedElement}
              className="p-2 rounded text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
              title="Copy"
            >
              <Copy className="h-5 w-5" />
            </button>
            <button
              onClick={handleCut}
              disabled={!selectedElement}
              className="p-2 rounded text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
              title="Cut"
            >
              <Scissors className="h-5 w-5" />
            </button>
            <button
              onClick={handlePaste}
              disabled={clipboardElements.length === 0}
              className="p-2 rounded text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
              title="Paste"
            >
              <Clipboard className="h-5 w-5" />
            </button>
            
            <div className="flex-1"></div>
            
            <button
              onClick={handleExportImage}
              className="p-2 rounded text-gray-700 hover:bg-gray-100"
              title="Export Image"
            >
              <Download className="h-5 w-5" />
            </button>
          </div>

          <div className="flex flex-1 gap-4">
            {/* Layers Panel */}
            {showLayersPanel && (
              <div className="w-64 bg-gray-50 p-3 rounded-lg overflow-y-auto">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-medium text-gray-900">Layers</h3>
                  <button 
                    onClick={handleAddLayer}
                    className="p-1 text-blue-600 hover:bg-blue-50 rounded"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
                
                <div className="space-y-2">
                  {layers.map(layer => (
                    <div 
                      key={layer.id} 
                      className={`flex items-center justify-between p-2 rounded ${
                        activeLayer === layer.id ? 'bg-blue-100' : 'bg-white'
                      } border border-gray-200`}
                    >
                      <div className="flex items-center">
                        <button
                          onClick={() => handleToggleLayerVisibility(layer.id)}
                          className={`mr-2 ${layer.visible ? 'text-blue-600' : 'text-gray-400'}`}
                        >
                          {layer.visible ? <Eye className="h-4 w-4" /> : <X className="h-4 w-4" />}
                        </button>
                        <span 
                          className="text-sm cursor-pointer"
                          onClick={() => setActiveLayer(layer.id)}
                        >
                          {layer.name}
                        </span>
                      </div>
                      <button
                        onClick={() => handleRemoveLayer(layer.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Minus className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Properties Panel */}
            {showPropertiesPanel && (
              <div className="w-64 bg-gray-50 p-3 rounded-lg overflow-y-auto">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-medium text-gray-900">Properties</h3>
                  <button 
                    onClick={() => setShowPropertiesPanel(false)}
                    className="p-1 text-gray-500 hover:bg-gray-200 rounded"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">
                      Color
                    </label>
                    <input
                      type="color"
                      value={activeColor}
                      onChange={(e) => setActiveColor(e.target.value)}
                      className="w-full h-8 rounded border border-gray-300"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">
                      Line Width
                    </label>
                    <div className="flex items-center">
                      <input
                        type="range"
                        min="1"
                        max="20"
                        value={lineWidth}
                        onChange={(e) => setLineWidth(parseInt(e.target.value))}
                        className="flex-1 mr-2"
                      />
                      <span className="text-xs w-6 text-center">{lineWidth}</span>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">
                      Opacity
                    </label>
                    <div className="flex items-center">
                      <input
                        type="range"
                        min="0.1"
                        max="1"
                        step="0.1"
                        value={opacity}
                        onChange={(e) => setOpacity(parseFloat(e.target.value))}
                        className="flex-1 mr-2"
                      />
                      <span className="text-xs w-6 text-center">{opacity}</span>
                    </div>
                  </div>
                  
                  {selectedElement && (
                    <div className="pt-4 border-t border-gray-200">
                      <h4 className="text-xs font-medium text-gray-700 mb-2">Selected Element</h4>
                      
                      <div className="space-y-2">
                        <div>
                          <label className="block text-xs text-gray-600">Type</label>
                          <div className="text-sm font-medium">{selectedElement.type}</div>
                        </div>
                        
                        {selectedElement.type === 'text' && (
                          <div>
                            <label className="block text-xs text-gray-600">Text</label>
                            <input
                              type="text"
                              value={selectedElement.text}
                              onChange={(e) => {
                                setSelectedElement({
                                  ...selectedElement,
                                  text: e.target.value
                                });
                                
                                // Update the element in the elements array
                                setElements(elements.map(el => 
                                  el === selectedElement ? { ...el, text: e.target.value } : el
                                ));
                              }}
                              className="w-full px-2 py-1 text-sm border border-gray-300 rounded"
                            />
                          </div>
                        )}
                        
                        <div>
                          <label className="block text-xs text-gray-600">Color</label>
                          <input
                            type="color"
                            value={selectedElement.color}
                            onChange={(e) => {
                              setSelectedElement({
                                ...selectedElement,
                                color: e.target.value
                              });
                              
                              // Update the element in the elements array
                              setElements(elements.map(el => 
                                el === selectedElement ? { ...el, color: e.target.value } : el
                              ));
                            }}
                            className="w-full h-6 rounded border border-gray-300"
                          />
                        </div>
                        
                        <div>
                          <button
                            onClick={() => {
                              setElements(elements.filter(el => el !== selectedElement));
                              setSelectedElement(null);
                            }}
                            className="w-full px-2 py-1 text-xs text-white bg-red-600 rounded hover:bg-red-700"
                          >
                            Delete Element
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Color Palette */}
            {showColorPalette && (
              <div className="w-64 bg-gray-50 p-3 rounded-lg overflow-y-auto">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-medium text-gray-900">Color Palette</h3>
                  <button 
                    onClick={() => setShowColorPalette(false)}
                    className="p-1 text-gray-500 hover:bg-gray-200 rounded"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
                
                <div className="grid grid-cols-4 gap-2">
                  {colorPalette.map((color, index) => (
                    <button
                      key={index}
                      onClick={() => setActiveColor(color)}
                      className={`w-full h-8 rounded-lg border-2 ${
                        activeColor === color ? 'border-gray-900' : 'border-gray-200'
                      }`}
                      style={{ backgroundColor: color }}
                      title={color}
                    />
                  ))}
                </div>
                
                <div className="mt-4">
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    Custom Color
                  </label>
                  <input
                    type="color"
                    value={activeColor}
                    onChange={(e) => setActiveColor(e.target.value)}
                    className="w-full h-8 rounded border border-gray-300"
                  />
                </div>
              </div>
            )}

            {/* Library Panel */}
            <div className="w-64 bg-gray-50 p-3 rounded-lg overflow-y-auto">
              <h3 className="text-sm font-medium text-gray-900 mb-3">Component Library</h3>
              
              <div className="space-y-4">
                {libraryItems.map((category) => (
                  <div key={category.category}>
                    <h4 className="text-xs font-medium text-gray-700 mb-2">{category.category}</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {category.items.map((item) => (
                        <div 
                          key={item.name}
                          className="flex items-center p-2 bg-white rounded border border-gray-200 text-xs cursor-pointer hover:bg-blue-50 hover:border-blue-200"
                        >
                          <div className="mr-2">{item.icon}</div>
                          <span>{item.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Canvas */}
            <div className="flex-1 border border-gray-300 rounded-lg overflow-hidden bg-white">
              <canvas
                ref={canvasRef}
                className="w-full h-full"
                style={{ 
                  cursor: activeTool === 'pen' ? 'crosshair' : 
                          activeTool === 'select' ? 'pointer' : 
                          activeTool === 'eraser' ? 'no-drop' :
                          activeTool === 'pipette' ? 'eyedropper' :
                          activeTool === 'text' ? 'text' :
                          isCropping ? 'crosshair' :
                          isAngleMeasuring ? 'crosshair' :
                          'crosshair',
                  transform: `scale(${zoom})`,
                  transformOrigin: '0 0'
                }}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
              />
            </div>
          </div>
        </div>
      ) : (
        <div className="flex flex-col h-full">
          <div className="flex flex-1 gap-4">
            {/* Materials List */}
            <div className="flex-1">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-gray-900">Materials List</h3>
                <div className="text-sm text-gray-600">
                  Total: <span className="font-bold">{formatCurrency(materials.reduce((sum, m) => sum + m.total, 0))}</span>
                </div>
              </div>
              
              <div className="border border-gray-200 rounded-lg overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Material</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Unit Price</th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {materials.map((material) => (
                      <tr 
                        key={material.id}
                        className={selectedMaterial?.id === material.id ? 'bg-blue-50' : 'hover:bg-gray-50'}
                        onClick={() => setSelectedMaterial(material)}
                      >
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-900">{material.name}</td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">{material.category}</td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-900 text-right">
                          {material.quantity} {material.unit}
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-900 text-right">
                          {formatCurrency(material.unitPrice)}
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm font-medium text-gray-900 text-right">
                          {formatCurrency(material.total)}
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-right text-sm font-medium">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteMaterial(material.id);
                            }}
                            className="text-red-600 hover:text-red-900"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                    {materials.length === 0 && (
                      <tr>
                        <td colSpan={6} className="px-4 py-4 text-sm text-gray-500 text-center">
                          No materials added yet. Add materials using the form below.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
            
            {/* Material Editor */}
            <div className="w-80 bg-gray-50 p-4 rounded-lg">
              <h3 className="text-sm font-medium text-gray-900 mb-4">
                {selectedMaterial ? 'Edit Material' : 'Add Material'}
              </h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Material Name</label>
                  <input
                    type="text"
                    value={selectedMaterial?.name || newMaterial.name}
                    onChange={(e) => selectedMaterial 
                      ? setSelectedMaterial({...selectedMaterial, name: e.target.value})
                      : setNewMaterial({...newMaterial, name: e.target.value})
                    }
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg"
                    placeholder="Enter material name"
                  />
                </div>
                
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Category</label>
                  <select
                    value={selectedMaterial?.category || newMaterial.category}
                    onChange={(e) => selectedMaterial 
                      ? setSelectedMaterial({...selectedMaterial, category: e.target.value})
                      : setNewMaterial({...newMaterial, category: e.target.value})
                    }
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg"
                  >
                    {materialCategories.map(category => (
                      <option key={category} value={category}>{category}</option>
                    ))}
                  </select>
                </div>
                
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Quantity</label>
                    <input
                      type="number"
                      min="0.1"
                      step="0.1"
                      value={selectedMaterial?.quantity || newMaterial.quantity}
                      onChange={(e) => {
                        const quantity = parseFloat(e.target.value) || 0;
                        if (selectedMaterial) {
                          const total = quantity * selectedMaterial.unitPrice;
                          setSelectedMaterial({...selectedMaterial, quantity, total});
                        } else {
                          setNewMaterial({...newMaterial, quantity});
                        }
                      }}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Unit</label>
                    <select
                      value={selectedMaterial?.unit || newMaterial.unit}
                      onChange={(e) => selectedMaterial 
                        ? setSelectedMaterial({...selectedMaterial, unit: e.target.value})
                        : setNewMaterial({...newMaterial, unit: e.target.value})
                      }
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg"
                    >
                      {units.map(unit => (
                        <option key={unit} value={unit}>{unit}</option>
                      ))}
                    </select>
                  </div>
                </div>
                
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Unit Price</label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={selectedMaterial?.unitPrice || newMaterial.unitPrice}
                      onChange={(e) => {
                        const unitPrice = parseFloat(e.target.value) || 0;
                        if (selectedMaterial) {
                          const total = selectedMaterial.quantity * unitPrice;
                          setSelectedMaterial({...selectedMaterial, unitPrice, total});
                        } else {
                          setNewMaterial({...newMaterial, unitPrice});
                        }
                      }}
                      className="w-full pl-8 pr-3 py-2 text-sm border border-gray-300 rounded-lg"
                      placeholder="0.00"
                    />
                  </div>
                </div>
                
                {selectedMaterial ? (
                  <div className="flex items-center justify-between pt-2">
                    <button
                      type="button"
                      onClick={() => setSelectedMaterial(null)}
                      className="px-3 py-1 text-sm text-gray-600 hover:text-gray-800"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleUpdateMaterial}
                      className="px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700"
                    >
                      Update Material
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={handleAddMaterial}
                    className="w-full px-3 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    Add Material
                  </button>
                )}
              </div>
              
              {/* Common Materials */}
              <div className="mt-6 pt-6 border-t border-gray-200">
                <h4 className="text-xs font-medium text-gray-700 mb-2">Common Materials</h4>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {commonMaterials.map((material) => (
                    <div 
                      key={material.name}
                      className="flex items-center justify-between p-2 bg-white rounded border border-gray-200 text-sm hover:bg-blue-50 hover:border-blue-200 cursor-pointer"
                      onClick={() => handleAddCommonMaterial(material)}
                    >
                      <div>
                        <div className="font-medium">{material.name}</div>
                        <div className="text-xs text-gray-500">{material.category}</div>
                      </div>
                      <div className="text-sm font-medium">{formatCurrency(material.unitPrice)}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          
          {/* Action Buttons */}
          <div className="flex justify-end mt-6 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={handleSaveSketch}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <Save className="h-4 w-4 mr-2" />
              Save Sketch & Materials
            </button>
          </div>
        </div>
      )}
    </div>
  );
};