import React, { useState } from 'react';
import { X, FileText, DollarSign, Calendar, User, CheckCircle, XCircle, Download, Printer, Mail, Edit, RefreshCw, ExternalLink, PenTool } from 'lucide-react';
import { Estimate, Customer } from '../../types';
import { formatDate, formatCurrency } from '../../lib/utils';
import { useCrmStore } from '../../stores/crmStore';
import { ArchitecturalSketch } from './ArchitecturalSketch';
import { CustomerFileGallery } from '../Files/CustomerFileGallery';

interface EstimateDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  estimate: Estimate | null;
  onEdit: (estimate: Estimate) => void;
}

export const EstimateDetailModal: React.FC<EstimateDetailModalProps> = ({
  isOpen,
  onClose,
  estimate,
  onEdit,
}) => {
  const { customers, jobs, updateEstimate } = useCrmStore();
  const [isProcessing, setIsProcessing] = useState(false);
  const [showSketch, setShowSketch] = useState(false);
  const [sketchData, setSketchData] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<'details' | 'files' | 'sketch'>('details');

  if (!isOpen || !estimate) return null;

  const customer = customers.find(c => c.id === estimate.customerId);
  const job = estimate.jobId ? jobs.find(j => j.id === estimate.jobId) : null;

  const handleAcceptEstimate = () => {
    setIsProcessing(true);
    // Simulate API call
    setTimeout(() => {
      setIsProcessing(false);
      updateEstimate(estimate.id, { 
        accepted: true,
        signedAt: new Date().toISOString()
      });
      alert('Estimate marked as accepted!');
    }, 1500);
  };

  const handleSendEstimate = () => {
    setIsProcessing(true);
    // Simulate API call
    setTimeout(() => {
      setIsProcessing(false);
      alert('Estimate sent to customer!');
    }, 1500);
  };

  const handleCreateInvoice = () => {
    setIsProcessing(true);
    // Simulate API call
    setTimeout(() => {
      setIsProcessing(false);
      alert('Invoice created from estimate!');
      onClose();
    }, 1500);
  };

  const handleSaveSketch = (data: any) => {
    setSketchData(data);
    updateEstimate(estimate.id, { sketchData: data });
    alert('Sketch saved successfully!');
  };

  const renderDetailsTab = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        {/* Estimate Status */}
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center space-x-3 mb-2">
            <FileText className="h-5 w-5 text-gray-600" />
            <h3 className="text-lg font-medium text-gray-900">Status</h3>
          </div>
          <div className="flex items-center space-x-2">
            {estimate.accepted ? (
              <>
                <CheckCircle className="h-5 w-5 text-green-600" />
                <span className="text-green-600 font-medium">Accepted</span>
                {estimate.signedAt && (
                  <span className="text-sm text-gray-600">
                    on {formatDate(estimate.signedAt)}
                  </span>
                )}
              </>
            ) : (
              <>
                <XCircle className="h-5 w-5 text-gray-400" />
                <span className="text-gray-500 font-medium">Pending</span>
              </>
            )}
          </div>
        </div>

        {/* Amount */}
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center space-x-3 mb-2">
            <DollarSign className="h-5 w-5 text-gray-600" />
            <h3 className="text-lg font-medium text-gray-900">Total Amount</h3>
          </div>
          <div className="text-2xl font-bold text-gray-900">
            {formatCurrency(estimate.total)}
          </div>
        </div>

        {/* Expiration Date */}
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center space-x-3 mb-2">
            <Calendar className="h-5 w-5 text-gray-600" />
            <h3 className="text-lg font-medium text-gray-900">Expiration</h3>
          </div>
          <div className="text-lg font-medium text-gray-900">
            {estimate.expirationDate ? formatDate(estimate.expirationDate) : 'Not specified'}
          </div>
        </div>
      </div>

      {/* Customer & Job Info */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Customer Info */}
        <div className="border border-gray-200 rounded-lg p-4">
          <div className="flex items-center space-x-3 mb-4">
            <User className="h-5 w-5 text-gray-600" />
            <h3 className="text-lg font-medium text-gray-900">Customer Information</h3>
          </div>
          
          {customer ? (
            <div className="space-y-2">
              <p className="text-sm font-medium text-gray-900">{customer.name}</p>
              {customer.email && (
                <p className="text-sm text-gray-600">{customer.email}</p>
              )}
              {customer.phone && (
                <p className="text-sm text-gray-600">{customer.phone}</p>
              )}
              {customer.address && (
                <p className="text-sm text-gray-600">{customer.address}</p>
              )}
            </div>
          ) : (
            <p className="text-sm text-gray-500">Customer information not available</p>
          )}
        </div>

        {/* Job Info */}
        <div className="border border-gray-200 rounded-lg p-4">
          <div className="flex items-center space-x-3 mb-4">
            <FileText className="h-5 w-5 text-gray-600" />
            <h3 className="text-lg font-medium text-gray-900">Job Information</h3>
          </div>
          
          {job ? (
            <div className="space-y-2">
              <p className="text-sm font-medium text-gray-900">
                {job.jobAddress}
              </p>
              <p className="text-sm text-gray-600">
                Status: {job.status}
              </p>
              {job.startDate && (
                <p className="text-sm text-gray-600">
                  Scheduled: {formatDate(job.startDate)}
                </p>
              )}
              {job.notes && (
                <p className="text-sm text-gray-600">
                  Notes: {job.notes}
                </p>
              )}
            </div>
          ) : (
            <p className="text-sm text-gray-500">No job associated with this estimate</p>
          )}
        </div>
      </div>

      {/* Line Items */}
      <div className="border border-gray-200 rounded-lg overflow-hidden mb-6">
        <div className="p-4 bg-gray-50 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">Line Items</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Description
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Quantity
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Unit Price
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Total
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {estimate.lineItems.map((item) => (
                <tr key={item.id}>
                  <td className="px-6 py-4 whitespace-normal text-sm text-gray-900">
                    {item.description}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">
                    {item.quantity}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">
                    {formatCurrency(item.unitPrice)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 text-right">
                    {formatCurrency(item.total)}
                  </td>
                </tr>
              ))}
              
              {/* Add sketch materials if available */}
              {estimate.sketchData && estimate.sketchData.materials && estimate.sketchData.materials.length > 0 && (
                <>
                  <tr>
                    <td colSpan={4} className="px-6 py-2 bg-gray-50 text-xs font-medium text-gray-700">
                      Materials from Architectural Sketch
                    </td>
                  </tr>
                  {estimate.sketchData.materials.map((material: any) => (
                    <tr key={material.id} className="bg-blue-50">
                      <td className="px-6 py-4 whitespace-normal text-sm text-gray-900">
                        {material.name} ({material.category})
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">
                        {material.quantity} {material.unit}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">
                        {formatCurrency(material.unitPrice)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 text-right">
                        {formatCurrency(material.total)}
                      </td>
                    </tr>
                  ))}
                </>
              )}
            </tbody>
            <tfoot className="bg-gray-50">
              <tr>
                <td colSpan={3} className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 text-right">
                  Total:
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900 text-right">
                  {formatCurrency(estimate.total + (estimate.sketchData ? estimate.sketchData.totalCost || 0 : 0))}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Notes & Terms */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Notes */}
        {estimate.notes && (
          <div className="border border-gray-200 rounded-lg p-4">
            <h3 className="text-sm font-medium text-gray-900 mb-2">Notes</h3>
            <p className="text-sm text-gray-600">{estimate.notes}</p>
          </div>
        )}

        {/* Terms */}
        {estimate.terms && (
          <div className="border border-gray-200 rounded-lg p-4">
            <h3 className="text-sm font-medium text-gray-900 mb-2">Terms & Conditions</h3>
            <p className="text-sm text-gray-600">{estimate.terms}</p>
          </div>
        )}
      </div>
    </div>
  );

  const renderFilesTab = () => (
    <div className="space-y-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Customer Files</h3>
      {customer ? (
        <CustomerFileGallery customerId={customer.id} />
      ) : (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <FileText className="h-8 w-8 mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500">No customer associated with this estimate</p>
        </div>
      )}
    </div>
  );

  const renderSketchTab = () => (
    <div className="space-y-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Architectural Sketch</h3>
      {customer ? (
        <ArchitecturalSketch 
          customerId={customer.id}
          customer={customer}
          onSave={handleSaveSketch}
          initialData={estimate.sketchData}
        />
      ) : (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <PenTool className="h-8 w-8 mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500">No customer associated with this estimate</p>
        </div>
      )}
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'details':
        return renderDetailsTab();
      case 'files':
        return renderFilesTab();
      case 'sketch':
        return renderSketchTab();
      default:
        return renderDetailsTab();
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-6xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Estimate #{estimate.id.slice(-6)}</h2>
            <p className="text-gray-600">
              {customer?.name || 'Unknown Customer'} • {formatDate(estimate.createdAt)}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab('details')}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                activeTab === 'details'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Details
            </button>
            <button
              onClick={() => setActiveTab('files')}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                activeTab === 'files'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Files
            </button>
            <button
              onClick={() => setActiveTab('sketch')}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                activeTab === 'sketch'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Sketch
            </button>
          </nav>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto" style={{ maxHeight: 'calc(90vh - 200px)' }}>
          {renderTabContent()}
        </div>

        {/* Action Buttons */}
        <div className="p-6 border-t border-gray-200 bg-gray-50">
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => onEdit(estimate)}
              className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Edit className="h-4 w-4 mr-2" />
              Edit Estimate
            </button>
            
            <button 
              className="inline-flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
            >
              <Printer className="h-4 w-4 mr-2" />
              Print Estimate
            </button>
            
            <button 
              className="inline-flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
            >
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </button>
            
            <button
              onClick={handleSendEstimate}
              disabled={isProcessing}
              className="inline-flex items-center px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors disabled:opacity-50"
            >
              {isProcessing ? (
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Mail className="h-4 w-4 mr-2" />
              )}
              Send to Customer
            </button>
            
            {!estimate.accepted ? (
              <button
                onClick={handleAcceptEstimate}
                disabled={isProcessing}
                className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
              >
                {isProcessing ? (
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <CheckCircle className="h-4 w-4 mr-2" />
                )}
                Mark as Accepted
              </button>
            ) : (
              <button
                onClick={handleCreateInvoice}
                disabled={isProcessing}
                className="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors disabled:opacity-50"
              >
                {isProcessing ? (
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <FileText className="h-4 w-4 mr-2" />
                )}
                Create Invoice
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};