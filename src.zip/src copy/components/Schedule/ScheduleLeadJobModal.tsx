import React, { useState, useEffect, useRef } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { X, Calendar, User, MapPin, Briefcase, Users, FileText, Search, Tag, Link, MessageSquare } from 'lucide-react';
import { useCrmStore } from '../../stores/crmStore';
import { useScheduleStore } from '../../stores/scheduleStore';
import { formatDate } from '../../lib/utils';
import type { Customer, Lead, Job } from '../../types';

const scheduleSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  description: z.string().optional(),
  startTime: z.string().min(1, 'Start time is required'),
  endTime: z.string().min(1, 'End time is required'),
  jobAddress: z.string().optional(),
  type: z.enum(['appointment', 'job', 'meeting']),
  status: z.enum(['available', 'busy', 'tentative']),
  notes: z.string().optional(),
});

type ScheduleFormData = z.infer<typeof scheduleSchema>;

interface ScheduleLeadJobModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialType?: 'lead' | 'job';
  initialCustomerId?: string;
  initialLeadId?: string;
  initialJobId?: string;
}

export const ScheduleLeadJobModal: React.FC<ScheduleLeadJobModalProps> = ({
  isOpen,
  onClose,
  initialType = 'lead',
  initialCustomerId,
  initialLeadId,
  initialJobId,
}) => {
  const { customers, leads, jobs, users, fetchCustomers, fetchLeads, fetchJobs, fetchUsers } = useCrmStore();
  const { createEvent } = useScheduleStore();
  
  const [isLoading, setIsLoading] = useState(false);
  const [scheduleType, setScheduleType] = useState<'lead' | 'job'>(initialType);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [customerSearchTerm, setCustomerSearchTerm] = useState('');
  const [showCustomerDropdown, setShowCustomerDropdown] = useState(false);
  const [leadSearchTerm, setLeadSearchTerm] = useState('');
  const [showLeadDropdown, setShowLeadDropdown] = useState(false);
  const [jobSearchTerm, setJobSearchTerm] = useState('');
  const [showJobDropdown, setShowJobDropdown] = useState(false);
  const [selectedAttendees, setSelectedAttendees] = useState<string[]>([]);
  const [userSearchTerm, setUserSearchTerm] = useState('');
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const [createActivityLog, setCreateActivityLog] = useState(true);
  
  const customerDropdownRef = useRef<HTMLDivElement>(null);
  const leadDropdownRef = useRef<HTMLDivElement>(null);
  const jobDropdownRef = useRef<HTMLDivElement>(null);
  const userDropdownRef = useRef<HTMLDivElement>(null);
  
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    watch,
  } = useForm<ScheduleFormData>({
    resolver: zodResolver(scheduleSchema),
    defaultValues: {
      title: '',
      description: '',
      startTime: '',
      endTime: '',
      jobAddress: '',
      type: 'appointment',
      status: 'busy',
      notes: '',
    },
  });

  // Fetch data when modal opens
  useEffect(() => {
    if (isOpen) {
      fetchCustomers();
      fetchLeads();
      fetchJobs();
      fetchUsers();
      
      // Set default start and end times
      const now = new Date();
      const oneHourLater = new Date(now.getTime() + 60 * 60 * 1000);
      
      setValue('startTime', now.toISOString().slice(0, 16));
      setValue('endTime', oneHourLater.toISOString().slice(0, 16));
      
      // Set initial values if provided
      if (initialCustomerId) {
        const customer = customers.find(c => c.id === initialCustomerId);
        if (customer) {
          setSelectedCustomer(customer);
          setCustomerSearchTerm(customer.name);
        }
      }
      
      if (initialLeadId) {
        const lead = leads.find(l => l.id === initialLeadId);
        if (lead) {
          setSelectedLead(lead);
          setLeadSearchTerm(`Lead #${lead.id.slice(-6)}`);
          
          // Also set customer if available
          if (lead.customer) {
            setSelectedCustomer(lead.customer);
            setCustomerSearchTerm(lead.customer.name);
          }
        }
      }
      
      if (initialJobId) {
        const job = jobs.find(j => j.id === initialJobId);
        if (job) {
          setSelectedJob(job);
          setJobSearchTerm(`Job #${job.id.slice(-6)}`);
          
          // Also set customer if available
          if (job.customer) {
            setSelectedCustomer(job.customer);
            setCustomerSearchTerm(job.customer.name);
          }
          
          // Also set lead if available
          if (job.lead) {
            setSelectedLead(job.lead);
            setLeadSearchTerm(`Lead #${job.lead.id.slice(-6)}`);
          }
        }
      }
    }
  }, [isOpen, initialCustomerId, initialLeadId, initialJobId, customers, leads, jobs, fetchCustomers, fetchLeads, fetchJobs, fetchUsers, setValue]);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (customerDropdownRef.current && !customerDropdownRef.current.contains(event.target as Node)) {
        setShowCustomerDropdown(false);
      }
      if (leadDropdownRef.current && !leadDropdownRef.current.contains(event.target as Node)) {
        setShowLeadDropdown(false);
      }
      if (jobDropdownRef.current && !jobDropdownRef.current.contains(event.target as Node)) {
        setShowJobDropdown(false);
      }
      if (userDropdownRef.current && !userDropdownRef.current.contains(event.target as Node)) {
        setShowUserDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Update title based on selected type and entity
  useEffect(() => {
    if (scheduleType === 'lead' && selectedLead) {
      setValue('title', `Lead Appointment: ${selectedLead.customer?.name || 'Customer'}`);
      setValue('type', 'appointment');
      
      if (selectedLead.customer?.address) {
        setValue('jobAddress', selectedLead.customer.address);
      }
    } else if (scheduleType === 'job' && selectedJob) {
      setValue('title', `Job: ${selectedJob.jobAddress}`);
      setValue('type', 'job');
      setValue('jobAddress', selectedJob.jobAddress);
    }
  }, [scheduleType, selectedLead, selectedJob, setValue]);

  const handleCustomerSelect = (customer: Customer) => {
    setSelectedCustomer(customer);
    setCustomerSearchTerm(customer.name);
    setShowCustomerDropdown(false);
    
    // Reset lead and job if customer changes
    if (selectedLead?.customerId !== customer.id) {
      setSelectedLead(null);
      setLeadSearchTerm('');
    }
    
    if (selectedJob?.customerId !== customer.id) {
      setSelectedJob(null);
      setJobSearchTerm('');
    }
  };

  const handleLeadSelect = (lead: Lead) => {
    setSelectedLead(lead);
    setLeadSearchTerm(`Lead #${lead.id.slice(-6)}`);
    setShowLeadDropdown(false);
    
    // Update customer if needed
    if (lead.customer && (!selectedCustomer || selectedCustomer.id !== lead.customer.id)) {
      setSelectedCustomer(lead.customer);
      setCustomerSearchTerm(lead.customer.name);
    }
  };

  const handleJobSelect = (job: Job) => {
    setSelectedJob(job);
    setJobSearchTerm(`Job #${job.id.slice(-6)}`);
    setShowJobDropdown(false);
    
    // Update customer if needed
    if (job.customer && (!selectedCustomer || selectedCustomer.id !== job.customer.id)) {
      setSelectedCustomer(job.customer);
      setCustomerSearchTerm(job.customer.name);
    }
    
    // Update lead if needed
    if (job.lead && (!selectedLead || selectedLead.id !== job.lead.id)) {
      setSelectedLead(job.lead);
      setLeadSearchTerm(`Lead #${job.lead.id.slice(-6)}`);
    }
  };

  const handleUserToggle = (userId: string) => {
    setSelectedAttendees(prev => 
      prev.includes(userId)
        ? prev.filter(id => id !== userId)
        : [...prev, userId]
    );
  };

  const onSubmit = async (data: ScheduleFormData) => {
    if (!selectedCustomer) {
      alert('Please select a customer');
      return;
    }
    
    if (scheduleType === 'lead' && !selectedLead) {
      alert('Please select a lead');
      return;
    }
    
    if (scheduleType === 'job' && !selectedJob) {
      alert('Please select a job');
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Create the event
      await createEvent({
        title: data.title,
        description: data.description,
        startTime: data.startTime,
        endTime: data.endTime,
        location: data.jobAddress,
        type: data.type,
        status: data.status,
        allDay: false,
        customerId: selectedCustomer.id,
        leadId: selectedLead?.id,
        jobId: selectedJob?.id,
        attendees: selectedAttendees.map(userId => ({
          userId,
          status: 'accepted',
          isRequired: true,
          role: 'attendee'
        })),
        notes: data.notes,
      });
      
      // Create activity log if enabled
      if (createActivityLog) {
        console.log('Creating activity log for:', {
          customerId: selectedCustomer.id,
          leadId: selectedLead?.id,
          jobId: selectedJob?.id,
          action: `Scheduled ${data.type}`,
          details: `${data.title} on ${formatDate(data.startTime)}`
        });
        
        // In a real implementation, you would call an API to create an activity log
      }
      
      onClose();
    } catch (error) {
      console.error('Failed to schedule event:', error);
      alert('An error occurred while scheduling the event');
    } finally {
      setIsLoading(false);
    }
  };

  const filteredCustomers = customers.filter(customer => 
    customer.name.toLowerCase().includes(customerSearchTerm.toLowerCase()) ||
    customer.email?.toLowerCase().includes(customerSearchTerm.toLowerCase()) ||
    customer.phone?.includes(customerSearchTerm)
  );

  const filteredLeads = leads.filter(lead => 
    (selectedCustomer ? lead.customerId === selectedCustomer.id : true) &&
    (leadSearchTerm ? 
      lead.id.toLowerCase().includes(leadSearchTerm.toLowerCase()) ||
      lead.customer?.name.toLowerCase().includes(leadSearchTerm.toLowerCase()) ||
      lead.notes?.toLowerCase().includes(leadSearchTerm.toLowerCase())
    : true)
  );

  const filteredJobs = jobs.filter(job => 
    (selectedCustomer ? job.customerId === selectedCustomer.id : true) &&
    (jobSearchTerm ? 
      job.id.toLowerCase().includes(jobSearchTerm.toLowerCase()) ||
      job.jobAddress.toLowerCase().includes(jobSearchTerm.toLowerCase()) ||
      job.notes?.toLowerCase().includes(jobSearchTerm.toLowerCase())
    : true)
  );

  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(userSearchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(userSearchTerm.toLowerCase())
  );

  const getUserName = (userId: string) => {
    const user = users.find(u => u.id === userId);
    return user ? user.name : 'Unknown User';
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">
            Schedule {scheduleType === 'lead' ? 'Lead Appointment' : 'Job'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-6">
          {/* Schedule Type */}
          <div className="flex items-center space-x-4 mb-4">
            <button
              type="button"
              onClick={() => setScheduleType('lead')}
              className={`flex-1 py-2 px-4 rounded-lg border ${
                scheduleType === 'lead'
                  ? 'bg-blue-50 border-blue-200 text-blue-700'
                  : 'bg-white border-gray-200 text-gray-700'
              }`}
            >
              Lead Appointment
            </button>
            <button
              type="button"
              onClick={() => setScheduleType('job')}
              className={`flex-1 py-2 px-4 rounded-lg border ${
                scheduleType === 'job'
                  ? 'bg-green-50 border-green-200 text-green-700'
                  : 'bg-white border-gray-200 text-gray-700'
              }`}
            >
              Schedule Job
            </button>
          </div>

          {/* Customer Selection */}
          <div ref={customerDropdownRef}>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Customer *
            </label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={customerSearchTerm}
                onChange={(e) => {
                  setCustomerSearchTerm(e.target.value);
                  setShowCustomerDropdown(true);
                  if (e.target.value === '') {
                    setSelectedCustomer(null);
                  }
                }}
                onFocus={() => setShowCustomerDropdown(true)}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Search customers..."
              />
              
              {showCustomerDropdown && (
                <div className="absolute z-10 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                  {filteredCustomers.map(customer => (
                    <div 
                      key={customer.id} 
                      className="p-2 hover:bg-gray-100 cursor-pointer"
                      onClick={() => handleCustomerSelect(customer)}
                    >
                      <div className="text-sm font-medium">{customer.name}</div>
                      {customer.email && (
                        <div className="text-xs text-gray-500">{customer.email}</div>
                      )}
                    </div>
                  ))}
                  {filteredCustomers.length === 0 && (
                    <div className="p-2 text-sm text-gray-500">No customers found</div>
                  )}
                  <div className="p-2 border-t border-gray-100">
                    <button
                      type="button"
                      onClick={() => setShowCustomerDropdown(false)}
                      className="w-full text-xs text-center text-blue-600 hover:text-blue-800"
                    >
                      Close
                    </button>
                  </div>
                </div>
              )}
            </div>
            {!selectedCustomer && (
              <p className="mt-1 text-sm text-red-600">Customer is required</p>
            )}
          </div>

          {/* Lead Selection (for lead appointments) */}
          {scheduleType === 'lead' && (
            <div ref={leadDropdownRef}>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Lead *
              </label>
              <div className="relative">
                <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  value={leadSearchTerm}
                  onChange={(e) => {
                    setLeadSearchTerm(e.target.value);
                    setShowLeadDropdown(true);
                    if (e.target.value === '') {
                      setSelectedLead(null);
                    }
                  }}
                  onFocus={() => setShowLeadDropdown(true)}
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Search leads..."
                  disabled={!selectedCustomer}
                />
                
                {showLeadDropdown && selectedCustomer && (
                  <div className="absolute z-10 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                    {filteredLeads.map(lead => (
                      <div 
                        key={lead.id} 
                        className="p-2 hover:bg-gray-100 cursor-pointer"
                        onClick={() => handleLeadSelect(lead)}
                      >
                        <div className="text-sm font-medium">Lead #{lead.id.slice(-6)}</div>
                        <div className="text-xs text-gray-500">
                          {lead.source} • {lead.status.replace('_', ' ')}
                        </div>
                      </div>
                    ))}
                    {filteredLeads.length === 0 && (
                      <div className="p-2 text-sm text-gray-500">No leads found for this customer</div>
                    )}
                    <div className="p-2 border-t border-gray-100">
                      <button
                        type="button"
                        onClick={() => setShowLeadDropdown(false)}
                        className="w-full text-xs text-center text-blue-600 hover:text-blue-800"
                      >
                        Close
                      </button>
                    </div>
                  </div>
                )}
              </div>
              {scheduleType === 'lead' && !selectedLead && (
                <p className="mt-1 text-sm text-red-600">Lead is required</p>
              )}
            </div>
          )}

          {/* Job Selection (for job scheduling) */}
          {scheduleType === 'job' && (
            <div ref={jobDropdownRef}>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Job *
              </label>
              <div className="relative">
                <Briefcase className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  value={jobSearchTerm}
                  onChange={(e) => {
                    setJobSearchTerm(e.target.value);
                    setShowJobDropdown(true);
                    if (e.target.value === '') {
                      setSelectedJob(null);
                    }
                  }}
                  onFocus={() => setShowJobDropdown(true)}
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Search jobs..."
                  disabled={!selectedCustomer}
                />
                
                {showJobDropdown && selectedCustomer && (
                  <div className="absolute z-10 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                    {filteredJobs.map(job => (
                      <div 
                        key={job.id} 
                        className="p-2 hover:bg-gray-100 cursor-pointer"
                        onClick={() => handleJobSelect(job)}
                      >
                        <div className="text-sm font-medium">Job #{job.id.slice(-6)}</div>
                        <div className="text-xs text-gray-500">
                          {job.jobAddress} • {job.status.replace('_', ' ')}
                        </div>
                      </div>
                    ))}
                    {filteredJobs.length === 0 && (
                      <div className="p-2 text-sm text-gray-500">No jobs found for this customer</div>
                    )}
                    <div className="p-2 border-t border-gray-100">
                      <button
                        type="button"
                        onClick={() => setShowJobDropdown(false)}
                        className="w-full text-xs text-center text-blue-600 hover:text-blue-800"
                      >
                        Close
                      </button>
                    </div>
                  </div>
                )}
              </div>
              {scheduleType === 'job' && !selectedJob && (
                <p className="mt-1 text-sm text-red-600">Job is required</p>
              )}
            </div>
          )}

          {/* Event Title */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Title *
            </label>
            <input
              {...register('title')}
              type="text"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter event title"
            />
            {errors.title && (
              <p className="mt-1 text-sm text-red-600">{errors.title.message}</p>
            )}
          </div>

          {/* Date & Time */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Start Date & Time *
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  {...register('startTime')}
                  type="datetime-local"
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              {errors.startTime && (
                <p className="mt-1 text-sm text-red-600">{errors.startTime.message}</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                End Date & Time *
              </label>
              <div className="relative">
                <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  {...register('endTime')}
                  type="datetime-local"
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              {errors.endTime && (
                <p className="mt-1 text-sm text-red-600">{errors.endTime.message}</p>
              )}
            </div>
          </div>

          {/* Location */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Location
            </label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                {...register('jobAddress')}
                type="text"
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter location"
              />
            </div>
          </div>

          {/* Event Type & Status */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Event Type
              </label>
              <select
                {...register('type')}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="appointment">Appointment</option>
                <option value="job">Job</option>
                <option value="meeting">Meeting</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Status
              </label>
              <select
                {...register('status')}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="busy">Busy</option>
                <option value="tentative">Tentative</option>
                <option value="available">Available</option>
              </select>
            </div>
          </div>

          {/* Attendees */}
          <div ref={userDropdownRef}>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Attendees
            </label>
            <div className="relative">
              <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={userSearchTerm}
                onChange={(e) => {
                  setUserSearchTerm(e.target.value);
                  setShowUserDropdown(true);
                }}
                onFocus={() => setShowUserDropdown(true)}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Search users to add..."
              />
              
              {showUserDropdown && (
                <div className="absolute z-10 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                  {filteredUsers.map(user => (
                    <div key={user.id} className="p-2 hover:bg-gray-100">
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={selectedAttendees.includes(user.id)}
                          onChange={() => handleUserToggle(user.id)}
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <div>
                          <div className="text-sm font-medium">{user.name}</div>
                          <div className="text-xs text-gray-500">{user.role}</div>
                        </div>
                      </label>
                    </div>
                  ))}
                  {filteredUsers.length === 0 && (
                    <div className="p-2 text-sm text-gray-500">No users found</div>
                  )}
                  <div className="p-2 border-t border-gray-100">
                    <button
                      type="button"
                      onClick={() => setShowUserDropdown(false)}
                      className="w-full text-xs text-center text-blue-600 hover:text-blue-800"
                    >
                      Close
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Selected Attendees */}
            {selectedAttendees.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-2">
                {selectedAttendees.map(userId => {
                  return (
                    <div key={userId} className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">
                      {getUserName(userId)}
                      <button
                        type="button"
                        onClick={() => handleUserToggle(userId)}
                        className="ml-1 text-blue-600 hover:text-blue-800"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Notes */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Notes
            </label>
            <textarea
              {...register('notes')}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Additional notes about this event..."
            />
          </div>

          {/* Activity Log Option */}
          <div className="flex items-center space-x-3">
            <input
              type="checkbox"
              id="createActivityLog"
              checked={createActivityLog}
              onChange={(e) => setCreateActivityLog(e.target.checked)}
              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <label htmlFor="createActivityLog" className="text-sm text-gray-700 flex items-center">
              <MessageSquare className="h-4 w-4 mr-1 text-gray-500" />
              Create activity log in customer record
            </label>
          </div>

          {/* Related Records */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-sm font-medium text-gray-900 mb-3">Related Records</h3>
            <div className="space-y-2">
              {selectedCustomer && (
                <div className="flex items-center space-x-2">
                  <User className="h-4 w-4 text-gray-500" />
                  <span className="text-sm text-gray-700">Customer: {selectedCustomer.name}</span>
                </div>
              )}
              {selectedLead && (
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4 text-gray-500" />
                  <span className="text-sm text-gray-700">Lead: #{selectedLead.id.slice(-6)} ({selectedLead.status.replace('_', ' ')})</span>
                </div>
              )}
              {selectedJob && (
                <div className="flex items-center space-x-2">
                  <Briefcase className="h-4 w-4 text-gray-500" />
                  <span className="text-sm text-gray-700">Job: #{selectedJob.id.slice(-6)} ({selectedJob.status.replace('_', ' ')})</span>
                </div>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end space-x-3 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading || 
                (!selectedCustomer) || 
                (scheduleType === 'lead' && !selectedLead) || 
                (scheduleType === 'job' && !selectedJob)}
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? 'Scheduling...' : 'Schedule'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};