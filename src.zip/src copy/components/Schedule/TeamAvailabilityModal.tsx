import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { X, Clock, Calendar, Users, User, Save, Trash2, Plus, Copy } from 'lucide-react';
import { useCrmStore } from '../../stores/crmStore';
import { useScheduleStore } from '../../stores/scheduleStore';
import type { User as UserType, Team } from '../../types';

const availabilitySchema = z.object({
  name: z.string().min(1, 'Name is required'),
  startDate: z.string().min(1, 'Start date is required'),
  endDate: z.string().min(1, 'End date is required'),
  startTime: z.string().min(1, 'Start time is required'),
  endTime: z.string().min(1, 'End time is required'),
  daysOfWeek: z.array(z.number()).min(1, 'At least one day must be selected'),
  isRecurring: z.boolean(),
  isTeamWide: z.boolean(),
  interval: z.number().min(1, 'Interval must be at least 1'),
  duration: z.number().min(1, 'Duration must be at least 1'),
});

type AvailabilityFormData = z.infer<typeof availabilitySchema>;

interface TeamAvailabilityModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTeamId?: string | null;
  initialUserId?: string | null;
}

export const TeamAvailabilityModal: React.FC<TeamAvailabilityModalProps> = ({
  isOpen,
  onClose,
  initialTeamId,
  initialUserId,
}) => {
  const { users, teams } = useCrmStore();
  const { createEvent, settings, updateSettings } = useScheduleStore();
  const [selectedTeamId, setSelectedTeamId] = useState<string | null>(initialTeamId || null);
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>(initialUserId ? [initialUserId] : []);
  const [isLoading, setIsLoading] = useState(false);
  const [availabilityType, setAvailabilityType] = useState<'available' | 'unavailable'>('available');
  const [showTeamMembers, setShowTeamMembers] = useState(false);
  const [workingHours, setWorkingHours] = useState(settings.workingHours);
  const [workingDays, setWorkingDays] = useState(settings.workingDays);
  const [isEditingHours, setIsEditingHours] = useState(false);
  const [blockDuration, setBlockDuration] = useState(60); // Default 60 minutes
  const [blockInterval, setBlockInterval] = useState(30); // Default 30 minutes

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    watch,
  } = useForm<AvailabilityFormData>({
    resolver: zodResolver(availabilitySchema),
    defaultValues: {
      name: availabilityType === 'available' ? 'Working Hours' : 'Time Off',
      startDate: new Date().toISOString().slice(0, 10),
      endDate: new Date().toISOString().slice(0, 10),
      startTime: workingHours.start,
      endTime: workingHours.end,
      daysOfWeek: workingDays,
      isRecurring: true,
      isTeamWide: !!initialTeamId,
      interval: 30,
      duration: 60,
    },
  });

  const isTeamWide = watch('isTeamWide');
  const isRecurring = watch('isRecurring');
  const daysOfWeek = watch('daysOfWeek');
  const startTime = watch('startTime');
  const endTime = watch('endTime');
  const interval = watch('interval');
  const duration = watch('duration');

  useEffect(() => {
    if (isOpen) {
      reset({
        name: availabilityType === 'available' ? 'Working Hours' : 'Time Off',
        startDate: new Date().toISOString().slice(0, 10),
        endDate: new Date().toISOString().slice(0, 10),
        startTime: workingHours.start,
        endTime: workingHours.end,
        daysOfWeek: workingDays,
        isRecurring: true,
        isTeamWide: !!initialTeamId,
        interval: blockInterval,
        duration: blockDuration,
      });
      setSelectedTeamId(initialTeamId || null);
      setSelectedUserIds(initialUserId ? [initialUserId] : []);
    }
  }, [isOpen, initialTeamId, initialUserId, reset, availabilityType, workingHours, workingDays, blockInterval, blockDuration]);

  const handleDayToggle = (day: number) => {
    const currentDays = daysOfWeek || [];
    if (currentDays.includes(day)) {
      setValue('daysOfWeek', currentDays.filter(d => d !== day));
    } else {
      setValue('daysOfWeek', [...currentDays, day]);
    }
  };

  const handleUserToggle = (userId: string) => {
    if (selectedUserIds.includes(userId)) {
      setSelectedUserIds(prev => prev.filter(id => id !== userId));
    } else {
      setSelectedUserIds(prev => [...prev, userId]);
    }
  };

  const handleTeamChange = (teamId: string) => {
    setSelectedTeamId(teamId === 'none' ? null : teamId);
    // Clear selected users when team changes
    setSelectedUserIds([]);
  };

  const handleSaveWorkingHours = () => {
    updateSettings({
      workingHours: {
        start: watch('startTime'),
        end: watch('endTime')
      },
      workingDays: daysOfWeek
    });
    setWorkingHours({
      start: watch('startTime'),
      end: watch('endTime')
    });
    setWorkingDays(daysOfWeek);
    setIsEditingHours(false);
    alert('Default working hours updated successfully!');
  };

  const onSubmit = async (data: AvailabilityFormData) => {
    setIsLoading(true);
    try {
      // If team-wide, get all users in the team
      let usersToApply: string[] = [];
      
      if (data.isTeamWide && selectedTeamId) {
        usersToApply = users
          .filter(user => user.teamId === selectedTeamId)
          .map(user => user.id);
      } else {
        usersToApply = selectedUserIds;
      }

      if (usersToApply.length === 0) {
        alert('Please select at least one user or team');
        setIsLoading(false);
        return;
      }

      // Create availability blocks for each user
      for (const userId of usersToApply) {
        // For each selected day of the week
        for (const day of data.daysOfWeek) {
          // Calculate the next occurrence of this day
          const startDate = new Date(data.startDate);
          const dayDiff = (day - startDate.getDay() + 7) % 7;
          startDate.setDate(startDate.getDate() + dayDiff);
          
          // Parse start and end times
          const [startHour, startMinute] = data.startTime.split(':').map(Number);
          const [endHour, endMinute] = data.endTime.split(':').map(Number);
          
          // Calculate total minutes in the time range
          const startTotalMinutes = startHour * 60 + startMinute;
          const endTotalMinutes = endHour * 60 + endMinute;
          const totalMinutes = endTotalMinutes - startTotalMinutes;
          
          // Calculate number of blocks based on interval
          const numBlocks = Math.floor(totalMinutes / data.interval);
          
          // Create blocks at specified intervals
          for (let i = 0; i < numBlocks; i++) {
            const blockStartMinutes = startTotalMinutes + (i * data.interval);
            const blockEndMinutes = Math.min(blockStartMinutes + data.duration, endTotalMinutes);
            
            if (blockEndMinutes <= blockStartMinutes) continue;
            
            const blockStartHour = Math.floor(blockStartMinutes / 60);
            const blockStartMinute = blockStartMinutes % 60;
            
            const blockEndHour = Math.floor(blockEndMinutes / 60);
            const blockEndMinute = blockEndMinutes % 60;
            
            const blockStartDateTime = new Date(startDate);
            blockStartDateTime.setHours(blockStartHour, blockStartMinute, 0, 0);
            
            const blockEndDateTime = new Date(startDate);
            blockEndDateTime.setHours(blockEndHour, blockEndMinute, 0, 0);
            
            // Create the event
            await createEvent({
              title: `${data.name} (${i + 1}/${numBlocks})`,
              description: `${availabilityType === 'available' ? 'Available' : 'Unavailable'} time block`,
              startTime: blockStartDateTime.toISOString(),
              endTime: blockEndDateTime.toISOString(),
              allDay: false,
              type: 'personal',
              status: availabilityType === 'available' ? 'available' : 'time_off',
              color: availabilityType === 'available' ? '#10B981' : '#6B7280',
              isRecurring: data.isRecurring,
              recurrencePattern: data.isRecurring ? {
                type: 'weekly',
                interval: 1,
                daysOfWeek: [day],
                endDate: data.endDate ? `${data.endDate}T23:59:59Z` : undefined,
              } : undefined,
              attendees: [
                {
                  userId,
                  status: 'accepted',
                  isRequired: true,
                  role: 'attendee'
                }
              ],
            });
          }
        }
      }

      onClose();
    } catch (error) {
      console.error('Failed to create availability blocks:', error);
      alert('An error occurred while creating availability blocks');
    } finally {
      setIsLoading(false);
    }
  };

  const getTeamMembers = (teamId: string) => {
    return users.filter(user => user.teamId === teamId);
  };

  const getTeamName = (teamId: string) => {
    const team = teams.find(t => t.id === teamId);
    return team ? team.name : 'Unknown Team';
  };

  const getUserName = (userId: string) => {
    const user = users.find(u => u.id === userId);
    return user ? user.name : 'Unknown User';
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">
            {isEditingHours ? 'Edit Default Working Hours' : 'Set Team Availability'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-6">
          {/* Availability Type */}
          {!isEditingHours && (
            <div className="flex items-center space-x-4 mb-4">
              <button
                type="button"
                onClick={() => setAvailabilityType('available')}
                className={`flex-1 py-2 px-4 rounded-lg border ${
                  availabilityType === 'available'
                    ? 'bg-green-50 border-green-200 text-green-700'
                    : 'bg-white border-gray-200 text-gray-700'
                }`}
              >
                Available Hours
              </button>
              <button
                type="button"
                onClick={() => setAvailabilityType('unavailable')}
                className={`flex-1 py-2 px-4 rounded-lg border ${
                  availabilityType === 'unavailable'
                    ? 'bg-gray-50 border-gray-200 text-gray-700'
                    : 'bg-white border-gray-200 text-gray-700'
                }`}
              >
                Time Off / Unavailable
              </button>
            </div>
          )}

          {/* Default Working Hours */}
          {!isEditingHours && (
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-blue-900">Default Working Hours</h3>
                <button
                  type="button"
                  onClick={() => setIsEditingHours(true)}
                  className="text-xs text-blue-700 hover:text-blue-900"
                >
                  Edit Defaults
                </button>
              </div>
              <div className="text-sm text-blue-800">
                <p>Working days: {workingDays.map(day => ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][day]).join(', ')}</p>
                <p>Hours: {workingHours.start} - {workingHours.end}</p>
              </div>
            </div>
          )}

          {isEditingHours ? (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Working Days
                </label>
                <div className="flex flex-wrap gap-2">
                  {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, index) => (
                    <button
                      key={day}
                      type="button"
                      onClick={() => handleDayToggle(index)}
                      className={`px-3 py-1 text-sm rounded-lg border transition-colors ${
                        daysOfWeek?.includes(index)
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                      }`}
                    >
                      {day}
                    </button>
                  ))}
                </div>
                {errors.daysOfWeek && (
                  <p className="mt-1 text-sm text-red-600">{errors.daysOfWeek.message}</p>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Start Time
                  </label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <input
                      {...register('startTime')}
                      type="time"
                      className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  {errors.startTime && (
                    <p className="mt-1 text-sm text-red-600">{errors.startTime.message}</p>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    End Time
                  </label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <input
                      {...register('endTime')}
                      type="time"
                      className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  {errors.endTime && (
                    <p className="mt-1 text-sm text-red-600">{errors.endTime.message}</p>
                  )}
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setIsEditingHours(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveWorkingHours}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700"
                >
                  Save Default Hours
                </button>
              </div>
            </>
          ) : (
            <>
              {/* Block Name */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Block Name
                </label>
                <input
                  {...register('name')}
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter a name for this availability block"
                />
                {errors.name && (
                  <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>
                )}
              </div>

              {/* Date Range */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Start Date
                  </label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <input
                      {...register('startDate')}
                      type="date"
                      className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  {errors.startDate && (
                    <p className="mt-1 text-sm text-red-600">{errors.startDate.message}</p>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    End Date
                  </label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <input
                      {...register('endDate')}
                      type="date"
                      className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  {errors.endDate && (
                    <p className="mt-1 text-sm text-red-600">{errors.endDate.message}</p>
                  )}
                </div>
              </div>

              {/* Time Range */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Start Time
                  </label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <input
                      {...register('startTime')}
                      type="time"
                      className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  {errors.startTime && (
                    <p className="mt-1 text-sm text-red-600">{errors.startTime.message}</p>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    End Time
                  </label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <input
                      {...register('endTime')}
                      type="time"
                      className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  {errors.endTime && (
                    <p className="mt-1 text-sm text-red-600">{errors.endTime.message}</p>
                  )}
                </div>
              </div>

              {/* Block Settings */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Block Duration (minutes)
                  </label>
                  <input
                    {...register('duration', { valueAsNumber: true })}
                    type="number"
                    min="15"
                    step="15"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  {errors.duration && (
                    <p className="mt-1 text-sm text-red-600">{errors.duration.message}</p>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Block Interval (minutes)
                  </label>
                  <input
                    {...register('interval', { valueAsNumber: true })}
                    type="number"
                    min="15"
                    step="15"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  {errors.interval && (
                    <p className="mt-1 text-sm text-red-600">{errors.interval.message}</p>
                  )}
                </div>
              </div>

              {/* Block Preview */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-900 mb-2">Block Preview</h3>
                <div className="text-sm text-gray-600">
                  {startTime && endTime && interval && duration ? (
                    <div>
                      <p>Creating time blocks from {startTime} to {endTime}</p>
                      <p>Each block will be {duration} minutes long</p>
                      <p>Blocks will start every {interval} minutes</p>
                      <p className="mt-2 font-medium">
                        {Math.floor(
                          (
                            (parseInt(endTime.split(':')[0]) * 60 + parseInt(endTime.split(':')[1])) - 
                            (parseInt(startTime.split(':')[0]) * 60 + parseInt(startTime.split(':')[1]))
                          ) / interval
                        )} blocks will be created
                      </p>
                    </div>
                  ) : (
                    <p>Please set start time, end time, interval and duration to see preview</p>
                  )}
                </div>
              </div>

              {/* Days of Week */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Days of Week
                </label>
                <div className="flex flex-wrap gap-2">
                  {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, index) => (
                    <button
                      key={day}
                      type="button"
                      onClick={() => handleDayToggle(index)}
                      className={`px-3 py-1 text-sm rounded-lg border transition-colors ${
                        daysOfWeek?.includes(index)
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                      }`}
                    >
                      {day}
                    </button>
                  ))}
                </div>
                {errors.daysOfWeek && (
                  <p className="mt-1 text-sm text-red-600">{errors.daysOfWeek.message}</p>
                )}
              </div>

              {/* Recurring Option */}
              <div className="flex items-center space-x-3">
                <input
                  {...register('isRecurring')}
                  type="checkbox"
                  id="isRecurring"
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="isRecurring" className="text-sm text-gray-700">
                  Recurring (repeats weekly)
                </label>
              </div>

              {/* Team/User Selection */}
              <div className="space-y-4 pt-4 border-t border-gray-200">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-medium text-gray-900">Apply To</h3>
                  <div className="flex items-center space-x-3">
                    <label className="inline-flex items-center">
                      <input
                        {...register('isTeamWide')}
                        type="checkbox"
                        className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                      <span className="ml-2 text-sm text-gray-700">Team-wide</span>
                    </label>
                  </div>
                </div>

                {isTeamWide ? (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Select Team
                    </label>
                    <select
                      value={selectedTeamId || 'none'}
                      onChange={(e) => handleTeamChange(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="none">Select a team</option>
                      {teams.map(team => (
                        <option key={team.id} value={team.id}>
                          {team.name}
                        </option>
                      ))}
                    </select>
                    
                    {selectedTeamId && (
                      <div className="mt-3">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-gray-600">Team Members:</span>
                          <button
                            type="button"
                            onClick={() => setShowTeamMembers(!showTeamMembers)}
                            className="text-xs text-blue-600 hover:text-blue-800"
                          >
                            {showTeamMembers ? 'Hide' : 'Show'} Members
                          </button>
                        </div>
                        
                        {showTeamMembers && (
                          <div className="bg-gray-50 p-3 rounded-lg max-h-40 overflow-y-auto">
                            <ul className="space-y-1">
                              {getTeamMembers(selectedTeamId).map(user => (
                                <li key={user.id} className="text-sm text-gray-700">
                                  • {user.name} ({user.role})
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ) : (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Select Users
                    </label>
                    <div className="bg-gray-50 p-3 rounded-lg max-h-40 overflow-y-auto">
                      {users.map(user => (
                        <label key={user.id} className="flex items-center space-x-2 py-1">
                          <input
                            type="checkbox"
                            checked={selectedUserIds.includes(user.id)}
                            onChange={() => handleUserToggle(user.id)}
                            className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                          />
                          <span className="text-sm text-gray-700">
                            {user.name} ({user.role})
                            {user.teamId && ` - ${getTeamName(user.teamId)}`}
                          </span>
                        </label>
                      ))}
                    </div>
                    
                    {selectedUserIds.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-2">
                        {selectedUserIds.map(userId => (
                          <div key={userId} className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">
                            {getUserName(userId)}
                            <button
                              type="button"
                              onClick={() => handleUserToggle(userId)}
                              className="ml-1 text-blue-600 hover:text-blue-800"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end space-x-3 pt-6 border-t border-gray-200">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? 'Saving...' : 'Save Availability'}
                </button>
              </div>
            </>
          )}
        </form>
      </div>
    </div>
  );
};