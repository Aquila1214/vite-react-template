import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  X, Calendar, Clock, MapPin, Users, Repeat, Bell, 
  Plus, Trash2, Save, Copy, Link, AlertTriangle, User 
} from 'lucide-react';
import type { ScheduleEvent, RecurrencePattern, EventAttendee } from '../../types/schedule';
import type { User as UserType, Team } from '../../types';
import { formatDateTime } from '../../lib/utils';

const eventSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  description: z.string().optional(),
  startTime: z.string(),
  endTime: z.string(),
  allDay: z.boolean(),
  location: z.string().optional(),
  type: z.enum(['appointment', 'job', 'meeting', 'break', 'travel', 'training', 'personal']),
  status: z.enum(['available', 'busy', 'tentative', 'time_off']),
  color: z.string(),
  isRecurring: z.boolean(),
});

type EventFormData = z.infer<typeof eventSchema>;

interface EventModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Partial<ScheduleEvent>) => Promise<void>;
  onDelete?: (id: string) => Promise<void>;
  event?: ScheduleEvent | null;
  selectedTimeSlot?: { start: Date; end: Date } | null;
  users: UserType[];
  teams: Team[];
  isLoading?: boolean;
}

const eventTypeOptions = [
  { value: 'appointment', label: 'Appointment', color: '#10B981' },
  { value: 'job', label: 'Job/Service', color: '#3B82F6' },
  { value: 'meeting', label: 'Meeting', color: '#8B5CF6' },
  { value: 'break', label: 'Break', color: '#6B7280' },
  { value: 'travel', label: 'Travel', color: '#F59E0B' },
  { value: 'training', label: 'Training', color: '#EF4444' },
  { value: 'personal', label: 'Personal', color: '#06B6D4' },
];

const statusOptions = [
  { value: 'available', label: 'Available', color: '#10B981' },
  { value: 'busy', label: 'Busy', color: '#EF4444' },
  { value: 'tentative', label: 'Tentative', color: '#F59E0B' },
  { value: 'time_off', label: 'Time Off', color: '#6B7280' },
];

export const EventModal: React.FC<EventModalProps> = ({
  isOpen,
  onClose,
  onSave,
  onDelete,
  event,
  selectedTimeSlot,
  users,
  teams,
  isLoading = false,
}) => {
  const [attendees, setAttendees] = useState<EventAttendee[]>([]);
  const [recurrencePattern, setRecurrencePattern] = useState<RecurrencePattern | null>(null);
  const [showRecurrence, setShowRecurrence] = useState(false);
  const [conflicts, setConflicts] = useState<ScheduleEvent[]>([]);
  const [activeTab, setActiveTab] = useState<'details' | 'attendees' | 'recurrence'>('details');
  
  const isEditing = !!event;
  
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch,
    setValue,
  } = useForm<EventFormData>({
    resolver: zodResolver(eventSchema),
  });

  const watchedType = watch('type');
  const watchedStartTime = watch('startTime');
  const watchedEndTime = watch('endTime');
  const watchedAllDay = watch('allDay');

  useEffect(() => {
    if (isOpen) {
      if (event) {
        // Editing existing event
        reset({
          title: event.title,
          description: event.description || '',
          startTime: event.startTime.slice(0, 16), // Format for datetime-local input
          endTime: event.endTime.slice(0, 16),
          allDay: event.allDay,
          location: event.location || '',
          type: event.type,
          status: event.status,
          color: event.color || '#3B82F6',
          isRecurring: event.isRecurring,
        });
        setAttendees(event.attendees || []);
        setRecurrencePattern(event.recurrencePattern || null);
        setShowRecurrence(event.isRecurring);
      } else if (selectedTimeSlot) {
        // Creating new event with selected time slot
        reset({
          title: '',
          description: '',
          startTime: selectedTimeSlot.start.toISOString().slice(0, 16),
          endTime: selectedTimeSlot.end.toISOString().slice(0, 16),
          allDay: false,
          location: '',
          type: 'appointment',
          status: 'tentative',
          color: '#3B82F6',
          isRecurring: false,
        });
        setAttendees([]);
        setRecurrencePattern(null);
        setShowRecurrence(false);
      } else {
        // Creating new event without time slot
        const now = new Date();
        const oneHourLater = new Date(now.getTime() + 60 * 60 * 1000);
        
        reset({
          title: '',
          description: '',
          startTime: now.toISOString().slice(0, 16),
          endTime: oneHourLater.toISOString().slice(0, 16),
          allDay: false,
          location: '',
          type: 'appointment',
          status: 'tentative',
          color: '#3B82F6',
          isRecurring: false,
        });
        setAttendees([]);
        setRecurrencePattern(null);
        setShowRecurrence(false);
      }
    }
  }, [isOpen, event, selectedTimeSlot, reset]);

  // Update color when type changes
  useEffect(() => {
    if (watchedType) {
      const typeOption = eventTypeOptions.find(opt => opt.value === watchedType);
      if (typeOption) {
        setValue('color', typeOption.color);
      }
    }
  }, [watchedType, setValue]);

  const addAttendee = (userId: string) => {
    if (!attendees.find(a => a.userId === userId)) {
      setAttendees([...attendees, {
        userId,
        status: 'pending',
        isRequired: true,
        role: 'attendee',
      }]);
    }
  };

  const removeAttendee = (userId: string) => {
    setAttendees(attendees.filter(a => a.userId !== userId));
  };

  const updateAttendeeStatus = (userId: string, status: EventAttendee['status']) => {
    setAttendees(attendees.map(a => 
      a.userId === userId ? { ...a, status } : a
    ));
  };

  const onSubmit = async (data: EventFormData) => {
    try {
      const eventData: Partial<ScheduleEvent> = {
        title: data.title,
        description: data.description,
        startTime: data.startTime,
        endTime: data.endTime,
        allDay: data.allDay,
        location: data.location,
        type: data.type,
        status: data.status,
        color: data.color,
        isRecurring: data.isRecurring,
        attendees,
        recurrencePattern: data.isRecurring ? recurrencePattern : undefined,
      };

      if (isEditing && event) {
        eventData.id = event.id;
      }

      await onSave(eventData);
      onClose();
    } catch (error) {
      console.error('Failed to save event:', error);
    }
  };

  const handleDeleteEvent = async () => {
    if (event && onDelete) {
      try {
        await onDelete(event.id);
        onClose();
      } catch (error) {
        console.error('Failed to delete event:', error);
      }
    }
  };

  const getUserName = (userId: string) => {
    const user = users.find(u => u.id === userId);
    return user ? user.name : 'Unknown User';
  };

  const renderDetailsTab = () => (
    <div className="space-y-6">
      {/* Basic Information */}
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Event Title *
          </label>
          <input
            {...register('title')}
            type="text"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Enter event title"
          />
          {errors.title && (
            <p className="mt-1 text-sm text-red-600">{errors.title.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Description
          </label>
          <textarea
            {...register('description')}
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Add event description..."
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Event Type
            </label>
            <select
              {...register('type')}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {eventTypeOptions.map(option => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Status
            </label>
            <select
              {...register('status')}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {statusOptions.map(option => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Location
          </label>
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              {...register('location')}
              type="text"
              className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Add location"
            />
          </div>
        </div>
      </div>

      {/* Date & Time */}
      <div className="space-y-4">
        <h3 className="text-lg font-medium text-gray-900">Date & Time</h3>
        
        <div className="flex items-center space-x-3">
          <input
            {...register('allDay')}
            type="checkbox"
            className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
          />
          <label className="text-sm text-gray-700">All day event</label>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Start {watchedAllDay ? 'Date' : 'Date & Time'}
            </label>
            <input
              {...register('startTime')}
              type={watchedAllDay ? 'date' : 'datetime-local'}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              End {watchedAllDay ? 'Date' : 'Date & Time'}
            </label>
            <input
              {...register('endTime')}
              type={watchedAllDay ? 'date' : 'datetime-local'}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      {/* Recurrence */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium text-gray-900">Recurrence</h3>
          <div className="flex items-center space-x-3">
            <input
              {...register('isRecurring')}
              type="checkbox"
              checked={showRecurrence}
              onChange={(e) => setShowRecurrence(e.target.checked)}
              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <label className="text-sm text-gray-700">Repeat this event</label>
          </div>
        </div>

        {showRecurrence && (
          <div className="bg-gray-50 p-4 rounded-lg space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Repeat
                </label>
                <select
                  value={recurrencePattern?.type || 'weekly'}
                  onChange={(e) => setRecurrencePattern({
                    ...recurrencePattern,
                    type: e.target.value as RecurrencePattern['type'],
                    interval: 1,
                  } as RecurrencePattern)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                  <option value="yearly">Yearly</option>
                  <option value="custom">Custom</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Every
                </label>
                <div className="flex items-center space-x-2">
                  <input
                    type="number"
                    min="1"
                    max="99"
                    value={recurrencePattern?.interval || 1}
                    onChange={(e) => setRecurrencePattern({
                      ...recurrencePattern,
                      interval: parseInt(e.target.value),
                    } as RecurrencePattern)}
                    className="w-20 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <span className="text-sm text-gray-600">
                    {recurrencePattern?.type === 'daily' ? 'day(s)' :
                     recurrencePattern?.type === 'weekly' ? 'week(s)' :
                     recurrencePattern?.type === 'monthly' ? 'month(s)' :
                     recurrencePattern?.type === 'yearly' ? 'year(s)' : 'interval(s)'}
                  </span>
                </div>
              </div>
            </div>

            {recurrencePattern?.type === 'weekly' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Repeat on
                </label>
                <div className="flex flex-wrap gap-2">
                  {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, index) => (
                    <button
                      key={day}
                      type="button"
                      onClick={() => {
                        const currentDays = recurrencePattern?.daysOfWeek || [];
                        const newDays = currentDays.includes(index)
                          ? currentDays.filter(d => d !== index)
                          : [...currentDays, index];
                        setRecurrencePattern({
                          ...recurrencePattern,
                          daysOfWeek: newDays,
                        } as RecurrencePattern);
                      }}
                      className={`px-3 py-1 text-sm rounded-lg border transition-colors ${
                        recurrencePattern?.daysOfWeek?.includes(index)
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                      }`}
                    >
                      {day}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  End Date
                </label>
                <input
                  type="date"
                  value={recurrencePattern?.endDate?.slice(0, 10) || ''}
                  onChange={(e) => setRecurrencePattern({
                    ...recurrencePattern,
                    endDate: e.target.value ? `${e.target.value}T23:59:59Z` : undefined,
                  } as RecurrencePattern)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Or after
                </label>
                <div className="flex items-center space-x-2">
                  <input
                    type="number"
                    min="1"
                    max="999"
                    value={recurrencePattern?.occurrences || ''}
                    onChange={(e) => setRecurrencePattern({
                      ...recurrencePattern,
                      occurrences: e.target.value ? parseInt(e.target.value) : undefined,
                    } as RecurrencePattern)}
                    className="w-20 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="10"
                  />
                  <span className="text-sm text-gray-600">occurrences</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  const renderAttendeesTab = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium text-gray-900">Event Attendees</h3>
        <span className="text-sm text-gray-500">
          {attendees.length} attendee{attendees.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* Add Attendees */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Add Team Members
        </label>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {users.map(user => {
            const isAttending = attendees.some(a => a.userId === user.id);
            return (
              <button
                key={user.id}
                type="button"
                onClick={() => isAttending ? removeAttendee(user.id) : addAttendee(user.id)}
                className={`flex items-center justify-between p-3 rounded-lg border transition-colors ${
                  isAttending
                    ? 'bg-blue-50 border-blue-200 text-blue-900'
                    : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center text-white text-sm font-medium">
                    {user.name.charAt(0)}
                  </div>
                  <div className="text-left">
                    <div className="text-sm font-medium">{user.name}</div>
                    <div className="text-xs text-gray-500">{user.role}</div>
                  </div>
                </div>
                {isAttending && (
                  <div className="text-blue-600">
                    <Users className="h-4 w-4" />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Attendee List */}
      {attendees.length > 0 && (
        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-3">Invited Attendees</h4>
          <div className="space-y-2">
            {attendees.map(attendee => {
              const user = users.find(u => u.id === attendee.userId);
              if (!user) return null;

              return (
                <div key={attendee.userId} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center text-white text-sm font-medium">
                      {user.name.charAt(0)}
                    </div>
                    <div>
                      <div className="text-sm font-medium text-gray-900">{user.name}</div>
                      <div className="text-xs text-gray-500">{user.role}</div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <select
                      value={attendee.status}
                      onChange={(e) => updateAttendeeStatus(attendee.userId, e.target.value as EventAttendee['status'])}
                      className="text-xs px-2 py-1 border border-gray-300 rounded focus:ring-1 focus:ring-blue-500"
                    >
                      <option value="pending">Pending</option>
                      <option value="accepted">Accepted</option>
                      <option value="declined">Declined</option>
                      <option value="tentative">Tentative</option>
                    </select>

                    <button
                      type="button"
                      onClick={() => removeAttendee(attendee.userId)}
                      className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Conflict Detection */}
      {conflicts.length > 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
            <div>
              <h4 className="text-sm font-medium text-yellow-800">Scheduling Conflicts Detected</h4>
              <div className="mt-2 text-sm text-yellow-700">
                <p>The following attendees have conflicts:</p>
                <ul className="mt-1 list-disc list-inside">
                  {conflicts.map(conflict => (
                    <li key={conflict.id}>
                      {conflict.title} - {formatDateTime(conflict.startTime)}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  const renderRecurrenceTab = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium text-gray-900 mb-4">Recurrence Settings</h3>
        
        {!showRecurrence ? (
          <div className="text-center py-8">
            <Repeat className="h-8 w-8 mx-auto text-gray-300 mb-4" />
            <p className="text-gray-500">Enable recurrence in the Details tab to configure repeat settings.</p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Recurrence Summary */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="text-sm font-medium text-blue-900 mb-2">Recurrence Summary</h4>
              <p className="text-sm text-blue-800">
                {recurrencePattern ? (
                  <>
                    Repeats {recurrencePattern.type} every {recurrencePattern.interval} {
                      recurrencePattern.type === 'daily' ? 'day(s)' :
                      recurrencePattern.type === 'weekly' ? 'week(s)' :
                      recurrencePattern.type === 'monthly' ? 'month(s)' :
                      recurrencePattern.type === 'yearly' ? 'year(s)' : 'interval(s)'
                    }
                    {recurrencePattern.daysOfWeek && recurrencePattern.daysOfWeek.length > 0 && (
                      <> on {recurrencePattern.daysOfWeek.map(d => ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][d]).join(', ')}</>
                    )}
                    {recurrencePattern.endDate && (
                      <> until {new Date(recurrencePattern.endDate).toLocaleDateString()}</>
                    )}
                    {recurrencePattern.occurrences && (
                      <> for {recurrencePattern.occurrences} occurrences</>
                    )}
                  </>
                ) : (
                  'No recurrence pattern configured'
                )}
              </p>
            </div>

            {/* Advanced Recurrence Options */}
            <div className="space-y-4">
              <h4 className="text-sm font-medium text-gray-900">Advanced Options</h4>
              
              {recurrencePattern?.type === 'monthly' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Day of Month
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="31"
                      value={recurrencePattern.dayOfMonth || ''}
                      onChange={(e) => setRecurrencePattern({
                        ...recurrencePattern,
                        dayOfMonth: e.target.value ? parseInt(e.target.value) : undefined,
                      })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="15"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Week of Month
                    </label>
                    <select
                      value={recurrencePattern.weekOfMonth || ''}
                      onChange={(e) => setRecurrencePattern({
                        ...recurrencePattern,
                        weekOfMonth: e.target.value ? parseInt(e.target.value) : undefined,
                      })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="">Select week</option>
                      <option value="1">First week</option>
                      <option value="2">Second week</option>
                      <option value="3">Third week</option>
                      <option value="4">Fourth week</option>
                      <option value="-1">Last week</option>
                    </select>
                  </div>
                </div>
              )}

              {recurrencePattern?.type === 'yearly' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Month of Year
                  </label>
                  <select
                    value={recurrencePattern.monthOfYear || ''}
                    onChange={(e) => setRecurrencePattern({
                      ...recurrencePattern,
                      monthOfYear: e.target.value ? parseInt(e.target.value) : undefined,
                    })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Select month</option>
                    {Array.from({ length: 12 }, (_, i) => (
                      <option key={i + 1} value={i + 1}>
                        {new Date(2024, i, 1).toLocaleDateString('en-US', { month: 'long' })}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            {/* Recurrence Preview */}
            <div>
              <h4 className="text-sm font-medium text-gray-900 mb-2">Next Occurrences</h4>
              <div className="bg-gray-50 rounded-lg p-3">
                <div className="text-sm text-gray-600 space-y-1">
                  {/* This would show calculated next occurrences */}
                  <div>Next: {watchedStartTime && new Date(watchedStartTime).toLocaleDateString()}</div>
                  <div>Following: {watchedStartTime && new Date(new Date(watchedStartTime).getTime() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString()}</div>
                  <div className="text-xs text-gray-500 mt-2">
                    Preview shows approximate dates based on current settings
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">
            {isEditing ? 'Edit Event' : 'Create New Event'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { id: 'details', label: 'Details', icon: Calendar },
              { id: 'attendees', label: 'Attendees', icon: Users, count: attendees.length },
              { id: 'recurrence', label: 'Recurrence', icon: Repeat },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                  {tab.count !== undefined && tab.count > 0 && (
                    <span className="bg-gray-100 text-gray-600 py-0.5 px-2 rounded-full text-xs">
                      {tab.count}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
            {activeTab === 'details' && renderDetailsTab()}
            {activeTab === 'attendees' && renderAttendeesTab()}
            {activeTab === 'recurrence' && renderRecurrenceTab()}
          </div>

          {/* Actions */}
          <div className="flex items-center justify-between p-6 border-t border-gray-200 bg-gray-50">
            <div className="flex items-center space-x-3">
              {isEditing && onDelete && (
                <button
                  type="button"
                  onClick={handleDeleteEvent}
                  className="flex items-center px-4 py-2 text-sm font-medium text-red-700 bg-red-100 border border-red-300 rounded-lg hover:bg-red-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete Event
                </button>
              )}
              
              {isEditing && (
                <button
                  type="button"
                  className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Duplicate
                </button>
              )}
            </div>

            <div className="flex items-center space-x-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Save className="h-4 w-4 mr-2" />
                {isLoading ? 'Saving...' : isEditing ? 'Update Event' : 'Create Event'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};