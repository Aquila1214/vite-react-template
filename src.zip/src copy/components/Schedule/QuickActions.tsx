import React, { useRef, useState } from 'react';
import { Download, Upload, Plus, Calendar, Users, Copy, Settings, CalendarDays, CalendarOff } from 'lucide-react';
import type { ScheduleEvent } from '../../types/schedule';

interface QuickActionsProps {
  onExport: () => void;
  onImport: (file: File) => void;
  onBulkCreate: (events: Partial<ScheduleEvent>[]) => void;
}

export const QuickActions: React.FC<QuickActionsProps> = ({
  onExport,
  onImport,
  onBulkCreate,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showDropdown, setShowDropdown] = useState(false);

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onImport(file);
      // Reset the input
      event.target.value = '';
    }
  };

  const handleBulkCreateTemplate = () => {
    // Create template events for common scenarios
    const templateEvents: Partial<ScheduleEvent>[] = [
      {
        title: 'Daily Standup',
        type: 'meeting',
        status: 'busy',
        isRecurring: true,
        recurrencePattern: {
          type: 'daily',
          interval: 1,
          daysOfWeek: [1, 2, 3, 4, 5], // Weekdays only
        },
      },
      {
        title: 'Lunch Break',
        type: 'break',
        status: 'time_off',
        isRecurring: true,
        recurrencePattern: {
          type: 'daily',
          interval: 1,
        },
      },
      {
        title: 'Weekly Team Meeting',
        type: 'meeting',
        status: 'busy',
        isRecurring: true,
        recurrencePattern: {
          type: 'weekly',
          interval: 1,
          daysOfWeek: [1], // Mondays
        },
      },
    ];

    onBulkCreate(templateEvents);
    setShowDropdown(false);
  };

  return (
    <div className="relative">
      <div className="flex items-center space-x-2">
        {/* Export */}
        <button
          onClick={onExport}
          className="flex items-center px-3 py-2 text-sm text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
          title="Export Calendar"
        >
          <Download className="h-4 w-4 mr-2" />
          Export
        </button>

        {/* Import */}
        <button
          onClick={handleImportClick}
          className="flex items-center px-3 py-2 text-sm text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
          title="Import Calendar"
        >
          <Upload className="h-4 w-4 mr-2" />
          Import
        </button>

        {/* Bulk Create */}
        <div className="relative">
          <button 
            onClick={() => setShowDropdown(!showDropdown)}
            className="flex items-center px-3 py-2 text-sm text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <Plus className="h-4 w-4 mr-2" />
            Bulk Create
          </button>
          
          {/* Dropdown Menu */}
          {showDropdown && (
            <div className="absolute right-0 mt-2 w-56 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
              <div className="py-2">
                <button
                  onClick={handleBulkCreateTemplate}
                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  <Calendar className="h-4 w-4 mr-3" />
                  Create Common Templates
                </button>
                
                <button
                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  <Users className="h-4 w-4 mr-3" />
                  Team Availability Blocks
                </button>
                
                <button
                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  <Copy className="h-4 w-4 mr-3" />
                  Duplicate Week
                </button>
                
                <button
                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  <CalendarDays className="h-4 w-4 mr-3" />
                  Set Working Hours
                </button>
                
                <button
                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  <CalendarOff className="h-4 w-4 mr-3" />
                  Set Time Off
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Hidden file input */}
        <input
          ref={fileInputRef}
          type="file"
          accept=".ics,.csv"
          onChange={handleFileChange}
          className="hidden"
        />
      </div>
    </div>
  );
};