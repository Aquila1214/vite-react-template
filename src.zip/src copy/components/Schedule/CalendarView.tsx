import React, { useState, useMemo, useRef, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Plus, Clock, MapPin, Users } from 'lucide-react';
import { formatDate, formatDateTime } from '../../lib/utils';
import type { ScheduleEvent, ViewType } from '../../types/schedule';
import type { User, Team } from '../../types';

interface CalendarViewProps {
  events: ScheduleEvent[];
  currentDate: Date;
  viewType: ViewType;
  onEventClick: (event: ScheduleEvent) => void;
  onTimeSlotClick: (timeSlot: { start: Date; end: Date }) => void;
  onEventUpdate: (eventData: Partial<ScheduleEvent>) => void;
  users: User[];
  teams: Team[];
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  events,
  currentDate,
  viewType,
  onEventClick,
  onTimeSlotClick,
  onEventUpdate,
  users,
  teams,
}) => {
  const [draggedEvent, setDraggedEvent] = useState<ScheduleEvent | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const dragSourceRef = useRef<{ day: Date, hour?: number } | null>(null);
  const dragTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const resizeTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const [isResizing, setIsResizing] = useState(false);
  const [resizeEvent, setResizeEvent] = useState<ScheduleEvent | null>(null);
  const [resizeDirection, setResizeDirection] = useState<'start' | 'end'>('end');
  const [resizeInitialPos, setResizeInitialPos] = useState<{ x: number, y: number } | null>(null);
  const [resizeInitialTime, setResizeInitialTime] = useState<{ start: Date, end: Date } | null>(null);

  // Clean up timeouts on unmount
  useEffect(() => {
    return () => {
      if (dragTimeoutRef.current) {
        clearTimeout(dragTimeoutRef.current);
      }
      if (resizeTimeoutRef.current) {
        clearTimeout(resizeTimeoutRef.current);
      }
    };
  }, []);

  // Define helper functions before using them in useMemo
  const generateDayView = (date: Date) => {
    const hours = Array.from({ length: 24 }, (_, i) => i);
    return {
      type: 'day' as const,
      date,
      hours,
      days: [date],
    };
  };

  const generateWeekView = (date: Date) => {
    const startOfWeek = new Date(date);
    startOfWeek.setDate(date.getDate() - date.getDay());
    
    const days = Array.from({ length: 7 }, (_, i) => {
      const day = new Date(startOfWeek);
      day.setDate(startOfWeek.getDate() + i);
      return day;
    });
    
    const hours = Array.from({ length: 24 }, (_, i) => i);
    
    return {
      type: 'week' as const,
      startDate: startOfWeek,
      days,
      hours,
    };
  };

  const generateMonthView = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startDate = new Date(firstDay);
    startDate.setDate(firstDay.getDate() - firstDay.getDay());
    
    const weeks = [];
    const current = new Date(startDate);
    
    while (current <= lastDay || current.getDay() !== 0) {
      const week = [];
      for (let i = 0; i < 7; i++) {
        week.push(new Date(current));
        current.setDate(current.getDate() + 1);
      }
      weeks.push(week);
      
      if (current.getMonth() !== month && current.getDay() === 0) break;
    }
    
    return {
      type: 'month' as const,
      year,
      month,
      weeks,
    };
  };

  // Generate calendar grid based on view type
  const calendarData = useMemo(() => {
    const today = new Date(currentDate);
    
    switch (viewType) {
      case 'day':
        return generateDayView(today);
      case 'week':
        return generateWeekView(today);
      case 'month':
        return generateMonthView(today);
      default:
        return generateWeekView(today);
    }
  }, [currentDate, viewType]);

  // Get events for a specific time slot
  const getEventsForSlot = (date: Date, hour?: number) => {
    return events.filter(event => {
      const eventStart = new Date(event.startTime);
      const eventEnd = new Date(event.endTime);
      
      if (event.allDay) {
        // For all-day events, check if the date matches
        const eventDate = new Date(eventStart);
        const slotDate = new Date(date);
        return eventDate.getFullYear() === slotDate.getFullYear() &&
               eventDate.getMonth() === slotDate.getMonth() &&
               eventDate.getDate() === slotDate.getDate();
      }
      
      if (hour !== undefined) {
        // Hour-specific filtering for day/week view
        const slotStart = new Date(date);
        slotStart.setHours(hour, 0, 0, 0);
        const slotEnd = new Date(slotStart);
        slotEnd.setHours(hour + 1, 0, 0, 0);
        
        return eventStart < slotEnd && eventEnd > slotStart;
      } else {
        // Day-specific filtering for month view
        const dayStart = new Date(date);
        dayStart.setHours(0, 0, 0, 0);
        const dayEnd = new Date(date);
        dayEnd.setHours(23, 59, 59, 999);
        
        return eventStart < dayEnd && eventEnd > dayStart;
      }
    });
  };

  // Get all-day events for a specific date
  const getAllDayEventsForDate = (date: Date) => {
    return events.filter(event => {
      if (!event.allDay) return false;
      
      const eventDate = new Date(event.startTime);
      const slotDate = new Date(date);
      
      return eventDate.getFullYear() === slotDate.getFullYear() &&
             eventDate.getMonth() === slotDate.getMonth() &&
             eventDate.getDate() === slotDate.getDate();
    });
  };

  const handleTimeSlotClick = (date: Date, hour?: number) => {
    // Don't create new events if we're in the middle of a drag operation
    if (isDragging || isResizing) return;
    
    const start = new Date(date);
    if (hour !== undefined) {
      start.setHours(hour, 0, 0, 0);
    }
    
    const end = new Date(start);
    if (hour !== undefined) {
      end.setHours(hour + 1, 0, 0, 0);
    } else {
      end.setHours(start.getHours() + 1, 0, 0, 0);
    }
    
    onTimeSlotClick({ start, end });
  };

  const handleEventDragStart = (event: ScheduleEvent, e: React.DragEvent, date: Date, hour?: number) => {
    e.stopPropagation();
    setDraggedEvent(event);
    setIsDragging(true);
    
    // Store the source day and hour for reference
    dragSourceRef.current = { day: date, hour };
    
    // Set the drag data
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', event.id);
    
    // Create a ghost image that's less visible
    const ghostElement = document.createElement('div');
    ghostElement.textContent = event.title;
    ghostElement.style.opacity = '0.5';
    ghostElement.style.position = 'absolute';
    ghostElement.style.top = '-1000px';
    document.body.appendChild(ghostElement);
    
    e.dataTransfer.setDragImage(ghostElement, 0, 0);
    
    // Clean up the ghost element after drag starts
    setTimeout(() => {
      document.body.removeChild(ghostElement);
    }, 0);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleEventDrop = (date: Date, hour: number | undefined, e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!draggedEvent || !dragSourceRef.current) {
      setIsDragging(false);
      setDraggedEvent(null);
      return;
    }
    
    // Calculate the new start and end times
    const originalStart = new Date(draggedEvent.startTime);
    const originalEnd = new Date(draggedEvent.endTime);
    const duration = originalEnd.getTime() - originalStart.getTime();
    
    const newStart = new Date(date);
    if (hour !== undefined) {
      newStart.setHours(hour, 0, 0, 0);
    } else {
      // For month view, keep the same time of day
      newStart.setHours(
        originalStart.getHours(),
        originalStart.getMinutes(),
        originalStart.getSeconds(),
        originalStart.getMilliseconds()
      );
    }
    
    const newEnd = new Date(newStart.getTime() + duration);
    
    // For all-day events, ensure they stay all-day
    if (draggedEvent.allDay) {
      newStart.setHours(0, 0, 0, 0);
      newEnd.setHours(23, 59, 59, 999);
    }
    
    // Create a copy of the event with new times
    const updatedEvent = {
      id: draggedEvent.id,
      startTime: newStart.toISOString(),
      endTime: newEnd.toISOString(),
      allDay: draggedEvent.allDay
    };
    
    // Use a timeout to delay the update (simulating human behavior)
    if (dragTimeoutRef.current) {
      clearTimeout(dragTimeoutRef.current);
    }
    
    dragTimeoutRef.current = setTimeout(() => {
      // Update the event with new times
      onEventUpdate(updatedEvent);
      
      // Create activity log if the event is related to a customer
      if (draggedEvent.customerId) {
        console.log(`Activity log: Event "${draggedEvent.title}" rescheduled for customer ${draggedEvent.customerId}`);
        // In a real implementation, you would call an API to create an activity log
      }
      
      // Reset drag state
      setIsDragging(false);
      setDraggedEvent(null);
      dragSourceRef.current = null;
      dragTimeoutRef.current = null;
    }, 500); // 500ms delay to simulate human behavior
  };

  const handleResizeStart = (event: ScheduleEvent, direction: 'start' | 'end', e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    
    setResizeEvent(event);
    setResizeDirection(direction);
    setIsResizing(true);
    setResizeInitialPos({ x: e.clientX, y: e.clientY });
    setResizeInitialTime({
      start: new Date(event.startTime),
      end: new Date(event.endTime)
    });
    
    // Add event listeners for mouse move and mouse up
    document.addEventListener('mousemove', handleResizeMove);
    document.addEventListener('mouseup', handleResizeEnd);
  };
  
  const handleResizeMove = (e: MouseEvent) => {
    if (!isResizing || !resizeEvent || !resizeInitialPos || !resizeInitialTime) return;
    
    // Calculate the time difference based on vertical movement
    const yDiff = e.clientY - resizeInitialPos.y;
    const hourDiff = Math.round(yDiff / 30); // Assuming 30px per hour
    
    if (resizeDirection === 'start') {
      const newStart = new Date(resizeInitialTime.start);
      newStart.setHours(newStart.getHours() + hourDiff);
      
      // Ensure start time doesn't go beyond end time
      if (newStart < resizeInitialTime.end) {
        setResizeEvent({
          ...resizeEvent,
          startTime: newStart.toISOString()
        });
      }
    } else {
      const newEnd = new Date(resizeInitialTime.end);
      newEnd.setHours(newEnd.getHours() + hourDiff);
      
      // Ensure end time doesn't go before start time
      if (newEnd > resizeInitialTime.start) {
        setResizeEvent({
          ...resizeEvent,
          endTime: newEnd.toISOString()
        });
      }
    }
  };
  
  const handleResizeEnd = () => {
    document.removeEventListener('mousemove', handleResizeMove);
    document.removeEventListener('mouseup', handleResizeEnd);
    
    if (!resizeEvent) {
      setIsResizing(false);
      return;
    }
    
    // Use a timeout to delay the update (simulating human behavior)
    if (resizeTimeoutRef.current) {
      clearTimeout(resizeTimeoutRef.current);
    }
    
    resizeTimeoutRef.current = setTimeout(() => {
      // Update the event with new times
      onEventUpdate({
        id: resizeEvent.id,
        startTime: resizeEvent.startTime,
        endTime: resizeEvent.endTime
      });
      
      // Create activity log if the event is related to a customer
      if (resizeEvent.customerId) {
        console.log(`Activity log: Event "${resizeEvent.title}" duration changed for customer ${resizeEvent.customerId}`);
        // In a real implementation, you would call an API to create an activity log
      }
      
      // Reset resize state
      setIsResizing(false);
      setResizeEvent(null);
      setResizeInitialPos(null);
      setResizeInitialTime(null);
      resizeTimeoutRef.current = null;
    }, 500); // 500ms delay to simulate human behavior
  };

  const getUserName = (userId: string) => {
    const user = users.find(u => u.id === userId);
    return user ? user.name : 'Unknown User';
  };

  const renderEvent = (event: ScheduleEvent, date: Date, hour?: number, isCompact = false) => {
    const attendeeNames = event.attendees?.map(a => getUserName(a.userId)).join(', ') || '';
    
    // For all-day events, render differently
    if (event.allDay) {
      return (
        <div
          key={event.id}
          draggable
          onDragStart={(e) => handleEventDragStart(event, e, date, hour)}
          onClick={(e) => {
            e.stopPropagation();
            onEventClick(event);
          }}
          className={`
            relative p-1 rounded-lg border-l-4 cursor-pointer transition-all duration-200 hover:shadow-md
            ${isCompact ? 'text-xs' : 'text-sm'} w-full
          `}
          style={{
            backgroundColor: event.color + '20',
            borderLeftColor: event.color,
          }}
        >
          <div className="font-medium text-gray-900 truncate">
            {event.title}
          </div>
          
          {/* Status indicator */}
          <div className={`absolute top-1 right-1 w-2 h-2 rounded-full ${
            event.status === 'busy' ? 'bg-red-500' :
            event.status === 'tentative' ? 'bg-yellow-500' :
            event.status === 'time_off' ? 'bg-gray-500' :
            'bg-green-500'
          }`} />
        </div>
      );
    }
    
    // For regular events
    return (
      <div
        key={event.id}
        draggable
        onDragStart={(e) => handleEventDragStart(event, e, date, hour)}
        onClick={(e) => {
          e.stopPropagation();
          onEventClick(event);
        }}
        className={`
          relative p-2 rounded-lg border-l-4 cursor-pointer transition-all duration-200 hover:shadow-md
          ${isCompact ? 'text-xs' : 'text-sm'}
        `}
        style={{
          backgroundColor: event.color + '20',
          borderLeftColor: event.color,
        }}
      >
        <div className="font-medium text-gray-900 truncate">
          {event.title}
        </div>
        
        {!isCompact && (
          <>
            <div className="flex items-center text-xs text-gray-600 mt-1">
              <Clock className="h-3 w-3 mr-1" />
              {formatDateTime(event.startTime)} - {formatDateTime(event.endTime)}
            </div>
            
            {event.location && (
              <div className="flex items-center text-xs text-gray-600 mt-1">
                <MapPin className="h-3 w-3 mr-1" />
                {event.location}
              </div>
            )}
            
            {attendeeNames && (
              <div className="flex items-center text-xs text-gray-600 mt-1">
                <Users className="h-3 w-3 mr-1" />
                {attendeeNames}
              </div>
            )}
          </>
        )}
        
        {/* Status indicator */}
        <div className={`absolute top-1 right-1 w-2 h-2 rounded-full ${
          event.status === 'busy' ? 'bg-red-500' :
          event.status === 'tentative' ? 'bg-yellow-500' :
          event.status === 'time_off' ? 'bg-gray-500' :
          'bg-green-500'
        }`} />
        
        {/* Resize handles */}
        <div 
          className="absolute top-0 left-0 right-0 h-2 cursor-ns-resize"
          onMouseDown={(e) => handleResizeStart(event, 'start', e)}
        />
        <div 
          className="absolute bottom-0 left-0 right-0 h-2 cursor-ns-resize"
          onMouseDown={(e) => handleResizeStart(event, 'end', e)}
        />
      </div>
    );
  };

  const renderDayView = () => {
    const { hours, days } = calendarData as ReturnType<typeof generateDayView>;
    const date = days[0];
    const allDayEvents = getAllDayEventsForDate(date);
    
    return (
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex-shrink-0 bg-gray-50 border-b border-gray-200 p-4">
          <h3 className="text-lg font-semibold text-gray-900">
            {formatDate(date)}
          </h3>
        </div>
        
        {/* All-day events */}
        {allDayEvents.length > 0 && (
          <div className="flex-shrink-0 bg-gray-50 border-b border-gray-200 p-2">
            <div className="flex items-center space-x-2">
              <div className="text-sm font-medium text-gray-700 w-16">All day</div>
              <div className="flex-1 space-y-1">
                {allDayEvents.map(event => renderEvent(event, date, undefined))}
              </div>
            </div>
          </div>
        )}
        
        {/* Time slots */}
        <div className="flex-1 overflow-y-auto">
          <div className="grid grid-cols-1 gap-0">
            {hours.map(hour => {
              const slotEvents = getEventsForSlot(date, hour).filter(event => !event.allDay);
              
              return (
                <div
                  key={hour}
                  className="border-b border-gray-100 min-h-[60px] p-2 hover:bg-gray-50 cursor-pointer"
                  onClick={() => handleTimeSlotClick(date, hour)}
                  onDragOver={handleDragOver}
                  onDrop={(e) => handleEventDrop(date, hour, e)}
                >
                  <div className="flex items-start space-x-3">
                    <div className="text-sm text-gray-500 w-16">
                      {hour.toString().padStart(2, '0')}:00
                    </div>
                    
                    <div className="flex-1 space-y-1">
                      {slotEvents.map(event => renderEvent(event, date, hour))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  };

  const renderWeekView = () => {
    const { days, hours } = calendarData as ReturnType<typeof generateWeekView>;
    
    // Collect all-day events for the week
    const allDayEventsByDay = days.map(day => getAllDayEventsForDate(day));
    const hasAllDayEvents = allDayEventsByDay.some(events => events.length > 0);
    
    return (
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex-shrink-0 bg-gray-50 border-b border-gray-200">
          <div className="grid grid-cols-8 gap-0">
            <div className="p-3 text-sm font-medium text-gray-500">Time</div>
            {days.map(day => (
              <div key={day.toISOString()} className="p-3 text-center border-l border-gray-200">
                <div className="text-sm font-medium text-gray-900">
                  {day.toLocaleDateString('en-US', { weekday: 'short' })}
                </div>
                <div className="text-lg font-semibold text-gray-900">
                  {day.getDate()}
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* All-day events row */}
        {hasAllDayEvents && (
          <div className="flex-shrink-0 border-b border-gray-200">
            <div className="grid grid-cols-8 gap-0">
              <div className="p-2 text-sm font-medium text-gray-500 border-r border-gray-200">
                All day
              </div>
              {days.map((day, dayIndex) => (
                <div 
                  key={day.toISOString()} 
                  className="p-2 border-r border-gray-200 last:border-r-0"
                  onDragOver={handleDragOver}
                  onDrop={(e) => handleEventDrop(day, undefined, e)}
                >
                  <div className="space-y-1">
                    {allDayEventsByDay[dayIndex].map(event => renderEvent(event, day, undefined, true))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Time grid */}
        <div className="flex-1 overflow-y-auto">
          <div className="grid grid-cols-8 gap-0">
            {/* Time column */}
            <div className="border-r border-gray-200">
              {hours.map(hour => (
                <div key={hour} className="h-16 border-b border-gray-100 p-2 text-sm text-gray-500">
                  {hour.toString().padStart(2, '0')}:00
                </div>
              ))}
            </div>
            
            {/* Day columns */}
            {days.map(day => (
              <div key={day.toISOString()} className="border-r border-gray-200">
                {hours.map(hour => {
                  const slotEvents = getEventsForSlot(day, hour).filter(event => !event.allDay);
                  
                  return (
                    <div
                      key={hour}
                      className="h-16 border-b border-gray-100 p-1 hover:bg-gray-50 cursor-pointer"
                      onClick={() => handleTimeSlotClick(day, hour)}
                      onDragOver={handleDragOver}
                      onDrop={(e) => handleEventDrop(day, hour, e)}
                    >
                      <div className="space-y-1">
                        {slotEvents.map(event => renderEvent(event, day, hour, true))}
                      </div>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  const renderMonthView = () => {
    const { weeks, month, year } = calendarData as ReturnType<typeof generateMonthView>;
    
    return (
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex-shrink-0 bg-gray-50 border-b border-gray-200">
          <div className="grid grid-cols-7 gap-0">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day} className="p-3 text-center text-sm font-medium text-gray-500 border-r border-gray-200 last:border-r-0">
                {day}
              </div>
            ))}
          </div>
        </div>
        
        {/* Calendar grid */}
        <div className="flex-1">
          <div className="grid grid-rows-6 gap-0 h-full">
            {weeks.map((week, weekIndex) => (
              <div key={weekIndex} className="grid grid-cols-7 gap-0 border-b border-gray-200 last:border-b-0">
                {week.map(day => {
                  const allDayEvents = getAllDayEventsForDate(day);
                  const regularEvents = getEventsForSlot(day).filter(event => !event.allDay);
                  const isCurrentMonth = day.getMonth() === month;
                  const isToday = day.toDateString() === new Date().toDateString();
                  
                  return (
                    <div
                      key={day.toISOString()}
                      className={`
                        border-r border-gray-200 last:border-r-0 p-2 cursor-pointer hover:bg-gray-50
                        ${!isCurrentMonth ? 'bg-gray-50 text-gray-400' : ''}
                        ${isToday ? 'bg-blue-50' : ''}
                      `}
                      onClick={() => handleTimeSlotClick(day)}
                      onDragOver={handleDragOver}
                      onDrop={(e) => handleEventDrop(day, undefined, e)}
                    >
                      <div className={`text-sm font-medium mb-1 ${isToday ? 'text-blue-600' : ''}`}>
                        {day.getDate()}
                      </div>
                      
                      {/* All-day events first */}
                      {allDayEvents.length > 0 && (
                        <div className="space-y-1 mb-1">
                          {allDayEvents.map(event => renderEvent(event, day, undefined, true))}
                        </div>
                      )}
                      
                      {/* Regular events */}
                      <div className="space-y-1">
                        {regularEvents.slice(0, 3).map(event => renderEvent(event, day, undefined, true))}
                        {regularEvents.length > 3 && (
                          <div className="text-xs text-gray-500">
                            +{regularEvents.length - 3} more
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="h-full bg-white">
      {viewType === 'day' && renderDayView()}
      {viewType === 'week' && renderWeekView()}
      {viewType === 'month' && renderMonthView()}
    </div>
  );
};