import React, { useState, useEffect } from 'react';
import { X, Calendar, Check, RefreshCw, AlertTriangle, Info } from 'lucide-react';
import { useScheduleStore } from '../../stores/scheduleStore';
import { useCrmStore } from '../../stores/crmStore';
import { formatDate } from '../../lib/utils';

interface Holiday {
  id: string;
  name: string;
  date: string;
  type: 'federal' | 'religious' | 'observance';
  selected: boolean;
}

interface HolidaySyncModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HolidaySyncModal: React.FC<HolidaySyncModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { createEvent, settings, updateSettings } = useScheduleStore();
  const { users } = useCrmStore();
  const [isLoading, setIsLoading] = useState(false);
  const [holidays, setHolidays] = useState<Holiday[]>([]);
  const [selectedHolidays, setSelectedHolidays] = useState<string[]>([]);
  const [year, setYear] = useState(new Date().getFullYear());
  const [applyToAllUsers, setApplyToAllUsers] = useState(true);
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [syncStatus, setSyncStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  // Generate holidays for the current year
  useEffect(() => {
    if (isOpen) {
      // Reset state
      setSyncStatus('idle');
      setApplyToAllUsers(true);
      setSelectedUsers([]);
      
      // Generate holidays for the selected year
      const federalHolidays = [
        { name: "New Year's Day", month: 0, day: 1, type: 'federal' },
        { name: "Martin Luther King Jr. Day", month: 0, day: 0, nthDay: 3, dayOfWeek: 1, type: 'federal' }, // 3rd Monday in January
        { name: "Presidents' Day", month: 1, day: 0, nthDay: 3, dayOfWeek: 1, type: 'federal' }, // 3rd Monday in February
        { name: "Memorial Day", month: 4, day: 0, nthDay: -1, dayOfWeek: 1, type: 'federal' }, // Last Monday in May
        { name: "Independence Day", month: 6, day: 4, type: 'federal' },
        { name: "Labor Day", month: 8, day: 0, nthDay: 1, dayOfWeek: 1, type: 'federal' }, // 1st Monday in September
        { name: "Columbus Day", month: 9, day: 0, nthDay: 2, dayOfWeek: 1, type: 'federal' }, // 2nd Monday in October
        { name: "Veterans Day", month: 10, day: 11, type: 'federal' },
        { name: "Thanksgiving Day", month: 10, day: 0, nthDay: 4, dayOfWeek: 4, type: 'federal' }, // 4th Thursday in November
        { name: "Christmas Day", month: 11, day: 25, type: 'federal' },
      ];

      const religiousHolidays = [
        { name: "Easter Sunday", month: 3, day: 9, type: 'religious', adjustable: true }, // Approximate for 2024
        { name: "Good Friday", month: 3, day: 7, type: 'religious', adjustable: true }, // Approximate for 2024
        { name: "Ash Wednesday", month: 1, day: 14, type: 'religious', adjustable: true }, // Approximate for 2024
        { name: "Palm Sunday", month: 3, day: 2, type: 'religious', adjustable: true }, // Approximate for 2024
        { name: "Hanukkah (Start)", month: 11, day: 25, type: 'religious', adjustable: true }, // Approximate for 2024
        { name: "Passover", month: 3, day: 22, type: 'religious', adjustable: true }, // Approximate for 2024
        { name: "Rosh Hashanah", month: 9, day: 2, type: 'religious', adjustable: true }, // Approximate for 2024
        { name: "Yom Kippur", month: 9, day: 11, type: 'religious', adjustable: true }, // Approximate for 2024
        { name: "Ramadan (Start)", month: 2, day: 10, type: 'religious', adjustable: true }, // Approximate for 2024
        { name: "Eid al-Fitr", month: 3, day: 9, type: 'religious', adjustable: true }, // Approximate for 2024
      ];

      const observances = [
        { name: "Valentine's Day", month: 1, day: 14, type: 'observance' },
        { name: "St. Patrick's Day", month: 2, day: 17, type: 'observance' },
        { name: "Mother's Day", month: 4, day: 0, nthDay: 2, dayOfWeek: 0, type: 'observance' }, // 2nd Sunday in May
        { name: "Father's Day", month: 5, day: 0, nthDay: 3, dayOfWeek: 0, type: 'observance' }, // 3rd Sunday in June
        { name: "Halloween", month: 9, day: 31, type: 'observance' },
      ];

      const allHolidays = [...federalHolidays, ...religiousHolidays, ...observances];
      
      // Calculate actual dates for the selected year
      const holidayDates: Holiday[] = allHolidays.map((holiday, index) => {
        let date: Date;
        
        if (holiday.nthDay !== undefined && holiday.dayOfWeek !== undefined) {
          // For holidays that fall on a specific nth day of the week in a month
          date = new Date(year, holiday.month, 1);
          
          // Find the first occurrence of the day of the week
          while (date.getDay() !== holiday.dayOfWeek) {
            date.setDate(date.getDate() + 1);
          }
          
          // If it's the nth occurrence, add (n-1) weeks
          if (holiday.nthDay > 0) {
            date.setDate(date.getDate() + (holiday.nthDay - 1) * 7);
          } else if (holiday.nthDay === -1) {
            // For "last" occurrence, start from the end of the month
            date = new Date(year, holiday.month + 1, 0);
            while (date.getDay() !== holiday.dayOfWeek) {
              date.setDate(date.getDate() - 1);
            }
          }
        } else {
          // For fixed date holidays
          date = new Date(year, holiday.month, holiday.day);
        }
        
        return {
          id: `holiday-${index}`,
          name: holiday.name,
          date: date.toISOString().split('T')[0],
          type: holiday.type as 'federal' | 'religious' | 'observance',
          selected: holiday.type === 'federal', // Pre-select federal holidays
        };
      });
      
      setHolidays(holidayDates);
      setSelectedHolidays(holidayDates.filter(h => h.type === 'federal').map(h => h.id));
    }
  }, [isOpen, year]);

  const handleHolidayToggle = (holidayId: string) => {
    setHolidays(holidays.map(holiday => 
      holiday.id === holidayId 
        ? { ...holiday, selected: !holiday.selected }
        : holiday
    ));
    
    setSelectedHolidays(prev => 
      prev.includes(holidayId)
        ? prev.filter(id => id !== holidayId)
        : [...prev, holidayId]
    );
  };

  const handleSelectAllHolidays = () => {
    setHolidays(holidays.map(holiday => ({ ...holiday, selected: true })));
    setSelectedHolidays(holidays.map(holiday => holiday.id));
  };

  const handleSelectFederalHolidays = () => {
    setHolidays(holidays.map(holiday => ({ 
      ...holiday, 
      selected: holiday.type === 'federal' 
    })));
    setSelectedHolidays(holidays.filter(h => h.type === 'federal').map(h => h.id));
  };

  const handleSelectReligiousHolidays = () => {
    setHolidays(holidays.map(holiday => ({ 
      ...holiday, 
      selected: holiday.selected || holiday.type === 'religious' 
    })));
    
    const religiousHolidayIds = holidays.filter(h => h.type === 'religious').map(h => h.id);
    setSelectedHolidays(prev => {
      const uniqueIds = new Set([...prev, ...religiousHolidayIds]);
      return Array.from(uniqueIds);
    });
  };

  const handleUserToggle = (userId: string) => {
    setSelectedUsers(prev => 
      prev.includes(userId)
        ? prev.filter(id => id !== userId)
        : [...prev, userId]
    );
  };

  const handleSyncHolidays = async () => {
    if (selectedHolidays.length === 0) {
      alert('Please select at least one holiday to sync');
      return;
    }
    
    if (!applyToAllUsers && selectedUsers.length === 0) {
      alert('Please select at least one user');
      return;
    }
    
    setIsLoading(true);
    setSyncStatus('loading');
    
    try {
      const selectedHolidayData = holidays.filter(h => selectedHolidays.includes(h.id));
      const usersToApply = applyToAllUsers ? users.map(u => u.id) : selectedUsers;
      
      for (const holiday of selectedHolidayData) {
        const holidayDate = new Date(holiday.date);
        
        for (const userId of usersToApply) {
          // Create an all-day event for the holiday
          await createEvent({
            title: holiday.name,
            description: `Holiday: ${holiday.name}`,
            startTime: `${holiday.date}T00:00:00Z`,
            endTime: `${holiday.date}T23:59:59Z`,
            allDay: true,
            type: 'personal',
            status: 'time_off',
            color: holiday.type === 'federal' ? '#EF4444' : 
                   holiday.type === 'religious' ? '#8B5CF6' : '#F59E0B',
            isRecurring: false,
            attendees: [
              {
                userId,
                status: 'accepted',
                isRequired: true,
                role: 'attendee'
              }
            ],
          });
        }
      }
      
      // Update holiday sync settings
      updateSettings({
        holidaySync: {
          enabled: true,
          lastSynced: new Date().toISOString(),
          includeFederal: selectedHolidayData.some(h => h.type === 'federal'),
          includeReligious: selectedHolidayData.some(h => h.type === 'religious'),
          includeObservances: selectedHolidayData.some(h => h.type === 'observance')
        }
      });
      
      setSyncStatus('success');
      setTimeout(() => {
        onClose();
      }, 2000);
    } catch (error) {
      console.error('Failed to sync holidays:', error);
      setSyncStatus('error');
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Sync Holidays to Calendar</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Year Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Select Year
            </label>
            <select
              value={year}
              onChange={(e) => setYear(parseInt(e.target.value))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {Array.from({ length: 5 }, (_, i) => new Date().getFullYear() + i).map(y => (
                <option key={y} value={y}>{y}</option>
              ))}
            </select>
          </div>

          {/* Quick Select Buttons */}
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={handleSelectFederalHolidays}
              className="px-3 py-1 text-sm bg-red-100 text-red-800 rounded-lg hover:bg-red-200 transition-colors"
            >
              Federal Holidays
            </button>
            <button
              type="button"
              onClick={handleSelectReligiousHolidays}
              className="px-3 py-1 text-sm bg-purple-100 text-purple-800 rounded-lg hover:bg-purple-200 transition-colors"
            >
              Religious Holidays
            </button>
            <button
              type="button"
              onClick={handleSelectAllHolidays}
              className="px-3 py-1 text-sm bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200 transition-colors"
            >
              Select All
            </button>
          </div>

          {/* Holidays List */}
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <div className="p-3 bg-gray-50 border-b border-gray-200 flex items-center justify-between">
              <h3 className="text-sm font-medium text-gray-900">Available Holidays</h3>
              <span className="text-xs text-gray-600">{selectedHolidays.length} selected</span>
            </div>
            <div className="max-h-60 overflow-y-auto">
              <div className="divide-y divide-gray-200">
                {holidays.map(holiday => (
                  <label
                    key={holiday.id}
                    className="flex items-center p-3 hover:bg-gray-50 cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={holiday.selected}
                      onChange={() => handleHolidayToggle(holiday.id)}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 mr-3"
                    />
                    <div className="flex-1">
                      <div className="flex items-center">
                        <span className="text-sm font-medium text-gray-900">{holiday.name}</span>
                        <span className={`ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                          holiday.type === 'federal' ? 'bg-red-100 text-red-800' :
                          holiday.type === 'religious' ? 'bg-purple-100 text-purple-800' :
                          'bg-amber-100 text-amber-800'
                        }`}>
                          {holiday.type}
                        </span>
                      </div>
                      <div className="text-xs text-gray-500">{formatDate(holiday.date)}</div>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          </div>

          {/* Apply To */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-gray-900">Apply To</h3>
              <label className="inline-flex items-center">
                <input
                  type="checkbox"
                  checked={applyToAllUsers}
                  onChange={(e) => setApplyToAllUsers(e.target.checked)}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="ml-2 text-sm text-gray-700">All Users</span>
              </label>
            </div>
            
            {!applyToAllUsers && (
              <div className="bg-gray-50 p-3 rounded-lg max-h-40 overflow-y-auto">
                {users.map(user => (
                  <label key={user.id} className="flex items-center space-x-2 py-1">
                    <input
                      type="checkbox"
                      checked={selectedUsers.includes(user.id)}
                      onChange={() => handleUserToggle(user.id)}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <span className="text-sm text-gray-700">
                      {user.name} ({user.role})
                    </span>
                  </label>
                ))}
              </div>
            )}
          </div>

          {/* Status Message */}
          {syncStatus === 'success' && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-3 flex items-start">
              <Check className="h-5 w-5 text-green-600 mr-2 flex-shrink-0" />
              <div>
                <p className="text-sm font-medium text-green-800">Holidays synced successfully!</p>
                <p className="text-xs text-green-700 mt-1">
                  {selectedHolidays.length} holidays have been added to the calendar as all-day events.
                </p>
              </div>
            </div>
          )}

          {syncStatus === 'error' && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-start">
              <AlertTriangle className="h-5 w-5 text-red-600 mr-2 flex-shrink-0" />
              <div>
                <p className="text-sm font-medium text-red-800">Failed to sync holidays</p>
                <p className="text-xs text-red-700 mt-1">
                  An error occurred while syncing holidays. Please try again.
                </p>
              </div>
            </div>
          )}

          {/* Info Message */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 flex items-start">
            <Info className="h-5 w-5 text-blue-600 mr-2 flex-shrink-0" />
            <div>
              <p className="text-sm font-medium text-blue-800">About Holiday Sync</p>
              <p className="text-xs text-blue-700 mt-1">
                Synced holidays will appear as all-day events on your calendar. They will be marked as "Time Off" by default.
                Religious holidays are approximate and may vary by denomination.
              </p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end space-x-3 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSyncHolidays}
              disabled={isLoading || selectedHolidays.length === 0}
              className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Syncing...
                </>
              ) : (
                <>
                  <Calendar className="h-4 w-4 mr-2" />
                  Sync Holidays
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};