import React, { useMemo } from 'react';
import { Clock, User, Calendar } from 'lucide-react';
import { formatDate, formatDateTime } from '../../lib/utils';
import type { ScheduleEvent } from '../../types/schedule';
import type { User as UserType, Team } from '../../types';

interface TimelineViewProps {
  events: ScheduleEvent[];
  currentDate: Date;
  onEventClick: (event: ScheduleEvent) => void;
  onTimeSlotClick: (timeSlot: { start: Date; end: Date }) => void;
  onEventUpdate: (eventData: Partial<ScheduleEvent>) => void;
  users: UserType[];
  teams: Team[];
}

export const TimelineView: React.FC<TimelineViewProps> = ({
  events,
  currentDate,
  onEventClick,
  onTimeSlotClick,
  onEventUpdate,
  users,
  teams,
}) => {
  // Generate timeline data (7 days centered around current date)
  const timelineData = useMemo(() => {
    const startDate = new Date(currentDate);
    startDate.setDate(currentDate.getDate() - 3);
    
    const days = Array.from({ length: 7 }, (_, i) => {
      const day = new Date(startDate);
      day.setDate(startDate.getDate() + i);
      return day;
    });
    
    const hours = Array.from({ length: 24 }, (_, i) => i);
    
    // Group events by user
    const userEvents = users.reduce((acc, user) => {
      acc[user.id] = events.filter(event =>
        event.attendees?.some(attendee => attendee.userId === user.id)
      );
      return acc;
    }, {} as Record<string, ScheduleEvent[]>);
    
    return { days, hours, userEvents };
  }, [currentDate, events, users]);

  const getEventPosition = (event: ScheduleEvent, day: Date) => {
    const eventStart = new Date(event.startTime);
    const eventEnd = new Date(event.endTime);
    
    const dayStart = new Date(day);
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(day);
    dayEnd.setHours(23, 59, 59, 999);
    
    // Check if event overlaps with this day
    if (eventEnd <= dayStart || eventStart >= dayEnd) {
      return null;
    }
    
    // Calculate position within the day
    const startHour = Math.max(0, (eventStart.getTime() - dayStart.getTime()) / (1000 * 60 * 60));
    const endHour = Math.min(24, (eventEnd.getTime() - dayStart.getTime()) / (1000 * 60 * 60));
    
    return {
      top: `${(startHour / 24) * 100}%`,
      height: `${((endHour - startHour) / 24) * 100}%`,
    };
  };

  const getUserColor = (userId: string) => {
    const user = users.find(u => u.id === userId);
    if (user?.teamId) {
      const team = teams.find(t => t.id === user.teamId);
      return team?.color || '#3B82F6';
    }
    return '#6B7280';
  };

  const renderEvent = (event: ScheduleEvent, position: { top: string; height: string }) => {
    return (
      <div
        key={event.id}
        className="absolute left-1 right-1 rounded-lg border-l-4 cursor-pointer transition-all duration-200 hover:shadow-md z-10"
        style={{
          top: position.top,
          height: position.height,
          backgroundColor: event.color + '20',
          borderLeftColor: event.color,
          minHeight: '20px',
        }}
        onClick={() => onEventClick(event)}
      >
        <div className="p-1 text-xs">
          <div className="font-medium text-gray-900 truncate">
            {event.title}
          </div>
          <div className="text-gray-600 truncate">
            {formatDateTime(event.startTime).split(' ')[1]} - {formatDateTime(event.endTime).split(' ')[1]}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex-shrink-0 bg-gray-50 border-b border-gray-200">
        <div className="grid grid-cols-8 gap-0">
          <div className="p-3 text-sm font-medium text-gray-500 border-r border-gray-200">
            Team Member
          </div>
          {timelineData.days.map(day => (
            <div key={day.toISOString()} className="p-3 text-center border-r border-gray-200 last:border-r-0">
              <div className="text-sm font-medium text-gray-900">
                {day.toLocaleDateString('en-US', { weekday: 'short' })}
              </div>
              <div className="text-lg font-semibold text-gray-900">
                {day.getDate()}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Timeline Grid */}
      <div className="flex-1 overflow-y-auto">
        <div className="grid grid-cols-8 gap-0">
          {/* User column */}
          <div className="border-r border-gray-200 bg-gray-50">
            {users.map(user => (
              <div
                key={user.id}
                className="h-32 border-b border-gray-200 p-3 flex items-center"
              >
                <div className="flex items-center space-x-3">
                  <div
                    className="w-4 h-4 rounded-full"
                    style={{ backgroundColor: getUserColor(user.id) }}
                  />
                  <div>
                    <div className="text-sm font-medium text-gray-900">
                      {user.name}
                    </div>
                    <div className="text-xs text-gray-500">
                      {user.role}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Day columns */}
          {timelineData.days.map(day => (
            <div key={day.toISOString()} className="border-r border-gray-200 last:border-r-0">
              {users.map(user => {
                const userDayEvents = timelineData.userEvents[user.id]?.filter(event => {
                  const eventStart = new Date(event.startTime);
                  const eventEnd = new Date(event.endTime);
                  const dayStart = new Date(day);
                  dayStart.setHours(0, 0, 0, 0);
                  const dayEnd = new Date(day);
                  dayEnd.setHours(23, 59, 59, 999);
                  
                  return eventStart < dayEnd && eventEnd > dayStart;
                }) || [];

                return (
                  <div
                    key={`${user.id}-${day.toISOString()}`}
                    className="h-32 border-b border-gray-200 relative hover:bg-gray-50 cursor-pointer"
                    onClick={() => {
                      const start = new Date(day);
                      start.setHours(9, 0, 0, 0);
                      const end = new Date(start);
                      end.setHours(10, 0, 0, 0);
                      onTimeSlotClick({ start, end });
                    }}
                  >
                    {/* Time grid lines */}
                    <div className="absolute inset-0 pointer-events-none">
                      {Array.from({ length: 4 }, (_, i) => (
                        <div
                          key={i}
                          className="absolute left-0 right-0 border-t border-gray-100"
                          style={{ top: `${(i + 1) * 25}%` }}
                        />
                      ))}
                    </div>

                    {/* Events */}
                    {userDayEvents.map(event => {
                      const position = getEventPosition(event, day);
                      return position ? renderEvent(event, position) : null;
                    })}

                    {/* Availability indicator */}
                    {userDayEvents.length === 0 && (
                      <div className="absolute inset-0 flex items-center justify-center text-xs text-gray-400">
                        Available
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {/* Legend */}
      <div className="flex-shrink-0 bg-gray-50 border-t border-gray-200 p-3">
        <div className="flex items-center justify-between text-xs text-gray-600">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Clock className="h-3 w-3" />
              <span>Timeline shows 7-day view centered on selected date</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-blue-500 rounded" />
              <span>Scheduled</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-green-500 rounded" />
              <span>Available</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-red-500 rounded" />
              <span>Busy</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};