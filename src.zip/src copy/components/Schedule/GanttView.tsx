import React, { useMemo } from 'react';
import { Calendar, Clock, User, ArrowRight } from 'lucide-react';
import { formatDate, formatDateTime } from '../../lib/utils';
import type { ScheduleEvent } from '../../types/schedule';
import type { User as UserType, Team } from '../../types';

interface GanttViewProps {
  events: ScheduleEvent[];
  currentDate: Date;
  onEventClick: (event: ScheduleEvent) => void;
  onTimeSlotClick: (timeSlot: { start: Date; end: Date }) => void;
  onEventUpdate: (eventData: Partial<ScheduleEvent>) => void;
  users: UserType[];
  teams: Team[];
}

export const GanttView: React.FC<GanttViewProps> = ({
  events,
  currentDate,
  onEventClick,
  onTimeSlotClick,
  onEventUpdate,
  users,
  teams,
}) => {
  // Generate Gantt chart data
  const ganttData = useMemo(() => {
    // Get date range (30 days from current date)
    const startDate = new Date(currentDate);
    startDate.setDate(currentDate.getDate() - 7);
    const endDate = new Date(currentDate);
    endDate.setDate(currentDate.getDate() + 23);
    
    // Generate days array
    const days = [];
    const current = new Date(startDate);
    while (current <= endDate) {
      days.push(new Date(current));
      current.setDate(current.getDate() + 1);
    }
    
    // Filter and sort events by start date
    const filteredEvents = events
      .filter(event => {
        const eventStart = new Date(event.startTime);
        const eventEnd = new Date(event.endTime);
        return eventEnd >= startDate && eventStart <= endDate;
      })
      .sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime());
    
    // Group events by type/project
    const groupedEvents = filteredEvents.reduce((acc, event) => {
      const key = event.jobId || event.type;
      if (!acc[key]) {
        acc[key] = [];
      }
      acc[key].push(event);
      return acc;
    }, {} as Record<string, ScheduleEvent[]>);
    
    return { days, startDate, endDate, groupedEvents, filteredEvents };
  }, [events, currentDate]);

  const getEventPosition = (event: ScheduleEvent) => {
    const eventStart = new Date(event.startTime);
    const eventEnd = new Date(event.endTime);
    const { startDate, endDate } = ganttData;
    
    const totalDays = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    const startOffset = Math.max(0, (eventStart.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    const duration = Math.max(0.1, (eventEnd.getTime() - eventStart.getTime()) / (1000 * 60 * 60 * 24));
    
    return {
      left: `${(startOffset / totalDays) * 100}%`,
      width: `${(duration / totalDays) * 100}%`,
    };
  };

  const getEventColor = (event: ScheduleEvent) => {
    switch (event.type) {
      case 'job':
        return '#3B82F6';
      case 'appointment':
        return '#10B981';
      case 'meeting':
        return '#8B5CF6';
      case 'break':
        return '#6B7280';
      case 'training':
        return '#F59E0B';
      default:
        return '#6B7280';
    }
  };

  const getUserName = (userId: string) => {
    const user = users.find(u => u.id === userId);
    return user ? user.name : 'Unknown User';
  };

  const renderTimelineHeader = () => {
    return (
      <div className="sticky top-0 bg-white border-b border-gray-200 z-10">
        {/* Month/Year header */}
        <div className="h-8 border-b border-gray-100">
          <div className="relative h-full">
            {ganttData.days.reduce((acc, day, index) => {
              if (index === 0 || day.getDate() === 1) {
                const monthWidth = ganttData.days.slice(index).findIndex((d, i) => 
                  i > 0 && d.getDate() === 1
                );
                const width = monthWidth === -1 ? ganttData.days.length - index : monthWidth;
                
                acc.push(
                  <div
                    key={`month-${day.getTime()}`}
                    className="absolute top-0 bottom-0 border-r border-gray-200 flex items-center justify-center text-xs font-medium text-gray-700"
                    style={{
                      left: `${(index / ganttData.days.length) * 100}%`,
                      width: `${(width / ganttData.days.length) * 100}%`,
                    }}
                  >
                    {day.toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
                  </div>
                );
              }
              return acc;
            }, [] as React.ReactNode[])}
          </div>
        </div>
        
        {/* Days header */}
        <div className="h-8 grid gap-0" style={{ gridTemplateColumns: `repeat(${ganttData.days.length}, 1fr)` }}>
          {ganttData.days.map(day => {
            const isToday = day.toDateString() === new Date().toDateString();
            const isWeekend = day.getDay() === 0 || day.getDay() === 6;
            
            return (
              <div
                key={day.toISOString()}
                className={`
                  border-r border-gray-100 last:border-r-0 flex items-center justify-center text-xs
                  ${isToday ? 'bg-blue-100 text-blue-900 font-medium' : ''}
                  ${isWeekend ? 'bg-gray-50 text-gray-500' : 'text-gray-700'}
                `}
              >
                {day.getDate()}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const renderEventBar = (event: ScheduleEvent) => {
    const position = getEventPosition(event);
    const color = event.color || getEventColor(event);
    const attendeeNames = event.attendees?.map(a => getUserName(a.userId)).join(', ') || '';
    
    return (
      <div
        key={event.id}
        className="absolute h-6 rounded-lg cursor-pointer transition-all duration-200 hover:shadow-md z-10"
        style={{
          left: position.left,
          width: position.width,
          backgroundColor: color,
          minWidth: '20px',
        }}
        onClick={() => onEventClick(event)}
        title={`${event.title}\n${formatDateTime(event.startTime)} - ${formatDateTime(event.endTime)}\n${attendeeNames}`}
      >
        <div className="h-full flex items-center px-2 text-white text-xs font-medium truncate">
          {event.title}
        </div>
        
        {/* Progress indicator for jobs */}
        {event.type === 'job' && event.status === 'busy' && (
          <div className="absolute bottom-0 left-0 h-1 bg-white bg-opacity-30 rounded-b-lg" style={{ width: '60%' }} />
        )}
      </div>
    );
  };

  return (
    <div className="h-full flex flex-col">
      {/* Controls */}
      <div className="flex-shrink-0 bg-gray-50 border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Project Timeline</h3>
            <p className="text-sm text-gray-600">
              Showing {ganttData.filteredEvents.length} events from {formatDate(ganttData.startDate)} to {formatDate(ganttData.endDate)}
            </p>
          </div>
          
          <div className="flex items-center space-x-4 text-sm text-gray-600">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-500 rounded" />
              <span>Jobs</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded" />
              <span>Appointments</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-purple-500 rounded" />
              <span>Meetings</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-amber-500 rounded" />
              <span>Training</span>
            </div>
          </div>
        </div>
      </div>

      {/* Gantt Chart */}
      <div className="flex-1 flex overflow-hidden">
        {/* Task list */}
        <div className="w-80 flex-shrink-0 bg-gray-50 border-r border-gray-200 overflow-y-auto">
          <div className="sticky top-0 bg-gray-100 border-b border-gray-200 p-3">
            <h4 className="text-sm font-medium text-gray-900">Tasks & Events</h4>
          </div>
          
          <div className="divide-y divide-gray-200">
            {Object.entries(ganttData.groupedEvents).map(([groupKey, groupEvents]) => (
              <div key={groupKey} className="p-3">
                <div className="flex items-center space-x-2 mb-2">
                  <div
                    className="w-3 h-3 rounded"
                    style={{ backgroundColor: getEventColor(groupEvents[0]) }}
                  />
                  <span className="text-sm font-medium text-gray-900">
                    {groupKey.startsWith('job') ? `Job #${groupKey.slice(-4)}` : groupKey.toUpperCase()}
                  </span>
                  <span className="text-xs text-gray-500">({groupEvents.length})</span>
                </div>
                
                <div className="space-y-1 ml-5">
                  {groupEvents.map(event => (
                    <div key={event.id} className="text-xs text-gray-600">
                      <div className="font-medium">{event.title}</div>
                      <div className="flex items-center space-x-2">
                        <Clock className="h-3 w-3" />
                        <span>{formatDate(event.startTime)}</span>
                        <ArrowRight className="h-3 w-3" />
                        <span>{formatDate(event.endTime)}</span>
                      </div>
                      {event.attendees && event.attendees.length > 0 && (
                        <div className="flex items-center space-x-1 mt-1">
                          <User className="h-3 w-3" />
                          <span>{event.attendees.map(a => getUserName(a.userId)).join(', ')}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Timeline */}
        <div className="flex-1 overflow-auto">
          {renderTimelineHeader()}
          
          <div className="relative">
            {/* Grid lines */}
            <div className="absolute inset-0 pointer-events-none">
              <div className="grid gap-0 h-full" style={{ gridTemplateColumns: `repeat(${ganttData.days.length}, 1fr)` }}>
                {ganttData.days.map((day, index) => {
                  const isToday = day.toDateString() === new Date().toDateString();
                  const isWeekend = day.getDay() === 0 || day.getDay() === 6;
                  
                  return (
                    <div
                      key={index}
                      className={`
                        border-r border-gray-100 last:border-r-0
                        ${isToday ? 'bg-blue-50' : ''}
                        ${isWeekend ? 'bg-gray-50' : ''}
                      `}
                    />
                  );
                })}
              </div>
            </div>

            {/* Event bars */}
            <div className="relative">
              {Object.entries(ganttData.groupedEvents).map(([groupKey, groupEvents], groupIndex) => (
                <div
                  key={groupKey}
                  className="relative border-b border-gray-100"
                  style={{ height: `${Math.max(40, groupEvents.length * 32)}px` }}
                >
                  {groupEvents.map((event, eventIndex) => (
                    <div
                      key={event.id}
                      className="absolute"
                      style={{
                        top: `${eventIndex * 32 + 8}px`,
                        left: 0,
                        right: 0,
                        height: '24px',
                      }}
                    >
                      {renderEventBar(event)}
                    </div>
                  ))}
                </div>
              ))}
            </div>

            {/* Today indicator */}
            <div className="absolute top-0 bottom-0 pointer-events-none">
              {ganttData.days.map((day, index) => {
                const isToday = day.toDateString() === new Date().toDateString();
                if (!isToday) return null;
                
                return (
                  <div
                    key="today-line"
                    className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-20"
                    style={{ left: `${((index + 0.5) / ganttData.days.length) * 100}%` }}
                  />
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};