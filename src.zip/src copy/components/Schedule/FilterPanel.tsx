import React, { useState } from 'react';
import { X, Save, RotateCcw, Filter } from 'lucide-react';
import type { ScheduleFilters, EventType, EventStatus } from '../../types/schedule';
import type { User, Team } from '../../types';

interface FilterPanelProps {
  filters: ScheduleFilters;
  onFiltersChange: (filters: Partial<ScheduleFilters>) => void;
  users: User[];
  teams: Team[];
  onSaveFilter?: (name: string, filters: ScheduleFilters) => void;
  savedFilters?: { name: string; filters: ScheduleFilters }[];
}

const eventTypeOptions: { value: EventType; label: string; color: string }[] = [
  { value: 'appointment', label: 'Appointments', color: '#10B981' },
  { value: 'job', label: 'Jobs/Services', color: '#3B82F6' },
  { value: 'meeting', label: 'Meetings', color: '#8B5CF6' },
  { value: 'break', label: 'Breaks', color: '#6B7280' },
  { value: 'travel', label: 'Travel', color: '#F59E0B' },
  { value: 'training', label: 'Training', color: '#EF4444' },
  { value: 'personal', label: 'Personal', color: '#06B6D4' },
];

const statusOptions: { value: EventStatus; label: string; color: string }[] = [
  { value: 'available', label: 'Available', color: '#10B981' },
  { value: 'busy', label: 'Busy', color: '#EF4444' },
  { value: 'tentative', label: 'Tentative', color: '#F59E0B' },
  { value: 'time_off', label: 'Time Off', color: '#6B7280' },
];

export const FilterPanel: React.FC<FilterPanelProps> = ({
  filters,
  onFiltersChange,
  users,
  teams,
  onSaveFilter,
  savedFilters = [],
}) => {
  const [saveFilterName, setSaveFilterName] = useState('');
  const [showSaveDialog, setShowSaveDialog] = useState(false);

  const handleTeamChange = (teamId: string, checked: boolean) => {
    const newTeamIds = checked
      ? [...filters.teamIds, teamId]
      : filters.teamIds.filter(id => id !== teamId);
    onFiltersChange({ teamIds: newTeamIds });
  };

  const handleUserChange = (userId: string, checked: boolean) => {
    const newUserIds = checked
      ? [...filters.userIds, userId]
      : filters.userIds.filter(id => id !== userId);
    onFiltersChange({ userIds: newUserIds });
  };

  const handleEventTypeChange = (eventType: EventType, checked: boolean) => {
    const newEventTypes = checked
      ? [...filters.eventTypes, eventType]
      : filters.eventTypes.filter(type => type !== eventType);
    onFiltersChange({ eventTypes: newEventTypes });
  };

  const handleStatusChange = (status: EventStatus, checked: boolean) => {
    const newStatuses = checked
      ? [...filters.statuses, status]
      : filters.statuses.filter(s => s !== status);
    onFiltersChange({ statuses: newStatuses });
  };

  const handleDateRangeChange = (field: 'start' | 'end', value: string) => {
    const date = value ? new Date(value) : null;
    onFiltersChange({
      dateRange: {
        ...filters.dateRange,
        [field]: date,
      },
    });
  };

  const clearAllFilters = () => {
    onFiltersChange({
      teamIds: [],
      userIds: [],
      eventTypes: [],
      statuses: [],
      dateRange: { start: null, end: null },
      showRecurringOnly: false,
      showConflictsOnly: false,
    });
  };

  const handleSaveFilter = () => {
    if (saveFilterName.trim() && onSaveFilter) {
      onSaveFilter(saveFilterName.trim(), filters);
      setSaveFilterName('');
      setShowSaveDialog(false);
    }
  };

  const hasActiveFilters = 
    filters.teamIds.length > 0 ||
    filters.userIds.length > 0 ||
    filters.eventTypes.length > 0 ||
    filters.statuses.length > 0 ||
    filters.dateRange.start ||
    filters.dateRange.end ||
    filters.showRecurringOnly ||
    filters.showConflictsOnly;

  return (
    <div className="space-y-6">
      {/* Filter Actions */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Filter className="h-4 w-4 text-gray-500" />
          <span className="text-sm font-medium text-gray-900">Filters</span>
          {hasActiveFilters && (
            <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">
              Active
            </span>
          )}
        </div>
        
        <div className="flex items-center space-x-2">
          {hasActiveFilters && (
            <button
              onClick={clearAllFilters}
              className="flex items-center px-3 py-1 text-xs text-gray-600 hover:text-gray-800 transition-colors"
            >
              <RotateCcw className="h-3 w-3 mr-1" />
              Clear All
            </button>
          )}
          
          {onSaveFilter && hasActiveFilters && (
            <button
              onClick={() => setShowSaveDialog(true)}
              className="flex items-center px-3 py-1 text-xs text-blue-600 hover:text-blue-800 transition-colors"
            >
              <Save className="h-3 w-3 mr-1" />
              Save Filter
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Teams Filter */}
        <div>
          <h4 className="text-sm font-medium text-gray-900 mb-3">Teams</h4>
          <div className="space-y-2">
            {teams.map(team => (
              <label key={team.id} className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={filters.teamIds.includes(team.id)}
                  onChange={(e) => handleTeamChange(team.id, e.target.checked)}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <div className="flex items-center space-x-2">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: team.color }}
                  />
                  <span className="text-sm text-gray-700">{team.name}</span>
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* Users Filter */}
        <div>
          <h4 className="text-sm font-medium text-gray-900 mb-3">Team Members</h4>
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {users.map(user => (
              <label key={user.id} className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={filters.userIds.includes(user.id)}
                  onChange={(e) => handleUserChange(user.id, e.target.checked)}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 bg-gray-300 rounded-full flex items-center justify-center text-white text-xs font-medium">
                    {user.name.charAt(0)}
                  </div>
                  <span className="text-sm text-gray-700">{user.name}</span>
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* Event Types Filter */}
        <div>
          <h4 className="text-sm font-medium text-gray-900 mb-3">Event Types</h4>
          <div className="space-y-2">
            {eventTypeOptions.map(option => (
              <label key={option.value} className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={filters.eventTypes.includes(option.value)}
                  onChange={(e) => handleEventTypeChange(option.value, e.target.checked)}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <div className="flex items-center space-x-2">
                  <div
                    className="w-3 h-3 rounded"
                    style={{ backgroundColor: option.color }}
                  />
                  <span className="text-sm text-gray-700">{option.label}</span>
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* Status Filter */}
        <div>
          <h4 className="text-sm font-medium text-gray-900 mb-3">Status</h4>
          <div className="space-y-2">
            {statusOptions.map(option => (
              <label key={option.value} className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={filters.statuses.includes(option.value)}
                  onChange={(e) => handleStatusChange(option.value, e.target.checked)}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <div className="flex items-center space-x-2">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: option.color }}
                  />
                  <span className="text-sm text-gray-700">{option.label}</span>
                </div>
              </label>
            ))}
          </div>
        </div>
      </div>

      {/* Date Range Filter */}
      <div>
        <h4 className="text-sm font-medium text-gray-900 mb-3">Date Range</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-gray-700 mb-1">From</label>
            <input
              type="date"
              value={filters.dateRange.start?.toISOString().split('T')[0] || ''}
              onChange={(e) => handleDateRangeChange('start', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-700 mb-1">To</label>
            <input
              type="date"
              value={filters.dateRange.end?.toISOString().split('T')[0] || ''}
              onChange={(e) => handleDateRangeChange('end', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      {/* Additional Options */}
      <div>
        <h4 className="text-sm font-medium text-gray-900 mb-3">Additional Options</h4>
        <div className="space-y-2">
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={filters.showRecurringOnly}
              onChange={(e) => onFiltersChange({ showRecurringOnly: e.target.checked })}
              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span className="text-sm text-gray-700">Show recurring events only</span>
          </label>
          
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={filters.showConflictsOnly}
              onChange={(e) => onFiltersChange({ showConflictsOnly: e.target.checked })}
              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span className="text-sm text-gray-700">Show conflicts only</span>
          </label>
        </div>
      </div>

      {/* Saved Filters */}
      {savedFilters.length > 0 && (
        <div>
          <h4 className="text-sm font-medium text-gray-900 mb-3">Saved Filters</h4>
          <div className="flex flex-wrap gap-2">
            {savedFilters.map((savedFilter, index) => (
              <button
                key={index}
                onClick={() => onFiltersChange(savedFilter.filters)}
                className="px-3 py-1 text-sm bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
              >
                {savedFilter.name}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Save Filter Dialog */}
      {showSaveDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Save Filter</h3>
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Filter Name
                </label>
                <input
                  type="text"
                  value={saveFilterName}
                  onChange={(e) => setSaveFilterName(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter filter name"
                  autoFocus
                />
              </div>

              <div className="flex items-center justify-end space-x-3">
                <button
                  onClick={() => setShowSaveDialog(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveFilter}
                  disabled={!saveFilterName.trim()}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Save Filter
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};