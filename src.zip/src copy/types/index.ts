export interface User {
  id: string;
  name: string;
  email: string;
  role: 'ADMIN' | 'SALES' | 'OPERATIONS' | 'TECHNICIAN' | 'CUSTOMER';
  phone?: string;
  teamId?: string;
  team?: Team;
  locationId?: string;
  location?: Location;
  createdAt: string;
  updatedAt: string;
}

export interface AdditionalContact {
  name: string;
  phone?: string;
  email?: string;
  role?: string;
}

export interface Team {
  id: string;
  name: string;
  description?: string;
  color: string;
  leaderId: string;
  leader?: User;
  members?: User[];
  locationId?: string;
  location?: Location;
  createdAt: string;
  updatedAt: string;
}

export interface Location {
  id: string;
  name: string;
  address?: string;
  phone?: string;
  email?: string;
  createdAt: string;
  updatedAt: string;
  teams?: Team[];
}

export interface Customer {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  address?: string;
  billingAddress?: string;
  notes?: string;
  additionalContacts?: AdditionalContact[];
  leadSource?: string;
  leadCost?: number;
  leadCampaign?: string;
  leadNotes?: string;
  referredBy?: string;
  locationId?: string;
  location?: Location;
  createdAt: string;
  updatedAt: string;
  // Related entities
  leads?: Lead[];
  jobs?: Job[];
  tasks?: Task[];
  messages?: Message[];
  files?: FileUpload[];
  estimates?: Estimate[];
  invoices?: Invoice[];
}

export interface GeneralContact {
  id: string;
  name: string;
  businessName?: string;
  phone?: string;
  email?: string;
  notes?: string;
  locationId?: string;
  location?: Location;
  createdAt: string;
  updatedAt: string;
  labels?: ContactLabel[];
  messages?: Message[];
}

export interface ContactLabel {
  id: string;
  name: string;
  color: string;
  contacts?: GeneralContact[];
}

export interface Lead {
  id: string;
  customerId: string;
  customer?: Customer;
  source: 'CALLRAIL' | 'FORM' | 'REFERRAL' | 'DIRECT';
  status: 'NEW' | 'CONTACTED' | 'QUALIFIED' | 'ESTIMATE_SENT' | 'CONVERTED' | 'LOST';
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
  tags?: string[];
  assignedTo?: string;
  assignedUser?: User;
  locationId?: string;
  location?: Location;
  notes?: string;
  leadScore?: number;
  createdAt: string;
  updatedAt: string;
  jobs?: Job[];
  tasks?: Task[];
}

export interface Job {
  id: string;
  customerId: string;
  customer?: Customer;
  leadId?: string;
  lead?: Lead;
  assignedTo?: string;
  assignedUser?: User;
  jobAddress: string; // Changed from 'location' to 'jobAddress'
  status: 'SCHEDULED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
  startDate?: string;
  endDate?: string;
  materials?: string;
  notes?: string;
  projectType?: string;
  permitRequired?: boolean;
  subStatus?: string;
  tags?: string[];
  progress?: number;
  estimatedValue?: number;
  daysInStage?: number;
  locationId?: string;
  location?: Location;
  createdAt: string;
  updatedAt: string;
  estimates?: Estimate[];
  tasks?: Task[];
  files?: FileUpload[];
}

export interface Estimate {
  id: string;
  customerId: string;
  customer?: Customer;
  jobId?: string;
  job?: Job;
  total: number;
  lineItems: EstimateLineItem[];
  pdfUrl?: string;
  signedAt?: string;
  accepted: boolean;
  expirationDate?: string;
  notes?: string;
  terms?: string;
  sketchData?: any;
  locationId?: string;
  location?: Location;
  createdAt: string;
  updatedAt: string;
  invoices?: Invoice[];
}

export interface EstimateLineItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface Invoice {
  id: string;
  customerId: string;
  customer?: Customer;
  estimateId?: string;
  estimate?: Estimate;
  status: 'PAID' | 'UNPAID' | 'OVERDUE' | 'CANCELLED';
  dueDate: string;
  amount: number;
  stripePaymentUrl?: string;
  locationId?: string;
  location?: Location;
  createdAt: string;
  updatedAt: string;
  payments?: Payment[];
}

export interface Payment {
  id: string;
  invoiceId: string;
  invoice?: Invoice;
  method: 'STRIPE' | 'CASH' | 'CHECK' | 'BANK_TRANSFER';
  status: 'PENDING' | 'COMPLETED' | 'FAILED' | 'REFUNDED';
  transactionId?: string;
  amount: number;
  createdAt: string;
  updatedAt: string;
}

export interface Task {
  id: string;
  customerId?: string;
  customer?: Customer;
  jobId?: string;
  job?: Job;
  description: string;
  dueDate: string;
  assignedTo: string;
  assignedUser?: User;
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
  type?: 'TASK' | 'REMINDER';
  priority?: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
  notes?: string;
  locationId?: string;
  location?: Location;
  createdAt: string;
  updatedAt: string;
}

export interface Message {
  id: string;
  customerId?: string;
  customer?: Customer;
  userId?: string;
  user?: User;
  type: 'SMS' | 'EMAIL';
  content: string;
  direction: 'INBOUND' | 'OUTBOUND';
  timestamp: string;
  // For unknown contacts
  fromPhone?: string;
  fromEmail?: string;
  fromName?: string;
  unknownContactId?: string;
  unknownContact?: UnknownContact;
  // For general contacts
  generalContactId?: string;
  generalContact?: GeneralContact;
}

export interface UnknownContact {
  id: string;
  phone?: string;
  email?: string;
  name?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  messages?: Message[];
}

export interface FileUpload {
  id: string;
  jobId?: string;
  job?: Job;
  customerId?: string;
  customer?: Customer;
  url: string;
  type: 'PHOTO' | 'VIDEO' | 'AUDIO' | 'PDF' | 'DOCUMENT' | 'SKETCH';
  uploadedBy: string;
  uploader?: User;
  fileName: string;
  fileSize: number;
  mimeType: string;
  thumbnailUrl?: string;
  metadata?: any;
  createdAt: string;
}

export interface ScheduleSlot {
  id: string;
  userId: string;
  user?: User;
  jobId?: string;
  job?: Job;
  startTime: string;
  endTime: string;
  createdAt: string;
}

export interface DashboardStats {
  totalCustomers: number;
  totalLeads: number;
  activeJobs: number;
  pendingEstimates: number;
  monthlyRevenue: number;
}

export interface PipelineStage {
  status: string;
  count: number;
  value: number;
}

export interface ActivityItem {
  id: string;
  type: 'customer' | 'lead' | 'job' | 'estimate' | 'task';
  title: string;
  description: string;
  time: string;
  user: string;
  customerId?: string;
  customerName?: string;
}