export interface SalesMetrics {
  // Primary KPIs
  averageRevenuePerLead: number;
  leadConversionRate: number;
  averageProjectValue: number;
  totalLeadVolume: number;
  
  // Additional metrics
  totalRevenue: number;
  leadsGenerated: number;
  leadsConverted: number;
  projectsWon: number;
  projectsLost: number;
  averageSalesCycle: number; // days
  
  // Comparison data
  previousPeriodComparison: {
    averageRevenuePerLead: ComparisonData;
    leadConversionRate: ComparisonData;
    averageProjectValue: ComparisonData;
    totalLeadVolume: ComparisonData;
    totalRevenue: ComparisonData;
  };
  
  // Year over year comparison
  yearOverYearComparison: {
    averageRevenuePerLead: ComparisonData;
    leadConversionRate: ComparisonData;
    averageProjectValue: ComparisonData;
    totalLeadVolume: ComparisonData;
    totalRevenue: ComparisonData;
  };
  
  // Breakdown by source
  leadsBySource: {
    source: string;
    count: number;
    conversionRate: number;
    revenue: number;
  }[];
  
  // Monthly trend data
  monthlyTrends: {
    month: string;
    leads: number;
    conversions: number;
    revenue: number;
    averageProjectValue: number;
  }[];
  
  // Performance vs targets
  targets: {
    revenue: { target: number; actual: number; percentage: number };
    leads: { target: number; actual: number; percentage: number };
    conversions: { target: number; actual: number; percentage: number };
  };
}

export interface ComparisonData {
  current: number;
  previous: number;
  change: number;
  changePercentage: number;
  trend: 'up' | 'down' | 'neutral';
}

export interface TeamMetrics extends SalesMetrics {
  teamId?: string;
  teamName?: string;
  memberCount: number;
  topPerformers: {
    userId: string;
    userName: string;
    metric: string;
    value: number;
  }[];
  teamRankings: {
    userId: string;
    userName: string;
    revenue: number;
    leads: number;
    conversions: number;
    conversionRate: number;
    rank: number;
  }[];
}

export interface HistoricalData {
  daily: {
    date: string;
    leads: number;
    conversions: number;
    revenue: number;
  }[];
  weekly: {
    week: string;
    leads: number;
    conversions: number;
    revenue: number;
  }[];
  monthly: {
    month: string;
    leads: number;
    conversions: number;
    revenue: number;
  }[];
  quarterly: {
    quarter: string;
    leads: number;
    conversions: number;
    revenue: number;
  }[];
  yearly: {
    year: string;
    leads: number;
    conversions: number;
    revenue: number;
  }[];
}

export interface SalesTarget {
  id: string;
  userId?: string;
  teamId?: string;
  type: 'revenue' | 'leads' | 'conversions' | 'projects';
  period: 'monthly' | 'quarterly' | 'yearly';
  target: number;
  actual: number;
  percentage: number;
  startDate: string;
  endDate: string;
  createdAt: string;
  updatedAt: string;
}

export type TimePeriod = 
  | 'last30days' 
  | 'last90days' 
  | 'thisMonth' 
  | 'lastMonth' 
  | 'thisQuarter' 
  | 'lastQuarter' 
  | 'thisYear' 
  | 'lastYear';

export type ViewMode = 'individual' | 'team' | 'historical';

export interface SalesActivity {
  id: string;
  userId: string;
  type: 'lead_created' | 'lead_converted' | 'estimate_sent' | 'project_won' | 'project_lost';
  description: string;
  value?: number;
  leadId?: string;
  customerId?: string;
  timestamp: string;
}

export interface SalesGoal {
  id: string;
  userId: string;
  title: string;
  description: string;
  targetValue: number;
  currentValue: number;
  unit: 'currency' | 'count' | 'percentage';
  deadline: string;
  status: 'active' | 'completed' | 'overdue';
  createdAt: string;
  updatedAt: string;
}