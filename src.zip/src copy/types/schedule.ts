export type ViewType = 'day' | 'week' | 'month' | 'timeline' | 'gantt';

export type EventStatus = 'available' | 'busy' | 'tentative' | 'time_off';

export type EventType = 'appointment' | 'job' | 'meeting' | 'break' | 'travel' | 'training' | 'personal';

export interface RecurrencePattern {
  type: 'daily' | 'weekly' | 'monthly' | 'yearly' | 'custom';
  interval: number; // Every X days/weeks/months
  daysOfWeek?: number[]; // 0-6 (Sunday-Saturday)
  dayOfMonth?: number; // 1-31
  weekOfMonth?: number; // 1-4, -1 (last)
  monthOfYear?: number; // 1-12
  endDate?: string;
  occurrences?: number;
}

export interface EventAttendee {
  userId: string;
  status: 'pending' | 'accepted' | 'declined' | 'tentative';
  isRequired: boolean;
  role?: 'organizer' | 'attendee' | 'resource';
}

export interface ScheduleEvent {
  id: string;
  title: string;
  description?: string;
  startTime: string;
  endTime: string;
  allDay: boolean;
  location?: string;
  type: EventType;
  status: EventStatus;
  color?: string;
  
  // Attendees
  attendees?: EventAttendee[];
  
  // Recurrence
  isRecurring: boolean;
  recurrencePattern?: RecurrencePattern;
  parentEventId?: string; // For recurring event instances
  
  // Google Calendar Integration
  googleEventId?: string;
  googleCalendarId?: string;
  lastSyncTime?: string;
  
  // Job/Customer Integration
  jobId?: string;
  customerId?: string;
  leadId?: string;
  taskId?: string;
  
  // Metadata
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  
  // Conflict detection
  hasConflicts?: boolean;
  conflictingEvents?: string[];
}

export interface ScheduleFilters {
  teamIds: string[];
  userIds: string[];
  eventTypes: EventType[];
  statuses: EventStatus[];
  dateRange: {
    start: Date | null;
    end: Date | null;
  };
  showRecurringOnly: boolean;
  showConflictsOnly: boolean;
}

export interface TimeSlot {
  start: Date;
  end: Date;
  isAvailable: boolean;
  conflicts?: ScheduleEvent[];
}

export interface HolidaySyncSettings {
  enabled: boolean;
  lastSynced: string | null;
  includeFederal: boolean;
  includeReligious: boolean;
  includeObservances: boolean;
}

export interface CalendarSettings {
  workingHours: {
    start: string; // "09:00"
    end: string; // "17:00"
  };
  workingDays: number[]; // 0-6 (Sunday-Saturday)
  timeZone: string;
  defaultEventDuration: number; // minutes
  allowOverlapping: boolean;
  autoSyncInterval: number; // minutes
  defaultView: ViewType;
  holidaySync?: HolidaySyncSettings;
}

export interface GoogleCalendarConfig {
  isConnected: boolean;
  accessToken?: string;
  refreshToken?: string;
  calendarId?: string;
  lastSyncTime?: string;
  syncEnabled: boolean;
  conflictResolution: 'google_wins' | 'local_wins' | 'manual';
}