export type TimePeriod = 
  | 'last7days' 
  | 'last30days' 
  | 'last90days' 
  | 'thisMonth' 
  | 'lastMonth' 
  | 'thisQuarter' 
  | 'lastQuarter' 
  | 'thisYear' 
  | 'lastYear';

export type DashboardView = 'overview' | 'sales' | 'operations' | 'marketing' | 'finance';

export interface MetricComparison {
  current: number;
  previous: number;
  change: number;
  changePercentage: number;
  trend: 'up' | 'down' | 'neutral';
}

export interface MetricWithComparison {
  value: number;
  comparison: MetricComparison;
  target?: number;
  targetPercentage?: number;
}

// Overview Dashboard Types
export interface OverviewPerformanceData {
  companyMetrics: {
    totalRevenue: MetricWithComparison;
    totalCustomers: MetricWithComparison;
    employeeCount: MetricWithComparison;
    operatingMargin: MetricWithComparison;
  };
  departmentSummary: {
    sales: {
      revenue: number;
      target: number;
      performance: number;
    };
    operations: {
      efficiency: number;
      target: number;
      performance: number;
    };
    marketing: {
      leads: number;
      target: number;
      performance: number;
    };
    finance: {
      margin: number;
      target: number;
      performance: number;
    };
  };
  trends: {
    month: string;
    revenue: number;
    customers: number;
    efficiency: number;
  }[];
}

// Sales Dashboard Types
export interface SalesPerformanceData {
  revenue: {
    total: MetricWithComparison;
    recurring: MetricWithComparison;
    newBusiness: MetricWithComparison;
    averageDealSize: MetricWithComparison;
  };
  pipeline: {
    totalValue: MetricWithComparison;
    qualifiedLeads: MetricWithComparison;
    conversionRate: MetricWithComparison;
    averageCycleTime: MetricWithComparison;
  };
  team: {
    topPerformers: {
      name: string;
      revenue: number;
      deals: number;
      performance: number;
    }[];
    quotaAttainment: {
      name: string;
      quota: number;
      achieved: number;
      percentage: number;
    }[];
  };
  customerAcquisition: {
    cost: MetricWithComparison;
    lifetime: MetricWithComparison;
    churnRate: MetricWithComparison;
  };
}

// Operations Dashboard Types
export interface OperationsPerformanceData {
  productivity: {
    overallEfficiency: MetricWithComparison;
    jobsCompleted: MetricWithComparison;
    averageJobTime: MetricWithComparison;
    utilizationRate: MetricWithComparison;
  };
  quality: {
    customerSatisfaction: MetricWithComparison;
    defectRate: MetricWithComparison;
    reworkRate: MetricWithComparison;
    firstTimeRight: MetricWithComparison;
  };
  resources: {
    teamUtilization: {
      teamName: string;
      utilization: number;
      capacity: number;
      efficiency: number;
    }[];
    equipmentUptime: MetricWithComparison;
    materialWaste: MetricWithComparison;
  };
  timeline: {
    onTimeDelivery: MetricWithComparison;
    averageDelay: MetricWithComparison;
    scheduleAdherence: MetricWithComparison;
  };
}

// Marketing Dashboard Types
export interface MarketingPerformanceData {
  campaigns: {
    active: number;
    totalSpend: MetricWithComparison;
    averageROI: MetricWithComparison;
    topPerforming: {
      name: string;
      spend: number;
      leads: number;
      roi: number;
    }[];
  };
  leadGeneration: {
    totalLeads: MetricWithComparison;
    qualifiedLeads: MetricWithComparison;
    costPerLead: MetricWithComparison;
    leadsByChannel: {
      channel: string;
      leads: number;
      cost: number;
      quality: number;
    }[];
  };
  engagement: {
    websiteTraffic: MetricWithComparison;
    conversionRate: MetricWithComparison;
    emailOpenRate: MetricWithComparison;
    socialEngagement: MetricWithComparison;
  };
  brand: {
    awareness: MetricWithComparison;
    sentiment: MetricWithComparison;
    shareOfVoice: MetricWithComparison;
  };
}

// Finance Dashboard Types
export interface FinancePerformanceData {
  profitLoss: {
    revenue: MetricWithComparison;
    grossProfit: MetricWithComparison;
    operatingIncome: MetricWithComparison;
    netIncome: MetricWithComparison;
  };
  cashFlow: {
    operating: MetricWithComparison;
    investing: MetricWithComparison;
    financing: MetricWithComparison;
    freeCashFlow: MetricWithComparison;
  };
  budgetAnalysis: {
    totalBudget: number;
    actualSpend: number;
    variance: number;
    departmentBreakdown: {
      department: string;
      budget: number;
      actual: number;
      variance: number;
      variancePercentage: number;
    }[];
  };
  forecasts: {
    quarterlyRevenue: {
      quarter: string;
      forecast: number;
      actual?: number;
      confidence: number;
    }[];
    expenses: {
      category: string;
      current: number;
      projected: number;
      trend: 'up' | 'down' | 'stable';
    }[];
  };
  kpis: {
    grossMargin: MetricWithComparison;
    operatingMargin: MetricWithComparison;
    currentRatio: MetricWithComparison;
    debtToEquity: MetricWithComparison;
  };
}

export interface ExportOptions {
  format: 'pdf' | 'excel' | 'csv';
  includeCharts: boolean;
  dateRange: {
    start: string;
    end: string;
  };
  sections: string[];
}